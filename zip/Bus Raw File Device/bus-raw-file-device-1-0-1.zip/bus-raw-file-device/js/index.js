var not_config = "",
  dialogConfig = {},
  reg = /^[a-zA-Z]:/;
$('.container').on("change", "[name]", function () {
  changeVal(this);
});
$('button').click(function () {
  var name = $(this).attr("language");
  switch (name) {
    case "add": {
      biSelectPath("context_list", BISelectPathType.OpenFile, {
        ".asc": "asc",
        ".blf": "blf"
      });
      break;
    }
    case "clear": {
      dialogConfig["context_list"] = [];
      $(".content").empty();
      setConfig();
      break;
    }
  }
})

function getConfig() {
  var text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><config ";
  for (var i in dialogConfig) {
    if (i == "context_list") {
      text += i + "=\"" + dialogConfig[i].join("|") + "\" ";
    } else {
      text += i + "=\"" + dialogConfig[i] + "\" ";
    }
  }
  text += "/></root>";
  return text;
}

function setConfig() {
  biSetModuleConfig("bus-raw-file-device.aspluginbusrawfile", getConfig());
}

function biOnInitEx(config, moduleConfigs) {
  if (biGetLanguage() == 1) {
    $('[language]').each(function () {
      var value = $(this).attr('language');
      $(this).text(en[value]);
    });
    not_config = "<Not Configured>";
  } else {
    $('[language]').each(function () {
      var value = $(this).attr('language');
      $(this).text(cn[value]);
    });
    not_config = "<未配置>";
  }
  for (var key in moduleConfigs) {
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    var root = xmlDoc.getElementsByTagName('root');
    var keys = root[0].childNodes[0].attributes;
    dialogConfig["context_list"] = Boolean(keys[0].value) ? keys[0].value.split("|") : [];
    loadConfig();
  }
}

function loadConfig() {
  if (dialogConfig["context_list"].length > 0) {
    for (var i in dialogConfig["context_list"]) {
      var val = dialogConfig["context_list"][i].split(",");
      $(".content").append("<div class=\"box fixclear\"><a href=\"javascript:;\" class=\"left\">" + val[0] + "</a><img src=\"bus-raw-file-device/img/del.png\" class=\"right\" onclick=\"remove(this)\" alt=\"delete\"></div>");
      biQueryFileExist(val[0]);
    }
  }
}

function remove(obj) {
  var i = $(obj).parents(".box").index();
  dialogConfig["context_list"].splice(i, 1);
  $(obj).parents(".box").remove();
  setConfig();
}

function changeVal(obj) {
  if ($(obj).is("select")) {
    var i = $(obj).parents(".box").index();
    var val = dialogConfig["context_list"][i];
    dialogConfig["context_list"][i] = val.substr(0, val.indexOf(",") + 1) + $(obj).val()
  }
  setConfig();
}

function biOnSelectedPath(key, path) {
  if (key == "context_list") {
    if (!Boolean(path)) return;
    var count = 0;
    for (var i of dialogConfig["context_list"]) {
      var val = i.substr(0, i.indexOf(","));
      if (path == val) {
        count++;
        return;
      };
    }
    if (count == 0) {
      dialogConfig["context_list"].push(path + ",0");
      $(".content").append("<div class=\"box fixclear\"><a href=\"javascript:;\" class=\"left\">" + path + "</a><img src=\"bus-raw-file-device/img/del.png\" class=\"right\" onclick=\"remove(this)\" alt=\"delete\"></div>");
    }
  }
  setConfig();
}

function biOnQueriedFileExist(exist, path) {
  if (!exist) {
    $(".content a").each(function () {
      if ($(this).text() == path) {
        $(this).addClass("red");
        return;
      };
    })
  }
}