var cn = {
  bus_path: "总线原始文件路径",
  add: "添加",
  clear: "清空"
},
  en = {
    bus_path: "Bus Raw File Path",
    add: "Add",
    clear: "Clear"
  };