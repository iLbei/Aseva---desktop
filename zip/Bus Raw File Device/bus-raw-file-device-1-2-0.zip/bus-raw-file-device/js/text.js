var cn = {
    bus_path: "总线原始文件路径",
    add: "添加",
    clear: "清空",
    load_speed: "读取倍率:",
    time_ratio: "时间比例:",
    not_config:"<未配置>",
    bus_files_path:"总线文件路径:"
  },
  en = {
    bus_path: "Bus Raw File Path",
    add: "Add",
    clear: "Clear",
    load_speed: "Load speed:",
    time_ratio: "Time ratio:",
    not_config:"<Not configured>",
    bus_files_path:"Bus files path:"
  };