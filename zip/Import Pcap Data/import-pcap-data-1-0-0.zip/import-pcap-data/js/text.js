var cn = {
  pcap_path: "PCAP路径",
  pcap_channel: "PCAP通道:",
  add: "添加",
  clear: "清空",
  output: "输出",
  output_data_path: "数据输出路径:",
  convert: "转换"
},
  en = {
    pcap_path: "Pcap Path",
    pcap_channel: "Pcap Channel:",
    add: "Add",
    clear: "Clear",
    output: "Output",
    output_data_path: "Output Data Path:",
    convert: "Convert"
  };