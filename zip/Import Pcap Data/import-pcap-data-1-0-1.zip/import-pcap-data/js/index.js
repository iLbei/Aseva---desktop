var not_config = "", dialogConfig = {}, reg = /^[a-zA-Z]:/;
$('.container').on("change", "[name]", function () {
  changeVal(this);
});
$("a[name=output_data_path]").click(function () {
  biSelectPath("output_data_path", BISelectPathType.Directory, null);
})
$('button').click(function () {
  var name = $(this).attr("language");
  switch (name) {
    case "add": {
      biSelectPath("context_list", BISelectPathType.OpenFile, { ".pcap": "pcap" });
      break;
    }
    case "clear": {
      dialogConfig["context_list"] = [];
      $(".content").empty();
      setConfig();
      break;
    }
    case "convert": {
      if ($("[name=output_data_path]").val().indexOf(not_config) == -1) {
        biRunStandaloneTask("Import Pcap Data", "import-pcap-data-task.aspluginpcap", getConfig())
      }
      break;
    }
  }


})
function getConfig() {
  var text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><config ";
  for (var i in dialogConfig) {
    if (i == "context_list") {
      text += i + "=\"" + dialogConfig[i].join("|") + "\" ";
    } else {
      text += i + "=\"" + dialogConfig[i] + "\" ";
    }
  }
  text += "/></root>";
  return text;
}
function setConfig() {
  biSetModuleConfig("import-pcap-data.aspluginpcap", getConfig());
}
function biOnInitEx(config, moduleConfigs) {
  if (biGetLanguage() == 1) {
    $('[language]').each(function () {
      var value = $(this).attr('language');
      $(this).text(en[value]);
    });
    not_config = "<Not Configured>";
    pcap_channel = en["pcap_channel"];
  } else {
    $('[language]').each(function () {
      var value = $(this).attr('language');
      $(this).text(cn[value]);
      not_config = "<未配置>";
      pcap_channel = cn["pcap_channel"];
    });
  }
  for (var key in moduleConfigs) {
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    var root = xmlDoc.getElementsByTagName('root');
    var keys = root[0].childNodes[0].attributes;
    dialogConfig["context_list"] = Boolean(keys[0].value) ? keys[0].value.split("|") : [];
    dialogConfig["output_data_path"] = keys[1].value;
    loadConfig();
  }
}
function loadConfig() {
  if (["", "null"].includes(dialogConfig["output_data_path"])) {
    $("[name=output_data_path]").text(not_config);
  } else {
    $("[name=output_data_path]").text(dialogConfig["output_data_path"]).attr("title", dialogConfig["output_data_path"]);
    biQueryDirectoryExist(dialogConfig["output_data_path"]);
  }
  if (dialogConfig["context_list"].length > 0) {
    for (var i in dialogConfig["context_list"]) {
      var val = dialogConfig["context_list"][i].split(",");
      $(".content").append("<div class=\"box\"><ul><li class=\"fixclear\"><a href=\"javascript:;\" class=\"left\">" + val[0] + "</a><img src=\"import-pcap-data/img/del.png\" class=\"right\" onclick=\"remove(this)\" alt=\"delete\"></li><li><span>" + pcap_channel + "</span><select name=\"\" id=\"\"><option value=\"-1\">(Disabled)</option><option value=\"1\">CH1</option><option value=\"2\">CH2</option><option value=\"3\">CH3</option><option value=\"4\">CH4</option><option value=\"5\">CH5</option><option value=\"6\">CH6</option><option value=\"7\">CH7</option><option value=\"8\">CH8</option><option value=\"9\">CH9</option><option value=\"10\">CH10</option><option value=\"11\">CH11</option><option value=\"12\">CH12</option><option value=\"13\">CH13</option><option value=\"14\">CH14</option><option value=\"15\">CH15</option><option value=\"16\">CH16</option></select></li></ul></div>");
      $(".content>.box").eq(i).find("select").val(Number(Boolean(val[1]) ? val[1] : -1));
      biQueryFileExist(val[0]);
    }
  }
}
function remove(obj) {
  var i = $(obj).parents(".box").index();
  dialogConfig["context_list"].splice(i, 1);
  $(obj).parents(".box").remove();
  setConfig();
}
function changeVal(obj) {
  if ($(obj).is("select")) {
    var i = $(obj).parents(".box").index();
    var val = dialogConfig["context_list"][i];
    dialogConfig["context_list"][i] = val.substr(0, val.indexOf(",") + 1) + $(obj).val()
  }
  setConfig();
}
function biOnSelectedPath(key, path) {
  if (key == "output_data_path") {
    if (!Boolean(path)) {
      $('[name=' + key + ']').removeAttr('title').text(not_config).removeClass("red");
      dialogConfig["output_data_path"] = path;
    } else {
      var text = path + (reg.test(path) ? '\\' : '\/');
      $('[name=' + key + ']').attr('title', text).text(text).removeClass("red");
      dialogConfig["output_data_path"] = text;
    };
  } else if (key == "context_list") {
    if (!Boolean(path)) return;
    var count = 0;
    for (var i of dialogConfig["context_list"]) {
      var val = i.substr(0, i.indexOf(","));
      if (path == val) {
        count++;
        return;
      };
    }
    if (count == 0) {
      dialogConfig["context_list"].push(path + ",-1");
      $(".content").append("<div class=\"box\"><ul><li class=\"fixclear\"><a href=\"javascript:;\" class=\"left\">" + path + "</a><img src=\"import-pcap-data/img/del.png\" class=\"right\" onclick=\"remove(this)\" alt=\"delete\"></li><li><span>" + pcap_channel + "</span><select name=\"\" id=\"\"><option value=\"-1\">(Disabled)</option><option value=\"1\">CH1</option><option value=\"2\">CH2</option><option value=\"3\">CH3</option><option value=\"4\">CH4</option><option value=\"5\">CH5</option><option value=\"6\">CH6</option><option value=\"8\">CH7</option><option value=\"9\">CH8</option><option value=\"9\">CH9</option><option value=\"10\">CH10</option><option value=\"11\">CH11</option><option value=\"12\">CH12</option><option value=\"13\">CH13</option><option value=\"14\">CH14</option><option value=\"15\">CH15</option><option value=\"16\">CH16</option></select></li></ul></div>");
    }
  }
  setConfig();
}
function biOnQueriedFileExist(exist, path) {
  if (!exist) {
    $(".content a").each(function () {
      if ($(this).text() == path) {
        $(this).addClass("red");
        return;
      };
    })
  }
}
function biOnQueriedDirectoryExist(exist, path) {
  if (!exist) $("[name=output_data_path]").addClass("red");
}