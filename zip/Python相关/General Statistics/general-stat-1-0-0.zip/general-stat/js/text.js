var cn = {
  enabled:"启用",
  turn_curvature:"转弯曲率阈值:",
  straight_curvature:"直行曲率阈值:",
  moduleName:"一般性统计"
},
  en = {
    enabled:"Enabled",
    turn_curvature:"Turning curvature:",
    straight_curvature:"Straight curvature:",
    moduleName:"General Statistics"
  };