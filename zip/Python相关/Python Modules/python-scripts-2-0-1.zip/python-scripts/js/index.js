var text,
  modules = [],
  remove_modules = [],
  bi_common_js = 0,
  not_config = "",
  inputs = "",
  none = "",
  regEn = /[\s+`~!@#$%^&*()_+<>?:"{},.\/;'[\]]/im,
  regCn = /[\s+·！#￥（——）：；“”‘、，|《。》？、【】[\]]/im,
  regNum = /[\u4e00-\u9fa5]/,
  input_signal = "",
  input_sample = "",
  output_siganl = "",
  output_sample = "",
  output_scene = "",
  output_report = "";
$(function () {
  if ($('.module_content>p.active').length == 0) {
    aDisabled('')
  }
  $('.param_val').attr('disabled', true);
})
$('input[type=number]').on({
  'change': function () {
    $(this).val(compareVal(this, $(this).val()));
    if ($(this).attr('step').length > 2) changeDraw($(this).parent().parent().siblings());
  },
  'blur': function () {
    if ($(this).attr('step').length > 2) changeDraw($(this).parent().parent().siblings());
  },
  'input': function (e) {
    if (e.which == undefined && $(this).attr('step').length > 2) changeDraw($(this).parent().parent().siblings());
  },
  'keypress': function (e) {
    if (e.charCode == 101 || e.charCode == 43) return false;
  }
})
$('.module_content').on('click', 'p', function () {
  $(this).addClass('active').siblings().removeClass('active');
  getContentVal(this);
})
// language
$('a').on('click', function () {
  var lang = $(this).attr('language');
  var i = $('.module_content>p.active').index();
  switch (lang) {
    case 'remove_module':
      var msg = (biGetLanguage() == 1 ? "Are you sure to remove the module\"" : "是否移除模块\"") + $('.module_content>p.active>span:eq(1)').text() + "\"?";
      biConfirm("remove_module", msg, "Confirm");
      break;
    case 'add_module':
      // aDisabled('enabled');
      remove_modules.sort(sortNum);
      if (remove_modules != 0) {
        $('.module_content').append('<p id="' + remove_modules[0] + '"><span>(X)</span><span>Unknown Script ' + (remove_modules[0] == 1 ? '' : remove_modules[0]) + ' </span></p>');
        $('.b_center [name=name]').val('Unknown Script ' + (remove_modules[0] == 1 ? '' : remove_modules[0]));
        remove_modules.shift();
      } else {
        var i = $('.module_content>p').length + 1;
        $('.module_content').append('<p id="' + i + '"><span>(X) </span><span>Unknown Script ' + (i == 1 ? '' : i) + ' </span></p>');
        $('.b_center [name=name]').val('Unknown Script ' + (i == 1 ? '' : i));
      }
      $('.module_content>p').eq($('.module_content>p').length - 1).addClass('active').siblings().removeClass('active');
      $('.io a').text(none);
      $('.basic select').val(10);
      modules.push([{
        'enabled': 'no',
        'id': generateUUID(),
        'name': $('.module_content>p.active>span:eq(1)').text(),
        'param': [],
        'type_auto_conversion': "yes",
        'freq': "10"
      }, {
        'content': {}
      }]);
      getContentVal($('.module_content>p.active'));
      $('.param_val').prop('disabled', true);
      setConfig();
      break;
    case 'import_code':
      var i = $('.module_content p.active').index();
      biSelectPath('import_code', BISelectPathType.OpenFile, {
        '.py': 'Python script'
      });
      break;
    case 'export_code':
      biSelectPath('export_code', BISelectPathType.CreateFile, {
        '.py': 'Python script'
      });
      break;
    case 'import_module':
      biSelectPath('import_module', BISelectPathType.OpenFile, {
        '.asmc': '*.asmc'
      });
      break;
    case 'export_module':
      biSelectPath('export_module', BISelectPathType.CreateFile, {
        '.asmc': 'Aseva Module Config'
      });
      break;
    case 'save':
      for (var j = 0; j < $('.loop_list_content>div').length; j++) {
        var name = $('.loop_list>li').eq(j).attr('language');
        modules[i][0][name] = $('.loop_list_content>.item:eq(' + j + ')>textarea').val();
      }
      break;
    case 'abort':
      for (var j = 0; j < $('.loop_list_content>div').length; j++) {
        var name = $('.loop_list>li').eq(j).attr('language');
        $('.loop_list_content>.item').eq(j).find('textarea').val(modules[i][0][name] == undefined ? '' : modules[i][0][name]);
      }
      break;
  }
  if (["save", "abort"].includes(lang)) {
    $('.module_content>p,[language="add_module"],[language="import_module"],[language="export_module"],[language="remove_module"]').removeClass('adisabled');
    $('[language=save],[language=abort]').addClass('adisabled');
    setConfig();
  }
})
//  I/O  
$('a').on('click', function () {
  var i = $('.module_content>p.active').index();
  switch ($(this).attr('class')) {
    case 'in':
      biOpenChildDialog("python-scripts.in.html", input_signal, new BISize(498, 268), i);
      break;
    case 'sample_in':
      biOpenChildDialog("python-scripts.samplein.html", input_sample, new BISize(374, 313), i);
      break;
    case 'out':
      biOpenChildDialog("python-scripts.out.html", output_siganl, new BISize(216, 294), i);
      break;
    case 'sample_out':
      biOpenChildDialog("python-scripts.sampleout.html", output_sample, new BISize(640, 233), i);
      break;
    case 'scene_out':
      biOpenChildDialog("python-scripts.sceneout.html", output_scene, new BISize(500, 186), i);
      break;
    case 'report_out':
      biOpenChildDialog("python-scripts.reportout.html", output_report, new BISize(723, 540), i);
      break;
    case "import_path":
      biOpenChildDialog("python-scripts.importpath.html", output_report, new BISize(700, 260), i);
  }
})

// b_center
$('.b_center [name]').change(function () {
  setConfig()
})
$('.b_center input[type=checkbox]').on('click', function () {
  var name = $(this).attr('name');
  if ($(this).is(':checked')) {
    modules[$('.module_content>p.active').index()][0][name] = 'yes';
    if (name == 'enabled') $('.module_content .active>span:nth-child(1)').text('(O)');
  } else {
    modules[$('.module_content>p.active').index()][0][name] = 'no';
    if (name == 'enabled') $('.module_content .active>span:nth-child(1)').text('(X)');
  }

})
$('.b_center [name=freq]').change(function () {
  var index = $('.module_content>p.active').index();
  modules[index][0]['freq'] = $('[name=freq]').val();
  setConfig();
})
$('.b_center [name=name]').on({
  'input': function () {
    // if (regEn.test($(this).val()) || regCn.test($(this).val())) {
    //   $(this).addClass('red');
    // } else {
    //   $(this).removeClass('red');
    if ($(this).val().length >= 1) {
      $('.module_content>p.active').find('span:nth-child(2)').text($(this).val());
      modules[$('.module_content>p.active').index()][0].name = $(this).val();
      setConfig();
    }
    // }
  },
  'change': function () {
    var count = 0;
    for (var i in remove_modules) {
      if (remove_modules[i] == $('.module_content>p.active').attr('id')) count++;
    }
    if (count == 0) {
      remove_modules.push(Number($('.module_content .active').eq(0).attr('id')));
      $('.module_content>p.active').removeAttr('id');
    }
  },
  'blur': function () {
    $(this).val(modules[$('.module_content>p.active').index()][0].name).removeClass('red');
  }
})

//parameters
$('.parameters>div>.table').on('click', 'ul>li>span', function (e) {
  if ($(this).parent().parent().hasClass('blue')) {
    if ($(this).next().length != 0) {
      $(this).parent().parent().removeClass('blue').siblings().removeClass('blue blue2');
      $(this).next().show().val($(this).text()).select();
      $(this).hide();
    }
  } else {
    $(this).parents('.table').find('ul').removeClass('blue').find('li').removeClass('blue').find('span').removeClass('white');
    $(this).parent().parent().addClass('blue');
    $(this).parent().removeClass('blue').siblings().addClass('blue');
  }
  $('.parameters>div>.table>.title>div').eq($(this).parent().index()).addClass('blue2').siblings().removeClass('blue2');
  if ($(this).parent().parent().find('li').eq(0).find('span').text() == '') {
    $('.param_val').val('').attr('disabled', true).addClass("disabled_background");
  } else {
    $('.param_val').attr('disabled', false).removeClass("disabled_background");;
    var paramI = modules[$('.module_content>p.active').index()][0]['param'][$('.parameters li.blue').parent().index()];
    if (paramI == undefined) {
      $('.param_val').val('');
      return;
    } else {
      var val = paramI['val'];
      if (val == '' || val == undefined) {
        $('.param_val').val('')
      } else {
        $('.param_val').val(val)
      };
    }
  }
})
$('.parameters>div>.table').on('input', 'input', function () {
  if ($(this).parent().parent().index() + 1 == $('.parameters>div>.table>.table_content>ul').length) {
    $('.parameters>div>.table>.table_content').append("<ul class=\"fixclear\"><li><span></span><input type=\"text\" ></li><li><span></span><input type=\"text\" ></li></ul>");
  }
})
$('.parameters>div>.table>.table_content').on('blur', 'ul>li>input', function (e) {
  var index = $('.module_content>p.active').index();
  var eq = $(this).parent().parent().index(); //ul索引
  var lieq = $(this).parent().index(); //li索引
  if (!Boolean(modules[index][0]['param']) || modules[index][0]['param'][eq] == undefined) {
    modules[index][0]['param'].push({
      "name": "",
      "value": "",
      "val": ""
    });
  }
  if (lieq == 0) {
    modules[index][0]['param'][eq]['name'] = $(this).val();
  } else if (lieq == 1) {
    modules[index][0]['param'][eq]['value'] = $(this).val();
  }
  $(this).prev().show().text($(this).val()).removeClass('white').attr('title', $(this).val());
  $(this).hide();
  setConfig();
})
$('.parameters .table>div:nth-child(1)>div').click(function () {
  if ($(this).find('span').eq(1).text() == '') {
    $(this).find('span').eq(1).text('▲').removeClass('up').addClass('down');
    $(this).siblings().find('span').eq(1).text('').removeClass('down up');
  }
  var param = modules[$('.module_content>p.active').index()][0]['param'];
  if ($(this).find('span').eq(1).hasClass('up')) {
    $(this).find('span').eq(1).text('▲').removeClass('up').addClass('down');
  } else {
    $(this).find('span').eq(1).text('▼').removeClass('down').addClass('up');
  }
  param.reverse();
  var text = '';
  var idx = param.length - $('.parameters .table_content>ul.blue').index() - 1;
  for (var i in param) {
    text += "<ul class=\"fixclear\"><li><span>" + param[i]['name'] + "</span><input type=\"text\"></li><li><span>" + param[i]['value'] + "</span><input type=\"text\"></li></ul>"
  }
  text += "<ul class=\"fixclear\"><li><span></span><input type=\"text\"></li><li><span></span><input type=\"text\"></li></ul>"
  $('.parameters .table_content').empty().append(text);
  $('.parameters .table_content>ul').eq(idx).addClass('blue');
})
$('.parameters').on('blur', 'input', function () {
  var param = '';
  if (modules[$('.module_content>p.active').index()][0]['param'] == undefined) {
    modules[$('.module_content>p.active').index()][0]['param'] = [];
    param = modules[$('.module_content>p.active').index()][0]['param'];
  } else {
    param = modules[$('.module_content>p.active').index()][0]['param'];
  }
  var index = $('.parameters li.blue').parent().index();
  if (param[index] == undefined) {
    param.push({
      'name': $('.parameters li.blue').parent().find('li').eq(0).find('span').text(),
      'value': $('.parameters li.blue').parent().find('li').eq(1).find('span').text(),
      'val': ''
    });
  } else {
    param[index]['name'] = $('.parameters li.blue').parent().find('li').eq(0).find('span').text();
    param[index]['value'] = $('.parameters li.blue').parent().find('li').eq(1).find('span').text();
    param[index]['val'] = param[index]['val'];
  }
  setConfig();
})
$('.parameters textarea').on('blur', function () {
  var param = modules[$('.module_content>p.active').index()][0]['param'];
  var index = $('.parameters li.blue').parent().index();
  if (param[index] != undefined) {
    param[index]['val'] = $('.parameters textarea').val();
  }
  setConfig();
})

//loop
$('.loop_list>li').on('click', function () {
  if ($('.loop_list_content>.item>textarea').attr('disabled')) return;
  $(this).removeClass('loop_list_other').addClass('checked').siblings().addClass('loop_list_other').removeClass('checked');
  $('.loop_list_content>.item').eq($(this).index()).show().siblings().hide();
})
$('.loop_list_content textarea').on({
  'input': function () {
    $('[language="save"],[language="abort"]').removeClass('adisabled');
    $('.module_content>p,[language="add_module"],[language="import_module"],[language="export_module"],[language="remove_module"]').addClass('adisabled')
  }
})
$('body').on('input', '[name=default_val]', function () {
  isNaN(Number($(this).val())) ? $(this).addClass('red') : $(this).removeClass('red');
})

//ctrl+s保存
$(window).keydown(function (e) {
  if (e.keyCode == 83 && e.ctrlKey) {
    var i = $('.module_content>p.active').index();
    for (var j = 0; j < $('.loop_list_content>div').length; j++) {
      var name = $('.loop_list>li').eq(j).attr('language');
      modules[i][0][name] = $('.loop_list_content>.item:eq(' + j + ')>textarea').val();
    }
    $('.module_content>p,[language="add_module"],[language="import_module"],[language="export_module"],[language="remove_module"]').removeClass('adisabled');
    $('[language=save],[language=abort]').addClass('adisabled');
    setConfig();
  }
});
//选中一行删掉一行
$('body').keydown(function (event) {
  var e = event || window.event;
  if (e.keyCode == 46) {
    if ($('.all').hasClass('flag')) {
      var i = 0;
      while (i < $('.table>ul').length - 1) {
        $('.table>ul')[i].remove();
        i = 0;
      }
    } else {
      if ($('.blue2').parents().hasClass('parameters')) {
        modules[$('.module_content>p.active').index()][0]['param'].splice($('.parameters .table_content>ul.blue').index(), 1);
        $('.parameters .table_content>ul.blue').remove();
        setConfig();
      } else {
        if ($('.blue2').parents().hasClass('sample_out') && $('[name="output_protocal"]').val() != '') {
          $('[language="output_add_sample"]').removeAttr('disabled');
        }
        $('.blue2').parent().remove();
      }
    }
  }
  $('.all').removeClass('flag');
});
// $('body').bind('selectstart', 'span,p', function () {
//   return false;
// })
function aDisabled(enabled) {
  if (enabled == 'enabled') {
    $('input,select,textarea').removeAttr('disabled').removeClass("disabled_background");
    $('.container span,.container a').removeClass('adisabled');
    $('a[language="save"],a[language="abort"]').addClass('adisabled');
    $(".table>.title>div,.table_content>ul>li").addClass("bc_white");
  } else {
    $('input,select,textarea').attr('disabled', true).addClass("disabled_background");
    $('textarea').val('');
    $('.io a').text(none);
    $('.container span,.container a').addClass('adisabled');
    $('[language="add_module"],[language=import_module],[language=import_path]').removeClass('adisabled');
    $(".table>.title>div,.table_content>ul>li").removeClass("bc_white");
  }
}

function compareVal(obj, val) {
  var step = $(obj).attr('step').length > 2 ? $(obj).attr('step').length - 2 : 0,
    v = Number(val),
    newVal = 0;
  if (isNaN(v)) {
    newVal = Number($(obj).attr('value'));
  } else {
    var min = Number($(obj).attr('min')),
      max = Number($(obj).attr('max'));
    v = v < min ? min : v;
    v = v > max ? max : v;
    if (step > 0) {
      newVal = Math.round((Math.abs(v) * Math.pow(10, step)).toFixed(1)) / Math.pow(10, step);
      if (v < 0) newVal = -newVal;
    } else {
      newVal = Math.floor(v);
    }
  }
  return step > 0 ? newVal.toFixed(step) : newVal;
}

function setConfig() {
  text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root>";
  for (var i in modules) {
    text += "<s "
    for (var j in modules[i][0]) {
      if (j != 'param' && j != 'cmd' && j != 'cmd_start' && j != 'cmd_end') {
        text += j + "=\"" + modules[i][0][j] + "\" ";
      }
    }
    text += ">"
    if (modules[i][1]['content'] == '') return;
    for (var j in modules[i][1]['content']) {
      switch (j) {
        case 'in': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<in signal=\"" + modules[i][1]['content'][j][k]['signal'] + "\" nearest=\"" + modules[i][1]['content'][j][k]['nearest'] + "\" param=\"" + modules[i][1]['content'][j][k]['param'] + "\" default_val=\"" + modules[i][1]['content'][j][k]['default_val'] + "\" />";
          }
          break;
        }
        case 'out': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<out param=\"" + modules[i][1]['content'][j][k]['param'] + "\" />";
          }
          break;
        }
        case 'sample_in': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<sample_in>" + modules[i][1]['content'][j][k] + "</sample_in>";
          }
          break;
        }
        case 'sample_out': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<sample_out id=\"" + modules[i][1]['content'][j][k]['id'] + "\" name=\"" + (modules[i][1]['content'][j][k]['name'] == undefined ? '' : modules[i][1]['content'][j][k]['name']) + "\">" + (modules[i][1]['content'][j][k]['val'] == undefined ? '' : modules[i][1]['content'][j][k]['val']) + "</sample_out>";
          }
          break;
        }
        case 'scene_out': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<scene_out id=\"" + modules[i][1]['content'][j][k]['id'] + "\">" + (modules[i][1]['content'][j][k]['val'] == undefined ? '' : modules[i][1]['content'][j][k]['val']) + "</scene_out>";
          }
          break;
        }
        case 'report_out': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<report_out id=\"" + modules[i][1]['content'][j][k]['id'] + "\" type=\"" + modules[i][1]['content'][j][k]['type'] + "\" title=\"" + modules[i][1]['content'][j][k]['title'] + "\" configs=\"" + modules[i][1]['content'][j][k]['configs'] + "\" column_titles=\"" + modules[i][1]['content'][j][k]['column_titles'] + "\" />"
          }
          break;
        }
      }
    }
    for (var k in modules[i][0]['param']) {
      text += "<param name=\"" + modules[i][0]['param'][k]['name'] + "\"" + " value=\"" + modules[i][0]['param'][k]['value'] + "\">" + modules[i][0]['param'][k]['val'] + "</param>";
    }
    text += "<cmd>" + (modules[i][0]['cmd'] == '' || modules[i][0]['cmd'] == undefined ? '' : getEncode64(modules[i][0]['cmd'])) + "</cmd>";
    text += "<cmd_start>" + (modules[i][0]['cmd_start'] == '' || modules[i][0]['cmd_start'] == undefined ? '' : getEncode64(modules[i][0]['cmd_start'])) + "</cmd_start>";
    text += "<cmd_end>" + (modules[i][0]['cmd_end'] == '' || modules[i][0]['cmd_end'] == undefined ? '' : getEncode64(modules[i][0]['cmd_end'])) + "</cmd_end>";
    text += "</s>"
  }
  text += "</root>";
  biSetModuleConfig("python-scripts.pluginpython", text);
}

function getContentVal(obj) {
  aDisabled('enabled');
  if ($('.module_content>p.active').length == 0) {
    $('.b_center [name=enabled]').prop('checked', false);
    $('.b_center [name=freq]').val(10);
    $('.b_center [name=name]').val('');
    $('.parameters .table_content').empty().append("<ul class=\"fixclear\"><li><span></span><input type=\"text\" tabindex=-1></li><li><span></span><input type=\"text\" tabindex=-1></li></ul>");
    $('.param_val').val('');
    return;
  };
  var i = $(obj).index();
  $('.b_center [name]').each(function () {
    var name = $(this).attr('name');
    if ($(this).attr('type') == 'checkbox') {
      modules[i][0][name] == 'yes' ? $('[name="' + name + '"]').prop('checked', true) : $('[name="' + name + '"]').prop('checked', false);
    } else if ($(this).is('select')) {
      $('[name="' + name + '"]').val((modules[i][0][name] == '' || modules[i][0][name] == undefined) ? 10 : modules[i][0][name]);
    } else {
      $('[name="' + name + '"]').val(modules[i][0][name]);
    }
  })
  modules[i][0]['name'] = $(obj).find('span').eq(1).text();
  $('[name=name]').val($(obj).find('span').eq(1).text());
  $('.loop_list_content textarea').each(function () {
    var name = $(this).attr('name');
    if (modules[i][0][name] != undefined) {
      // $(this).val(getDecode(modules[i][0][name]));
      $(this).val(modules[i][0][name]);
    } else {
      $(this).val('');
    }
  })
  $('.param_val').val('');
  $('.io a').each(function () {
    var name = $(this).attr('class');
    var config = modules[i][1]['content'][name];
    if (config == undefined || config.length == 0) {
      $(this).text(none);
    } else if (config.length == 1) {
      if (name == 'sample_out' || name == 'report_out' || name == 'scene_out') {
        $(this).text(config[0]['id']);
      } else if (name == 'in') {
        $(this).text(config[0]['param']);
      } else if (name == 'sample_in') {
        $(this).text(config[0]);
      } else if (name == 'out') {
        $(this).text(config[0]['param']);
      }
    } else {
      $(this).text(config.length + inputs);
    }
  })
  $('.param_val').attr('disabled', $('.param_val').val() == '' ? true : false);
  if (modules[i][0]['param'] == undefined) {
    $('.parameters .table_content').html("<ul class=\"fixclear\"><li><span></span><input type=\"text\" tabindex=-1></li><li><span></span><input type=\"text\" tabindex=-1></li></ul>");
    return;
  };
  $('.parameters .table_content').empty();
  for (var j = 0; j < modules[i][0]['param'].length; j++) {
    $('.parameters .table_content').append("<ul class=\"fixclear\"><li><span>" + modules[i][0]['param'][j]['name'] + "</span><input type=\"text\" tabindex=-1></li><li><span>" + modules[i][0]['param'][j]['value'] + "</span><input type=\"text\" tabindex=-1></li></ul>")
  }
  $('.parameters .table_content>ul:nth-child(1)>li').addClass('blue');
  if (modules[i][0]['param'].length != 0) {
    $('.param_val').removeAttr('disabled').val(modules[i][0]['param'][0]['val']);
  }
  $('.parameters .table_content').append("<ul class=\"fixclear\"><li><span></span><input type=\"text\" tabindex=-1></li><li><span></span><input type=\"text\" tabindex=-1></li></ul>");
}

function biOnInitEx(config, moduleConfigs) {
  for (var key in moduleConfigs) {
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString([moduleConfigs[key]], "text/xml");
    var countrys = xmlDoc.getElementsByTagName('root');
    for (var k = 0; k < countrys[0].childNodes.length; k++) {
      var obj = {};
      var arrConfig = [];
      var keys = countrys[0].childNodes[k].attributes;
      for (var n = 0; n < keys.length; n++) {
        obj[keys[n].nodeName] = keys[n].nodeValue;
      }
      arrConfig.push(obj, {
        'content': {}
      });
      var sample_in = [],
        scene_out = [],
        sample_out = [],
        signal_in = [],
        signal_out = [],
        report_out = [],
        param = [],
        cmd = '',
        cmd_start = '',
        cmd_end = '';
      for (var j = 0; j < countrys[0].childNodes[k].childNodes.length; j++) {
        var keyss = countrys[0].childNodes[k].childNodes[j].attributes;
        obj = {};
        var nodeName = countrys[0].childNodes[k].childNodes[j].localName;
        var innerHtml = countrys[0].childNodes[k].childNodes[j].innerHTML;
        switch (nodeName) {
          case 'sample_in': {
            sample_in.push(innerHtml)
            break;
          }
          case 'scene_out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
              obj['val'] = innerHtml;
            }
            scene_out.push(obj);
            break;
          }
          case 'sample_out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
              obj['val'] = innerHtml;
            }
            sample_out.push(obj);
            break;
          }
          case 'report_out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            report_out.push(obj);
            break;
          }
          case 'in': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            signal_in.push(obj);
            break;
          }
          case 'out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            signal_out.push(obj);
            break;
          }
          case 'param': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            obj['val'] = innerHtml;
            param.push(obj);
            break;
          }
          case 'cmd': {
            cmd += getDecode(innerHtml) + "\n\n";
            break;
          }
          case 'cmd_start': {
            cmd_start = getDecode(innerHtml) + "\n\n";
            break;
          }
          case 'cmd_end': {
            cmd_end = getDecode(innerHtml) + "\n\n";
            break;
          }
        }
        arrConfig[0]['param'] = param;
        arrConfig[1].content['in'] = signal_in;
        arrConfig[1].content['scene_out'] = scene_out;
        arrConfig[1].content['sample_out'] = sample_out;
        arrConfig[1].content['out'] = signal_out;
        arrConfig[1].content['report_out'] = report_out;
        arrConfig[1].content['sample_in'] = sample_in;
        arrConfig[0]['cmd'] = cmd;
        arrConfig[0]['cmd_start'] = cmd_start;
        arrConfig[0]['cmd_end'] = cmd_end;
      }
      modules.push(arrConfig);
    }
  }
  loadConfig(modules);
}

function loadConfig(config) {
  biQueryGlobalPath("PythonImportPathes");
  for (var i in modules) {
    var o = modules[i][0]['enabled'] == 'yes' ? '(O)' : '(X)';
    $('.module_content').append("<p><span>" + o + "</span><span>" + modules[i][0]['name'] + "</span></p>");
  }
  $('[language]').each(function () {
    var value = $(this).attr('language');
    if (biGetLanguage() == 1) {
      $(this).text(en[value]);
      not_config = en["not_config"];
      inputs = " inputs";
      none = en["none"];
      input_signal = "Input Signal";
      input_sample = "Input Sample";
      output_siganl = "Output Signal";
      output_sample = "Output Sample";
      output_scene = "Output Scene";
      output_report = "Output Report";
    } else {
      $(this).text(cn[value]);
      not_config = cn["not_config"];
      inputs = "个输入";
      none = cn["none"];
      input_signal = "输入信号";
      input_sample = "输入样本";
      output_siganl = "输出信号";
      output_sample = "输出样本";
      output_scene = "输出场景";
      output_report = "输出报告";
    }
  });
}

function biOnQueriedGlobalPath(id, paths) {
  if (paths.length == 0) $('[language=cant_find]').show().removeClass('adisabled').addClass('red').text(biGetLanguage() == 1 ? en['cant_find'] : cn['cant_find']);
  for (var i = 0; i < paths.length; i++) {
    biQueryFilesInDirectory(paths[i]);
    $('.import_path_content').append("<p title='" + paths[i] + "'>" + paths[i] + "</p>");
  }
}

function biOnClosedChildDialog(htmlName, result) {
  var index = $('.module_content>p.active').index();
  switch (htmlName) {
    case "python-scripts.importpath.html": {
      biQueryGlobalPath("PythonImportPathes");
      break;
    }
    case "python-scripts.in.html": {
      var val = JSON.parse(biGetLocalVariable("python_script_in" + index));
      if (val != null) {
        var arr = [];
        for (let i in val) {
          if (!$.isEmptyObject(val[i])) arr.push(val[i])
        }
        modules[index][1]["content"]["in"] = arr;
        var length = arr.length > 1 ? arr.length + inputs : (arr.length == 1 ? arr[0]["param"] : none);
        $(".in").text(length);
      }

      break;
    }
    case "python-scripts.samplein.html": {
      var val = JSON.parse(biGetLocalVariable("python_script_samplein" + index));
      if (val != null) {
        modules[index][1]["content"]["sample_in"] = val;
        var length = val.length > 1 ? val.length + inputs : (val.length == 1 ? val[0] : none);
        $(".sample_in").text(length);
      };
      break;
    }
    case "python-scripts.out.html": {
      var val = JSON.parse(biGetLocalVariable("python_script_out" + index));
      if (val != null) {
        modules[index][1]["content"]["out"] = val;
        var length = val.length > 1 ? val.length + inputs : (val.length == 1 ? val[0]["param"] : none);
        $(".out").text(length);
      }
      break;
    }
    case "python-scripts.sampleout.html": {
      var val = JSON.parse(biGetLocalVariable("python_script_sampleout" + index));
      if (val != null) {
        modules[index][1]["content"]["sample_out"] = val;
        var length = val.length > 1 ? val.length + inputs : (val.length == 1 ? val[0]["id"] : none);
        $(".sample_out").text(length);
      }
      break;
    }
    case "python-scripts.sceneout.html": {
      var val = JSON.parse(biGetLocalVariable("python_script_sceneout" + index));
      if (val != null) {
        modules[index][1]["content"]["scene_out"] = val;
        var length = val.length > 1 ? val.length + inputs : (val.length == 1 ? val[0]["id"] : none);
        $(".scene_out").text(length);
      }
      break;
    }
    case "python-scripts.reportout.html": {
      var val = JSON.parse(biGetLocalVariable("python_script_reportout" + index));
      if (val != null) {
        modules[index][1]["content"]["report_out"] = val;
        var length = val.length > 1 ? val.length + inputs : (val.length == 1 ? val[0]["id"] : none);
        $(".report_out").text(length);
      }
      break;
    }
  }
}
//import path
function biOnQueriedFilesInDirectory(files, path) {
  var dir = files[0].split('\n');
  for (var i in dir) {
    if (dir[i].indexOf('bi_common.py') != -1) {
      bi_common_js++;
    }
  }
  bi_common_js == 0 ? $('[language=cant_find').show().removeClass('adisabled') : $('[language=cant_find').hide();
}

function biOnSelectedPath(key, path) {
  switch (key) {
    case 'import_module': {
      biQueryFileText(path);
      break;
    }
    case 'import_code': {
      biQueryFileText(path);
      break;
    }
    case 'export_code': {
      var i = $('.loop_list>li.checked').index();
      var val = $('.loop_list_content>div').eq(i).find('textarea').val();
      biWriteFileText(path, val);
      break;
    }
    case 'export_module': {
      var outHtml = '',
        text = '';
      outHtml += "<?xml version=\"1.0\" encoding=\"utf-8\"?><root type=\"python-script-function\">";
      text = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
      var moduleI = modules[$('.module_content>p.active').index()];
      text += "<root "
      for (var j in moduleI[0]) {
        if (j != 'param' && j != 'cmd' && j != 'cmd_start' && j != 'cmd_end') {
          text += j + "=\"" + moduleI[0][j] + "\" ";
        }
      }
      text += ">"
      for (var j in moduleI[0]['param']) {
        text += "<param name=\"" + moduleI[0]['param'][j]['name'] + "\"" + " value=\"" + moduleI[0]['param'][j]['value'] + "\">" + moduleI[0]['param'][j]['val'] + "</param>";
      }
      if (moduleI[1]['content'] == '') return;
      for (var j in moduleI[1]['content']) {
        switch (j) {
          case 'in': {
            for (var k in moduleI[1]['content'][j]) {
              text += "<in signal=\"" + moduleI[1]['content'][j][k]['signal'] + "\" nearest=\"" + moduleI[1]['content'][j][k]['nearest'] + "\" param=\"" + moduleI[1]['content'][j][k]['param'] + "\" default_val=\"" + moduleI[1]['content'][j][k]['default_val'] + "\" />";
            }
            break;
          }
          case 'out': {
            for (var k in moduleI[1]['content'][j]) {
              text += "<out param=\"" + moduleI[1]['content'][j][k]['param'] + "\" />";
            }
            break;
          }
          case 'sample_in': {
            for (var k in moduleI[1]['content'][j]) {
              text += "<sample_in>" + moduleI[1]['content'][j][k] + "</sample_in>";
            }
            break;
          }
          case 'sample_out': {
            for (var k in moduleI[1]['content'][j]) {
              text += "<sample_out id=\"" + moduleI[1]['content'][j][k]['id'] + "\" name=\"" + moduleI[1]['content'][j][k]['name'] + "\"></sample_out>";
            }
            break;
          }
          case 'scene_out': {
            for (var k in moduleI[1]['content'][j]) {
              text += "<scene_out id=\"" + moduleI[1]['content'][j][k]['id'] + "\">" + moduleI[1]['content'][j][k]['val'] + "</scene_out>";
            }
            break;
          }
          case 'report_out': {
            for (var k in moduleI[1]['content'][j]) {
              text += "<report_out id=\"" + moduleI[1]['content'][j][k]['id'] + "\" type=\"" + moduleI[1]['content'][j][k]['type'] + "\" title=\"" + moduleI[1]['content'][j][k]['title'] + "\" configs=\"" + moduleI[1]['content'][j][k]['configs'] + "\" column_titles=\"" + moduleI[1]['content'][j][k]['column_titles'] + "\" />"
            }
            break;
          }
        }
      }
      text += "<cmd>" + (moduleI[0]['cmd'] == '' || moduleI[0]['cmd'] == undefined ? '' : getEncode64(moduleI[0]['cmd'])) + "</cmd>";
      text += "<cmd_start>" + (moduleI[0]['cmd_start'] == '' || moduleI[0]['cmd_start'] == undefined ? '' : getEncode64(moduleI[0]['cmd_start'])) + "</cmd_start>";
      text += "<cmd_end>" + (moduleI[0]['cmd_end'] == '' || moduleI[0]['cmd_end'] == undefined ? '' : getEncode64(moduleI[0]['cmd_end'])) + "</cmd_end>";
      text += "</root>"
      outHtml += getEncode64(text);
      outHtml += "</root>";
      biWriteFileText(path, outHtml);
    }
    break;
  }
}
//remove module
function biOnResultOfConfirm(key, result) {
  switch (key) {
    case "remove_module": {
      if (result) {
        if ($('.module_content>p').length == 0) return;
        if ($('.module_content .active').eq(0).attr('id') != undefined) {
          remove_modules.push($('.module_content .active').eq(0).attr('id') == '' ? 1 : Number($('.module_content .active').eq(0).attr('id')))
        }
        if ($('.module_content>p').length == 1) {
          aDisabled('')
          $('.module_content .active').eq(0).remove();
          $('.io a').text(none)
          $('[language="add_module"],[language=import_module]').removeClass('adisabled');
          $('.b_center [name=enabled]').prop('checked', false);
          $('.b_center [name=freq]').val(10);
          $('.b_center [name=name]').val('');
          $('.parameters .table_content').empty().append("<ul class=\"fixclear\"><li><span></span><input type=\"text\"></li><li><span></span><input type=\"text\"></li></ul>");
          $('.param_val').val('');
          modules = [];
        } else {
          if ($('.module_content .active').eq(0).next().length == 0) {
            getContentVal($('.module_content .active').prev());
            modules.splice($('.module_content .active').eq(0).index(), 1);
            $('.module_content .active').prev().addClass('active');
            $('.module_content .active').eq(1).remove();
          } else {
            getContentVal($('.module_content .active').next());
            modules.splice($('.module_content .active').eq(0).index(), 1);
            $('.module_content .active').next().addClass('active');
            $('.module_content .active').eq(0).remove();
          }
        };
        setConfig();
      }
      break;
    }
  }
}
//import module
function biOnQueriedFileText(text, path) {
  if (path.indexOf('.asmc') != -1) {
    aDisabled('enabled');
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(text, "text/xml");
    var config = getDecode(xmlDoc.childNodes[0].innerHTML);
    xmlDoc = parser.parseFromString(config, "text/xml")
    var countrys = xmlDoc.getElementsByTagName('root');
    var obj = {};
    var arrConfig = [];
    var count = 0;
    var keys = countrys[0].getAttributeNames();
    for (var n = 0; n < keys.length; n++) {
      obj[keys[n]] = countrys[0].getAttribute(keys[n]);
      if (keys[n] == 'id') {
        var id = countrys[0].getAttribute(keys[n]);
        for (var i in modules) {
          if (modules[i][0]['id'] == id) count++;
        }
      }
    }
    if (count != 0) {
      biAlert('Module with the same ID and the same name exist:' + path, 'Error');
    } else {
      arrConfig.push(obj, {
        'content': {}
      });
      var sample_in = [],
        scene_out = [],
        sample_out = [],
        signal_in = [],
        signal_out = [],
        report_out = [],
        param = [],
        cmd = '',
        cmd_start = '',
        cmd_end = '';
      for (var j = 0; j < countrys[0].childNodes.length; j++) {
        var keyss = countrys[0].childNodes[j].attributes;
        var innerHtml = countrys[0].childNodes[j].innerHTML;
        obj = {};
        var nodeName = countrys[0].childNodes[j].localName;
        switch (nodeName) {
          case 'sample_in': {
            sample_in.push(innerHtml)
            break;
          }
          case 'scene_out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
              obj['val'] = innerHtml;
            }
            scene_out.push(obj);
            break;
          }
          case 'sample_out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            sample_out.push(obj);
            break;
          }
          case 'report_out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            report_out.push(obj);
            break;
          }
          case 'in': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            signal_in.push(obj);
            break;
          }
          case 'out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            signal_out.push(obj);
            break;
          }
          case 'param': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            obj['val'] = innerHtml;
            param.push(obj);
            break;
          }
          case 'cmd': {
            cmd += getDecode(innerHtml) + '\n\n';
            break;
          }
          case 'cmd_start': {
            cmd_start += getDecode(innerHtml) + '\n\n';
            break;
          }
          case 'cmd_end': {
            cmd_end += getDecode(innerHtml) + '\n\n';
            break;
          }
        }
      }
      arrConfig[0]['param'] = param;
      arrConfig[1].content['in'] = signal_in;
      arrConfig[1].content['scene_out'] = scene_out;
      arrConfig[1].content['sample_out'] = sample_out;
      arrConfig[1].content['out'] = signal_out;
      arrConfig[1].content['report_out'] = report_out;
      arrConfig[1].content['sample_in'] = sample_in;
      arrConfig[0]['cmd'] = cmd;
      arrConfig[0]['cmd_start'] = cmd_start;
      arrConfig[0]['cmd_end'] = cmd_end;
      modules.push(arrConfig);
      $('.module_content>p').removeClass('active');
      $('.module_content').append('<p class="active"><span>' + (arrConfig[0]['enabled'] == 'yes' ? '(O)' : '(X)') + '</span><span>' + arrConfig[0]['name'] + '</span></p>');
      getContentVal($('.module_content>p.active'));
      $('.parameters .title>.left').addClass('blue2');
      $('.parameters .table_content>ul').eq(0).addClass('blue');
    }
  } else if (path.indexOf('.py') != -1) {
    var i = $('.loop_list>li.checked').index();
    $('.loop_list_content>div').eq(i).find('textarea').val(text);
    $('[language="save"],[language="abort"]').removeClass('adisabled');
    $('.module_content>p,[language="add_module"],[language="import_module"],[language="export_module"],[language="remove_module"]').addClass('adisabled');
  }
  setConfig();
}

function sortNum(a, b) {
  return a - b;
}
function generateUUID() {
  var d = new Date().getTime();
  if (window.performance && typeof window.performance.now === "function") {
    d += performance.now(); //use high-precision timer if available
  }
  var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    var r = (d + Math.random() * 16) % 16 | 0;
    d = Math.floor(d / 16);
    return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
  });
  return uuid;
}