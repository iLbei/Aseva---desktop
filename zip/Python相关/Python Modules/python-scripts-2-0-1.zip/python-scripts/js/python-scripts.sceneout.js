var text,
  modules = [],
  childIndex = 0,
  regEn = /[\s+`~!@#$%^&*()_+<>?:"{},.\/;'[\]]/im,
  regCn = /[\s+·！#￥（——）：；“”‘、，|《。》？、【】[\]]/im,
  regNum = /[\u4e00-\u9fa5]/;

$('.scene_out>.table').on('click', 'ul>li>span', function (e) {
  if ($(this).parent().hasClass('blue') && $(this).parents('ul').find('.blue2').length == 0) {
    if ($(this).next().length != 0) {
      $(this).parent().removeClass('blue').siblings().removeClass('blue blue2');
      $(this).next().show().val($(this).html()).select();
      $(this).hide();
    }
  } else {
    $(this).parents('.table').find('li').removeClass('blue blue2').find('span').removeClass('white');
    $(this).addClass('white').parent().addClass('blue').siblings().removeClass('blue2');
  }
})

$('.scene_out>.table').on('input', 'input', function () {
  if ($(this).parent().parent().index() + 1 == $('.scene_out>.table>.table_content>ul').length) {
    $('.scene_out>.table>.table_content').append("<ul class=\"fixclear\"><li></li><li><span></span><input type=\"text\" name=\"id\" tabindex=-1></li><li><span></span><input type=\"text\" tabindex=-1></li></ul>");
  }
  $(this).prev().html($(this).val());
  setConfig();
})

$('.scene_out>.table>.table_content').on('click', 'ul>li:nth-child(1)', function () {
  $(this).addClass('blue2').siblings().addClass('blue');
  $(this).siblings().find('span').addClass('white');
  $(this).parent().siblings().find('span').removeClass('white');
  $(this).parent().siblings().find('li').removeClass('blue blue2');
})

$('.scene_out>.table>.table_content').on('blur', 'ul>li>input', function (e) {
  $(this).prev().show().removeClass('white').attr('title', $(this).val());
  $(this).hide();
})

$('body').keydown(function (event) {
  var e = event || window.event;
  if (e.keyCode == 46 && $(".blue2").parent().index() < $(".table_content>ul").length - 1) {
    $(".blue2").parent().remove();
    setConfig();
  }
});

function setConfig() {
  var arr = [];
  for (var i = 0; i < $('.scene_out .table_content>ul').length - 1; i++) {
    var out_sample_obj = {};
    var span = $('.scene_out .table_content>ul').eq(i).find('li').eq(1).find('span').html();
    if (span != '' && !regEn.test(span) && !regCn.test(span) && !regNum.test(span)) {
      out_sample_obj['id'] = span;
      out_sample_obj['val'] = $('.scene_out .table_content>ul').eq(i).find('li').eq(2).find('span').html();
      arr.push(out_sample_obj);
    };
  }
  modules[childIndex][1]['content']['scene_out'] = arr;
  text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root>";
  for (var i in modules) {
    text += "<s "
    for (var j in modules[i][0]) {
      if (j != 'param' && j != 'cmd' && j != 'cmd_start' && j != 'cmd_end') {
        text += j + "=\"" + modules[i][0][j] + "\" ";
      }
    }
    text += ">"
    if (modules[i][1]['content'] == '') return;
    for (var j in modules[i][1]['content']) {
      switch (j) {
        case 'in': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<in signal=\"" + modules[i][1]['content'][j][k]['signal'] + "\" nearest=\"" + modules[i][1]['content'][j][k]['nearest'] + "\" param=\"" + modules[i][1]['content'][j][k]['param'] + "\" default_val=\"" + modules[i][1]['content'][j][k]['default_val'] + "\" />";
          }
          break;
        }
        case 'out': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<out param=\"" + modules[i][1]['content'][j][k]['param'] + "\" />";
          }
          break;
        }
        case 'sample_in': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<sample_in>" + modules[i][1]['content'][j][k] + "</sample_in>";
          }
          break;
        }
        case 'sample_out': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<sample_out id=\"" + modules[i][1]['content'][j][k]['id'] + "\" name=\"" + (modules[i][1]['content'][j][k]['name'] == undefined ? '' : modules[i][1]['content'][j][k]['name']) + "\">" + (modules[i][1]['content'][j][k]['val'] == undefined ? '' : modules[i][1]['content'][j][k]['val']) + "</sample_out>";
          }
          break;
        }
        case 'scene_out': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<scene_out id=\"" + modules[i][1]['content'][j][k]['id'] + "\">" + (modules[i][1]['content'][j][k]['val'] == undefined ? '' : modules[i][1]['content'][j][k]['val']) + "</scene_out>";
          }
          break;
        }
        case 'report_out': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<report_out id=\"" + modules[i][1]['content'][j][k]['id'] + "\" type=\"" + modules[i][1]['content'][j][k]['type'] + "\" title=\"" + modules[i][1]['content'][j][k]['title'] + "\" configs=\"" + modules[i][1]['content'][j][k]['configs'] + "\" column_titles=\"" + modules[i][1]['content'][j][k]['column_titles'] + "\" />"
          }
          break;
        }
      }
    }
    for (var k in modules[i][0]['param']) {
      text += "<param name=\"" + modules[i][0]['param'][k]['name'] + "\"" + " value=\"" + modules[i][0]['param'][k]['value'] + "\">" + modules[i][0]['param'][k]['val'] + "</param>";
    }
    if (Boolean(modules[i][0]['cmd'])) text += "<cmd>" + modules[i][0]['cmd'] + "</cmd>";
    if (Boolean(modules[i][0]['cmd_start'])) text += "<cmd_start>" + modules[i][0]['cmd_start'] + "</cmd_start>";
    if (Boolean(modules[i][0]['cmd_end'])) text += "<cmd_end>" + modules[i][0]['cmd_end'] + "</cmd_end>";
    text += "</s>"
  }
  text += "</root>";
  biSetModuleConfig("python-scripts.pluginpython", text);
  biSetLocalVariable("python_script_sceneout"+childIndex, JSON.stringify(modules[childIndex][1]['content']["scene_out"]));
}

function biOnInitEx(config, moduleConfigs) {
  childIndex = config;
  for (var key in moduleConfigs) {
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    var countrys = xmlDoc.getElementsByTagName('root');
    for (var k = 0; k < countrys[0].childNodes.length; k++) {
      var obj = {};
      var arrConfig = [];
      var keys = countrys[0].childNodes[k].attributes;
      for (var n = 0; n < keys.length; n++) {
        obj[keys[n].nodeName] = keys[n].nodeValue;
      }
      arrConfig.push(obj, { 'content': {} });
      var sample_in = [], scene_out = [], sample_out = [], signal_in = [], signal_out = [], report_out = [], param = [], cmd = '', cmd_start = '', cmd_end = '';
      for (var j = 0; j < countrys[0].childNodes[k].childNodes.length; j++) {
        var keyss = countrys[0].childNodes[k].childNodes[j].attributes;
        obj = {};
        var nodeName = countrys[0].childNodes[k].childNodes[j].localName;
        var innerHtml = countrys[0].childNodes[k].childNodes[j].innerHTML;
        switch (nodeName) {
          case 'sample_in': {
            sample_in.push(innerHtml)
            break;
          }
          case 'scene_out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
              obj['val'] = innerHtml;
            }
            scene_out.push(obj);
            break;
          }
          case 'sample_out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
              obj['val'] = innerHtml;
            }
            sample_out.push(obj);
            break;
          }
          case 'report_out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            report_out.push(obj);
            break;
          }
          case 'in': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            signal_in.push(obj);
            break;
          }
          case 'out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            signal_out.push(obj);
            break;
          }
          case 'param': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            obj['val'] = innerHtml;
            param.push(obj);
            break;
          }
          case 'cmd': {
            cmd += innerHtml + "\n\n";
            break;
          }
          case 'cmd_start': {
            cmd_start = innerHtml + "\n\n";
            break;
          }
          case 'cmd_end': {
            cmd_end = innerHtml + "\n\n";
            break;
          }
        }
        arrConfig[0]['param'] = param;
        arrConfig[1].content['in'] = signal_in;
        arrConfig[1].content['scene_out'] = scene_out;
        arrConfig[1].content['sample_out'] = sample_out;
        arrConfig[1].content['out'] = signal_out;
        arrConfig[1].content['report_out'] = report_out;
        arrConfig[1].content['sample_in'] = sample_in;
        arrConfig[0]['cmd'] = cmd;
        arrConfig[0]['cmd_start'] = cmd_start;
        arrConfig[0]['cmd_end'] = cmd_end;
      }
      modules.push(arrConfig);
    }
  }
  var val = modules[config][1]['content']["scene_out"];
  for (var i in val) {
    $('.scene_out .table_content').append("<ul class=\"fixclear\"><li></li><li><span>" + val[i]['id'] + "</span><input type=\"text\" name=\"id\" tabindex=-1></li><li><span>" + (val[i]['val'] == undefined ? '' : val[i]['val']) + "</span><input type=\"text\" tabindex=-1></li></ul>");
  }
  $('.scene_out .table_content').append("<ul class=\"fixclear\"><li></li><li><span></span><input type=\"text\" name=\"id\"></li><li><span></span><input type=\"text\"></li></ul>");
  $('[language]').each(function () {
    var value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value]);
  });
}