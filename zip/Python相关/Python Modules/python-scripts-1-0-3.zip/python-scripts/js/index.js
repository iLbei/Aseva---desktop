let text,
  modules = [],
  remove_modules = [],
  bi_common_js = 0,
  not_config = "",
  inputs = "",
  none = "",
  regEn = /[\s+`~!@#$%^&*()_+<>?:"{},.\/;'[\]]/im,
  regCn = /[\s+·！#￥（——）：；“”‘、，|《。》？、【】[\]]/im,
  regNum = /[\u4e00-\u9fa5]/;
$(function () {
  if ($('.module_content>p.active').length == 0) {
    aDisabled('')
  }
  $('.param_val').attr('disabled', true);
})
function getDecode(str) {
  return decodeURIComponent(atob(str).split('').map(function (c) {
    return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
  }).join(''));
}
function getEncode64(str) {
  return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g,
    function toSolidBytes(match, p1) {
      return String.fromCharCode('0x' + p1);
    }));

}
$('input[type=number]').on({
  'change': function () {
    $(this).val(compareVal(this));
    if ($(this).attr('step').length > 2) changeDraw($(this).parent().parent().siblings())
  },
  'blur': function () {
    if ($(this).attr('step').length > 2) changeDraw($(this).parent().parent().siblings())
  },
  'input': function (e) {
    if (e.which == undefined && $(this).attr('step').length > 2) changeDraw($(this).parent().parent().siblings())
  },
  'keypress': function (e) {
    if (e.charCode == 101 || e.charCode == 43) {
      return false;
    }
  }
})
$('.b_center [name]').change(function () {
  setConfig()
})
function sortNum(a, b) {
  return a - b;
}
$('.module_content').on('click', 'p', function () {
  $(this).addClass('active').siblings().removeClass('active');
  getContentVal(this);
})
function getContentVal(obj) {
  aDisabled('enabled');
  if ($('.module_content>p.active').length == 0) {
    $('.b_center [name=enabled]').prop('checked', false);
    $('.b_center [name=freq]').val(10);
    $('.b_center [name=name]').val('');
    $('.parameters .table_content').empty().append(`<ul class="fixclear">
    <li><span></span><input type="text" tabindex=-1></li>
    <li><span></span><input type="text" tabindex=-1></li>
  </ul>`);
    $('.param_val').val('');
    return;
  };
  let i = $(obj).index();
  $('.b_center [name]').each(function () {
    let name = $(this).attr('name');
    if ($(this).attr('type') == 'checkbox') {
      modules[i][0][name] == 'yes' ? $('[name="' + name + '"]').prop('checked', true) : $('[name="' + name + '"]').prop('checked', false);
    } else if ($(this).is('select')) {
      $('[name="' + name + '"]').val((modules[i][0][name] == '' || modules[i][0][name] == undefined) ? 10 : modules[i][0][name]);
    } else {
      $('[name="' + name + '"]').val(modules[i][0][name]);
    }
  })
  modules[i][0]['name'] = $(obj).find('span').eq(1).html();
  $('[name=name]').val($(obj).find('span').eq(1).html());
  $('.loop_list_content textarea').each(function () {
    let name = $(this).attr('name');
    if (modules[i][0][name] != undefined) {
      $(this).val(modules[i][0][name]);
    } else {
      $(this).val('');
    }
  })
  $('.param_val').val('');
  $('.io a').each(function () {
    let name = $(this).attr('class');
    let config = modules[i][1]['content'][name];
    if (config == undefined || config.length == 0) {
      $(this).html(none);
    } else if (config.length == 1) {
      if (name == 'sample_out' || name == 'report_out' || name == 'scene_out') {
        $(this).html(config[0]['id']);
      } else if (name == 'in') {
        $(this).html(config[0]['param']);
      } else if (name == 'sample_in') {
        $(this).html(config[0]);
      } else if (name == 'out') {
        $(this).html(config[0]['param']);
      }
    } else {
      $(this).html(config.length + inputs);
    }

  })
  $('.param_val').attr('disabled', $('.param_val').val() == '' ? true : false);
  if (modules[i][0]['param'] == undefined) {
    $('.parameters .table_content').html(`<ul class="fixclear">
    <li><span></span><input type="text" tabindex=-1></li>
    <li><span></span><input type="text" tabindex=-1></li>
  </ul>`)
    return;
  };
  $('.parameters .table_content').empty();
  for (let j = 0; j < modules[i][0]['param'].length; j++) {
    $('.parameters .table_content').append(`<ul class="fixclear">
    <li><span>`+ modules[i][0]['param'][j]['name'] + `</span><input type="text" tabindex=-1></li>
    <li><span>`+ modules[i][0]['param'][j]['value'] + `</span><input type="text" tabindex=-1></li>
  </ul>`)
  }
  $('.parameters .table_content>ul:nth-child(1)').addClass('blue');
  if (modules[i][0]['param'].length != 0) {
    $('.param_val').removeAttr('disabled').val(modules[i][0]['param'][0]['val']);
  }
  $('.parameters .table_content').append(`<ul class="fixclear">
    <li><span></span><input type="text" tabindex=-1></li>
    <li><span></span><input type="text" tabindex=-1></li>
  </ul>`);
}
$('.b_center input[type=checkbox]').on('click', function () {
  let name = $(this).attr('name');
  if ($(this).is(':checked')) {
    modules[$('.module_content>p.active').index()][0][name] = 'yes';
    if(name == 'enabled') $('.module_content .active>span:nth-child(1)').html('(O)');
  } else {
    modules[$('.module_content>p.active').index()][0][name] = 'no';
    if(name == 'enabled') $('.module_content .active>span:nth-child(1)').html('(X)');
  }

})
$('.close').on('click', function () {
  let name = $(this).parent().parent().attr('class');
  let index = $('.module_content>p.active').index();
  let arr = [];
  switch (name) {
    case 'in':
      for (let i = 0; i < $('.in>div:nth-child(2)>div').length; i++) {
        let div = $('.in>div:nth-child(2)>div').eq(i);
        if (div.find('[name=param]').val() != '' && div.find('[name=signal]').html().indexOf('(') == -1) {
          arr.push({ 'signal': div.find('[name=signal]').attr('id'), 'param': div.find('[name="param"]').val(), 'default_val': div.find('[name="default_val"]').val(), 'nearest': div.find('[name^="nearest"]:checked').val() })
        }
      }
      $('a.in').html(arr.length > 0 ? (arr.length == 1 ? arr[0].param : arr.length + inputs) : none);
      modules[index][1]['content']['in'] = arr;
      break;
    case 'sample_in':
      $('a.sample_in').html($('.sample_content>p').length > 0 ? ($('.sample_content>p').length == 1 ? $('.sample_content>p').html() : $('.sample_content>p').length + inputs) : none);
      $('.sample_in button').attr('disabled', true);
      $('[name = protocal]').val('');
      $('[name="protocal_channel"]').val(-1);
      for (let i = 0; i < $('.sample_content>p').length; i++) {
        arr.push($('.sample_content>p').eq(i).html());
      }
      modules[index][1]['content']['sample_in'] = arr;
      break;
    case 'out':
      $('.out input').each(function () {
        if ($(this).val() != '' && !$(this).hasClass('red')) {
          arr.push({ 'param': $(this).val() });
        } else if ($(this).hasClass('red') && modules[index][1]['content']['out'][$(this).parent().index()]) {
          arr.push({ 'param': modules[index][1]['content']['out'][$(this).parent().index()]['param'] });
        }
      })
      modules[index][1]['content']['out'] = arr;
      $('a.out').html(arr.length > 0 ? (arr.length == 1 ? arr[0]['param'] : arr.length + inputs) : none);
      break;
    case 'sample_out':
      for (let i = 0; i < $('.sample_out .table_content>ul').length; i++) {
        let out_sample_obj = {};
        out_sample_obj['id'] = $('.sample_out .table_content>ul').eq(i).find('li').eq(1).find('span').html();
        out_sample_obj['name'] = $('.sample_out .table_content>ul').eq(i).find('li').eq(2).find('span').html();
        out_sample_obj['val'] = $('.sample_out .table_content>ul').eq(i).find('li').eq(3).find('span').html();
        arr.push(out_sample_obj);
      }
      $('a.sample_out').html(arr.length > 0 ? (arr.length == 1 ? arr[0]['id'] : arr.length + inputs) : none);
      modules[index][1]['content']['sample_out'] = arr;
      break;
    case 'scene_out':
      for (let i = 0; i < $('.scene_out .table_content>ul').length - 1; i++) {
        let out_sample_obj = {};
        let span = $('.scene_out .table_content>ul').eq(i).find('li').eq(1).find('span').html();
        if (span != '' && !regEn.test(span) && !regCn.test(span) && !regNum.test(span)) {
          out_sample_obj['id'] = span;
          out_sample_obj['val'] = $('.scene_out .table_content>ul').eq(i).find('li').eq(2).find('span').html();
          arr.push(out_sample_obj);
        };
      }
      $('a.scene_out').html(arr.length > 0 ? (arr.length == 1 ? arr[0]['id'] : arr.length + inputs) : none);
      modules[index][1]['content']['scene_out'] = arr;
      break;
    case 'report_out':
      for (let i = 0; i < $('.report_out_content>div').length; i++) {
        let boxVal = [];
        let id = Number($('.report_out_content>div').eq(i).attr('id'))
        let obj = {};
        obj['id'] = $('.report_out_content>div').eq(i).find('[name=id]').html();
        obj['type'] = $('.report_out_content>div').eq(i).find('div>div:nth-child(1)>span:nth-child(2)').attr('type');
        if (!$('.report_out_content>div').eq(i).find('[name=report_title]').hasClass('red')) {
          obj['title'] = $('.report_out_content>div').eq(i).find('[name=report_title]').val();
        } else {
          obj['title'] = modules[index][1]['content']['report_out'][0]['title'];
        }
        switch (id) {
          case 1:
            obj['configs'] = '';
            obj['column_titles'] = "Value";
            break;
          case 2:
            let XLabels = $('.report_out_content>div').eq(i).find('[name="XLabels"]').val();
            boxVal = [$('.report_out_content>div').eq(i).find('[name="histogram_mode"]').val(), $('.report_out_content>div').eq(i).find('[name=hist_x_title]').val(), $('.report_out_content>div').eq(i).find('[name="hist_defaultval"]').eq(0).val(), $('.report_out_content>div').eq(i).find('[name="hist_defaultval"]').eq(1).val(), 'XValues', $('.report_out_content>div').eq(i).find('[name="XValues"]').eq(0).val(), $('.report_out_content>div').eq(i).find('[name="XValues"]').eq(1).val(), $('.report_out_content>div').eq(i).find('[name="XValues"]').eq(2).val()]
            if (XLabels != '') boxVal.push('XLabels', XLabels);
            obj['configs'] = boxVal;
            obj['column_titles'] = [$('.report_out_content>div').eq(i).find('[name="column_titles"]').eq(0).val(), 'Aux', $('.report_out_content>div').eq(i).find('[name="column_titles"]').eq(1).val(), 'Aux'];
            break;
          case 3:
            obj['configs'] = [$('.report_out_content>div').eq(i).find('[name=scatter_configs]').eq(0).val(), $('.report_out_content>div').eq(i).find('[name=scatter_configs]').eq(1).val(), $('.report_out_content>div').eq(i).find('[name=scatter_configs]').eq(3).val(), $('.report_out_content>div').eq(i).find('[name=scatter_configs]').eq(4).val(), $('.report_out_content>div').eq(i).find('[name=scatter_configs]').eq(2).val(), $('[name=scatter_configs]').eq(5).val()];
            obj['column_titles'] = [$('.report_out_content>div').eq(i).find('[name=scatter_title]').eq(0).val(), $('.report_out_content>div').eq(i).find('[name=scatter_title]').eq(1).val()];
            break;
          case 4:
            obj['configs'] = [$('.report_out_content>div').eq(i).find('[name=matrix_mode]').val()];
            for (let j = 0; j < 6; j++) {
              obj['configs'].push($('.report_out_content>div').eq(i).find('[name=matrix_val]').eq(j).val());
            }
            obj['configs'].push($('.report_out_content>div').eq(i).find('[name=matrix_range]').eq(0).val(), $('.report_out_content>div').eq(i).find('[name=matrix_range]').eq(1).val(), $('.report_out_content>div').eq(i).find('[name="martrix_title"]').eq(0).val(), $('.report_out_content>div').eq(i).find('[name="martrix_title"]').eq(1).val(), $('.report_out_content>div').eq(i).find('[name="matrix_defaultval"]').val())
            obj['column_titles'] = "Value,Aux";
            break;
          case 5:
            obj['configs'] = [$('.report_out_content>div').eq(i).find('[name=label_mode]').val(), 1, 1, $('.report_out_content>div').eq(i).find('[name=label_val]').val(), $('.report_out_content>div').eq(i).find('[name="label_defaultval"]').val(), $('.report_out_content>div').eq(i).find('[name="label_title"]').eq(0).val(), $('.report_out_content>div').eq(i).find('[name="label_title"]').eq(1).val(), $('.report_out_content>div').eq(i).find('[name="label_word"]').eq(0).val(), $('.report_out_content>div').eq(i).find('[name="label_word"]').eq(1).val()];
            obj['column_titles'] = "Value,Aux";
            break;
        }
        arr.push(obj);
      }
      $('a.report_out').html(arr.length > 0 ? (arr.length == 1 ? arr[0]['id'] : arr.length + inputs) : none);
      modules[index][1]['content']['report_out'] = arr;
      break;
    case 'import_path':
      bi_common_js = 0;
      let text = [];
      for (let i = 0; i < $('.import_path_content>p').length; i++) {
        let html = $('.import_path_content>p').eq(i).html();
        biQueryFilesInDirectory(html);
        text.push(html);
      }
      bi_common_js == 0 ? $('[language=cant_find').show().removeClass('adisabled') : $('[language=cant_find').hide();
      biSetGlobalPath("PythonImportPathes", text)
      break;
  }
  $(this).parent().parent().hide();
  $('.trans').hide();
  setConfig();
})
$('.in').on('click', '.signal_list', function () {
  $(this).addClass('bdBlack').siblings().removeClass('bdBlack');
})
function biOnQueriedFilesInDirectory(files, path) {
  let dir = files[0].split('\n');
  for (let i in dir) {
    if (dir[i].indexOf('bi_common.py') != -1) {
      bi_common_js++;
    }
  }
  bi_common_js == 0 ? $('[language=cant_find').show().removeClass('adisabled') : $('[language=cant_find').hide();
}
function generateUUID() {
  var d = new Date().getTime();
  if (window.performance && typeof window.performance.now === "function") {
    d += performance.now(); //use high-precision timer if available
  }
  var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    var r = (d + Math.random() * 16) % 16 | 0;
    d = Math.floor(d / 16);
    return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
  });
  return uuid;
}
// language
$('a').on('click', function () {
  let name = $(this).attr('language');
  switch (name) {
    case 'input_remove_signal':
      $('.bdBlack').remove();
      break;
    case 'input_add_signal':
      let leng = $('.in>div').eq(1).find('div').length;
      $('.in>div').eq(1).append(`<div class="signal_list">
        <span class="red" language="in_param_name"></span>
        <input type="text" name="param" id="">
        <span language="default_val">默认值:</span>
        <input type="text" name="default_val" id="">
        <input type="radio" name="nearest`+ leng + `" id="" value="no"><span language="nearest">最近</span>
        <input type="radio" name="nearest`+ leng + `" id="" value="yes" checked><span language="chazhi">插值</span>
        <br>
        <span language="source_signal">来源信号:</span>
        <a href="javascript:;" language="not_config" class="red" name="signal">`+ not_config + `</a>
      </div>`);
      break;
    case 'remove_module':
      $('.sure p').html((biGetLanguage() == 1 ? "Are you sure to remove the module\"" : "是否移除模块\"") + $('.module_content>p.active>span:eq(1)').html() + "\"?").attr('title', $('.module_content>p.active>span:eq(1)').html());
      setConfig();
      $('.sure').show();
      break;
    case 'add_module':
      aDisabled('enabled');
      remove_modules.sort(sortNum);
      if (remove_modules != 0) {
        $('.module_content').append('<p id="' + remove_modules[0] + '"><span>(X)</span><span>Unknown Script ' + (remove_modules[0] == 1 ? '' : remove_modules[0]) + ' </span></p>');
        $('.b_center [name=name]').val('Unknown Script ' + (remove_modules[0] == 1 ? '' : remove_modules[0]));
        remove_modules.shift();
      } else {
        let i = $('.module_content>p').length + 1;
        $('.module_content').append('<p id="' + i + '"><span>(X) </span><span>Unknown Script ' + (i == 1 ? '' : i) + ' </span></p>');
        $('.b_center [name=name]').val('Unknown Script ' + (i == 1 ? '' : i));
      }
      $('.module_content>p').eq($('.module_content>p').length - 1).addClass('active').siblings().removeClass('active');
      $('.io a').html(none);
      $('.basic select').val(10);
      modules.push([{ 'enabled': 'no', 'id': generateUUID(), 'name': $('.module_content>p.active>span:eq(1)').html(), 'param': [], 'type_auto_conversion': "yes", 'freq': "10" }, { 'content': {} }]);
      getContentVal($('.module_content>p.active'));
      $('.param_val').prop('disabled', true);
      setConfig();
      break;
    case 'input_remove_sample':
      $('[language=add_sample]').removeAttr('disabled');
      $('.sample_in .active').remove();
      break;
    case 'output_add_sample':
      $('.out>div:nth-child(3)').append(`<div class="out_list"><span language="param_name" class="red"></span><input type="text" name="param"></div>`);
      $('.out_list').eq($('.out_list').length - 1).addClass('bdBlack').siblings().removeClass('bdBlack')
      break;
    case 'output_remove_sample':
      $('.out .bdBlack').remove();
      break;
    case 'import_module':
      biSelectPath('import_module', BISelectPathType.OpenFile, { '.asmc': '*.asmc' });
      break;
    case 'import_code':
      let i = $('.module_content p.active').index();
      biSelectPath('import_code', BISelectPathType.OpenFile, { '.py': 'Python script' });
      break;
    case 'export_code':
      biSelectPath('export_code', BISelectPathType.CreateFile, { '.py': 'Python script' });
      break;
    case 'import_path': {
      $('.import_path,.trans').show();
      break;
    }
    case 'export_module': {
      biSelectPath('export_module', BISelectPathType.CreateFile, { '.asmc': 'Aseva Module Config' });
    }
  }
})
function aDisabled(enabled) {
  if (enabled == 'enabled') {
    $('input,select,textarea').removeAttr('disabled');
    $('.container span,.container a').removeClass('adisabled');
    $('a[language="save"],a[language="abort"]').addClass('adisabled');
  } else {
    $('input,select,textarea').attr('disabled', true);
    $('textarea').val('');
    $('.io a').html(none);
    $('.container span,.container a').addClass('adisabled');
    $('[language="add_module"],[language=import_module],[language=import_path]').removeClass('adisabled');
  }
}
function biOnSelectedPath(key, path) {
  switch (key) {
    case 'import_module': {
      biQueryFileText(path);
      break;
    }
    case 'import_code': {
      biQueryFileText(path);
      break;
    }
    case 'export_code': {
      let i = $('.loop_list>li.checked').index();
      let val = $('.loop_list_content>div').eq(i).find('textarea').val();
      biWriteFileText(path, val);
      break;
    }
    case 'add_path': {
      if (path != null) {
        let count = 0;
        for (let i = 0; i < $('.import_path_content>p').length; i++) {
          if ($('.import_path_content>p').eq(i).html() == path) count++;
        }
        if (count == 0) {
          $('.import_path_content').append('<p>' + path + '</p>');
        } else {
          biAlert('Path already exists.')
        }
      }
      break;
    }
    case 'export_module': {
      let outHtml = '', text = '';
      outHtml += "<?xml version=\"1.0\" encoding=\"utf-8\"?><root type=\"python-script-function\">";
      text = `<?xml version="1.0" encoding="utf-8"?>`;
      let moduleI = modules[$('.module_content>p.active').index()];
      text += "<root "
      for (let j in moduleI[0]) {
        if (j != 'param' && j != 'cmd' && j != 'cmd_start' && j != 'cmd_end') {
          text += j + "=\"" + moduleI[0][j] + "\" ";
        }
      }
      text += ">"
      for (let j in moduleI[0]['param']) {
        text += "<param name=\"" + moduleI[0]['param'][j]['name'] + "\"" + " value=\"" + moduleI[0]['param'][j]['value'] + "\">" + moduleI[0]['param'][j]['val'] + "</param>";
      }
      if (moduleI[1]['content'] == '') return;
      for (let j in moduleI[1]['content']) {
        switch (j) {
          case 'in': {
            for (let k in moduleI[1]['content'][j]) {
              text += "<in signal=\"" + moduleI[1]['content'][j][k]['signal'] + "\" nearest=\"" + moduleI[1]['content'][j][k]['nearest'] + "\" param=\"" + moduleI[1]['content'][j][k]['param'] + "\" default_val=\"" + moduleI[1]['content'][j][k]['default_val'] + "\" />";
            }
            break;
          }
          case 'out': {
            for (let k in moduleI[1]['content'][j]) {
              text += "<out param=\"" + moduleI[1]['content'][j][k]['param'] + "\" />";
            }
            break;
          }
          case 'sample_in': {
            for (let k in moduleI[1]['content'][j]) {
              text += "<sample_in>" + moduleI[1]['content'][j][k] + "</sample_in>";
            }
            break;
          }
          case 'sample_out': {
            for (let k in moduleI[1]['content'][j]) {
              text += "<sample_out id=\"" + moduleI[1]['content'][j][k]['id'] + "\" name=\"" + moduleI[1]['content'][j][k]['name'] + "\"></sample_out>";
            }
            break;
          }
          case 'scene_out': {
            for (let k in moduleI[1]['content'][j]) {
              text += "<scene_out id=\"" + moduleI[1]['content'][j][k]['id'] + "\">" + moduleI[1]['content'][j][k]['val'] + "</scene_out>";
            }
            break;
          }
          case 'report_out': {
            for (let k in moduleI[1]['content'][j]) {
              text += "<report_out id=\"" + moduleI[1]['content'][j][k]['id'] + "\" type=\"" + moduleI[1]['content'][j][k]['type'] + "\" title=\"" + moduleI[1]['content'][j][k]['title'] + "\" configs=\"" + moduleI[1]['content'][j][k]['configs'] + "\" column_titles=\"" + moduleI[1]['content'][j][k]['column_titles'] + "\" />"
            }
            break;
          }
        }
      }
      text += "<cmd>" + (moduleI[0]['cmd'] == '' || moduleI[0]['cmd'] == undefined ? '' : getEncode64(moduleI[0]['cmd'])) + "</cmd>";
      text += "<cmd_start>" + (moduleI[0]['cmd_start'] == '' || moduleI[0]['cmd_start'] == undefined ? '' : getEncode64(moduleI[0]['cmd_start'])) + "</cmd_start>";
      text += "<cmd_end>" + (moduleI[0]['cmd_end'] == '' || moduleI[0]['cmd_end'] == undefined ? '' : getEncode64(moduleI[0]['cmd_end'])) + "</cmd_end>";
      text += "</root>"
      outHtml += getEncode64(text);
      outHtml += "</root>";
      biWriteFileText(path, outHtml);
    }
      break;
  }
}

function biOnQueriedFileText(text, path) {
  if (path.indexOf('.asmc') != -1) {
    aDisabled('enabled');
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(text, "text/xml");
    let config = getDecode(xmlDoc.childNodes[0].innerHTML);
    xmlDoc = parser.parseFromString(config, "text/xml")
    let countrys = xmlDoc.getElementsByTagName('root');
    let obj = {};
    let arrConfig = [];
    let count = 0;
    let keys = countrys[0].getAttributeNames();
    for (let n = 0; n < keys.length; n++) {
      obj[keys[n]] = countrys[0].getAttribute(keys[n]);
      if (keys[n] == 'id') {
        let id = countrys[0].getAttribute(keys[n]);
        for (let i in modules) {
          if (modules[i][0]['id'] == id) count++;
        }
      }
    }
    if (count != 0) {
      biAlert('Module with the same ID and the same name exist:' + path, 'Error');
    } else {
      arrConfig.push(obj, { 'content': {} });
      let sample_in = [], scene_out = [], sample_out = [], signal_in = [], signal_out = [], report_out = [], param = [], cmd = '', cmd_start = '', cmd_end = '';
      for (let j = 0; j < countrys[0].childNodes.length; j++) {
        let keyss = countrys[0].childNodes[j].getAttributeNames();
        let innerHtml = countrys[0].childNodes[j].innerHTML;
        obj = {};
        let nodeName = countrys[0].childNodes[j].localName;
        switch (nodeName) {
          case 'sample_in': {
            sample_in.push(innerHtml)
            break;
          }
          case 'scene_out': {
            for (let i in keyss) {
              obj[keyss[i]] = countrys[0].childNodes[j].getAttribute(keyss[i]);
              obj['val'] = innerHtml;
            }
            scene_out.push(obj);
            break;
          }
          case 'sample_out': {
            for (let i in keyss) {
              obj[keyss[i]] = countrys[0].childNodes[j].getAttribute(keyss[i]);
            }
            sample_out.push(obj);
            break;
          }
          case 'report_out': {
            for (let i in keyss) {
              obj[keyss[i]] = countrys[0].childNodes[j].getAttribute(keyss[i]);
            }
            report_out.push(obj);
            break;
          }
          case 'in': {
            for (let i in keyss) {
              obj[keyss[i]] = countrys[0].childNodes[j].getAttribute(keyss[i]);
            }
            signal_in.push(obj);
            break;
          }
          case 'out': {
            for (let i in keyss) {
              obj[keyss[i]] = countrys[0].childNodes[j].getAttribute(keyss[i]);
            }
            signal_out.push(obj);
            break;
          }
          case 'param': {
            for (let i in keyss) {
              obj[keyss[i]] = countrys[0].childNodes[j].getAttribute(keyss[i]);
            }
            obj['val'] = innerHtml;
            param.push(obj);
            break;
          }
          case 'cmd': {
            cmd += getDecode(innerHtml) + '\n\n';
            break;
          }
          case 'cmd_start': {
            cmd_start += getDecode(innerHtml) + '\n\n';
            break;
          }
          case 'cmd_end': {
            cmd_end += getDecode(innerHtml) + '\n\n';
            break;
          }
        }
      }
      arrConfig[0]['param'] = param;
      arrConfig[1].content['in'] = signal_in;
      arrConfig[1].content['scene_out'] = scene_out;
      arrConfig[1].content['sample_out'] = sample_out;
      arrConfig[1].content['out'] = signal_out;
      arrConfig[1].content['report_out'] = report_out;
      arrConfig[1].content['sample_in'] = sample_in;
      arrConfig[0]['cmd'] = cmd;
      arrConfig[0]['cmd_start'] = cmd_start;
      arrConfig[0]['cmd_end'] = cmd_end;
      modules.push(arrConfig);
      $('.module_content>p').removeClass('active');
      $('.module_content').append('<p class="active"><span>' + (arrConfig[0]['enabled'] == 'yes' ? '(O)' : '(X)') + '</span><span>' + arrConfig[0]['name'] + '</span></p>');
      getContentVal($('.module_content>p.active'));
      $('.parameters .title>.left').addClass('blue2');
      $('.parameters .table_content>ul').eq(0).addClass('blue');
    }
  } else if (path.indexOf('.py') != -1) {
    let i = $('.loop_list>li.checked').index();
    $('.loop_list_content>div').eq(i).find('textarea').val(text);
    $('[language="save"],[language="abort"]').removeClass('adisabled');
    $('.module_content>p,[language="add_module"],[language="import_module"],[language="export_module"],[language="remove_module"]').addClass('adisabled');
  }
  setConfig();
}
//in
$('.in>div:nth-child(2)').on('click', 'div a[name = signal]', function () {
  let key = $(this).parent().index();
  let id = $(this).attr('id');
  biSelectSignal(key, id, false, false, false, false, false)
})
$('.in').on('input', '.signal_list [name="param"]', function () {
  $(this).val() != '' ? $(this).prev().removeClass('red') : $(this).prev().addClass('red');
})
function biOnSelectedSignal(key, valueSignalInfo, signBitSignalInfo, scale) {
  if (valueSignalInfo != null && valueSignalInfo.typeName == null) return;
  if (valueSignalInfo == null) {
    $('.in>div:nth-child(2)>div').eq(Number(key) - 3).find('a[name=signal]').html(not_config).addClass('red').removeClass('green').removeAttr('id title');
  } else {
    $('.in>div:nth-child(2)>div').eq(Number(key) - 3).find('a[name=signal]').html(valueSignalInfo.typeName + ':' + valueSignalInfo.signalName).removeClass('red').addClass('green').attr('id', valueSignalInfo.id).attr('title', valueSignalInfo.typeName + ':' + valueSignalInfo.signalName);
  }
}
// class
$('a').on('click', function () {
  let name = $(this).attr('class');
  let pIndex = $('.module_content>p.active').index();
  let val = modules[pIndex][1]['content'][name];
  switch (name) {
    case 'in':
      $('.in>div').eq(1).find('div').remove();
      for (let i in val) {
        biQuerySignalInfo(i, val[i]['signal']);
        $('.in>div').eq(1).append(`<div class="signal_list">
        <span language="param_name"></span>
        <input type="text" name="param" id="" value="`+ val[i]['param'] + `">
        <span language="default_val"></span>
        <input type="text" name="default_val" value="`+ val[i]['default_val'] + `" id="">
        <input type="radio" name="nearest`+ i + `" id="" value="no"><span language="nearest"></span>
        <input type="radio" name="nearest`+ i + `" id="" value="yes"><span language="chazhi"></span>
        <br>
        <span language="source_signal"></span>
        <a href="javascript:;" language="not_config" id="`+ val[i]['signal'] + `" name="signal"></a></div>`);
        $("[name='nearest" + i + "'][value='" + val[i]["nearest"] + "']").prop('checked', true);
      }
      $('div.in,.trans').show();
      break;
    case 'sample_in':
      $('.sample_in .sample_content').empty();
      for (let i in val) {
        $('.sample_in .sample_content').append("<p>" + val[i] + "</p>");
      }
      $('div.sample_in,.trans').show();
      break;
    case 'out':
      $('.out>div:nth-child(3)').empty();
      for (let i in val) {
        $('.out>div:nth-child(3)').append(`<div class="out_list"><span language="param_name"></span><input type="text" name="param" value="` + val[i]['param'] + `"></div>`);
      }
      $('div.out,.trans').show();
      break;
    case 'sample_out':
      $('.sample_out .table_content').empty();
      for (let i in val) {
        for (let k in val[i]) {
          if (val[i][k] == undefined || val[i][k] == '') val[i][k] == '';
        }
        if (val[i]['val'] == "undefined" || val[i]['val'] == undefined || val[i]['val'] == '') val[i]['val'] = '';
        $('.sample_out .table_content').append(`<ul class="fixclear"><li class="select"></li><li><span title="` + val[i]['id'] + `" id="` + val[i]['id'] + `">` + val[i]['id'] + `</span></li><li><span title="` + val[i]['name'] + `" name="name">` + val[i]['name'] + `</span><input type="text" tabindex=-1></li><li><span>` + val[i]['val'] + `</span> <input type="text" class="text" tabindex=-1></li></ul>`)
      }
      $('[name=output_protocal]').val('');
      $('[name=output_protocal_channel]').val(-1);
      $('div.sample_out,.trans').show();
      break;
    case 'scene_out':
      $('.scene_out .table_content').empty();
      $('div.scene_out,.trans').show();
      for (let i in val) {
        $('.scene_out .table_content').append(`<ul class="fixclear">
        <li></li><li><span>`+ val[i]['id'] + `</span><input type="text" name="id" tabindex=-1></li><li><span>` + (val[i]['val'] == undefined ? '' : val[i]['val']) + `</span><input type="text" tabindex=-1></li></ul>`);
      }
      $('.scene_out .table_content').append(`<ul class="fixclear">
        <li></li><li><span></span><input type="text" name="id"></li><li><span></span><input type="text"></li></ul>`);
      break;
    case 'report_out':
      $('.report_out_content').empty();
      $('div.report_out,.trans').show();
      for (let i in val) {
        let configs = (Array.isArray(val[i]['configs'])) ? val[i]['configs'] : val[i]['configs'].split(',');
        let column_titles = (Array.isArray(val[i]['column_titles'])) ? val[i]['column_titles'] : val[i]['column_titles'].split(',');
        switch (val[i]['type']) {
          case 'SingleValue':
            $('.report_out_content').append(`<div class="single_val fixclear" id="1"><div><div class="left"><span language="report_name" class="left" name="id">` + val[i]['id'] + `</span><span language="SingleValue" class="right" type="SingleValue">` + val[i]['type'] + `</span><br><span language="title"></span><input type="text" name="report_title" value="` + val[i]['title'] + `"></div><div class="right"><button class="del">DEL</button></div></div></div>`);
            break;
          case "HistAndLine":
            $('.report_out_content').append(` <div class="histogram fixclear" id="2"><div class="fixclear"><div class="left">
            <span language="report_name" class="left" name="id">`+ val[i]['id'] + `</span><span language="hist_report" class="right" type="HistAndLine"></span><br><span language="title"></span><input type="text" name="report_title" value="` + val[i]['title'] + `"></div>
          <div class="right"><button class="del">DEL</button></div>
        </div>
        <div class="left title_left">
          <span language="x_title"></span><input type="text" name="hist_x_title" value="`+ configs[1] + `">
          <span language="mode"></span><select name="histogram_mode">
            <option value="Sum">Sum</option>
            <option value="Aver">Aver</option>
            <option value="Min">Min</option>
            <option value="Max">Max</option>
            <option value="Percentage">Percentage</option>
            <option value="HitRatio">HitRatio</option>
            <option value="SumAndSum">SumAndSum</option>
            <option value="MinAndMin">MinAndMin</option>
            <option value="MinAndMax">MinAndMax</option>
            <option value="MaxAndMax">MaxAndMax</option>
            <option value="AverAndMin">AverAndMin</option>
            <option value="AverAndMax">AverAndMax</option>
            <option value="AverAndAver">AverAndAver</option>
            <option value="AverAndDev">AverAndDev</option>
          </select>
          <span language="hist_title"></span><input type="text" name="column_titles" value="`+ column_titles[0] + `">
          <span language="histogram_title"></span><input type="text" name="column_titles" class="histogram_disabled" value="`+ (column_titles[2] == undefined ? 'Line title' : column_titles[2]) + `" disabled>
        </div>
        <div class="left">
          <span language="x_values">刻度:</span>
          <ul class="hist_list fixclear">
            <li language="numeric_mode">数值</li>
            <li class="hist_list_li_other" language="label_mode">文字</li>
          </ul>
          <div class="hist_list_content">
            <div class="item">
              <span language="xiayan">下沿</span>
              <input type="text" name="XValues" value="`+ configs[5] + `">
              <span language="jiange">间隔</span>
              <input type="text" name="XValues" value="`+ configs[6] + `">
              <span language="geshu">格数</span>
              <input type="text" name="XValues" value="`+ configs[7] + `">
            </div>
            <div class="item">
              <span language="title_split">文字标签(逗号分隔):</span>
              <input type="text" name="XLabels" value="`+ (configs[9] == undefined ? '' : configs[9]) + `">
            </div>
          </div>
          <span language="hist_def_val">默认值:</span><input type="text"  name="hist_defaultval" value="`+ configs[2] + `" >
          <br>
          <span language="line_def_val">默认值:</span><input type="text" value="`+ configs[3] + `" name="hist_defaultval" class="histogram_disabled" disabled>
        </div>
      </div>`);
            $('.report_out_content>div').eq($('.report_out_content>div').length - 1).find('[name="histogram_mode"]').val(configs[0]);
            break;
          case 'ScatterPoints':
            $('.report_out_content').append(`<div class="scatter_diagram fixclear" id="3"><div class="fixclear"><div class="left"><span language="report_name" class="left" name="id">` + val[i]['id'] + `</span><span language="scatter_report" class="right" type="ScatterPoints">散点图报告</span><br><span language="title"></span><input type="text" name="report_title" value="` + val[i]['title'] + `"></div><div class="right"><button class="del">DEL</button></div></div><div class="left title_left"><span language="x_title"></span><input type="text" name="scatter_title" value="` + column_titles[0] + `"><span language="y_title">Y轴标题</span><input type="text" name="scatter_title" value="` + column_titles[1] + `"></div>
        <div class="left"><span language="x_xiayan">范围下沿:</span><input type="text"  value="` + configs[0] + `" name="scatter_configs"><span language="x_shangyan">范围上沿:</span><input type="text"  value="` + configs[1] + `" name="scatter_configs"><span language="x_geshu">X格数:</span><input type="text"  value="` + configs[4] + `" name="scatter_configs"><span language="y_xiayan">Y轴范围下沿:</span><input type="text"  value="` + configs[2] + `" name="scatter_configs"><span language="y_shangyan">Y轴范围上沿:</span><input type="text"  value="` + configs[3] + `" name="scatter_configs"><span language="y_geshu">Y格数:</span><input type="text"  value="` + configs[5] + `" name="scatter_configs"></div></div>`);
            break;
          case 'MatrixTable':
            $('.report_out_content').append(`<div class="matrix_diagram fixclear" id="4">
        <div class="fixclear">
          <div class="left">
            <span language="report_name" class="left" name="id">` + val[i]['id'] + `</span>
            <span language="MatrixTable" class="right" type="MatrixTable">矩阵热力图报告</span>
            <br>
            <span language="title"></span>
            <input type="text" name="report_title" value="` + val[i]['title'] + `">
          </div>
          <div class="right">
            <button class="del">DEL</button>
          </div>
        </div>
        <div class="left title_left">
          <span language="x_title"></span><input type="text" name="martrix_title" value="` + configs[9] + `">
          <span language="y_title">Y轴标题</span><input type="text" name="martrix_title" value="` + configs[10] + `">
          <span language="mode"></span><select name="matrix_mode">
            <option value="Sum">Sum</option>
            <option value="Aver">Aver</option>
            <option value="Min">Min</option>
            <option value="Max">Max</option>
            <option value="Percentage">Percentage</option>
          </select>
        </div>
        <div class="left">
          <span language="xiayan">下沿</span><input type="text" name="matrix_val" value="` + configs[1] + `">
          <span language="jiange">间隔</span><input type="text" name="matrix_val" value="` + configs[2] + `">
          <span language="geshu">格数</span><input type="text" name="matrix_val" value="` + configs[3] + `">
          <span language="xiayan">下沿</span><input type="text" name="matrix_val" value="` + configs[4] + `">
          <span language="jiange">间隔</span><input type="text" name="matrix_val" value="` + configs[5] + `">
          <span language="geshu">格数</span><input type="text" name="matrix_val" value="` + configs[6] + `">
          <div class="bottom"><span language="matrix_fanwei">数值显示范围:</span><input type="text" value="` + configs[7] + `" name="matrix_range">~<input type="text" value="` + configs[8] + `"  name="matrix_range"><span language="hist_def_val">默认值</span><input type="text" value="` + configs[11] + `" name="matrix_defaultval"></div></div></div>`);
            $('.report_out_content>div').eq($('.report_out_content>div').length - 1).find('[name="matrix_mode"]').val(configs[0])
            break;
          case 'LabelTable':
            $('.report_out_content').append(`<div class="table_diagram fixclear" id="5">
        <div class="fixclear">
          <div class="left">
            <span language="report_name" class="left" name="id">`+ val[i]['id'] + `</span>
            <span language="LabelTable" class="right" type="LabelTable">表格热力图报告</span>
            <br>
            <span language="title"></span>
            <input type="text" name="report_title" value="`+ val[i]['title'] + `">
          </div>
          <div class="right">
            <button class="del">DEL</button>
          </div>
        </div>
        <div class="left title_left">
          <span language="x_title"></span><input type="text" name="label_title" value="`+ configs[5] + `">
          <span language="y_title">Y轴标题</span><input type="text" name="label_title" value="`+ configs[6] + `">
          <span language="mode"></span><select name="label_mode">
            <option value="Sum">Sum</option>
            <option value="Aver">Aver</option>
            <option value="Min">Min</option>
            <option value="Max">Max</option>
            <option value="Percentage">Percentage</option>
          </select>
        </div>
        <div class="left">
          <span language="title_split">文字标签(逗号分隔)</span><input type="text" name="label_word" value="`+ configs[7] + `">
          <span language="title_split">文字标签(逗号分隔)</span><input type="text" name="label_word" value="`+ configs[8] + `">
          <div class="bottom">
            <span language="val_direction">数值方向:</span>
            <select name="label_val">
              <option value="0">Positive</option>
              <option value="1">Negative</option>
              <option value="2">Bidirectional</option>
            </select>
            <span language="hist_def_val">默认值:</span><input type="text" name="label_defaultval" value="`+ configs[4] + `">
          </div>
        </div>
      </div>`);
            $('.report_out_content>div').eq($('.report_out_content>div').length - 1).find('[name="label_mode"]').val(configs[0]);
            $('.report_out_content>div').eq($('.report_out_content>div').length - 1).find('[name="label_val"]').val(configs[3]);
            break;
        }
      }
      $('[name="histogram_mode"]').each(function () {
        histogramModeChange(this);
      })
      break;
  }
  $('[name=default_val]').each(function () {
    isNaN(Number($(this).val())) ? $(this).addClass('red') : $(this).removeClass('red');
  })
})
function biOnQueriedSignalInfo(key, signalInfo) {
  let signal = $('.in>div>div').eq(Number(key)).find('a[name=signal]');
  if (signalInfo == null) {
    signal.html(signal.attr('id')).addClass('red').removeClass('green');
  } else {
    signal.html(signalInfo.typeName + ":" + signalInfo.signalName).addClass('green').removeClass('red');
  }
}
$('.sample_in button').on('click', function () {
  let name = $(this).attr('language');
  switch (name) {
    case 'add_sample':
      let html = $('[name="protocal"]').val() + ($('[name=protocal_channel]').val() == -1 ? '' : '@' + $('[name=protocal_channel]').val());
      $('.sample_content').append('<p name="' + html + '">' + html + '</p>');
      $('.sample_in button').attr('disabled', true);
      break;
    case 'reload_sample':
      $('.sample_in .active').eq(0).html($('[name="protocal"]').val() + ($('[name=protocal_channel]').val() == -1 ? '' : '@' + $('[name=protocal_channel]').val()));
      $('.sample_in button').attr('disabled', true);
      break;
  }
})
$('[name=protocal]').on('input', function () {
  if ($(this).val() == '' || regEn.test($(this).val()) || regCn.test($(this).val()) || regNum.test($(this).val())) {
    $('[language = add_sample],[language="reload_sample"]').attr('disabled', true);
  } else {
    let val = $(this).val() + ($('[name=protocal_channel]').val() == '' ? '' : ('@' + $('[name=protocal_channel]').val()));
    if ($('.sample_content>p').length > 0) {
      let count = 0;
      $('.sample_content>p').each(function () {
        if (val == $(this).html()) count++;
      })
      if (count == 0) {
        $('[language = add_sample]').removeAttr('disabled');
      } else {
        $('[language = add_sample]').attr('disabled', true);
      }
      if ($('.sample_in .active').html()) {
        $('.sample_in button').removeAttr('disabled')
      }
    } else {
      $('[language = add_sample]').removeAttr('disabled');
    }
  }
})
$('[name="protocal_channel"]').change(function () {
  if ($('[name="protocal"]').val() == '' || regEn.test($('[name="protocal"]').val()) || regCn.test($('[name="protocal"]').val()) || regNum.test($('[name="protocal"]').val())) {
    $('[language = add_sample],[language="reload_sample"]').attr('disabled', true);
  } else {
    let val = $('[name=protocal]').val() + ($(this).val() == '' ? '' : ('@' + $(this).val()));
    if ($('.sample_content>p').length > 0) {
      let count = 0;
      $('.sample_content>p').each(function () {
        if (val == $(this).html()) count++;
      })
      if (count == 0) {
        $('[language = add_sample]').removeAttr('disabled');
      } else {
        $('[language = add_sample]').attr('disabled', true);
      }
    } else {
      $('[language = add_sample]').removeAttr('disabled');
    }
  }
})
$('.sample_content').on('click', 'p', function () {
  let proVal = $(this).html().indexOf('@') == -1 ? $(this).html().length : $(this).html().indexOf('@');
  let chaVal = $(this).html().indexOf('@') == -1 ? -1 : Number($(this).html().substr($(this).html().indexOf('@') + 1));
  $(this).addClass('active').siblings().removeClass('active');
  $('[name=protocal]').val($(this).html().substr(0, proVal));
  $('[name = protocal_channel]').val(chaVal);
})
$('.out').on('click', '.out_list', function () {
  $(this).addClass('bdBlack').siblings().removeClass('bdBlack');
})
$('.out').on('input', 'input', function () {
  $(this).val() != '' ? $(this).prev().removeClass('red') : $(this).prev().addClass('red');
  if (regEn.test($(this).val()) || regCn.test($(this).val()) || regNum.test($(this).val())) {
    $(this).addClass('red');
  } else {
    $(this).removeClass('red');
  }
})
//选中一行删掉一行
$('body').keydown(function (event) {
  let e = event || window.event;
  if (e.keyCode == 46) {
    if ($('.all').hasClass('flag')) {
      let i = 0;
      while (i < $('.table>ul').length - 1) {
        $('.table>ul')[i].remove();
        i = 0;
      }
    } else {
      if ($('.blue2').parents().hasClass('parameters')) {
        modules[$('.module_content>p.active').index()][0]['param'].splice($('.parameters .table_content>ul.blue').index(), 1);
        $('.parameters .table_content>ul.blue').remove();
        setConfig();
      } else {
        if ($('.blue2').parents().hasClass('sample_out') && $('[name="output_protocal"]').val() != '') {
          $('[language="output_add_sample"]').removeAttr('disabled');
        }
        $('.blue2').parent().remove();
      }
    }
  }
  $('.all').removeClass('flag');
});
// sample_out
//选中输出通道别名，protocal和channel获取到值并改变
$('.sample_out>.table>.table_content').on('click', 'ul>li:nth-child(1)', function () {
  $(this).addClass('blue2').siblings().addClass('blue');
  $(this).siblings().find('span').addClass('white');
  $(this).parent().siblings().find('span').removeClass('white');
  $(this).parent().siblings().find('li').removeClass('blue blue2');
  let proVal = $(this).next().find('span').html().indexOf('@') == -1 ? $(this).next().find('span').html().length : $(this).next().find('span').html().indexOf('@');
  let chaVal = $(this).next().find('span').html().indexOf('@') == -1 ? -1 : Number($(this).next().find('span').html().substr($(this).next().find('span').html().indexOf('@') + 1));
  $('[name=output_protocal]').val($(this).next().find('span').html().substr(0, proVal));
  $('[name = output_protocal_channel]').val(chaVal);
})
$('.sample_out>.table>.table_content').on('click', 'ul>li>span', function (e) {
  if ($(this).parent().hasClass('blue') && $(this).parents('ul').find('.blue2').length == 0) {
    if ($(this).next().length != 0) {
      $(this).parent().removeClass('blue').siblings().removeClass('blue blue2');
      $(this).next().removeAttr('maxlength').show().val($(this).html()).select();
      $(this).hide();
    }
  } else {
    $(this).parents('.table').find('li').removeClass('blue blue2');
    $(this).parents('.table').find('span').removeClass('white');
    $(this).addClass('white').parent().addClass('blue').siblings().removeClass('blue2');
  }
})
$('.sample_out>.table>.table_content').on('blur', 'ul>li>input', function (e) {
  $(this).prev().show().html($(this).val()).removeClass('white').attr('title', $(this).val());
  $(this).hide().attr('maxlength', 0);
})
$('.sample_out button').on('click', function () {
  let name = $(this).attr('language');
  switch (name) {
    case 'output_add_sample':
      let html = $('[name="output_protocal"]').val() + ($('[name=output_protocal_channel]').val() == -1 ? '' : '@' + $('[name=output_protocal_channel]').val());
      let val = `<ul class="fixclear"><li class="select"></li><li><span title="` + html + `" id="` + html + `">` + html + `</span></li><li><span title="Unnamed Sample" name="name">Unnamed Sample</span><input type="text" tabindex=-1></li><li><span></span> <input type="text" class="text" tabindex=-1></li></ul>`;
      $(this).parents('.sample_out').find('.table>.table_content').append(val);
      $('.sample_out button').attr('disabled', true);
      break;
    case 'output_reload_sample':
      $('.sample_out .blue2').next().html("<span>" + $('[name="output_protocal"]').val() + ($('[name=output_protocal_channel]').val() == -1 ? '' : '@' + $('[name=output_protocal_channel]').val()) + "</span>");
      $('.sample_out button').attr('disabled', true);
      break;
  }
})
$('[name=output_protocal]').on('input', function () {
  if ($(this).val() == '' || regEn.test($(this).val()) || regCn.test($(this).val()) || regNum.test($('[name="output_protocal"]').val())) {
    $('[language = output_add_sample],[language="output_reload_sample"]').attr('disabled', true);
  } else {
    let val = $(this).val() + ($('[name=output_protocal_channel]').val() == -1 ? '' : ('@' + $('[name=output_protocal_channel]').val()));
    if ($('.sample_out>.table>.table_content>ul').length > 0) {
      let count = 0, selectCount = 0;
      $('.sample_out>.table>.table_content>ul>li:nth-child(2)>span').each(function () {
        if (val == $(this).html()) count++;
      })
      $('.sample_out>.table>.table_content>ul>li:nth-child(1)').each(function () {
        if ($(this).hasClass('blue2')) selectCount++;
      })
      if (count == 0) {
        $('[language = output_add_sample]').removeAttr('disabled');
        if (selectCount != 0) $('[language="output_reload_sample"]').removeAttr('disabled')
      } else {
        $('.sample_out button').attr('disabled', true);
      }
    } else {
      $('[language = output_add_sample]').removeAttr('disabled');
    }
  }
})
$('[name="output_protocal_channel"]').change(function () {
  if ($('[name="output_protocal"]').val() == '' || regEn.test($('[name="output_protocal"]').val()) || regCn.test($('[name="output_protocal"]').val()) || regNum.test($('[name="output_protocal"]').val())) {
    $('[language = output_add_sample],[language="output_reload_sample"]').attr('disabled', true);
  } else {
    let val = $('[name=output_protocal]').val() + ($(this).val() == -1 ? '' : ('@' + $(this).val()));
    if ($('.sample_out>.table>.table_content>ul').length > 0) {
      let count = 0, selectCount = 0;
      $('.sample_out>.table>.table_content>ul>li:nth-child(2)>span').each(function () {
        if (val == $(this).html()) count++;
      })
      $('.sample_out>.table>.table_content>ul>li:nth-child(1)').each(function () {
        if ($(this).hasClass('blue2')) selectCount++;
      })
      if (count == 0) {
        $('[language = output_add_sample]').removeAttr('disabled');
      } else {
        $('[language = output_add_sample]').attr('disabled', true);
      }
      if (val != $('.blue2').next().html() && selectCount != 0 && count == 0) {
        $('.sample_out [language=output_reload_sample]').removeAttr('disabled');
      } else {
        $('.sample_out [language=output_reload_sample]').attr('disabled', true);
      }
    } else {
      $('[language = output_add_sample]').removeAttr('disabled');
    }
  }
})
//scene_out
$('.scene_out>.table').on('click', 'ul>li>span', function (e) {
  if ($(this).parent().hasClass('blue') && $(this).parents('ul').find('.blue2').length == 0) {
    if ($(this).next().length != 0) {
      $(this).parent().removeClass('blue').siblings().removeClass('blue blue2');
      $(this).next().show().val($(this).html()).select();
      $(this).hide();
    }
  } else {
    $(this).parents('.table').find('li').removeClass('blue blue2').find('span').removeClass('white');
    $(this).addClass('white').parent().addClass('blue').siblings().removeClass('blue2');
  }
})
$('.scene_out>.table').on('input', 'input', function () {
  if ($(this).parent().parent().index() + 1 == $('.scene_out>.table>.table_content>ul').length) {
    $('.scene_out>.table>.table_content').append(`<ul class="fixclear"><li></li><li><span></span><input type="text" name="id" tabindex=-1></li><li><span></span><input type="text" tabindex=-1></li></ul>`)
  }
})
$('.scene_out>.table>.table_content').on('click', 'ul>li:nth-child(1)', function () {
  $(this).addClass('blue2').siblings().addClass('blue');
  $(this).siblings().find('span').addClass('white');
  $(this).parent().siblings().find('span').removeClass('white');
  $(this).parent().siblings().find('li').removeClass('blue blue2');
})
$('.scene_out>.table>.table_content').on('blur', 'ul>li>input', function (e) {
  $(this).prev().show().html($(this).val()).removeClass('white').attr('title', $(this).val());
  $(this).hide();
})
//output report
$('.report_out_content').on('click', '.hist_list>li', function () {
  $(this).removeClass('hist_list_li_other').siblings().addClass('hist_list_li_other');
  $(this).parent().next().find('.item').eq($(this).index()).show().siblings().hide();
})
$('.loop_list>li').on('click', function () {
  if ($('.loop_list_content>.item>textarea').attr('disabled')) return;
  $(this).removeClass('loop_list_other').addClass('checked').siblings().addClass('loop_list_other').removeClass('checked');
  $('.loop_list_content>.item').eq($(this).index()).show().siblings().hide();
})
$('a').on('click', function () {
  let lang = $(this).attr('language');
  switch (lang) {
    case 'add_single_val':
      $('.report_out_content').append(`<div class="single_val fixclear" id="1"><div><div class="left"><span language="report_name" class="left" name="id">` + $('[name=report_id]').val() + `</span><span language="SingleValue" class="right" type="SingleValue"></span><br><span language="title"></span><input type="text" name="report_title" value="Value report"></div><div class="right"><button class="del">DEL</button></div></div></div>`);
      break;
    case 'add_histogram':
      $('.report_out_content').append(` <div class="histogram fixclear" id="2">
      <div class="fixclear">
        <div class="left">
          <span language="report_name" class="left" name="id">`+ $('[name=report_id]').val() + `</span>
          <span language="hist_report" class="right" type="HistAndLine"></span>
          <br>
          <span language="title"></span>
          <input type="text" name="report_title" value="Hist-line report">
        </div>
        <div class="right">
          <button class="del">DEL</button>
        </div>
      </div>
      <div class="left title_left">
        <span language="x_title"></span><input type="text" name="hist_x_title" value="X title">
        <span language="mode"></span><select name="histogram_mode">
          <option value="Sum">Sum</option>
          <option value="Aver">Aver</option>
          <option value="Min">Min</option>
          <option value="Max">Max</option>
          <option value="Percentage">Percentage</option>
          <option value="HitRatio">HitRatio</option>
          <option value="SumAndSum">SumAndSum</option>
          <option value="MinAndMin">MinAndMin</option>
          <option value="MinAndMax">MinAndMax</option>
          <option value="MaxAndMax">MaxAndMax</option>
          <option value="AverAndMin">AverAndMin</option>
          <option value="AverAndMax">AverAndMax</option>
          <option value="AverAndAver">AverAndAver</option>
          <option value="AverAndDev">AverAndDev</option>
        </select>
        <span language="hist_title"></span><input type="text" name="column_titles" value="Hist title">
        <span language="histogram_title"></span><input type="text" name="column_titles" class="histogram_disabled" value="Line title" disabled>
      </div>
      <div class="left">
        <span language="x_values">刻度:</span>
        <ul class="hist_list fixclear">
          <li language="numeric_mode">数值</li>
          <li class="hist_list_li_other" language="label_mode">文字</li>
        </ul>
        <div class="hist_list_content">
          <div class="item">
            <span language="xiayan">下沿</span>
            <input type="text" name="XValues" value="0">
            <span language="jiange">间隔</span>
            <input type="text" name="XValues" value="10">
            <span language="geshu">格数</span>
            <input type="text" name="XValues" value="10">
          </div>
          <div class="item">
            <span language="title_split">文字标签(逗号分隔):</span>
            <input type="text" name="XLabels">
          </div>
        </div>
        <span language="hist_def_val">默认值:</span><input type="text"  name="hist_defaultval" value="0" >
        <br>
        <span language="line_def_val">默认值:</span><input type="text" value="0" name="hist_defaultval" class="histogram_disabled" disabled>
      </div>
    </div>`)
      break;
    case 'add_scatter_diagram':
      $('.report_out_content').append(`<div class="scatter_diagram fixclear" id="3"><div class="fixclear"><div class="left"><span language="report_name" class="left" name="id">` + $('[name=report_id]').val() + `</span><span language="scatter_report" class="right" type="ScatterPoints">散点图报告</span><br><span language="title"></span><input type="text" name="report_title" value="Scatter report"></div><div class="right"><button class="del">DEL</button></div></div><div class="left title_left"><span language="x_title"></span><input type="text" name="scatter_title" value="X title"><span language="y_title">Y轴标题</span><input type="text" name="scatter_title" value="Y title"></div>
      <div class="left"><span language="x_xiayan">范围下沿:</span><input type="text"  value="-50" name="scatter_configs"><span language="x_shangyan">范围上沿:</span><input type="text"  value="50" name="scatter_configs"><span language="x_geshu">X格数:</span><input type="text"  value="10" name="scatter_configs"><span language="y_xiayan">Y轴范围下沿:</span><input type="text"  value="-50" name="scatter_configs"><span language="y_shangyan">Y轴范围上沿:</span><input type="text"  value="50" name="scatter_configs"><span language="y_geshu">Y格数:</span><input type="text"  value="10" name="scatter_configs"></div></div>`);
      break;
    case 'add_matrix_diagram':
      $('.report_out_content').append(`<div class="matrix_diagram fixclear" id="4">
      <div class="fixclear">
        <div class="left">
          <span language="report_name" class="left" name="id">`+ $('[name=report_id]').val() + `</span>
          <span language="MatrixTable" class="right" type="MatrixTable">矩阵热力图报告</span>
          <br>
          <span language="title"></span>
          <input type="text" name="report_title" value="Matrix table report">
        </div>
        <div class="right">
          <button class="del">DEL</button>
        </div>
      </div>
      <div class="left title_left">
        <span language="x_title"></span><input type="text" name="martrix_title" value="X title">
        <span language="y_title">Y轴标题</span><input type="text" name="martrix_title" value="Y title">
        <span language="mode"></span><select name="matrix_mode">
          <option value="Sum">Sum</option>
          <option value="Aver">Aver</option>
          <option value="Min">Min</option>
          <option value="Max">Max</option>
          <option value="Percentage">Percentage</option>
        </select>
      </div>
      <div class="left">
        <span language="xiayan">下沿</span><input type="text" name="matrix_val" value="0">
        <span language="jiange">间隔</span><input type="text" name="matrix_val" value="10">
        <span language="geshu">格数</span><input type="text" name="matrix_val" value="10">
        <span language="xiayan">下沿</span><input type="text" name="matrix_val" value="0">
        <span language="jiange">间隔</span><input type="text" name="matrix_val" value="10">
        <span language="geshu">格数</span><input type="text" name="matrix_val" value="10">
        <div class="bottom"><span language="matrix_fanwei">数值显示范围:</span><input type="text" value="0" name="matrix_range">~<input type="text" value="100"  name="matrix_range"><span language="hist_def_val">默认值</span><input type="text" value="0" name="matrix_defaultval"></div></div></div>`);
      break;
    case 'add_table_diagram':
      $('.report_out_content').append(`<div class="table_diagram fixclear" id="5">
      <div class="fixclear">
        <div class="left">
          <span language="report_name" class="left" name="id">`+ $('[name=report_id]').val() + `</span>
          <span language="LabelTable" class="right" type="LabelTable">表格热力图报告</span>
          <br>
          <span language="title"></span>
          <input type="text" name="report_title" value="Label table report">
        </div>
        <div class="right">
          <button class="del">DEL</button>
        </div>
      </div>
      <div class="left title_left">
        <span language="x_title"></span><input type="text" name="label_title" value="X title">
        <span language="y_title">Y轴标题</span><input type="text" name="label_title" value="Y title">
        <span language="mode"></span><select name="label_mode">
          <option value="Sum">Sum</option>
          <option value="Aver">Aver</option>
          <option value="Min">Min</option>
          <option value="Max">Max</option>
          <option value="Percentage">Percentage</option>
        </select>
      </div>
      <div class="left">
        <span language="title_split">文字标签(逗号分隔)</span><input type="text" name="label_word" value="X1,X2,X3">
        <span language="title_split">文字标签(逗号分隔)</span><input type="text" name="label_word" value="Y1,Y2,Y3">
        <div class="bottom">
          <span language="val_direction">数值方向:</span>
          <select name="label_val">
            <option value="0">Positive</option>
            <option value="1">Negative</option>
            <option value="2">Bidirectional</option>
          </select>
          <span language="hist_def_val">默认值:</span><input type="text" name="label_defaultval" value="0">
        </div>
      </div>
    </div>`);
      break;
  }
  $('body>div:not(:nth-child(1)) [language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value]);
  });
  $('.report_out_bottom a').addClass('adisabled');
})
$('[name=report_id]').on('input', function () {
  if ($('.report_out_content>div').length == 0) {
    $('.report_out_bottom a').removeClass('adisabled');
  } else {
    let count = 0;
    $('.report_out_content>div [language=report_name]').each(function () {
      if ($(this).html() == $('[name=report_id]').val()) count++;
    })
    if (count == 0 && $(this).val() != '') {
      $('.report_out_bottom a').removeClass('adisabled')
    } else {
      $('.report_out_bottom a').addClass('adisabled')
    };
  }
})
$('.report_out_content').on('click', '.del', function () {
  $(this).parent().parent().parent().remove();
})
function histogramModeChange(obj) {
  let i = 0;
  $(obj).children().each(function () {
    if ($(this).attr('value') == $(obj).val()) {
      i = $(this).index();
      return;
    }
  })
  $(obj).parent().parent().find('.histogram_disabled').attr('disabled', i < 6 ? true : false);
}
$('.report_out_content').on('change', '[name=histogram_mode]', function () {
  histogramModeChange(this);
})
$('body').on('input', '[name="report_title"]', function () {
  if (regEn.test($(this).val()) || regCn.test($(this).val())) {
    $(this).addClass('red');
  } else {
    $(this).removeClass('red');
  }
})
//parameters
$('.parameters>div>.table').on('click', 'ul>li>span', function (e) {
  if ($(this).parent().parent().hasClass('blue')) {
    if ($(this).next().length != 0) {
      $(this).parent().parent().removeClass('blue').siblings().removeClass('blue blue2');
      $(this).next().show().val($(this).html()).select();
      $(this).hide();
    }
  } else {
    $(this).parents('.table').find('ul').removeClass('blue').find('li').removeClass('blue').find('span').removeClass('white');
    $(this).addClass('white').parent().parent().addClass('blue');
    $(this).parent().removeClass('blue').siblings().addClass('blue');
  }
  $('.parameters>div>.table>.title>div').eq($(this).parent().index()).addClass('blue2').siblings().removeClass('blue2');
  if ($(this).parent().parent().find('li').eq(0).find('span').html() == '') {
    $('.param_val').val('').attr('disabled', true)
  } else {
    $('.param_val').attr('disabled', false);
    let paramI = modules[$('.module_content>p.active').index()][0]['param'][$('.parameters li.blue').parent().index()];
    if (paramI == undefined) {
      $('.param_val').val('');
      return;
    } else {
      let val = paramI['val'];
      if (val == '' || val == undefined) {
        $('.param_val').val('')
      } else {
        $('.param_val').val(val)
      };
    }
  }
})
$('.parameters>div>.table').on('input', 'input', function () {
  if ($(this).parent().parent().index() + 1 == $('.parameters>div>.table>.table_content>ul').length) {
    $('.parameters>div>.table>.table_content').append(`<ul class="fixclear">
    <li><span></span><input type="text" ></li><li><span></span><input type="text" ></li></ul>`)
  }
})
$('.parameters>div>.table>.table_content').on('blur', 'ul>li>input', function (e) {
  let index = $('.module_content>p.active').index();
  let eq = $(this).parent().parent().index();//ul索引
  let lieq = $(this).parent().index();//li索引
  if (modules[index][0]['param'][eq] == undefined) {
    modules[index][0]['param'].push({ "name": "", "value": "", "val": "" });
  }
  if (lieq == 0) {
    modules[index][0]['param'][eq]['name'] = $(this).val();
  } else if (lieq == 1) {
    modules[index][0]['param'][eq]['value'] = $(this).val();
  }
  $(this).prev().show().html($(this).val()).removeClass('white').attr('title', $(this).val());
  $(this).hide();
  setConfig();
})
$('.parameters .table>div:nth-child(1)>div').click(function () {
  if ($(this).find('span').eq(1).html() == '') {
    $(this).find('span').eq(1).html('▲').removeClass('up').addClass('down');
    $(this).siblings().find('span').eq(1).html('').removeClass('down up');
  }
  let param = modules[$('.module_content>p.active').index()][0]['param'];
  if ($(this).find('span').eq(1).hasClass('up')) {
    $(this).find('span').eq(1).html('▲').removeClass('up').addClass('down');
  } else {
    $(this).find('span').eq(1).html('▼').removeClass('down').addClass('up');
  }
  param.reverse();
  let text = '';
  let idx = param.length - $('.parameters .table_content>ul.blue').index() - 1;
  for (let i in param) {
    text += `<ul class="fixclear">
    <li><span>`+ param[i]['name'] + `</span><input type="text"></li>
    <li><span>`+ param[i]['value'] + `</span><input type="text"></li>
  </ul>`
  }
  text += `<ul class="fixclear">
    <li><span></span><input type="text"></li>
    <li><span></span><input type="text"></li>
  </ul>`
  $('.parameters .table_content').empty().append(text);
  $('.parameters .table_content>ul').eq(idx).addClass('blue');
})
function compareVal(obj) {
  let step = $(obj).attr('step');
  let v = parseFloat($(obj).val());
  if (isNaN(v)) { v = Number($(obj).attr('value')) };
  let min = parseFloat($(obj).attr('min')),
    max = parseFloat($(obj).attr('max'));
  v = v < min ? min : v;
  v = v > max ? max : v;
  return v.toFixed(step.length - 2 > 0 ? step.length - 2 : 0);
}
function setConfig() {
  text = `<?xml version="1.0" encoding="utf-8"?><root>`;
  for (let i in modules) {
    text += "<s "
    for (let j in modules[i][0]) {
      if (j != 'param' && j != 'cmd' && j != 'cmd_start' && j != 'cmd_end') {
        text += j + "=\"" + modules[i][0][j] + "\" ";
      }
    }
    text += ">"
    if (modules[i][1]['content'] == '') return;
    for (let j in modules[i][1]['content']) {
      switch (j) {
        case 'in': {
          for (let k in modules[i][1]['content'][j]) {
            text += "<in signal=\"" + modules[i][1]['content'][j][k]['signal'] + "\" nearest=\"" + modules[i][1]['content'][j][k]['nearest'] + "\" param=\"" + modules[i][1]['content'][j][k]['param'] + "\" default_val=\"" + modules[i][1]['content'][j][k]['default_val'] + "\" />";
          }
          break;
        }
        case 'out': {
          for (let k in modules[i][1]['content'][j]) {
            text += "<out param=\"" + modules[i][1]['content'][j][k]['param'] + "\" />";
          }
          break;
        }
        case 'sample_in': {
          for (let k in modules[i][1]['content'][j]) {
            text += "<sample_in>" + modules[i][1]['content'][j][k] + "</sample_in>";
          }
          break;
        }
        case 'sample_out': {
          for (let k in modules[i][1]['content'][j]) {
            text += "<sample_out id=\"" + modules[i][1]['content'][j][k]['id'] + "\" name=\"" + (modules[i][1]['content'][j][k]['name'] == undefined ? '' : modules[i][1]['content'][j][k]['name']) + "\">" + (modules[i][1]['content'][j][k]['val'] == undefined ? '' : modules[i][1]['content'][j][k]['val']) + "</sample_out>";
          }
          break;
        }
        case 'scene_out': {
          for (let k in modules[i][1]['content'][j]) {
            text += "<scene_out id=\"" + modules[i][1]['content'][j][k]['id'] + "\">" + (modules[i][1]['content'][j][k]['val'] == undefined ? '' : modules[i][1]['content'][j][k]['val']) + "</scene_out>";
          }
          break;
        }
        case 'report_out': {
          for (let k in modules[i][1]['content'][j]) {
            text += "<report_out id=\"" + modules[i][1]['content'][j][k]['id'] + "\" type=\"" + modules[i][1]['content'][j][k]['type'] + "\" title=\"" + modules[i][1]['content'][j][k]['title'] + "\" configs=\"" + modules[i][1]['content'][j][k]['configs'] + "\" column_titles=\"" + modules[i][1]['content'][j][k]['column_titles'] + "\" />"
          }
          break;
        }
      }
    }
    for (let k in modules[i][0]['param']) {
      text += "<param name=\"" + modules[i][0]['param'][k]['name'] + "\"" + " value=\"" + modules[i][0]['param'][k]['value'] + "\">" + modules[i][0]['param'][k]['val'] + "</param>";
    }
    text += "<cmd>" + (modules[i][0]['cmd'] == '' || modules[i][0]['cmd'] == undefined ? '' : getEncode64(modules[i][0]['cmd'])) + "</cmd>";
    text += "<cmd_start>" + (modules[i][0]['cmd_start'] == '' || modules[i][0]['cmd_start'] == undefined ? '' : getEncode64(modules[i][0]['cmd_start'])) + "</cmd_start>";
    text += "<cmd_end>" + (modules[i][0]['cmd_end'] == '' || modules[i][0]['cmd_end'] == undefined ? '' : getEncode64(modules[i][0]['cmd_end'])) + "</cmd_end>";
    text += "</s>"
  }
  text += "</root>";
  biSetModuleConfig("python-scripts.pluginpython", text);
}
$('.b_center [name=freq]').change(function () {
  let index = $('.module_content>p.active').index();
  modules[index][0]['freq'] = $('[name=freq]').val();
  setConfig();
})
$('.b_center [name=name]').on({
  'input': function () {
    if (regEn.test($(this).val()) || regCn.test($(this).val())) {
      $(this).addClass('red');
    } else {
      $(this).removeClass('red');
      if ($(this).val().length >= 1) {
        $('.module_content>p.active').find('span:nth-child(2)').text($(this).val());
        modules[$('.module_content>p.active').index()][0].name = $(this).val();
        setConfig();
      }
    }
  },
  'change': function () {
    let count = 0;
    for (let i in remove_modules) {
      if (remove_modules[i] == $('.module_content>p.active').attr('id')) count++;
    }
    if (count == 0) {
      remove_modules.push(Number($('.module_content .active').eq(0).attr('id')));
      $('.module_content>p.active').removeAttr('id');
    }
  },
  'blur': function () {
    $(this).val(modules[$('.module_content>p.active').index()][0].name).removeClass('red');
  }
})
$('.parameters').on('blur', 'input', function () {
  let param = '';
  if (modules[$('.module_content>p.active').index()][0]['param'] == undefined) {
    modules[$('.module_content>p.active').index()][0]['param'] = [];
    param = modules[$('.module_content>p.active').index()][0]['param'];
  } else {
    param = modules[$('.module_content>p.active').index()][0]['param'];
  }
  let index = $('.parameters li.blue').parent().index();
  if (param[index] == undefined) {
    param.push({ 'name': $('.parameters li.blue').parent().find('li').eq(0).find('span').html(), 'value': $('.parameters li.blue').parent().find('li').eq(1).find('span').html(), 'val': '' });
  } else {
    param[index]['name'] = $('.parameters li.blue').parent().find('li').eq(0).find('span').html();
    param[index]['value'] = $('.parameters li.blue').parent().find('li').eq(1).find('span').html();
    param[index]['val'] = param[index]['val'];
  }
  setConfig();
})
$('.parameters textarea').on('blur', function () {
  let param = modules[$('.module_content>p.active').index()][0]['param'];
  let index = $('.parameters li.blue').parent().index();
  if (param[index] != undefined) {
    param[index]['val'] = $('.parameters textarea').val();
  }
  setConfig();
})
//loop
$('.loop_list_content textarea').on({
  'input': function () {
    $('[language="save"],[language="abort"]').removeClass('adisabled');
    $('.module_content>p,[language="add_module"],[language="import_module"],[language="export_module"],[language="remove_module"]').addClass('adisabled')
  }
})
//ctrl+s保存
$(window).keydown(function (e) {
  if (e.keyCode == 83 && e.ctrlKey) {
    let i = $('.module_content>p.active').index();
    for (let j = 0; j < $('.loop_list_content>div').length; j++) {
      let name = $('.loop_list>li').eq(j).attr('language');
      modules[i][0][name] = getEncode64($('.loop_list_content>.item:eq(' + j + ')>textarea').val());
    }
    $('.module_content>p,[language="add_module"],[language="import_module"],[language="export_module"],[language="remove_module"]').removeClass('adisabled');
    $('[language=save],[language=abort]').addClass('adisabled');
    setConfig();
  }
});
$('a').on('click', function () {
  let lang = $(this).attr('language');
  let i = $('.module_content>p.active').index();
  switch (lang) {
    case 'save': {
      for (let j = 0; j < $('.loop_list_content>div').length; j++) {
        let name = $('.loop_list>li').eq(j).attr('language');
        modules[i][0][name] = getEncode64($('.loop_list_content>.item:eq(' + j + ')>textarea').val());
      }
      break;
    }
    case 'abort': {
      for (let j = 0; j < $('.loop_list_content>div').length; j++) {
        let name = $('.loop_list>li').eq(j).attr('language');
        $('.loop_list_content>.item').eq(j).find('textarea').val(modules[i][0][name] == undefined ? '' : getDecode(modules[i][0][name]));
      }
    }
  }
  $('.module_content>p,[language="add_module"],[language="import_module"],[language="export_module"],[language="remove_module"]').removeClass('adisabled');
  $('[language=save],[language=abort]').addClass('adisabled');
  setConfig();
})
//remove_module button
$('.yes').click(function () {
  if ($('.module_content>p').length == 0) return;
  if ($('.module_content .active').eq(0).attr('id') != undefined) {
    remove_modules.push($('.module_content .active').eq(0).attr('id') == '' ? 1 : Number($('.module_content .active').eq(0).attr('id')))
  }
  if ($('.module_content>p').length == 1) {
    aDisabled('')
    $('.module_content .active').eq(0).remove();
    $('.io a').html(none)
    $('[language="add_module"],[language=import_module]').removeClass('adisabled');
    $('.b_center [name=enabled]').prop('checked', false);
    $('.b_center [name=freq]').val(10);
    $('.b_center [name=name]').val('');
    $('.parameters .table_content').empty().append(`<ul class="fixclear">
    <li><span></span><input type="text"></li>
    <li><span></span><input type="text"></li>
  </ul>`);
    $('.param_val').val('');
    modules = [];
  } else {
    if ($('.module_content .active').eq(0).next().length == 0) {
      getContentVal($('.module_content .active').prev());
      modules.splice($('.module_content .active').eq(0).index(), 1);
      $('.module_content .active').prev().addClass('active');
      $('.module_content .active').eq(1).remove();
    } else {
      getContentVal($('.module_content .active').next());
      modules.splice($('.module_content .active').eq(0).index(), 1);
      $('.module_content .active').next().addClass('active');
      $('.module_content .active').eq(0).remove();
    }
  };
  $('.sure').hide();
  setConfig();
})
$('.no').click(function () {
  $('.sure').hide();
})
//import_path button
$('.import_path button').click(function () {
  let lang = $(this).attr('language');
  switch (lang) {
    case 'remove_path': {
      $('.import_path_content>p.active').remove();
      $(this).attr('disabled', true)
      break;
    }
    case 'add_path': {
      biSelectPath('add_path', BISelectPathType.Directory, 'null');
      break;
    }
  }
})
$('.import_path_content').on('click', 'p', function () {
  $(this).addClass('active').siblings().removeClass('active');
  $('.remove_path').attr('disabled', false)
})
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(1136, 590);
  $('[language]').each(function () {
    let value = $(this).attr('language');
    if (biGetLanguage() == 1) {
      $(this).html(en[value]);
      not_config = "(Not configured)";
      inputs = " inputs";
      none = '(None)';
    } else {
      $(this).html(cn[value]);
      not_config = "(未配置)";
      inputs = "个输入";
      none = '(无)';
    }
  });
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString([moduleConfigs[key]], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('root');
    for (let k = 0; k < countrys[0].childNodes.length; k++) {
      let obj = {};
      let arrConfig = [];
      let keys = countrys[0].childNodes[k].getAttributeNames();
      for (let n = 0; n < keys.length; n++) {
        obj[keys[n]] = countrys[0].childNodes[k].getAttribute(keys[n]);
      }
      arrConfig.push(obj, { 'content': {} });
      let sample_in = [], scene_out = [], sample_out = [], signal_in = [], signal_out = [], report_out = [], param = [], cmd = '', cmd_start = '', cmd_end = '';
      for (let j = 0; j < countrys[0].childNodes[k].childNodes.length; j++) {
        let keyss = countrys[0].childNodes[k].childNodes[j].getAttributeNames();
        obj = {};
        let nodeName = countrys[0].childNodes[k].childNodes[j].localName;
        let innerHtml = countrys[0].childNodes[k].childNodes[j].innerHTML;
        switch (nodeName) {
          case 'sample_in': {
            sample_in.push(innerHtml)
            break;
          }
          case 'scene_out': {
            for (let i in keyss) {
              obj[keyss[i]] = countrys[0].childNodes[k].childNodes[j].getAttribute(keyss[i]);
              obj['val'] = innerHtml;
            }
            scene_out.push(obj);
            break;
          }
          case 'sample_out': {
            for (let i in keyss) {
              obj[keyss[i]] = countrys[0].childNodes[k].childNodes[j].getAttribute(keyss[i]);
              obj['val'] = innerHtml;
            }
            sample_out.push(obj);
            break;
          }
          case 'report_out': {
            for (let i in keyss) {
              obj[keyss[i]] = countrys[0].childNodes[k].childNodes[j].getAttribute(keyss[i]);
            }
            report_out.push(obj);
            break;
          }
          case 'in': {
            for (let i in keyss) {
              obj[keyss[i]] = countrys[0].childNodes[k].childNodes[j].getAttribute(keyss[i]);
            }
            signal_in.push(obj);
            break;
          }
          case 'out': {
            for (let i in keyss) {
              obj[keyss[i]] = countrys[0].childNodes[k].childNodes[j].getAttribute(keyss[i]);
            }
            signal_out.push(obj);
            break;
          }
          case 'param': {
            for (let i in keyss) {
              obj[keyss[i]] = countrys[0].childNodes[k].childNodes[j].getAttribute(keyss[i]);
            }
            obj['val'] = innerHtml;
            param.push(obj);
            break;
          }
          case 'cmd': {
            cmd += getDecode(innerHtml) + "\n\n";
            break;
          }
          case 'cmd_start': {
            cmd_start = getDecode(innerHtml) + "\n\n";
            break;
          }
          case 'cmd_end': {
            cmd_end = getDecode(innerHtml) + "\n\n";
            break;
          }
        }
        arrConfig[0]['param'] = param;
        arrConfig[1].content['in'] = signal_in;
        arrConfig[1].content['scene_out'] = scene_out;
        arrConfig[1].content['sample_out'] = sample_out;
        arrConfig[1].content['out'] = signal_out;
        arrConfig[1].content['report_out'] = report_out;
        arrConfig[1].content['sample_in'] = sample_in;
        arrConfig[0]['cmd'] = cmd;
        arrConfig[0]['cmd_start'] = cmd_start;
        arrConfig[0]['cmd_end'] = cmd_end;
      }
      modules.push(arrConfig);
    }
  }
  loadConfig(modules);
}
function loadConfig(config) {
  biQueryGlobalPath("PythonImportPathes");
  for (let i in modules) {
    let o = modules[i][0]['enabled'] == 'yes' ? '(O)' : '(X)';
    $('.module_content').append("<p><span>" + o + "</span><span>" + modules[i][0]['name'] + "</span></p>");
  }
}
function biOnQueriedGlobalPath(id, paths) {
  if (paths.length == 0) $('[language=cant_find]').show().removeClass('adisabled').addClass('red').html(biGetLanguage() == 1 ? en['cant_find'] : cn['cant_find']);
  for (let i = 0; i < paths.length; i++) {
    biQueryFilesInDirectory(paths[i]);
    $('.import_path_content').append("<p title='" + paths[i] + "'>" + paths[i] + "</p>");
  }
}
$('body').on('input', '[name=default_val]', function () {
  isNaN(Number($(this).val())) ? $(this).addClass('red') : $(this).removeClass('red');
})


