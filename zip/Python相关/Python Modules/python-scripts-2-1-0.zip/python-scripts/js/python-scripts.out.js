var childIndex = 0,
  modules = [],
  reg = /^[A-Za-z_][A-Za-z_0-9]{0,}$/im;

// language
$('a').on('click', function () {
  var name = $(this).attr('language');
  switch (name) {
    case 'output_add_sample':
      $('.out>div').append("<div class=\"out_list\"><span language=\"in_param_name\" class=\"red\"></span><input type=\"text\" name=\"param\"></div>");
      $('.out>div>div').eq($('.out>div>div').length - 1).addClass('bdBlack').siblings().removeClass('bdBlack');
      $('[language]').each(function () {
        var value = $(this).attr('language');
        $(this).text(biGetLanguage() == 1 ? en[value] : cn[value]);
      });
      break;
    case 'output_remove_sample':
      modules[childIndex][1]['content']["out"].splice($('.bdBlack').index(), 1);
      $('.bdBlack').remove();
      changeVal();
      break;
    default:
      return;
  }
})

$('.out').on('click', '.out_list', function () {
  $(this).addClass('bdBlack').siblings().removeClass('bdBlack');
})
$('.out').on('input', 'input', function () {
  $(this).val() != '' ? $(this).prev().removeClass('red') : $(this).prev().addClass('red');
  if (reg.test($(this).val())) {
    $(this).removeClass('red').addClass("green").attr("value", $(this).val());
  } else {
    $(this).addClass('red').removeClass("green");
  }
  modules[childIndex][1]['content']["out"] = [];
  $(".out>div>div").each(function (i) {
    if (!$(this).find("[name=param]").hasClass("red") && !$(this).find("[language=in_param_name]").hasClass("red")) {
      modules[childIndex][1]['content']["out"][i] = {
        "param": $(this).find("[name=param]").attr("value")
      };
    }
  })
  changeVal();
}).on('blur', 'input', function () {
  if ($(this).hasClass("red")) $(this).val($(this).attr("value")).removeClass("red").addClass("green");
  if ($(this).val().trim().length != 0) {
    $(this).prev().removeClass("red");
  } else {
    $(this).prev().addClass("red");
  }
})

function changeVal() {
  biSetLocalVariable("python_script_out" + childIndex, JSON.stringify(modules[childIndex][1]['content']["out"]));
  setConfig();
}

function biOnInitEx(config, moduleConfigs) {
  childIndex = config;
  for (var key in moduleConfigs) {
    console.log(key, moduleConfigs[key]);
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    var countrys = xmlDoc.getElementsByTagName('root');
    for (var k = 0; k < countrys[0].childNodes.length; k++) {
      var obj = {};
      var arrConfig = [];
      var keys = countrys[0].childNodes[k].attributes;
      for (var n = 0; n < keys.length; n++) {
        obj[keys[n].nodeName] = keys[n].nodeValue;
      }
      arrConfig.push(obj, {
        'content': {}
      });
      var sample_in = [],
        scene_out = [],
        sample_out = [],
        signal_in = [],
        signal_out = [],
        report_out = [],
        param = [],
        cmd = '',
        cmd_start = '',
        cmd_end = '';
      for (var j = 0; j < countrys[0].childNodes[k].childNodes.length; j++) {
        var keyss = countrys[0].childNodes[k].childNodes[j].attributes;
        obj = {};
        var nodeName = countrys[0].childNodes[k].childNodes[j].localName;
        var innerHtml = countrys[0].childNodes[k].childNodes[j].innerHTML;
        switch (nodeName) {
          case 'sample_in': {
            sample_in.push(innerHtml)
            break;
          }
          case 'scene_out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
              obj['val'] = innerHtml;
            }
            scene_out.push(obj);
            break;
          }
          case 'sample_out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
              obj['val'] = innerHtml;
            }
            sample_out.push(obj);
            break;
          }
          case 'report_out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            report_out.push(obj);
            break;
          }
          case 'in': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            signal_in.push(obj);
            break;
          }
          case 'out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            signal_out.push(obj);
            break;
          }
          case 'param': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            obj['val'] = innerHtml;
            param.push(obj);
            break;
          }
          case 'cmd': {
            cmd += innerHtml + "\n\n";
            break;
          }
          case 'cmd_start': {
            cmd_start = innerHtml + "\n\n";
            break;
          }
          case 'cmd_end': {
            cmd_end = innerHtml + "\n\n";
            break;
          }
        }
        arrConfig[0]['param'] = param;
        arrConfig[1].content['in'] = signal_in;
        arrConfig[1].content['scene_out'] = scene_out;
        arrConfig[1].content['sample_out'] = sample_out;
        arrConfig[1].content['out'] = signal_out;
        arrConfig[1].content['report_out'] = report_out;
        arrConfig[1].content['sample_in'] = sample_in;
        arrConfig[0]['cmd'] = cmd;
        arrConfig[0]['cmd_start'] = cmd_start;
        arrConfig[0]['cmd_end'] = cmd_end;
      }
      modules.push(arrConfig);
    }
  }
  loadConfig(config);
}

function loadConfig(index) {
  var val = modules[index][1]['content']["out"];
  for (var i in val) {
    $('.out>div').append("<div class=\"out_list\"><span language=\"in_param_name\"></span><input type=\"text\" name=\"param\" value=\"" + val[i]['param'] + "\"></div>");
    $('.out>div>div').eq(i).find("[name=param]").addClass(reg.test(val[i]['param']) ? "green" : "red");
  }
  $('[language]').each(function () {
    var value = $(this).attr('language');
    $(this).text(biGetLanguage() == 1 ? en[value] : cn[value]);
  });
}