var modules = [],
  activeIndex = 0;
$('input[type=number]').on({
  'input': function (e) {
    if (e.which == undefined) {
      var step = $(this).attr("step").length - 2;
      var val = Number($(this).val());
      $(this).val(step > 0 ? val.toFixed(step) : val);
    }
    modules[activeIndex][0]["overwrite_freq"] = compareVal($("[name=overwrite_freq]"), $("[name=overwrite_freq]").val());
    biSetLocalVariable("python_script_overwritefreq" + activeIndex, JSON.stringify(modules[activeIndex][0]));
    setConfig();
  },
  'keypress': function (e) {
    if (!(e.charCode >= 48 && e.charCode <= 57) && !(e.charCode == 45 || e.charCode == 46)) return false;
  }
})

$("[name=overwritedef]").change(function () {
  if ($(this).is(":checked")) {
    modules[activeIndex][0]["overwrite_freq"] = "yes";
  } else {
    modules[activeIndex][0]["overwrite_freq"] = $("[name=overwrite_freq]").val();
  }
  useDefault();
  biSetLocalVariable("python_script_overwritefreq" + activeIndex, JSON.stringify(modules[activeIndex][0]));
  setConfig();
})

function useDefault() {
  if ($("[name=overwritedef]").is(":checked")) {
    $("[name=overwrite_freq]").addClass("disabled_background").attr("disabled", true);
    $("[language=overwrite_freq]").addClass("disabled_a");
  } else {
    $("[name=overwrite_freq]").removeClass("disabled_background").attr("disabled", false);
    $("[language=overwrite_freq]").removeClass("disabled_a");
  }
}

function loadConfig(config) {
  activeIndex = Number(config);
  if (modules[activeIndex][0]["overwrite_freq"] == undefined || modules[activeIndex][0]["overwrite_freq"] == "yes") {
    $("[name=overwritedef]").attr("checked", true);
  } else {
    $("[name=overwritedef]").attr("checked", false);
    $("[name=overwrite_freq]").val(compareVal($("[name=overwrite_freq]"), modules[config][0]["overwrite_freq"]));
  }
  useDefault(modules[activeIndex][0]["overwrite_freq"]);
}

function compareVal(obj, val) {
  var step = $(obj).attr('step').length > 2 ? $(obj).attr('step').length - 2 : 0,
    v = Number(val),
    newVal = 0;
  if (isNaN(v)) {
    newVal = Number($(obj).attr('value'));
  } else {
    var min = Number($(obj).attr('min')),
      max = Number($(obj).attr('max'));
    v = v < min ? min : v;
    v = v > max ? max : v;
    if (step > 0) {
      newVal = Math.round((Math.abs(v) * Math.pow(10, step)).toFixed(1)) / Math.pow(10, step);
      if (v < 0) newVal = -newVal;
    } else {
      newVal = Math.floor(v);
    }
  }
  return step > 0 ? newVal.toFixed(step) : newVal;
}