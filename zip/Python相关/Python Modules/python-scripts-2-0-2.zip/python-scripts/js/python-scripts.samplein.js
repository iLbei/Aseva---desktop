var text,
  childIndex = 0,
  modules = [],
  regEn = /[\s+`~!@#$%^&*()_+<>?:"{},.\/;'[\]]/im,
  regCn = /[\s+·！#￥（——）：；“”‘、，|《。》？、【】[\]]/im,
  regNum = /[\u4e00-\u9fa5]/;

$('a[language=input_remove_sample]').on('click', function () {
  $('[language=add_sample]').removeAttr('disabled').removeClass("button_disabled");
  $('.sample_in .active').remove();
  setConfig();
})

$('.sample_in button').on('click', function () {
  var name = $(this).attr('language');
  switch (name) {
    case 'add_sample':
      var html = $('[name="protocal"]').val() + ($('[name=protocal_channel]').val() == -1 ? '' : '@' + $('[name=protocal_channel]').val());
      $('.sample_content').append('<p name="' + html + '">' + html + '</p>');
      break;
    case 'reload_sample':
      $('.sample_in .active').eq(0).html($('[name="protocal"]').val() + ($('[name=protocal_channel]').val() == -1 ? '' : '@' + $('[name=protocal_channel]').val()));
      break;
  }
  $('.sample_in button').attr('disabled', true).addClass("button_disabled");
  setConfig();
})

$('[name=protocal]').on('input', function () {
  if ($(this).val() == '' || regEn.test($(this).val()) || regCn.test($(this).val()) || regNum.test($(this).val())) {
    $("[name=protocal]").addClass("red");
    $('[language = add_sample],[language="reload_sample"]').attr('disabled', true).addClass("button_disabled");
  } else {
    $("[name=protocal]").removeClass("red");
    var val = $(this).val() + ($('[name=protocal_channel]').val() == -1 ? '' : ('@' + $('[name=protocal_channel]').val()));
    if ($('.sample_content>p').length > 0) {
      var count = 0;
      $('.sample_content>p').each(function () {
        if (val == $(this).html()) count++;
      })
      if (count == 0) {
        if ($('.sample_in .active').html()) {
          $('.sample_in button').removeAttr('disabled').removeClass("button_disabled");
        } else {
          $('[language = add_sample]').removeAttr('disabled').removeClass("button_disabled");
        }
      } else {
        $('.sample_in button').attr('disabled', true).addClass("button_disabled");
      }
    } else {
      $('[language = add_sample]').removeAttr('disabled').removeClass("button_disabled");
    }
  }
})

$('[name="protocal_channel"]').change(function () {
  if ($('[name="protocal"]').val() == '' || regEn.test($('[name="protocal"]').val()) || regCn.test($('[name="protocal"]').val()) || regNum.test($('[name="protocal"]').val())) {
    $('[language = add_sample],[language="reload_sample"]').attr('disabled', true).addClass("button_disabled");
  } else {
    var val = $('[name=protocal]').val() + ($(this).val() == -1 ? '' : ('@' + $(this).val()));
    if ($('.sample_content>p').length > 0) {
      var count = 0;
      $('.sample_content>p').each(function () {
        if (val == $(this).html()) count++;
      })
      if (count == 0) {
        if ($('.sample_in .active').html()) {
          $('.sample_in button').removeAttr('disabled').removeClass("button_disabled");
        } else {
          $('[language = add_sample]').removeAttr('disabled').removeClass("button_disabled");
        }
      } else {
        $('.sample_in button').attr('disabled', true).addClass("button_disabled");
      }
    } else {
      $('[language = add_sample]').removeAttr('disabled').removeClass("button_disabled");
    }
  }
})

$('.sample_content').on('click', 'p', function () {
  var proVal = $(this).html().indexOf('@') == -1 ? $(this).html().length : $(this).html().indexOf('@');
  var chaVal = $(this).html().indexOf('@') == -1 ? -1 : Number($(this).html().substr($(this).html().indexOf('@') + 1));
  $(this).addClass('active').siblings().removeClass('active');
  $('[name=protocal]').val($(this).html().substr(0, proVal));
  $('[name = protocal_channel]').val(chaVal);
  $(".sample_in button").attr("disabled", true).addClass("button_disabled");
})

function setConfig() {
  var arr = [];
  for (var i = 0; i < $('.sample_content>p').length; i++) {
    arr.push($('.sample_content>p').eq(i).html());
  }
  modules[childIndex][1]['content']['sample_in'] = arr;
  text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root>";
  for (var i in modules) {
    text += "<s "
    for (var j in modules[i][0]) {
      if (j != 'param' && j != 'cmd' && j != 'cmd_start' && j != 'cmd_end') {
        text += j + "=\"" + modules[i][0][j] + "\" ";
      }
    }
    text += ">"
    if (modules[i][1]['content'] == '') return;
    for (var j in modules[i][1]['content']) {
      switch (j) {
        case 'in': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<in signal=\"" + modules[i][1]['content'][j][k]['signal'] + "\" nearest=\"" + modules[i][1]['content'][j][k]['nearest'] + "\" param=\"" + modules[i][1]['content'][j][k]['param'] + "\" default_val=\"" + modules[i][1]['content'][j][k]['default_val'] + "\" />";
          }
          break;
        }
        case 'out': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<out param=\"" + modules[i][1]['content'][j][k]['param'] + "\" />";
          }
          break;
        }
        case 'sample_in': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<sample_in>" + modules[i][1]['content'][j][k] + "</sample_in>";
          }
          break;
        }
        case 'sample_out': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<sample_out id=\"" + modules[i][1]['content'][j][k]['id'] + "\" name=\"" + (modules[i][1]['content'][j][k]['name'] == undefined ? '' : modules[i][1]['content'][j][k]['name']) + "\">" + (modules[i][1]['content'][j][k]['val'] == undefined ? '' : modules[i][1]['content'][j][k]['val']) + "</sample_out>";
          }
          break;
        }
        case 'scene_out': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<scene_out id=\"" + modules[i][1]['content'][j][k]['id'] + "\">" + (modules[i][1]['content'][j][k]['val'] == undefined ? '' : modules[i][1]['content'][j][k]['val']) + "</scene_out>";
          }
          break;
        }
        case 'report_out': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<report_out id=\"" + modules[i][1]['content'][j][k]['id'] + "\" type=\"" + modules[i][1]['content'][j][k]['type'] + "\" title=\"" + modules[i][1]['content'][j][k]['title'] + "\" configs=\"" + modules[i][1]['content'][j][k]['configs'] + "\" column_titles=\"" + modules[i][1]['content'][j][k]['column_titles'] + "\" />"
          }
          break;
        }
      }
    }
    for (var k in modules[i][0]['param']) {
      text += "<param name=\"" + modules[i][0]['param'][k]['name'] + "\"" + " value=\"" + modules[i][0]['param'][k]['value'] + "\">" + modules[i][0]['param'][k]['val'] + "</param>";
    }
    text += "<cmd>" + (modules[i][0]['cmd'] == '' || modules[i][0]['cmd'] == undefined ? '' : modules[i][0]['cmd']) + "</cmd>";
    text += "<cmd_start>" + (modules[i][0]['cmd_start'] == '' || modules[i][0]['cmd_start'] == undefined ? '' : modules[i][0]['cmd_start']) + "</cmd_start>";
    text += "<cmd_end>" + (modules[i][0]['cmd_end'] == '' || modules[i][0]['cmd_end'] == undefined ? '' : modules[i][0]['cmd_end']) + "</cmd_end>";
    text += "</s>"
  }
  text += "</root>";
  biSetModuleConfig("python-scripts.pluginpython", text);
  biSetLocalVariable("python_script_samplein" + childIndex, JSON.stringify(modules[childIndex][1]['content']["sample_in"]));
}

function biOnInitEx(config, moduleConfigs) {
  childIndex = config;
  for (var key in moduleConfigs) {
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    var countrys = xmlDoc.getElementsByTagName('root');
    for (var k = 0; k < countrys[0].childNodes.length; k++) {
      var obj = {};
      var arrConfig = [];
      var keys = countrys[0].childNodes[k].attributes;
      for (var n = 0; n < keys.length; n++) {
        obj[keys[n].nodeName] = keys[n].nodeValue;
      }
      arrConfig.push(obj, {
        'content': {}
      });
      var sample_in = [],
        scene_out = [],
        sample_out = [],
        signal_in = [],
        signal_out = [],
        report_out = [],
        param = [],
        cmd = '',
        cmd_start = '',
        cmd_end = '';
      for (var j = 0; j < countrys[0].childNodes[k].childNodes.length; j++) {
        var keyss = countrys[0].childNodes[k].childNodes[j].attributes;
        obj = {};
        var nodeName = countrys[0].childNodes[k].childNodes[j].localName;
        var innerHtml = countrys[0].childNodes[k].childNodes[j].innerHTML;
        switch (nodeName) {
          case 'sample_in': {
            sample_in.push(innerHtml)
            break;
          }
          case 'scene_out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
              obj['val'] = innerHtml;
            }
            scene_out.push(obj);
            break;
          }
          case 'sample_out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
              obj['val'] = innerHtml;
            }
            sample_out.push(obj);
            break;
          }
          case 'report_out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            report_out.push(obj);
            break;
          }
          case 'in': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            signal_in.push(obj);
            break;
          }
          case 'out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            signal_out.push(obj);
            break;
          }
          case 'param': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            obj['val'] = innerHtml;
            param.push(obj);
            break;
          }
          case 'cmd': {
            cmd += innerHtml + "\n\n";
            break;
          }
          case 'cmd_start': {
            cmd_start = innerHtml + "\n\n";
            break;
          }
          case 'cmd_end': {
            cmd_end = innerHtml + "\n\n";
            break;
          }
        }
        arrConfig[0]['param'] = param;
        arrConfig[1].content['in'] = signal_in;
        arrConfig[1].content['scene_out'] = scene_out;
        arrConfig[1].content['sample_out'] = sample_out;
        arrConfig[1].content['out'] = signal_out;
        arrConfig[1].content['report_out'] = report_out;
        arrConfig[1].content['sample_in'] = sample_in;
        arrConfig[0]['cmd'] = cmd;
        arrConfig[0]['cmd_start'] = cmd_start;
        arrConfig[0]['cmd_end'] = cmd_end;
      }
      modules.push(arrConfig);
    }
  }
  var val = modules[config][1]['content']["sample_in"];
  for (var i in val) {
    $('.sample_in .sample_content').append("<p>" + val[i] + "</p>");
  }
  $(".sample_in button").attr("disabled", true).addClass("button_disabled");
  $('[name=default_val]').each(function () {
    isNaN(Number($(this).val())) ? $(this).addClass('red') : $(this).removeClass('red');
  })
  var lang = biGetLanguage() == 1 ? en : cn;
  $('[language]').each(function () {
    var value = $(this).attr('language');
    $(this).text(lang[value]);
  });
}