var text,
  childIndex = 0,
  modules = [],
  remove_modules = [],
  bi_common_js = 0,
  not_config = "",
  inputs = "",
  regEn = /[\s+`~!@#$%^&*()_+<>?:"{},.\/;'[\]]/im,
  regCn = /[\s+·！#￥（——）：；“”‘、，|《。》？、【】[\]]/im,
  regNum = /[\u4e00-\u9fa5]/;

$(".in").on("change", "[name]", function () {
  setConfig();
})

$('.in').on('click', '.signal_list', function () {
  $(this).addClass('bdBlack').siblings().removeClass('bdBlack');
})

// addremove
$('a').on('click', function () {
  var name = $(this).attr('language');
  switch (name) {
    case 'input_remove_signal':
      $('.bdBlack').remove();
      setConfig();
      break;
    case 'input_add_signal':
      var leng = $('.in>div').find('div').length;
      $('.in>div').append("<div class=\"signal_list\"><span class=\"red\" language=\"in_param_name\"></span><input type=\"text\" name=\"param\" id=\"\"><span language=\"default_val\">默认值:</span><input type=\"text\" name=\"default_val\" id=\"\"><input type=\"radio\" name=\"nearest" + leng + "\" id=\"nearest_1" + leng + "\" value=\"no\"><label for=\"nearest_1" + leng + "\" language=\"nearest\">最近</label><input type=\"radio\" name=\"nearest" + leng + "\" id=\"nearest_2" + leng + "\" value=\"yes\" checked><label for=\"nearest_2" + leng + "\" language=\"chazhi\">插值</label><br><span language=\"source_signal\">来源信号:</span><a href=\"javascript:;\" language=\"not_config\" class=\"red\" name=\"signal\">" + not_config + "</a></div>");
      $('.in>div>div:last-child [language]').each(function () {
        var value = $(this).attr('language');
        $(this).text(biGetLanguage() == 1 ? en[value] : cn[value]);
      });
      break;
  }
})

//select signal 
$('.in>div').on('click', 'div a[name = signal]', function () {
  var key = $(this).parent().index();
  var id = $(this).attr('id');
  biSelectSignal(key, id, false, false, false, false, false)
})

$('.in').on('input', '.signal_list [name="param"]', function () {
  $(this).val() != '' ? $(this).prev().removeClass('red') : $(this).prev().addClass('red');
  if (regEn.test($(this).val()) || regCn.test($(this).val()) || regNum.test($(this).val())) {
    $(this).addClass('red')
  } else {
    $(this).removeClass('red');
  }
})

$('body').on('input', '[name=default_val]', function () {
  isNaN(Number($(this).val())) ? $(this).addClass('red') : $(this).removeClass('red');
})

function biOnSelectedSignal(key, valueSignalInfo, signBitSignalInfo, scale) {
  if (valueSignalInfo != null && valueSignalInfo.typeName == null) return;
  if (valueSignalInfo == null) {
    $('.in>div>div').eq(key).find('a[name=signal]').text(not_config).addClass('red').removeClass('green').removeAttr('id title');
  } else {
    $('.in>div>div').eq(key).find('a[name=signal]').text(valueSignalInfo.typeName + ':' + valueSignalInfo.signalName).removeClass('red').addClass('green').attr('id', valueSignalInfo.id).attr('title', valueSignalInfo.typeName + ':' + valueSignalInfo.signalName);
  }
  setConfig();
}

function biOnQueriedSignalInfo(key, signalInfo) {
  var signal = $('.in>div>div').eq(Number(key)).find('a[name=signal]');
  if (signalInfo == null) {
    signal.text(signal.attr('id')).addClass('red').removeClass('green');
  } else {
    signal.text(signalInfo.typeName + ":" + signalInfo.signalName).addClass('green').removeClass('red');
  }
}

function setConfig() {
  modules[childIndex][1]["content"]["in"] = [];
  $(".in>div>div").each(function (i) {
      modules[childIndex][1]["content"]["in"].push({});
    if ($(this).find('[name=param]').val() != '' && $(this).find('[name=signal]').text().indexOf(not_config) == -1 && !($(this).find('[name="param"]').hasClass('red') || $(this).find('[name="default_val"]').hasClass('red'))) {
      $(".in>div>div").eq(i).find("[name]").each(function () {
        var name = $(this).attr("name");
        var type = $(this).attr("type");
        if (type == "number" || type == "text") {
          modules[childIndex][1]["content"]["in"][i][name] = $(this).val();
        } else if (type == "radio" && $(this).is(":checked")) {
          name = name.substring(0, name.length - 1);
          modules[childIndex][1]["content"]["in"][i][name] = $(this).attr("value");
        } else if ($(this).is("a")) {
          modules[childIndex][1]["content"]["in"][i][name] = $(this).attr('id');
        }
      })
    }
  })
  text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root>";
  for (var i in modules) {
    text += "<s "
    for (var j in modules[i][0]) {
      if (j != 'param' && j != 'cmd' && j != 'cmd_start' && j != 'cmd_end') {
        text += j + "=\"" + modules[i][0][j] + "\" ";
      }
    }
    text += ">"
    if (modules[i][1]['content'] == '') return;
    for (var j in modules[i][1]['content']) {
      switch (j) {
        case 'in': {
          for (var k in modules[i][1]['content'][j]) {
            if(modules[i][1]['content'][j][k]!={}){
              text += "<in signal=\"" + modules[i][1]['content'][j][k]['signal'] + "\" nearest=\"" + modules[i][1]['content'][j][k]['nearest'] + "\" param=\"" + modules[i][1]['content'][j][k]['param'] + "\" default_val=\"" + modules[i][1]['content'][j][k]['default_val'] + "\" />";
            }
          }
          break;
        }
        case 'out': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<out param=\"" + modules[i][1]['content'][j][k]['param'] + "\" />";
          }
          break;
        }
        case 'sample_in': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<sample_in>" + modules[i][1]['content'][j][k] + "</sample_in>";
          }
          break;
        }
        case 'sample_out': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<sample_out id=\"" + modules[i][1]['content'][j][k]['id'] + "\" name=\"" + (modules[i][1]['content'][j][k]['name'] == undefined ? '' : modules[i][1]['content'][j][k]['name']) + "\">" + (modules[i][1]['content'][j][k]['val'] == undefined ? '' : modules[i][1]['content'][j][k]['val']) + "</sample_out>";
          }
          break;
        }
        case 'scene_out': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<scene_out id=\"" + modules[i][1]['content'][j][k]['id'] + "\">" + (modules[i][1]['content'][j][k]['val'] == undefined ? '' : modules[i][1]['content'][j][k]['val']) + "</scene_out>";
          }
          break;
        }
        case 'report_out': {
          for (var k in modules[i][1]['content'][j]) {
            text += "<report_out id=\"" + modules[i][1]['content'][j][k]['id'] + "\" type=\"" + modules[i][1]['content'][j][k]['type'] + "\" title=\"" + modules[i][1]['content'][j][k]['title'] + "\" configs=\"" + modules[i][1]['content'][j][k]['configs'] + "\" column_titles=\"" + modules[i][1]['content'][j][k]['column_titles'] + "\" />"
          }
          break;
        }
      }
    }
    for (var k in modules[i][0]['param']) {
      text += "<param name=\"" + modules[i][0]['param'][k]['name'] + "\"" + " value=\"" + modules[i][0]['param'][k]['value'] + "\">" + modules[i][0]['param'][k]['val'] + "</param>";
    }
    if (Boolean(modules[i][0]['cmd'])) text += "<cmd>" + modules[i][0]['cmd'] + "</cmd>";
    if (Boolean(modules[i][0]['cmd_start'])) text += "<cmd_start>" + modules[i][0]['cmd_start'] + "</cmd_start>";
    if (Boolean(modules[i][0]['cmd_end'])) text += "<cmd_end>" + modules[i][0]['cmd_end'] + "</cmd_end>";
    text += "</s>"
  }
  text += "</root>";
  biSetModuleConfig("python-scripts.pluginpython", text);
  biSetLocalVariable("python_script_in" + childIndex, JSON.stringify(modules[childIndex][1]['content']["in"]));
}

function biOnInitEx(config, moduleConfigs) {
  childIndex = config;
  for (var key in moduleConfigs) {
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    var countrys = xmlDoc.getElementsByTagName('root');
    for (var k = 0; k < countrys[0].childNodes.length; k++) {
      var obj = {};
      var arrConfig = [];
      var keys = countrys[0].childNodes[k].attributes;
      for (var n = 0; n < keys.length; n++) {
        obj[keys[n].nodeName] = keys[n].nodeValue;
      }
      arrConfig.push(obj, {
        'content': {}
      });
      var sample_in = [],
        scene_out = [],
        sample_out = [],
        signal_in = [],
        signal_out = [],
        report_out = [],
        param = [],
        cmd = '',
        cmd_start = '',
        cmd_end = '';
      for (var j = 0; j < countrys[0].childNodes[k].childNodes.length; j++) {
        var keyss = countrys[0].childNodes[k].childNodes[j].attributes;
        obj = {};
        var nodeName = countrys[0].childNodes[k].childNodes[j].localName;
        var innerHtml = countrys[0].childNodes[k].childNodes[j].innerHTML;
        switch (nodeName) {
          case 'sample_in': {
            sample_in.push(innerHtml)
            break;
          }
          case 'scene_out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
              obj['val'] = innerHtml;
            }
            scene_out.push(obj);
            break;
          }
          case 'sample_out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
              obj['val'] = innerHtml;
            }
            sample_out.push(obj);
            break;
          }
          case 'report_out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            report_out.push(obj);
            break;
          }
          case 'in': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            signal_in.push(obj);
            break;
          }
          case 'out': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            signal_out.push(obj);
            break;
          }
          case 'param': {
            for (var i of keyss) {
              obj[i.nodeName] = i.nodeValue;
            }
            obj['val'] = innerHtml;
            param.push(obj);
            break;
          }
          case 'cmd': {
            cmd += innerHtml + "\n\n";
            break;
          }
          case 'cmd_start': {
            cmd_start = innerHtml + "\n\n";
            break;
          }
          case 'cmd_end': {
            cmd_end = innerHtml + "\n\n";
            break;
          }
        }
        arrConfig[0]['param'] = param;
        arrConfig[1].content['in'] = signal_in;
        arrConfig[1].content['scene_out'] = scene_out;
        arrConfig[1].content['sample_out'] = sample_out;
        arrConfig[1].content['out'] = signal_out;
        arrConfig[1].content['report_out'] = report_out;
        arrConfig[1].content['sample_in'] = sample_in;
        arrConfig[0]['cmd'] = cmd;
        arrConfig[0]['cmd_start'] = cmd_start;
        arrConfig[0]['cmd_end'] = cmd_end;
      }
      modules.push(arrConfig);
    }
  }
  var val = modules[config][1]['content']["in"];
  for (var i in val) {
    biQuerySignalInfo(i, val[i]['signal']);
    $('.in>div').append("<div class=\"signal_list\"><span language=\"in_param_name\"></span><input type=\"text\" name=\"param\" id=\"\" value=\"" + val[i]['param'] + "\"><span language=\"default_val\"></span><input type=\"text\" name=\"default_val\" value=\"" + val[i]['default_val'] + "\" id=\"\"><input type=\"radio\" name=\"nearest" + i + "\" id=\"nearest_1\" value=\"no\"><label for=\"nearest_1\" language=\"nearest\"></label><input type=\"radio\" name=\"nearest" + i + "\" id=\"nearest_2\" value=\"yes\"><label for=\"nearest_2\" language=\"chazhi\"></label><br><span language=\"source_signal\"></span><a href=\"javascript:;\" language=\"not_config\" id=\"" + val[i]['signal'] + "\" name=\"signal\"></a></div>");
    $("[name='nearest" + i + "'][value='" + val[i]["nearest"] + "']").prop('checked', true);
  }
  $('[name=default_val]').each(function () {
    isNaN(Number($(this).val())) ? $(this).addClass('red') : $(this).removeClass('red');
  })
  $('[language]').each(function () {
    var value = $(this).attr('language');
    if (biGetLanguage() == 1) {
      $(this).text(en[value]);
      not_config = en["not_config"];
    } else {
      $(this).text(cn[value]);
      not_config = cn["not_config"];
    }
  });
  $(".in>div>div:last-child").addClass("bdBlack");
}