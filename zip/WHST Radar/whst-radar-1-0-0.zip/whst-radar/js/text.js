var cn = {
  radar: "毫米波雷达",
  bus_channel:"总线通道:",
  process:"进程",
  message_id:"报文ID:",
  obj_output:"目标物输出通道:",
  point_cloud_output:"点云输出通道:",
  origin:"原点[m]: X",
  pitch: "倾斜度:",
  yaw: "偏航:"
},
  en = {
    radar: "Radar",
    bus_channel:"Bus Channel:",
    process:"Process",
    message_id:"Message ID:",
    obj_output:"Objects Output:",
    point_cloud_output:"Point Cloud Output:",
    origin:"Origin [m]: X",
    yaw: "Yaw Offset[°]:",
    pitch: "Pitch:"
  };