var cn = {
  roEnable: "启用",
  not_config:"<未配置>",
  staticObjectsJsonFile:"静态目标物文件(JSON):",
  gnssImuInputChannel:"交通信息样本输出通道:",
  lanesChannel:"车道线输入通道:"
},
  en = {
    roEnable: "Enabled",
    not_config:"<Not configured>",
    staticObjectsJsonFile:"Static Object File (JSON):",
    gnssImuInputChannel:"GNSS-IMU Input Channel:",
    lanesChannel:"Lanes Input Channel:"
  };