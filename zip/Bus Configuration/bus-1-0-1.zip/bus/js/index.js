let busChannelTypes = [],
  busList = [],
  deviceConfig = [], bds = [], index, not_config, bdsI = '';
for (let i = 0; i < 16; i++) {
  if (i < 8) {
    $('.protocolList:eq(0)').append("<li><div class=\"left\"><span>CH" + (i + 1) + "</span><br><a href=\"javascript:;\" language=\"add_channel_protocol\" class=\"ch" + i + "\">添加</a></div> <div class=\"right\" id=\"ch" + i + "\"></div></li>")
  } else {
    $('.protocolList:eq(1)').append("<li><div class=\"left\"><span>CH" + (i + 1) + "</span><br><a href=\"javascript:;\" language=\"add_channel_protocol\" class=\"ch" + i + "\">添加</a></div> <div class=\"right\" id=\"ch" + i + "\"></div></li>")
  }

}
//a标签点击弹出弹框
$('[language=bus_infomation]').click(function () {
  let lang = $(this).attr('language');
  $('.trans').show();
  $('.' + lang).show();
})
$('.busList').on('click', '[name=icon]', function () {
  if ($(this).hasClass('bcRed')) {
    $(this).removeClass('bcRed').addClass('bcGreen').attr('enabled', 'yes');
  } else if ($(this).hasClass('bcGreen')) {
    $(this).removeClass('bcGreen').addClass('bcRed').attr('enabled', 'no');
  }
  mapChannelChange();
  setConfig();
})
//弹框的x号点击关掉页面
$('.close,.closeInfo').click(function () {
  $(this).parent().parent().hide();
  $('.trans').hide();
  if ($(this).parent().parent().hasClass('open')) {
    for (let i = 0; i < $('.message_binding_content>ul>li').length; i++) {
      if ($('[name=counter_signal]>option').eq($('[name=counter_signal]').val()).html() == $('.message_binding_content>ul>li').eq(i).find('span').eq(0).html()) {
        bds[bdsI][i + 1]['type'] = "Counter";
      } else if ($('[name=validator_signal]>option').eq($('[name=validator_signal]').val()).html() == $('.message_binding_content>ul>li').eq(i).find('span').eq(0).html()) {
        bds[bdsI][i + 1]['type'] = "Validator";
      } else {
        bds[bdsI][i + 1]['type'] = "Normal";
      }
      bds[bdsI][i + 1]['source'] = $('.message_binding_content>ul>li').eq(i).find('a').attr('id');
      bds[bdsI][i + 1]['signal'] = $('a.message').attr('id') + ':' + $('.message_binding_content>ul>li').eq(i).find('span:eq(0)').html();
      bds[bdsI][i + 1]['scale'] = $('.message_binding_content>ul>li').eq(i).find('a').attr('scale');
      bds[bdsI][i + 1]['default'] = $('.message_binding_content>ul>li').eq(i).find('input').val();
    }
    bds[bdsI][bds[bdsI].length - 1] = $('[name=validator_type]').val() == 'xor' ? { "type": "xor" } : { "type": "crc8", "origin": $('[name=origin]').val(), "poly": $('[name=poly]').val(), 'inversion': $('[name=inversion]').is(':checked') ? 'yes' : 'no' };
    bdsI = '';
  } else if ($(this).parent().parent().attr('class') == 'add_binding') {
    if ($('a.message').html().indexOf('(') == -1) {
      $('.message_bindings_content').append("<a href=\"javascript:;\" id=\"" + $('a.message').attr('id') + "\">" + $('a.message').attr('val') + "</a>")
    }
    let bd = [];
    bd.push({ 'message': $('a.message').attr('id') });
    for (let i = 0; i < $('.message_binding_content>ul>li').length; i++) {
      let obj = {};
      if ($('[name=counter_signal]>option').eq($('[name=counter_signal]').val()).html() == $('.message_binding_content>ul>li').eq(i).find('span').eq(0).html()) {
        obj['type'] = "Counter";
      } else if ($('[name=validator_signal]>option').eq($('[name=validator_signal]').val()).html() == $('.message_binding_content>ul>li').eq(i).find('span').eq(0).html()) {
        obj['type'] = "Validator";
      } else {
        obj['type'] = "Normal";
      }
      obj['source'] = $('.message_binding_content>ul>li').eq(i).find('a').attr('id');
      obj['signal'] = $('a.message').attr('id') + ':' + $('.message_binding_content>ul>li').eq(i).find('span:eq(0)').html();
      obj['scale'] = $('.message_binding_content>ul>li').eq(i).find('a').attr('scale');
      obj['default'] = $('.message_binding_content>ul>li').eq(i).find('input').val();
      bd.push(obj);
    }
    let validator_type = $('[name=validator_type]').val() == 'xor' ? { "type": "xor" } : { "type": "crc8", "origin": $('[name=origin]').val(), "poly": $('[name=poly]').val(), 'inversion': $('[name=inversion]').is(':checked') ? 'yes' : 'no' }
    bd.push(validator_type)
    bds.push(bd);
    bdsI = '';
  }
  $('.validation_parameters').hide();
  setConfig();
})
function bindingDisabled(bdsI) {
  if (bdsI === '') {
    $('.message').html(biGetLanguage() == 1 ? '(Not configured)' : '(未配置)').removeAttr('id val').removeClass('a_disabled span_disabled');
    $('.add_binding select').val(0);
    $('.message_binding_content>ul,[name="counter_signal"],[name="validator_signal"]').empty();
    $('[name="counter_signal"],[name="validator_signal"]').append('<option value="0">(Disabled)</option>')
    $('.validation_parameters [type=number]').val(0).next().html('0x0');
    $('.validation_parameters [type=checkbox]').attr('checked', false);
    $('[name=validator_type]').val('xor');
    $('[language="validation_parameters"]').hide();
  } else {
    biQuerySignalsInBusMessage('open_message', bds[bdsI][0]['message']);
  }
}
//点击添加，选择协议文件
$('[language="add_channel_protocol"]').click(function () {
  let arr = [];
  $('.protocolList>li>div.right a').each(function () {
    let id = $(this).attr('id');
    let md5 = $(this).attr('md5');
    arr.push({ 'fileName': id, 'md5': md5 })
  })
  biSelectBusProtocols($(this).attr('class'), arr)
})
function biOnSelectedBusProtocols(key, busProtocols) {
  if (key.indexOf('ch') != -1) {
    $('div#' + key).append('<a href="javascript:;" id="' + busProtocols[0]['fileName'] + '" md5="' + busProtocols[0]['md5'] + '">' + busProtocols[0]['fileName'] + '</a>');
  }
  setConfig();
}
//点击添加的协议文件名
$('.protocolList>li>div.right,.message_bindings_content,.message_binding_content').on('click', 'a', function () {
  let id = $(this).attr('id');
  if ($(this).parent().parent().parent().hasClass('protocolList')) {
    $('.dbc').html((biGetLanguage() == 1 ? 'Are you sure to remove protocol file' : '是否移除协议文件\'') + id + '\'?').attr('id', id);
    $('.confirm,.trans').show();
  } else if ($(this).parent().hasClass('message_bindings_content')) {
    if ($(this).hasClass('red')) {
      $('.dbc').html(biGetLanguage() == 1 ? 'Do you want to delete the wrong binding?' : '是否删除有错误的绑定?').attr('id', id);
      $('.confirm,.trans').show();
    } else {
      bdsI = $(this).index();
      $('.add_binding').addClass('open');
      bindingDisabled(bdsI);
      return;
    }
  } else if ($(this).parent().parent().parent().hasClass('message_binding_content')) {
    let name = $(this).attr('class');
    let id = $(this).attr('id');
    let scale = $(this).attr('scale');
    biSelectSignal(name, id, false, null, true, scale, null);
  }
})
$('.removeDBC').on('click', function () {
  let id = $('.dbc').attr('id');
  $('.protocolList div.right,.message_bindings_content').find('a').each(function () {
    if ($(this).attr('id') == id) {
      if ($(this).parent().hasClass('message_bindings_content')) {
        bds.splice($(this).index(), 1);
      }
      $(this).remove();
    };
  })
  setConfig();
})

function biOnInitEx(config, moduleConfigs) {
  if (biGetRunningMode() != 1) {
    $('.busList,a[language="add_binding"]').show();
    $('.message_bindings_content').show();
  } else {
    $('h5').show();
    $('.busList,a[language="add_binding"]').hide();
  };
  biSetViewSize(1112, 613);
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('root');
    let arr = [], chList = [];
    for (let i = 0; i < countrys[0].childNodes.length; i++) {
      let keys = countrys[0].childNodes[i].getAttributeNames();
      if (countrys[0].childNodes[i].nodeName.indexOf('device') != -1) {
        let obj = {};
        for (let n = 0; n < keys.length; n++) {
          obj[keys[n]] = countrys[0].childNodes[i].getAttribute(keys[n]);
        }
        busList.push(obj);
      }
      if (countrys[0].childNodes[i].nodeName.indexOf('ch') != -1) {
        if (countrys[0].childNodes[i].childNodes.length == 0) {
          chList.push("");
        } else {
          let ch = [];
          for (let j = 0; j < countrys[0].childNodes[i].childNodes.length; j++) {
            let o = {};
            for (let k in countrys[0].childNodes[i].childNodes[j].getAttributeNames()) {
              let key = countrys[0].childNodes[i].childNodes[j].getAttributeNames()[k];
              let val = countrys[0].childNodes[i].childNodes[j].getAttribute(key);
              o[key] = val;
            }
            ch.push(o);
          }
          chList.push(ch);
        }
      }
      if (countrys[0].childNodes[i].nodeName.indexOf('bd') != -1) {
        let bd = [];
        bd.push({ "message": countrys[0].childNodes[i].getAttribute('message') });
        for (let j = 0; j < countrys[0].childNodes[i].childNodes.length; j++) {
          let o = {};
          for (let k in countrys[0].childNodes[i].childNodes[j].getAttributeNames()) {
            let key = countrys[0].childNodes[i].childNodes[j].getAttributeNames()[k];
            let val = countrys[0].childNodes[i].childNodes[j].getAttribute(key);
            o[key] = val;
          }
          bd.push(o);
        }
        bds.push(bd);
      }
    }
    arr.push(busList, chList);
    loadConfig(arr);
  }
  biQueryBusDevicesInfo();
  not_config = biGetLanguage() == 1 ? '(Not configured)' : '(未配置)';
}
function loadConfig(config) {
  let versions = biGetNativeModuleVersions(2);
  for (let i in versions) {
    $('.version').append('<p>' + i + '：v' + versions[i] + '</p>')
  }
  for (let i = 0; i < config[0].length; i++) {
    deviceConfig.push(config[0][i]);
  }
  for (let i in bds) {
    biQueryBusMessageInfo(bds[i][0]['message'], bds[i][0]['message']);
  }
  for (let i = 0; i < bds.length; i++) {
    for (let j = 1; j < bds[i].length - 1; j++) {
      if (bds[i][j]['source'] != '' && bds[i][j]['source'] != "null") {
        biQuerySignalInfo(i, bds[i][j]['source']);
      }
    }
  }
  for (let i in config[1]) {
    if (config[1][i] != '') {
      for (let j in config[1][i]) {
        $('#ch' + i).append(`<a href="javascript:;" id="` + config[1][i][j]['id'] + `" md5="` + config[1][i][j]['md5'] + `" class="red">` + config[1][i][j]['id'] + `</a>`);
      }
    };
  }
  $(".protocolList>li>div.right>a").each(function () {
    let i = $(this).parent().parent().index();
    let j = $(this).index();
    let id = $(this).attr("id");
    let md5 = $(this).attr("md5");
    console.log('ch' + i + ">a:eq(" + j + ")");
    biQueryBusProtocolInfo('ch' + i + ">a:eq(" + j + ")", { "fileName": id, "md5": md5 });
  })
}

function biOnQueriedBusProtocolInfo(key, busProtocolInfo) {
  console.log(key);
  if (busProtocolInfo["status"] == 1) {
    $('#' + key).removeClass('red');
  }
}
function biOnQueriedBusMessageInfo(key, busMessageInfo) {
  if (busMessageInfo == null) {
    $('.message_bindings_content').append("<a href=\"javascript:;\" class=\"red\" id=\"" + key + "\">" + key + "</a>");
  } else {
    $('.message_bindings_content').append("<a href=\"javascript:;\" id=\"" + busMessageInfo.id + "\">" + busMessageInfo.protocol + ":" + busMessageInfo.name + "</a>");
  }
}
function biOnQueriedBusDevicesInfo(devicesInfo) {
  let devices = JSON.parse(JSON.stringify(devicesInfo)),
    busList2 = JSON.parse(JSON.stringify(busList)),
    busListExistIndex = [],
    busListExist = [],
    busListIndex = [];
  for (let i in BIBusChannelType) {
    busChannelTypes.push(i);
  }
  // aspro里面有设备
  if (busList.length > 0) {
    for (let i = 0; i < busList.length; i++) {
      let busListName = busList[i].device_type + (busList[i].device_serial == 0 ? busList[i].device_channel : busList[i].device_serial);
      for (let j in devicesInfo) {
        let deviceInfoName = devicesInfo[j].type + (devicesInfo[j].serial == 0 ? devicesInfo[j].index : devicesInfo[j].serial);
        // 如果aspro里和获取到的设备一样，就把他删掉，留着已经移除的设备变灰色
        if (deviceInfoName == busListName) {
          devices.splice(j, 1, '')
          //删除掉aspro里面已经存在的设备,留下新增设备但是aspro里面没有的
          busListIndex.push(i);
          //将aspro里面存在的设备放在buslistexist里面,方便读取数据
          busListExist.push(busList[i]);
          busListExistIndex.push(Number(j));
          break;
        }
      }
    }
    // 读取到设备,aspro里面也有,读取数据
    for (let i = 0; i < busListExistIndex.length; i++) {
      let name1 = devicesInfo[busListExistIndex[i]].description,
        type_option = "",
        support_types = devicesInfo[busListExistIndex[i]].supportedTypes,
        serial = devicesInfo[busListExistIndex[i]].serial,
        index = String.fromCharCode(String(busListExist[i].device_channel).charCodeAt() + 17),
        type = devicesInfo[busListExistIndex[i]].type,
        name2 = type + (serial.length > 1 ? '#' + serial : '') + '-' + index;
      for (let k in support_types) {
        let type = busChannelTypes[support_types[k]];
        type_option += `<option value="` + support_types[k] + `">` + type + `</option>`;
      }
      $('.busList').append(`<li class="fixclear">
              <span class="left bcRed" name="icon" enabled="no"></span>
              <ul class="left">
              <li class="fixclear">
              <div class="left">
               <p class="name1" title="`+ name1 + `">` + name1 + `</p>
               <span class="name2" device_type="`+ type + `" device_serial="` + serial + `" device_channel="` + busListExist[i].device_channel + `">` + name2 + `</span>
              </div>
              <div class="right"><span language="channel">软件通道:</span>
                <select name="map_channel">
                  <option value="1">CH1</option>
                  <option value="2">CH2</option>
                  <option value="3">CH3</option>
                  <option value="4">CH4</option>
                  <option value="5">CH5</option>
                  <option value="6">CH6</option>
                  <option value="7">CH7</option>
                  <option value="8">CH8</option>
                  <option value="9">CH9</option>
                  <option value="10">CH10</option>
                  <option value="11">CH11</option>
                  <option value="12">CH12</option>
                  <option value="13">CH13</option>
                  <option value="14">CH14</option>
                  <option value="15">CH15</option>
                  <option value="16">CH16</option>
                </select>
              </div>
            </li>
            <li>
              <span language="type">类型:</span>
              <select name="channel_type">
                `+ type_option + `
              </select>
              <span language="rate">速率:</span>
              <select name="bit_rate"></select>
              <span language="bit_rate_sub">子速率:</span>
              <select name="bit_rate_sub"></select>
            </li>
              </ul>
            </li>`);
    }
    // 读取到设备,但aspro里面没有,新增设备
    for (let i = 0; i < devices.length; i++) {
      if (devices[i] != '') {
        let name1 = devicesInfo[i].description,
          type_option = "",
          support_types = devicesInfo[i].supportedTypes,
          serial = devicesInfo[i].serial,
          index = String.fromCharCode(String(devicesInfo[i].index).charCodeAt() + 17),
          name2 = devicesInfo[i].type + (serial.length > 1 ? '#' + serial : '') + '-' + index,
          type = devicesInfo[i].type,
          idx = devicesInfo[i].index;
        for (let k in support_types) {
          let type = busChannelTypes[support_types[k]];
          type_option += `<option value="` + support_types[k] + `">` + type + `</option>`;
        }
        $('.busList').append(`<li class="fixclear">
              <span class="left bcRed" name="icon" enabled="no"></span>
              <ul class="left">
              <li class="fixclear">
              <div class="left">
               <p class="name1" title="`+ name1 + `">` + name1 + `</p>
               <span class="name2" device_type="`+ type + `" device_serial="` + serial + `" device_channel="` + idx + `">` + name2 + `</span>
              </div>
              <div class="right"><span language="channel">软件通道:</span>
                <select name="map_channel">
                  <option value="1">CH1</option>
                  <option value="2">CH2</option>
                  <option value="3">CH3</option>
                  <option value="4">CH4</option>
                  <option value="5">CH5</option>
                  <option value="6">CH6</option>
                  <option value="7">CH7</option>
                  <option value="8">CH8</option>
                  <option value="9">CH9</option>
                  <option value="10">CH10</option>
                  <option value="11">CH11</option>
                  <option value="12">CH12</option>
                  <option value="13">CH13</option>
                  <option value="14">CH14</option>
                  <option value="15">CH15</option>
                  <option value="16">CH16</option>
                </select>
              </div>
            </li>
            <li>
              <span language="type">类型:</span>
              <select name="channel_type">
                `+ type_option + `
              </select>
              <span language="rate">速率:</span>
              <select name="bit_rate"></select>
              <span language="bit_rate_sub">子速率:</span>
              <select name="bit_rate_sub" disabled></select>
            </li>
              </ul>
            </li>`);
      };
    }
    for (let i in busListIndex) {
      busList2.splice(busListIndex[i], 1, '');
    }
    // 没有读取到设备,但是aspro里面有的,icon变灰色
    for (let i in busList2) {
      if (busList2[i] != '') {
        let name = busList[i].device_type + (busList2[i].device_serial.length > 1 ? ' #' + busList2[i].device_serial : '') + '-' + String.fromCharCode(String(busList2[i].device_channel).charCodeAt() + 17);
        let option = '';
        for (let j = 1; j <= 16; j++) {
          select = j == Number(busList2[i].map_channel) ? 'selected' : '';
          option += "<option value=\"" + j + "\"" + select + ">CH" + j + "</option>";
        }
        $('.busList').append(`<li class="fixclear">
            <span class="left bcGray" name="icon" enabled="no"></span>
            <ul class="left">
            <li class="fixclear">
            <div class="left">
             <span class="name2" title="`+ name + `" device_type="` + busList2[i].device_type + `" device_serial="` + busList2[i].device_serial + `" device_channel="` + busList2[i].device_channel + `">` + name + `</span>
            </div>
            <div class="right"><span language="channel">软件通道:</span>
              <select name="map_channel">
              `+ option + `
              </select>
            </div>
          </li>
          <li>
            <span language="type">类型:</span>
            <select name="channel_type" disabled>
            </select>
            <span language="rate">速率:</span>
            <select name="bit_rate" disabled></select>
            <span language="bit_rate_sub">子速率:</span>
            <select name="bit_rate_sub" disabled></select>
          </li>
            </ul>
            <img src="bus/img/del.png" class="removeBusDevice right">
          </li>`);
      }
    }
    // aspro里面没设备
  } else {
    //aseva里面无设备
    for (let i in devicesInfo) {
      let name1 = devicesInfo[i].description,
        type_option = "",
        support_types = devicesInfo[i].supportedTypes,
        serial = devicesInfo[i].serial,
        index = String.fromCharCode(String(devicesInfo[i].index).charCodeAt() + 17),
        name2 = devicesInfo[i].type + (serial.length > 1 ? '#' + serial : '') + '-' + index;
      for (let j in support_types) {
        let type = busChannelTypes[support_types[j]];
        type_option += `<option value="` + support_types[k] + `">` + type + `</option>`;
      }
      $('.busList').append(`<li class="fixclear">
          <span class="left bcRed" name="icon" enabled="no"></span>
          <ul class="left">
          <li class="fixclear">
          <div class="left">
           <p class="name1" title="`+ name1 + `">` + name1 + `</p>
           <span class="name2" device_type="`+ devicesInfo[i].type + `" device_serial="` + serial + `" device_channel="` + devicesInfo[i].index + `">` + name2 + `444</span>
          </div>
          <div class="right"><span language="channel">软件通道:</span>
            <select name="map_channel">
              <option value="1">CH1</option>
              <option value="2">CH2</option>
              <option value="3">CH3</option>
              <option value="4">CH4</option>
              <option value="5">CH5</option>
              <option value="6">CH6</option>
              <option value="7">CH7</option>
              <option value="8">CH8</option>
              <option value="9">CH9</option>
              <option value="10">CH10</option>
              <option value="11">CH11</option>
              <option value="12">CH12</option>
              <option value="13">CH13</option>
              <option value="14">CH14</option>
              <option value="15">CH15</option>
              <option value="16">CH16</option>
            </select>
          </div>
        </li>
        <li>
          <span language="type">类型:</span>
          <select name="channel_type">
            `+ type_option + `
          </select>
          <span language="rate">速率:</span>
          <select name="bit_rate"></select>
          <span language="bit_rate_sub">子速率:</span>
          <select name="bit_rate_sub"></select>
        </li>
          </ul>
        </li>`);
    }
  }
  for (let i in busListIndex) {
    if (deviceConfig[busListIndex[i]].enabled == 'yes' && !$('.busList>li').eq(i).find('[name="icon"]').hasClass('bcGray')) {
      $('.busList>li').eq(i).find('[name="icon"]').removeClass('bcRed').addClass('bcGreen').attr('enabled', deviceConfig[busListIndex[i]].enabled);
    } else if (deviceConfig[busListIndex[i]].enabled == 'no' && !$('.busList>li').eq(i).find('[name="icon"]').hasClass('bcGray')) {
      $('.busList>li').eq(i).find('[name="icon"]').removeClass('bcGreen').addClass('bcRed');
    }
    $('.busList>li').eq(i).find('[name="map_channel"]').val(deviceConfig[busListIndex[i]].map_channel == '0' ? 1 : deviceConfig[busListIndex[i]].map_channel);
    $('.busList>li').eq(i).find('[name="channel_type"]').val(deviceConfig[busListIndex[i]].channel_type);
    let type = deviceConfig[busListIndex[i]].channel_type,
      bit_rate = '',
      bit_rate_sub = '';
    if (type == '1') {
      bit_rate = '<option value="1">5K</option><option value="2">10K</option><option value="3">20K</option><option value="18">33K</option><option value="4">40K</option><option value="5">50K</option><option value="6">62K</option><option value="7">80K</option><option value="8">83K</option><option value="9">100K</option><option value="10">125K</option><option value="11">200K</option><option value="12">250K</option><option value="13">400K</option><option value="14">500K</option><option value="15">666K</option><option value="16">800K</option><option value="17">1M</option>';
      bit_rate_sub = '';
    } else if (type == '2') {
      bit_rate = '<option value="101">500K</option><option value="102">1M</option><option value="103">2M</option><option value="104">4M</option><option value="106">6M</option><option value="105">8M</option></select>';
      bit_rate_sub = `<option value="14">500K</option><option value="17">1M</option>`;
    } else if (type == '4') {
      bit_rate = '<option value="301">2.5M</option><option value="302">5M</option><option value="303">10M</option>';
      bit_rate_sub = '';
    } else if (type == '0' || type == '3' || type == '4') {
      bit_rate = '';
      bit_rate_sub = '';
    }
    if (bit_rate == '') {
      $('.busList>li').eq(i).find('[name="bit_rate"]').attr('disabled', true);
    } else {
      $('.busList>li').eq(i).find('[name=bit_rate]').empty().append(bit_rate).val(deviceConfig[busListIndex[i]].bit_rate);
    }
    if (bit_rate_sub == '') {
      $('.busList>li').eq(i).find('[name="bit_rate_sub"]').attr('disabled', true);
    } else {
      $('.busList>li').eq(i).find('[name="bit_rate_sub"]').empty().append(bit_rate_sub).val(deviceConfig[busListIndex[i]].bit_rate_sub);
      if (deviceConfig[busListIndex[i]].bit_rate == '101') $('.busList>li').eq(i).find('[name="bit_rate_sub"]').attr('disabled', true);
    }
  }
  mapChannelChange();
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value]);
  });
}
function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root>";
  $('.busList>li').each(function () {
    text += "<device"
    text += " device_type=\"" + $(this).find('.name2').attr('device_type') + "\"";
    text += " device_serial=\"" + $(this).find('.name2').attr('device_serial') + "\" ";
    text += " device_channel=\"" + $(this).find('.name2').attr('device_channel') + "\" ";
    $(this).find('select').each(function () {
      text += $(this).attr('name') + "=\"" + ($(this).val() == undefined ? "" : $(this).val()) + "\" ";
    });
    text += "enabled=\"" + $(this).find('[name=icon]').attr('enabled') + "\" ";
    text += "/>";
  })
  $('.protocol>ul>li').each(function () {
    let ch = $(this).find('div.right').attr('id');
    if ($(this).find('div.right').find('a').length == 0) {
      text += "<" + ch + "/>";
    } else {
      text += "<" + ch + ">";
      $(this).find('div.right a').each(function () {
        text += "<protocol_file "
        text += " id=\"" + $(this).attr('id') + "\"";
        text += " md5=\"" + $(this).attr('md5') + "\"";
        text += "/>";
      })
      text += "</" + ch + ">";
    }
  })
  for (let i in bds) {
    text += "<bd message=\"" + bds[i][0]['message'] + "\">";
    for (let j = 1; j < bds[i].length - 1; j++) {
      text += "<sg signal=\"" + bds[i][j]['signal'] + "\" ";
      text += "type=\"" + bds[i][j]['type'] + "\" ";
      text += "source=\"" + bds[i][j]['source'] + "\" ";
      text += "scale=\"" + bds[i][j]['scale'] + "\" ";
      text += "default=\"" + bds[i][j]['default'] + "\" ";
      text += "/>";
    }
    if (bds[i][bds[i].length - 1]['type'] == 'xor') {
      text += "<vd type=\"xor\"/>";
    } else if (bds[i][bds[i].length - 1]['type'] == 'crc8') {
      text += "<vd type=\"" + bds[i][bds[i].length - 1]['type'] + "\" ";
      text += "origin=\"" + bds[i][bds[i].length - 1]['origin'] + "\" ";
      text += "poly=\"" + bds[i][bds[i].length - 1]['poly'] + "\" ";
      text += "inversion=\"" + bds[i][bds[i].length - 1]['inversion'] + "\" ";
      text += "/>";
    }

    text += "</bd>";
  }
  text += "</root>";
  console.log(text);
  biSetModuleConfig("bus.system", text);
}
$('.bus').on('click', '.removeBusDevice', function () {
  $(this).parent().remove();
  setConfig();
})
$('.container').on('change', '[name=channel_type]', function () {
  let type = $(this).val();
  let bit_rate = '',
    bit_rate_sub = '';
  if (type == '1') {
    bit_rate = '<option value="1">5K</option><option value="2">10K</option><option value="3">20K</option><option value="18">33K</option><option value="4">40K</option><option value="5">50K</option><option value="6">62K</option><option value="7">80K</option><option value="8">83K</option><option value="9">100K</option><option value="10">125K</option><option value="11">200K</option><option value="12">250K</option><option value="13">400K</option><option value="14">500K</option><option value="15">666K</option><option value="16">800K</option><option value="17">1M</option>';
    bit_rate_sub = '';
  } else if (type == '2') {
    bit_rate = '<option value="101">500K</option><option value="102">1M</option><option value="103">2M</option><option value="104">4M</option><option value="106">6M</option><option value="106">8M</option></select>';
    bit_rate_sub = `<option value="14">500K</option><option value="17">1M</option>`;
  } else if (type == '4') {
    bit_rate = '<option value="0">2.5M</option><option value="1">5M</option><option value="2">10M</option>';
    bit_rate_sub = '';
  } else if (type == '0' || type == '3' || type == '4') {
    bit_rate = '';
    bit_rate_sub = '';
  }
  if (bit_rate == '') {
    $(this).parent().find('[name="bit_rate"]').empty().attr('disabled', true);
  } else {
    $(this).parent().find('[name=bit_rate]').empty().append(bit_rate).removeAttr('disabled');
  }
  if (bit_rate_sub == '') {
    $(this).parent().find('[name="bit_rate_sub"]').empty().attr('disabled', true);
  } else {
    $(this).parent().find('[name="bit_rate_sub"]').empty().append(bit_rate_sub).removeAttr('disabled');
  }
  if (type == '1') {
    $(this).parent().find('[name="bit_rate"]').val(14);
    $(this).parent().find('[name="bit_rate_sub"]').attr('disabled', true);
  } else if (type == '2') {
    $(this).parent().find('[name="bit_rate"]').val(103);
    $(this).parent().find('[name="bit_rate_sub"]').val(14);
  }
})
$('.container').on('change', '[name=bit_rate]', function () {
  if ($(this).val() == '101') {
    if ($(this).parent().find('[name=bit_rate_sub]').val() == 14) {
      $(this).parent().find('[name=bit_rate_sub]').attr('disabled', true);
    } else {
      $(this).parent().find('[name=bit_rate_sub]').attr('disabled', false);
    }
  }
})
function mapChannelChange() {
  let arr = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []];
  $('.busList>li').each(function () {
    if ($(this).find('span[name=icon]').hasClass('bcGreen')) {
      arr[Number($(this).find('[name=map_channel]').val())].push($(this).index());
      $(this).find('[name=map_channel]').prev().removeClass('red');
    } else if ($(this).find('span[name=icon]').hasClass('bcRed')) {
      $(this).find('[name=map_channel]').prev().removeClass('red');
    }
  })
  for (let i in arr) {
    if (arr[i].length > 1) {
      for (let j in arr[i]) {
        $('.busList>li').eq(arr[i][j]).find('[name=map_channel]').prev().addClass('red');
      }
      $('.busList>li').eq(arr[i][0]).find('[name=map_channel]').prev().removeClass('red');
    }
  }
}
$('.container').on('change', '[name=map_channel]', function () {
  mapChannelChange();
})
$('.container').on('change', '[name]', function () {
  setConfig();
})
$('body').on('click', 'a.message', function () {
  let id = $(this).attr('id');
  let name = $(this).attr('class');
  biSelectBusMessage(name, id);
})
function biOnSelectedBusMessage(key, busMessageInfo) {
  switch (key) {
    case 'message': {
      let count = 0;
      for (let i in $('.message_bindings_content>a')) {
        if ($('.message_bindings_content>a').eq(Number(i)).attr('id') == busMessageInfo.id) {
          biAlert('The message is already binded.');
          count++;
          return;
        }
      }
      if (count == 0) {
        $('.' + key).html(busMessageInfo.name).attr({ 'id': busMessageInfo.id, 'val': busMessageInfo.protocol + ':' + busMessageInfo.name });
        biQuerySignalsInBusMessage('add_message', busMessageInfo.id);
        $('[name="counter_signal"],[name="validator_signal"],.message_binding_content>ul').empty();
        $('[name="counter_signal"],[name="validator_signal"]').append('<option value="0">(Disabled)</option>');
        $('[language="validation_parameters"]').removeClass('span_disabled a_disabled');
      }
      break;
    }
  }
}
function biOnQueriedSignalsInBusMessage(key, signalIDList) {
  switch (key) {
    case 'add_message': {
      for (let i in signalIDList) {
        $('.message_binding_content>ul').append("<li><span>" + signalIDList[i] + "</span><span language=\"\">Source signal:</span><a href=\"javascript:;\" language=\"not_config\" class=\"a" + i + "\" id=\"\" scale=\"1\">(Not configured)</a><span language=\"\">Default value:</span><input type=\"text\" name=\"default\" value=\"0\"></li>");
        $('[name="counter_signal"],[name="validator_signal"]').append('<option value="' + (Number(i) + 1) + '">' + signalIDList[i] + '</option>');
      }
      break;
    }
    case 'open_message': {
      $('div.add_binding').show();
      let counter = 0, validator = 0;
      $('.message_binding_content>ul').empty();
      $('[name="counter_signal"],[name="validator_signal"]').empty().append("<option value=\"0\">(Disabled)</option>");
      for (let i = 1; i <= bds[bdsI].length - 2; i++) {
        let source = bds[bdsI][i]['source'] == '' || bds[bdsI][i]['source'] == undefined || bds[bdsI][i]['source'] == 'null' ? not_config : bds[bdsI][i]['source'].slice(bds[bdsI][i]['source'].indexOf(':') + 1, bds[bdsI][i]['source'].length);
        if (bds[bdsI][i]['type'] == "Counter") counter = i;
        if (bds[bdsI][i]['type'] == "Validator") validator = i;
        $('.message_binding_content>ul').append("<li><span>" + signalIDList[i - 1] + "</span><span language=\"\">Source signal:</span><a href=\"javascript:;\" language=\"not_config\" class=\"a" + i + "\" scale=\"" + bds[bdsI][i]['scale'] + "\" id=\"" + bds[bdsI][i]['source'] + "\">" + source + "</a><span language=\"\">Default value:</span><input type=\"text\" name=\"default\" value=\"" + bds[bdsI][i]['default'] + "\"></li>");
        $('[name="counter_signal"],[name="validator_signal"]').append('<option value="' + i + '">' + signalIDList[i - 1] + '</option>').val();
        biQuerySignalInfo("a" + i, bds[bdsI][i]['source']);
      }
      let message = $('.message_bindings_content>a').eq(bdsI).html();
      $('a.message').html(message.slice(message.lastIndexOf(':') + 1, message.length)).addClass('a_disabled span_disabled').attr('id', bds[bdsI][0]['message']);
      $('[name="counter_signal"]').val(counter);
      $('[name="validator_signal"]').val(validator);
      bindingSelectChange([counter, validator]);
      $('[name="validator_type"]').val(bds[bdsI][bds[bdsI].length - 1]['type']);
      $('.validation_parameters [name]').each(function () {
        let type = $(this).attr('type');
        let name = $(this).attr('name');
        if (type == 'number') {
          $(this).val(bds[bdsI][bds[bdsI].length - 1][name]).next().html('0x' + Number(!bds[bdsI][bds[bdsI].length - 1][name] ? 0 : bds[bdsI][bds[bdsI].length - 1][name]).toString(16));
        } else if (type == 'checkbox') {
          $(this).prop('checked', bds[bdsI][bds[bdsI].length - 1][name] == 'yes' ? true : false);
        }
      });
      $('[name="validator_type"]').val() == 'crc8' ? $('[language="validation_parameters"]').show() : $('[language="validation_parameters"]').hide();
      break;
    }
  }
}
function biOnQueriedSignalInfo(key, signalInfo) {
  if (Number(key) && signalInfo == null) {
    $('.message_bindings_content>a').eq(Number(key)).addClass('red').html($('.message_bindings_content>a').eq(Number(key)).attr('id'));
  } else {
    $("." + key).html(signalInfo.typeName + ":" + signalInfo.signalName)
  }

}
function biOnSelectedSignal(key, valueSignalInfo, signBitSignalInfo, scale) {
  if (valueSignalInfo == null) {
    $('.' + key).html(not_config).attr('scale', 1).removeAttr('id');
  } else {
    if (valueSignalInfo.typeName == undefined) {
      $('.' + key).html(not_config).attr('scale', 1).removeAttr('id');
    } else {
      $('.' + key).html(valueSignalInfo.typeName + ':' + valueSignalInfo.signalName).attr('id', valueSignalInfo.id).attr('scale', scale);
    }
  }
}
$('.del_message').on('click', function () {
  bindingDisabled('');
  $(this).parent().parent().hide();
  $('.validation_parameters').hide();
  if (bdsI !== '') { bds.splice(bdsI, 1) };
  if ($('.message_bindings_content>a').length == 1) {
    bds = [];
  }
  $('.message_bindings_content>a').eq(bdsI).remove();
  $('.trans').hide();
  setConfig();
})
$('[name="validator_type"]').change(function () {
  $(this).val() == 'crc8' ? $(this).next().show() : $(this).next().hide();
  if ($('.message_binding_content>ul>li').length > 0) {
    $(this).next().removeClass('span_disabled adisabled');
  } else {
    $(this).next().addClass('span_disabled a_disabled');
  }
})
$('.add_binding_bottom select').change(function () {
  bindingSelectChange([$('[name =counter_signal ]').val(), $('[name="validator_signal"]').val()]);
})
function bindingSelectChange(val) {
  $('.message_binding_content>ul>li>span').removeClass('span_disabled')
  $('.message_binding_content>ul>li>a').removeClass('a_disabled');
  $('.message_binding_content>ul>li>input').attr('disabled', false).removeClass('span_disabled');
  for (let i in val) {
    if ((Number(val[i]) - 1) < 0) break;
    $('.message_binding_content>ul>li:eq(' + (Number(val[i]) - 1) + ')').find('span').addClass('span_disabled');
    $('.message_binding_content>ul>li:eq(' + (Number(val[i]) - 1) + ')').find('a').addClass('a_disabled');
    $('.message_binding_content>ul>li:eq(' + (Number(val[i]) - 1) + ')').find('input').attr('disabled', true).addClass('span_disabled');
  }
}
$('a').click(function () {
  let name = $(this).attr('language');
  $('div.' + name).show();
  switch (name) {
    case 'add_binding': {
      $('div.add_binding').removeClass('open');
      bindingDisabled('');
      break;
    }
  }
})
$('body').on('blur', 'input[type=number]', function () {
  $(this).val(compareVal(this));
  let name = $(this).attr('name');
  switch (name) {
    case 'origin':
    case 'poly': {
      $(this).next().html('0x' + Number($(this).val()).toString(16));
    }
  }
})
function compareVal(obj) {
  let step = $(obj).attr('step'),
    v = Number($(obj).val()),
    min = Number($(obj).attr('min')),
    max = Number($(obj).attr('max'));
  if (isNaN(v)) { v = Number($(obj).attr('value')); }
  v = v < min ? min : v;
  v = v > max ? max : v;
  return v.toFixed(step.length > 2 ? step.length - 2 : 0)
}