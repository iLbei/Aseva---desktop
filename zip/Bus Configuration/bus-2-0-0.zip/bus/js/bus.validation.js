let busList = [], chList = [], bds = [], not_config, bdsI = '';
$('.validation_parameters').on('input', 'input[type=number]', function () {
  setConfig();
})
$('.validation_parameters').on('blur', 'input[type=number]', function () {
  $(this).val(compareVal(this, $(this).val()));
  $(this).next().html('0x' + Number($(this).val()).toString(16));
})
$("[name]").change(function () {
  bds[bdsI][bds[bdsI].length - 1]["origin"] = $('[name=origin]').val();
  bds[bdsI][bds[bdsI].length - 1]["poly"] = $('[name=poly]').val();
  bds[bdsI][bds[bdsI].length - 1]["inversion"] = $('[name=inversion]').is(":checked")?"yes":"no";
  setConfig();
})
function biOnInitEx(config, moduleConfigs) {
  bdsI = Boolean(config) ? Number(config) : "";
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value]);
  });
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('root');
    for (let i = 0; i < countrys[0].childNodes.length; i++) {
      let keys = countrys[0].childNodes[i].getAttributeNames();
      if (countrys[0].childNodes[i].nodeName.indexOf('device') != -1) {
        let obj = {};
        for (let n = 0; n < keys.length; n++) {
          obj[keys[n]] = countrys[0].childNodes[i].getAttribute(keys[n]);
        }
        busList.push(obj);
      }
      if (countrys[0].childNodes[i].nodeName.indexOf('ch') != -1) {
        if (countrys[0].childNodes[i].childNodes.length == 0) {
          chList.push("");
        } else {
          let ch = [];
          for (let j = 0; j < countrys[0].childNodes[i].childNodes.length; j++) {
            let o = {};
            for (let k in countrys[0].childNodes[i].childNodes[j].getAttributeNames()) {
              let key = countrys[0].childNodes[i].childNodes[j].getAttributeNames()[k];
              let val = countrys[0].childNodes[i].childNodes[j].getAttribute(key);
              o[key] = val;
            }
            ch.push(o);
          }
          chList.push(ch);
        }
      }
      if (countrys[0].childNodes[i].nodeName.indexOf('bd') != -1) {
        let bd = [];
        bd.push({ "message": countrys[0].childNodes[i].getAttribute('message') });
        for (let j = 0; j < countrys[0].childNodes[i].childNodes.length; j++) {
          let o = {};
          for (let k in countrys[0].childNodes[i].childNodes[j].getAttributeNames()) {
            let key = countrys[0].childNodes[i].childNodes[j].getAttributeNames()[k];
            let val = countrys[0].childNodes[i].childNodes[j].getAttribute(key);
            o[key] = val;
          }
          bd.push(o);
        }
        bds.push(bd);
      }
    }
  }
  loadConfig(config);
}

function loadConfig(config) {
  if (config == "") return;
  $('.validation_parameters [name]').each(function () {
    let type = $(this).attr('type');
    let name = $(this).attr('name');
    let val = bds[bdsI][bds[bdsI].length - 1][name];
    if (type == 'number') {
      $(this).val(compareVal(this,val)).next().html('0x' + Number(!val ? 0 : compareVal(this,val)).toString(16));
    } else if (type == 'checkbox') {
      $(this).prop('checked', val == 'yes');
    }
  });
}

function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root>";
  for (var i in busList) {
    text += "<device "
    for (let j in busList[i]) {
      text += j + "=\"" + busList[i][j] + "\" ";
    }
    text += "/>";
  }
  for (let i in chList) {
    let ch = "ch" + i;
    if (chList[i] == "") {
      text += "<" + ch + "/>";
    } else {
      text += "<" + ch + ">";
      for (let j in chList[i]) {
        text += "<protocol_file "
        text += " id=\"" + chList[i][j]['id'] + "\"";
        text += " md5=\"" + chList[i][j]['md5'] + "\"";
        text += "/>";
      }
      text += "</" + ch + ">";
    }
  }
  for (let i in bds) {
    text += "<bd message=\"" + bds[i][0]['message'] + "\">";
    for (let j = 1; j < bds[i].length - 1; j++) {
      text += "<sg signal=\"" + bds[i][j]['signal'] + "\" ";
      text += "type=\"" + bds[i][j]['type'] + "\" ";
      text += "source=\"" + bds[i][j]['source'] + "\" ";
      text += "scale=\"" + bds[i][j]['scale'] + "\" ";
      text += "default=\"" + bds[i][j]['default'] + "\" ";
      text += "/>";
    }
    if (bds[i][bds[i].length - 1]['type'] == 'xor') {
      text += "<vd type=\"xor\"/>";
    } else if (bds[i][bds[i].length - 1]['type'] == 'crc8') {
      text += "<vd type=\"" + bds[i][bds[i].length - 1]['type'] + "\" ";
      text += "origin=\"" + bds[i][bds[i].length - 1]['origin'] + "\" ";
      text += "poly=\"" + bds[i][bds[i].length - 1]['poly'] + "\" ";
      text += "inversion=\"" + bds[i][bds[i].length - 1]['inversion'] + "\" ";
      text += "/>";
    }
    text += "</bd>";
  }
  text += "</root>";
  biSetModuleConfig("bus.system", text);
}

function compareVal(obj, val) {
  var step = $(obj).attr('step').length > 2 ? $(obj).attr('step').length - 2 : 0,
    v = Number(val),
    newVal = 0;
  if (isNaN(v)) {
    newVal = Number($(obj).attr('value'));
  } else {
    var min = Number($(obj).attr('min')),
      max = Number($(obj).attr('max'));
    v = v < min ? min : v;
    v = v > max ? max : v;
    newVal = Math.round(Math.abs(v) * Math.pow(10, step)) / Math.pow(10, step);
    if (v < 0) newVal = -newVal;
  }
  return newVal.toFixed(step);
}