let cn = {
  enable: "启用",
  channel: "通道",
},
  en = {
    enable: "Enable",
    channel: "Channel ",
  };