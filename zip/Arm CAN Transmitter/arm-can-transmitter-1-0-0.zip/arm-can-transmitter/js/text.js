let cn = {
  enable: "启用",
  channel: "通道",
  listeng_mode:"监听模式"
},
  en = {
    enable: "Enable",
    channel: "Channel ",
    listeng_mode:"Listen-only mode"
  };