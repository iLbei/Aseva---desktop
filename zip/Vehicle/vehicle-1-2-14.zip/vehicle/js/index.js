let viewSize = new BISize(700, 600); //窗口大小
let language = sessionStorage.getItem("language"); //取中英文,用于刷新保存的值
let configuration = "";
$(function () {
  // let parser = new DOMParser();
  // let xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root enabled=\"yes\" frequency=\"50\" imu_channel=\"-1\" speed_value=\"rt3001.dbc:1579:ApproxSpeed2D\" speed_sign=\"null\" speed_scale=\"1\" steer_value=\"null\" steer_sign=\"null\" steer_scale=\"1\" steer_rate_value=\"null\" steer_rate_scale=\"1\" steer_torque_value=\"null\" steer_torque_scale=\"1\" brake_value=\"null\" brake_scale=\"1\" throttle_value=\"null\" throttle_scale=\"1\" turn_left_signal=\"null\" turn_left_values=\"0\" turn_right_signal=\"null\" turn_right_values=\"0\" gear_signal=\"null\" gear_d_values=\"0\" gear_n_values=\"0\" gear_r_values=\"0\" gear_p_values=\"0\" speed_fl_value=\"null\" speed_fl_sign=\"null\" speed_fl_scale=\"1\" speed_fr_value=\"null\" speed_fr_sign=\"null\" speed_fr_scale=\"1\" speed_rl_value=\"null\" speed_rl_sign=\"null\" speed_rl_scale=\"1\" speed_rr_value=\"null\" speed_rr_sign=\"null\" speed_rr_scale=\"1\" engine_speed_value=\"null\" engine_speed_scale=\"1\" engine_torque_value=\"null\" engine_torque_scale=\"1\" horn_signal=\"null\" horn_values=\"0\" head_light_signal=\"null\" head_light_n_values=\"0\" head_light_f_values=\"0\" wiper_signal=\"null\" wiper_slow_level_signal=\"null\" wiper_single_values=\"0\" wiper_slow_values=\"0\" wiper_slow1_values=\"0\" wiper_slow2_values=\"0\" wiper_slow3_values=\"0\" wiper_slow4_values=\"0\" wiper_slow5_values=\"0\" wiper_medium_values=\"0\" wiper_fast_values=\"0\" lowfreq_brake=\"yes\" lowfreq_throttle=\"yes\" lowfreq_turn=\"yes\" lowfreq_gear=\"yes\" lowfreq_horn=\"yes\" lowfreq_wiper=\"yes\" lowfreq_headlight=\"yes\" vehicle_width=\"1.9\" vehicle_length=\"4.6\" vehicle_height=\"1.5\" steer_angle_ratio=\"15\" wheel_base=\"2.8\" rear_tread=\"1.6\" front_overhang=\"0.9\" contour_control=\"0.7043478488922119\" enable_can_output=\"no\" output_can_channel=\"1\" output_can_msgid=\"0\" enable_can_output2=\"no\" output_can_channel2=\"1\" output_can_msgid2=\"0\" output_can_turn_left=\"1\" output_can_turn_right=\"1\" output_can_brake=\"1\" output_can_brake_thresh=\"1\"><contour_before x=\"0\" y=\"0.5\" /><contour_after x=\"1\" y=\"0.5\" /></root>";
  // let xmlDoc = parser.parseFromString(xml, "text/xml");
  // sessionStorage.setItem("vehicle_config", xml);
  // dataPlayBack(xmlDoc);
});


function uuid() {
  var s = [];
  var hexDigits = "0123456789abcdef";
  for (var i = 0; i < 32; i++) {
    s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
  }
  s[14] = "4";
  s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1); // bits 6-7 of the clock_seq_hi_and_reserved to 01
  s[8] = s[13] = s[18] = s[23];
  var uuid = s.join("");
  return uuid;
}

function changeOutPutVersion(obj) {
  let version = $(obj).val();
  if (version == "3") {
    $('[name=vehicle_height]').attr("disabled", true).next().hide();
    $('#steer_rate_value').addClass('not_a');
    $('#steer_torque_value').addClass('not_a');
    $('[language=contour]~div>div:nth-of-type(1)>a').each(function () {
      if (!$(this).hasClass('not_a')) $(this).addClass('not_a');
    });
    clearCanvas();
  } else {
    $('[name=vehicle_height]').attr("disabled", false).next().show();
    $('#steer_rate_value').removeClass('not_a');
    $('#steer_torque_value').removeClass('not_a');
    $('[language=reset]').removeClass('not_a');
    reset();
  }
}

function checkImuChannel() {
  let options = $("[name=imu_channel] option:selected");
  if (options.val() > -1 && options.text().indexOf("(") != -1) {
    $('[language=imu_channel]').addClass('red');
  } else {
    $('[language=imu_channel]').removeClass('red');
  }
}

function otherOpen() {
  window.location.href = "vehicle.other_settings.html";
}

function configureOpen() {
  window.location.href = "vehicle.can_box.html";
}

function canBoxClose() {
  $('.shadow').hide();
  $('.canBox').hide();
}



$('select').change(function () {
  setConfig();
});
$('[type=checkbox]').click(function () {
  setConfig();
});
$('[type=number]').change(function () {
  setConfig();
}).blur(function () {
  let max = Number($(this).attr('max'));
  let min = Number($(this).attr('min'));
  let v = Number($(this).val());
  v = v < min ? min : v;
  v = v > max ? max : v;
  $(this).val(v).attr('value', v);
  setConfig();
});



let idNameArr = [];
/**
 *  页面加载时,读取本地配置
 */
function loadConfig(config) {
  if (config == null) return;
  let type = biGetLanguage();
  let val = JSON.parse(config);
  $('.container').find('[name]').each(function () {
    let value = $(this).attr("name");
    let type = $(this).attr("type");
    if (type == "checkbox") {
      if (val[value] == "yes") {
        $(this).prop("checked", true);
      } else {
        $(this).prop("checked", false);
      }
    } else if (type == "number") {
      let step = $(this).attr('step').length - 2;
      let v = parseFloat(val[value]);
      if (step <= -1) {
        $(this).val(v.toFixed(0));
      } else {
        $(this).val(v.toFixed(step));
      }
    } else if (type != "number") {
      let t = val[value] == "null" ? "0" : val[value];
      $(this).val(t);
    }
  });
  $('.container').find('a').each(function () {
    let id = $(this).attr('id');
    let scaleName = $(this).attr('scaleName');
    let sign = $(this).attr('sign');
    if (id != undefined) {
      let signal = val[id];
      if (signal != "null") {
        let arr = signal.split(":");
        if (arr[0].indexOf(".dbc") != -1) {
          biQueryBusProtocolFileChannel(arr[0]);
          idNameArr.push(id + "|" + signal);
        } else {
          $(this).addClass('springgreen').html(arr[2]);
          $(this).parent().attr("title", arr[1] + ":" + arr[2]);
          if (val[scaleName] != "null") $(this).attr("scale", val[scaleName]);
          if (val[sign] != "null") $(this).attr("signVal", val[sign]);
        }
        $(this).attr('val', signal);
      } else {
        $(this).parent().removeAttr('title');
        $(this).removeClass('springgreen').removeAttr("val").removeAttr("signVal");
        if (scaleName != undefined) $(this).attr("scale", "1");
        let lang = type == 1 ? "(Not configured)" : "(未配置)";
        $(this).html(lang);
      }
    }
  });
  biQueryChannelNames("1", "gnssimu-sample-v7", 6);

}
let channelArr = ["A", "B", "C", "D", "E", "F"]

function biOnQueriedChannelNames(key, channelNames) {
  let arr = [];
  for (let key in channelNames) {
    arr.push(channelNames[key]);
  }
  $('[name=imu_channel]').children('option').each(function (i, v) {
    if (i != 0 && arr[i - 1] != "") $(this).html(channelArr[i - 1] + ": " + arr[i - 1]);
  });
  checkImuChannel();
}

//获取总线协议文件绑定的通道
function biOnQueriedBusProtocolFileChannel(busFileProtocolID, busChannel) {
  if (busChannel == 0) {
    for (let i = 0; i < idNameArr.length; i++) {
      let arr = idNameArr[i].split("|");
      $('.container').find('#' + arr[0]).html(arr[1]).addClass('red').removeClass('springgreen');
    }
  } else {
    for (let i = 0; i < idNameArr.length; i++) {
      let arr = idNameArr[i].split("|");
      biQuerySignalInfo(arr[0], arr[1]);
    }
  }
}
//获取信号信息
function biOnQueriedSignalInfo(key, signalID) {
  if (key == "dbc" && signalID != null) {
    $(signalObj).next().html(signalID.typeName + ":" + signalID.signalName);
    $(signalObj).parent().attr("title", signalID.typeName + ":" + signalID.signalName);
  } else {
    $('.container').find('#' + key)
      .html(signalID.signalName)
      .addClass('springgreen')
      .parent().attr("title", signalID.typeName + ":" + signalID.signalName);
  }
}

/**
 * 判断中英文
 */
function changeLanguage(type) {
  if (type == 1) {
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(en[value])
    });
  } else {
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(cn[value])
    });
  }
}
//正则判断是否是数字
function NumberCheck(num) {
  var re = /^\d*\.{0,1}\d*$/;
  if (num == "") return null;
  return re.exec(num) != null ? num : null;
}
//检查文本框的值
function checkTextValue(obj) {
  let str = $(obj).val();
  if (str.indexOf(',') != -1) {
    let flag = false;
    let arr = str.split(","),
      newArr = [];;
    for (let i = 0; i < arr.length; i++) {
      if (arr[i] == "") {
        flag = true;
        break;
      }
      let v = Number(arr[i]);
      if (arr[i] != "") {
        if (isNaN(v)) {
          flag = true;
          break;
        }
      }
      newArr.push(v);
    }
    if (flag) {
      $(obj).addClass('red').removeClass('green');
    } else {
      $(obj).addClass('green').attr('value', newArr.join());
    }
  } else {
    let v = Number(str);
    if (!isNaN(v) && str != "") { //green
      $(obj).addClass('green').attr('value', v).removeClass('red');
    } else if (str != "") { //red
      $(obj).addClass('red').removeClass('green');
    } else if (str == "" && $(obj).hasClass('bar')) {
      $(obj).attr('value', "");
    }
  }

}

$('[type=text]').bind("input propertychange", function () {
  checkTextValue($(this));
  setConfig();
}).blur(function () {
  if ($(this).hasClass('green')) {
    let str = $(this).val();
    if (str.indexOf(",") != -1) {
      let arr = str.split(','),
        newArr = [];
      for (let i = 0; i < arr.length; i++) {
        let v = Number(arr[i]);
        newArr.push(v);
      }
      $(this).val(newArr.join()).attr('value', newArr.join());
    } else {
      if (str != "") {
        let v = Number(str);
        $(this).val(v).attr('value', v);
      } else {
        let v = $(this).attr('value');
        $(this).val(v).attr('value', v);
      }
    }
  } else if ($(this).hasClass('red')) {
    let v = $(this).attr('value');
    $(this).val(v).removeClass('red').addClass('green');
  }
  setConfig();
});

/**
 * 写配置
 */

function setConfig() {
  let text = setData();
  sessionStorage.setItem('vehicle_config', text);
  let vehicle_width = $('[name=vehicle_width]').val();
  let vehicle_length = $('[name=vehicle_length]').val();
  biSetGlobalVariable("Subject.VehicleWidth", vehicle_width);
  biSetGlobalVariable("Subject.VehicleLength", vehicle_length);
  biSetModuleConfig("vehicle.pluginplatform", text);

}


function setData() {
  let config = sessionStorage.getItem('vehicle_config');
  let object = parseXml(config);
  let xmlHead = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
  var xmlDoc = $($.parseXML(config));
  $('.container').find('[name]').each(function () {
    let name = $(this).attr('name');
    let type = $(this).attr('type');
    let vv = $(this).val();
    if (type == "checkbox") {
      vv = $(this).get(0).checked ? "yes" : "no";
    } else if (type == "number") {
      let step = $(this).attr('step').length - 2;
      let v = Number($(this).val());
      let value;
      if (!isNaN(v) && $(this).val() != "") {
        let min = parseFloat($(this).attr('min')),
          max = parseFloat($(this).attr('max'));
        v = v < min ? min : v;
        v = v > max ? max : v;
        if (step <= -1) {
          value = v.toFixed(0);
        } else {
          value = v.toFixed(step);
        }
      } else {
        value = $(this).attr('value');
      }
      vv = value;
    } else if ($(this).is('select')) {
      vv = $(this).val();
    } else if (type == "text" && name != "x" && name != "y") {
      vv = $(this).val();
    }
    $(xmlDoc).find('root').attr(name, vv);
  });
  $('.container').find('a').each(function () {
    let id = $(this).attr('id');
    let val = $(this).attr('val');
    if (id != undefined) {
      let signal = val == undefined ? "null" : val;
      let scale = $(this).attr('scale');
      let scaleName = $(this).attr('scaleName');
      let sign = $(this).attr('sign');
      let signVal = $(this).attr('signVal');
      if (sign != undefined) $(xmlDoc).find('root').attr(sign, (signVal == undefined ? "null" : signVal));
      $(xmlDoc).find('root').attr(id, signal);
      if (scaleName != undefined) $(xmlDoc).find('root').attr(scaleName, scale);
    }
  });
  let contour_before = $(xmlDoc).find('root').find('contour_before');
  $(contour_before).remove();
  let contour_after = $(xmlDoc).find('root').find('contour_after');
  $(contour_after).remove();
  for (let i = 0; i < object.arr.length; i++) {
    let c = object.arr[i];
    let node;
    if (c.x < 0.5) {
      node = "<contour_before x=\"" + c.x + "\"";
      node += " y=\"" + c.y + "\"/>";
    } else if (c.x > 0.5) {
      node = "<contour_after x=\"" + c.x + "\"";
      node += " y=\"" + c.y + "\"/>";
    }
    $(xmlDoc).find('root').append(node);
  }
  let xml = xmlHead + $(xmlDoc).find('root')[0].outerHTML;
  return xml;
}

function parseXml(config) {
  let parser = new DOMParser();
  let xmlDoc = parser.parseFromString(config, "text/xml");
  let countrys = xmlDoc.getElementsByTagName('root');
  let o = new Object();
  let oKeys = countrys[0].getAttributeNames();
  for (let i = 0; i < oKeys.length; i++) {
    o[oKeys[i]] = countrys[0].getAttribute(oKeys[i]);
  }
  let arr = [];
  for (let i = 0; i < countrys[0].childNodes.length; i++) {
    let keyss = countrys[0].childNodes[i].getAttributeNames();
    let obj = new Object();
    for (let j = 0; j < keyss.length; j++) {
      obj[keyss[j]] = countrys[0].childNodes[i].getAttribute(keyss[j]);
    }
    arr.push(obj);
  }
  o["arr"] = arr;
  return o;
}


function importAsmc() {
  var filter = { ".asmc": "ASEva Module Configuration (*.asmc)" };
  biSelectPath("OpenFilePath", BISelectPathType.OpenFile, filter);
}

function exportAsmc() {
  var filter = { ".asmc": "ASEva Module Configuration (*.asmc)" };
  biSelectPath("CreateFilePath", BISelectPathType.CreateFile, filter);
}

function biOnSelectedPath(key, path) {
  if (path == null) {
    return;
  }
  if (key == "CreateFilePath") {
    let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
    let base = new Base64();
    biWriteFileText(path, text + "<root type=\"vehicle-config-v2\">" + base.encode(setData()) + "</root>");
  } else if (key == "OpenFilePath") {
    biQueryFileText(path);
  }
}

function biOnQueriedFileText(text, path) {
  if (text != null) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(text, "text/xml");
    let obj = xmlDoc.getElementsByTagName("root");
    if (obj[0].getAttribute("type") == "vehicle-config-v2") {
      let base = new Base64();
      if (obj[0].firstChild.nodeValue != null) {
        xmlDoc = parser.parseFromString(base.decode(obj[0].firstChild.nodeValue), "text/xml");
        sessionStorage.setItem("vehicle_config", base.decode(obj[0].firstChild.nodeValue));
        biSetModuleConfig("vehicle.pluginplatform", base.decode(obj[0].firstChild.nodeValue));
        dataPlayBack(xmlDoc);
      }
    }
  }
}



/**
 * 选择信号
 * @param {} obj 当前节点
 */
let signalObj = null; //选择的元素的class名
function selectSignal(obj, flag) {
  if ($(obj).hasClass('not_a')) return;
  let originID = null;
  if ($(obj).html().lastIndexOf('(') == -1) originID = $(obj).attr('val');
  let scale = $(obj).attr('scale');
  scale = Number(scale);
  signalObj = obj;
  let signFlag = $(obj).attr('sign') == undefined ? false : true;
  let signVal = $(obj).attr('signVal') == undefined ? null : $(obj).attr('signVal');
  let key = "TargetSignal";
  biSelectSignal(key, originID, signFlag, signVal, flag, scale, "[m]");
}

function biOnSelectedSignal(key, valueInfo, signBitInfo, scale) {
  console.log(valueInfo);
  if (valueInfo == null) {
    let text = biGetLanguage() == 1 ? "(Not configured)" : "(未配置)";
    $(signalObj).removeClass('springgreen');
    $(signalObj).html(text);
    $(signalObj).removeAttr("val");
    $(signalObj).parent().removeAttr("title");
    $(signalObj).removeAttr('signVal');
    $(signalObj).attr('scale', "1");
  } else if (valueInfo.typeName == undefined) {
    $(signalObj).addClass('red').removeClass('springgreen').html(valueInfo.id).attr('val', valueInfo.id);
  } else {
    $(signalObj).parent().attr("title", valueInfo.typeName + ":" + valueInfo.signalName);
    $(signalObj).attr("val", valueInfo.id).attr('scale', scale).addClass('springgreen').html(valueInfo.signalName);
    if (signBitInfo != null) $(signalObj).attr('signVal', signBitInfo.id);
  }
  setConfig();
}
$('.space_a').mouseover(function (e) {
  if ($(this).children('p').html() == "" || $(this).children('a').hasClass('not_a')) return
  $(this).children('p').show();
  let left = e.offsetX + 30;
  let idName = $(this).children('a').attr('id');
  if (idName == "speed_fr_value" || idName == "turn_right_signal" || idName == "gear_signal" || idName == "speed_rr_value") {
    left = e.offsetX - 200;
  }
  $(this).children('p').css({ "left": left + "px", "top": 25 + "px" });
}).mouseout(function (e) {
  $(this).children('p').hide();
});

function biOnInitEx(config, moduleConfigs) {
  let type = biGetLanguage();
  configuration = config;
  changeLanguage(type);
  sessionStorage.setItem("language", type);
  let xml = sessionStorage.getItem('vehicle_config');
  let parser = new DOMParser();
  biSetViewSize(700, 600);
  if (xml != null) {
    biSetModuleConfig("vehicle.pluginplatform", xml);
  } else {
    for (let key in moduleConfigs) {
      xml = moduleConfigs[key]
      sessionStorage.setItem("vehicle_config", moduleConfigs[key]);
    }
  }
  let xmlDoc = parser.parseFromString(xml, "text/xml");
  dataPlayBack(xmlDoc);
}

function dataPlayBack(xmlDoc) {
  let countrys = xmlDoc.getElementsByTagName('root');
  let o = new Object();
  let oKeys = countrys[0].getAttributeNames();
  for (let i = 0; i < oKeys.length; i++) {
    o[oKeys[i]] = countrys[0].getAttribute(oKeys[i]);
  }
  let arr = [];
  for (let i = 0; i < countrys[0].childNodes.length; i++) {
    let nodeName = countrys[0].childNodes[i].nodeName;
    let conu = xmlDoc.getElementsByTagName(nodeName);
    let keyss = conu[0].getAttributeNames();
    let obj = new Object();
    for (let j = 0; j < keyss.length; j++) {
      obj[keyss[j]] = conu[0].getAttribute(keyss[j]);
    }
    arr.push(obj);
  }
  o["arr"] = arr;
  loadConfig(JSON.stringify(o));
}



function Base64() {

  // private property
  _keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

  // public method for encoding
  this.encode = function (input) {
    var output = "";
    var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
    var i = 0;
    input = _utf8_encode(input);
    while (i < input.length) {
      chr1 = input.charCodeAt(i++);
      chr2 = input.charCodeAt(i++);
      chr3 = input.charCodeAt(i++);
      enc1 = chr1 >> 2;
      enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
      enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
      enc4 = chr3 & 63;
      if (isNaN(chr2)) {
        enc3 = enc4 = 64;
      } else if (isNaN(chr3)) {
        enc4 = 64;
      }
      output = output +
        _keyStr.charAt(enc1) + _keyStr.charAt(enc2) +
        _keyStr.charAt(enc3) + _keyStr.charAt(enc4);
    }
    return output;
  }

  // public method for decoding
  this.decode = function (input) {
    var output = "";
    var chr1, chr2, chr3;
    var enc1, enc2, enc3, enc4;
    var i = 0;
    input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
    while (i < input.length) {
      enc1 = _keyStr.indexOf(input.charAt(i++));
      enc2 = _keyStr.indexOf(input.charAt(i++));
      enc3 = _keyStr.indexOf(input.charAt(i++));
      enc4 = _keyStr.indexOf(input.charAt(i++));
      chr1 = (enc1 << 2) | (enc2 >> 4);
      chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
      chr3 = ((enc3 & 3) << 6) | enc4;
      output = output + String.fromCharCode(chr1);
      if (enc3 != 64) {
        output = output + String.fromCharCode(chr2);
      }
      if (enc4 != 64) {
        output = output + String.fromCharCode(chr3);
      }
    }
    output = _utf8_decode(output);
    return output;
  }

  // private method for UTF-8 encoding
  _utf8_encode = function (string) {
    string = string.replace(/\r\n/g, "\n");
    var utftext = "";
    for (var n = 0; n < string.length; n++) {
      var c = string.charCodeAt(n);
      if (c < 128) {
        utftext += String.fromCharCode(c);
      } else if ((c > 127) && (c < 2048)) {
        utftext += String.fromCharCode((c >> 6) | 192);
        utftext += String.fromCharCode((c & 63) | 128);
      } else {
        utftext += String.fromCharCode((c >> 12) | 224);
        utftext += String.fromCharCode(((c >> 6) & 63) | 128);
        utftext += String.fromCharCode((c & 63) | 128);
      }

    }
    return utftext;
  }

  // private method for UTF-8 decoding
  _utf8_decode = function (utftext) {
    var string = "";
    var i = 0;
    var c = c1 = c2 = 0;
    while (i < utftext.length) {
      c = utftext.charCodeAt(i);
      if (c < 128) {
        string += String.fromCharCode(c);
        i++;
      } else if ((c > 191) && (c < 224)) {
        c2 = utftext.charCodeAt(i + 1);
        string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
        i += 2;
      } else {
        c2 = utftext.charCodeAt(i + 1);
        c3 = utftext.charCodeAt(i + 2);
        string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
        i += 3;
      }
    }
    return string;
  }
}