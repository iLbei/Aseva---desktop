$(function() {
    let config = sessionStorage.getItem("vehicle_config");
    let object = parseXml(config);
    if (object == null) return;
    $('.canBox>.content').find('[name]').each(function() {
        let value = $(this).attr("name");
        let type = $(this).attr("type");
        if (type == "checkbox") {
            object[value] == "yes" ? $(this).prop("checked", true) : $(this).prop("checked", false);
        } else if (type == "number") {
            let step = $(this).attr('step').length - 2;
            let v = parseFloat(object[value]);
            if (step <= -1) {
                $(this).val(v.toFixed(0));
            } else {
                $(this).val(v.toFixed(step));
            }
        } else if (type != "number") {
            let t = object[value] == "null" ? "0" : object[value];
            $(this).val(t);
        }
    });
});
/**
 * ok后，返回到主页面
 */
function ok() {
    let config = sessionStorage.getItem("vehicle_config");
    let object = parseXml(config);
    let xmlHead = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
    var xmlDoc = $($.parseXML(config));
    $('.canBox>.content').find('[name]').each(function() {
        let value = $(this).attr("name");
        let type = $(this).attr("type");
        let vv = $(this).val();
        if (type == "checkbox") vv = $(this).get(0).checked ? "yes" : "no";
        $(xmlDoc).find('root').attr(value, vv);
    });
    let contour_before = $(xmlDoc).find('root').find('contour_before');
    $(contour_before).remove();
    let contour_after = $(xmlDoc).find('root').find('contour_after');
    $(contour_after).remove();
    for (let i = 0; i < object.arr.length; i++) {
        let c = object.arr[i];
        let node;
        if (c.x < 0.5) {
            node = "<contour_before x=\"" + c.x + "\"";
            node += " y=\"" + c.y + "\"/>";
        } else if (c.x > 0.5) {
            node = "<contour_after x=\"" + c.x + "\"";
            node += " y=\"" + c.y + "\"/>";
        }
        $(xmlDoc).find('root').append(node);
    }
    let xml = xmlHead + $(xmlDoc).find('root')[0].outerHTML;
    sessionStorage.setItem('vehicle_config', xml);
    window.location.href = "vehicle.html";
}

function biOnInit(config) {
    let type = biGetLanguage();
    changeLanguage(type);
    biSetViewSize(472, 260);
}
/**
 * 判断中英文
 */
function changeLanguage(type) {
    if (type == 1) {
        $('[language]').each(function() {
            let value = $(this).attr('language');
            $(this).html(en[value])
        });
    } else {
        $('[language]').each(function() {
            let value = $(this).attr('language');
            $(this).html(cn[value])
        });
    }
}

function parseXml(config) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(config, "text/xml");
    let countrys = xmlDoc.getElementsByTagName('root');
    let o = new Object();
    let oKeys = countrys[0].getAttributeNames();
    for (let i = 0; i < oKeys.length; i++) {
        o[oKeys[i]] = countrys[0].getAttribute(oKeys[i]);
    }
    let arr = [];
    for (let i = 0; i < countrys[0].childNodes.length; i++) {
        let keyss = countrys[0].childNodes[i].getAttributeNames();
        let obj = new Object();
        for (let j = 0; j < keyss.length; j++) {
            obj[keyss[j]] = countrys[0].childNodes[i].getAttribute(keyss[j]);
        }
        arr.push(obj);
    }
    o["arr"] = arr;
    return o;
}

$('[type=number]').change(function() {

}).blur(function() {
    let max = Number($(this).attr('max'));
    let min = Number($(this).attr('min'));
    let v = Number($(this).val());
    v = v < min ? min : v;
    v = v > max ? max : v;
    $(this).val(v).attr('value', v);
});