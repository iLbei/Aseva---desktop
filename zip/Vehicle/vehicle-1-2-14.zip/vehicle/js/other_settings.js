let canvas, ctx;
let circleArr = []; //存放circle
let circleIndex = -1; //记录每个circle下标
let flag = false;
let leftLocal = 0,
  topLocal = 0;
let oldLeft = 0,
  oldTop = 0;
let oldX = 0,
  oldY = 0;
let center = new BIPoint(150, 52);
let object;
let scaleA = 1;
$(function () {
  canvas = $('#myCanvas')[0];
  ctx = canvas.getContext('2d');
  let config = sessionStorage.getItem('vehicle_config');
  object = parseXml(config);
  reset(object.vehicle_width, object.vehicle_length, object.arr);
});
let idNameArr = [];

function loadConfig(config) {
  if (config == null) return;
  let type = biGetLanguage();
  let val = config;
  $('.other_settings').find('[name]').each(function () {
    let value = $(this).attr("name");
    let type = $(this).attr("type");
    if (type == "checkbox") {
      if (val[value] == "yes") {
        $(this).prop("checked", true);
      } else {
        $(this).prop("checked", false);
      }
    } else if (type == "number") {
      let step = $(this).attr('step').length - 2;
      let v = parseFloat(val[value]);
      if (step <= -1) {
        $(this).val(v.toFixed(0));
      } else {
        $(this).val(v.toFixed(step));
      }
    } else if (type != "number") {
      let t = val[value] == "null" ? "0" : val[value];
      $(this).val(t);
    }
  });
  $('.other_settings').find('a').each(function () {
    let id = $(this).attr('id');
    let scaleName = $(this).attr('scaleName');
    let sign = $(this).attr('sign');
    if (id != undefined) {
      if (id.indexOf('scale_') != -1) {
        $(this).html(type == 1 ? "Scale:Small" : "Scale:Large")
      } else {
        let signal = val[id];
        if (signal != "null" && signal != null) {
          let arr = signal.split(":");
          if (arr[0].indexOf(".dbc") != -1) {
            biQueryBusProtocolFileChannel(arr[0]);
            idNameArr.push(id + "|" + signal);
          } else {
            $(this).addClass('springgreen').html(arr[2]);
            $(this).parent().attr("title", arr[1] + ":" + arr[2]);
            if (val[scaleName] != "null") $(this).attr("scale", val[scaleName]);
            if (val[sign] != "null") $(this).attr("signVal", val[sign]);
          }
          $(this).attr('val', signal);
        } else {
          $(this).parent().removeAttr('title');
          $(this).removeClass('springgreen').removeAttr("val").removeAttr("signVal");
          if (scaleName != undefined) $(this).attr("scale", "1");
          let lang = type == 1 ? "(Not configured)" : "(未配置)";
          $(this).html(lang);
        }
      }
    }
  });
}
//获取总线协议文件绑定的通道
function biOnQueriedBusProtocolFileChannel(busFileProtocolID, busChannel) {
  if (busChannel == 0) {
    for (let i = 0; i < idNameArr.length; i++) {
      let arr = idNameArr[i].split("|");
      $('.other_settings').find('#' + arr[0]).html(arr[1]).addClass('red').removeClass('springgreen');
    }
  } else {
    for (let i = 0; i < idNameArr.length; i++) {
      let arr = idNameArr[i].split("|");
      biQuerySignalInfo(arr[0], arr[1]);
    }
  }
}
//获取信号信息
function biOnQueriedSignalInfo(key, signalID) {
  if (key == "dbc" && signalID != null) {
    $(signalObj).next().html(signalID.typeName + ":" + signalID.signalName);
    $(signalObj).parent().attr("title", signalID.typeName + ":" + signalID.signalName);
  } else {
    $('.other_settings').find('#' + key)
      .html(signalID.signalName)
      .removeClass('red')
      .addClass('springgreen')
      .parent().attr("title", signalID.typeName + ":" + signalID.signalName);
  }
}
/**
 * 选择信号
 * @param {} obj 当前节点
 */
let signalObj = null; //选择的元素的class名
function selectSignal(obj, flag) {
  if ($(obj).hasClass('not_a')) return;
  let originID = null;
  if ($(obj).html().lastIndexOf('(') == -1) originID = $(obj).attr('val');
  let scale = $(obj).attr('scale');
  scale = Number(scale);
  signalObj = obj;
  let signFlag = $(obj).attr('sign') == undefined ? false : true;
  let signVal = $(obj).attr('signVal') == undefined ? null : $(obj).attr('signVal');
  let key = "TargetSignal";
  if ($(obj).hasClass('red')) key += "2";
  biSelectSignal(key, originID, signFlag, signVal, flag, scale, "[m]");
}

function biOnSelectedSignal(key, valueInfo, signBitInfo, scale) {
  if (valueInfo == null) {
    let text = biGetLanguage() == 1 ? "(Not configured)" : "(未配置)";
    $(signalObj).removeClass('springgreen');
    $(signalObj).html(text);
    $(signalObj).removeAttr("val");
    $(signalObj).parent().removeAttr("title");
  } else if (key == "TargetSignal") {
    let arr = valueInfo.id.split(":");
    $(signalObj).attr("val", valueInfo.id).attr('scale', scale).addClass('springgreen').html(arr[2]);
    $(signalObj).parent().attr("title", arr[1] + ":" + arr[2]);
    if (signBitInfo != null) $(signalObj).attr('signVal', signBitInfo.id);
  }
}
/**
 * 确认
 */
function ok() {
  let config = sessionStorage.getItem("vehicle_config");
  let xmlHead = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
  var xmlDoc = $($.parseXML(config));
  $('.other_settings').find('[name]').each(function () {
    let value = $(this).attr("name");
    let type = $(this).attr("type");
    let vv = $(this).val();
    if (type == "checkbox") vv = $(this).get(0).checked ? "yes" : "no";
    if (value != "x" && value != "y") $(xmlDoc).find('root').attr(value, vv);
  });
  $('.other_settings').find('a').each(function () {
    let id = $(this).attr("id");
    let signal = $(this).attr('val') == undefined ? "null" : $(this).attr('val');
    let scaleName = $(this).attr("scaleName");
    let scale = $(this).attr('scale');
    $(xmlDoc).find('root').attr(id, signal);
    $(xmlDoc).find('root').attr(scaleName, scale);
  });
  let contour_before = $(xmlDoc).find('root').find('contour_before');
  $(contour_before).remove();
  let contour_after = $(xmlDoc).find('root').find('contour_after');
  $(contour_after).remove();
  let w = Number(object.vehicle_width),
    l = Number(object.vehicle_length);
  for (let i = 1; i < circleArr.length - 1; i++) {
    let v1 = circleArr[i];
    if (v1.flag) continue;
    let node;
    if (v1.position == "contour_before") {
      node = "<contour_before x=\"" + v1.vy / l + "\"";
      node += " y=\"" + v1.vx / w + "\"/>";
    } else {
      node = "<contour_after x=\"" + v1.vy / l + "\"";
      node += " y=\"" + v1.vx / w + "\"/>";
    }
    $(xmlDoc).find('root').append(node);
  }
  let xml = xmlHead + $(xmlDoc).find('root')[0].outerHTML;
  sessionStorage.setItem('vehicle_config', xml);
  window.location.href = "vehicle.html";
}
//正则判断是否是数字
function NumberCheck(num) {
  var re = /^\d*\.{0,1}\d*$/;
  if (num == "") return null;
  return re.exec(num) != null ? num : null;
}
//检查文本框的值
function checkTextValue(obj) {
  let str = $(obj).val();
  if (str.indexOf(',') != -1) {
    let flag = false;
    let arr = str.split(","),
      newArr = [];;
    for (let i = 0; i < arr.length; i++) {
      if (arr[i] == "") {
        flag = true;
        break;
      }
      let v = Number(arr[i]);
      if (arr[i] != "") {
        if (isNaN(v)) {
          flag = true;
          break;
        }
      }
      newArr.push(v);
    }
    if (flag) {
      $(obj).addClass('red').removeClass('green');
    } else {
      $(obj).addClass('green').attr('value', newArr.join());
    }
  } else {
    let v = Number(str);
    if (!isNaN(v) && str != "") { //green
      $(obj).addClass('green').attr('value', v).removeClass('red');
    } else if (str != "") { //red
      $(obj).addClass('red').removeClass('green');
    } else if (str == "" && $(obj).hasClass('bar')) {
      $(obj).attr('value', "");
    }
  }

}
$('[type=text]').bind("input propertychange", function () {
  checkTextValue($(this));
}).blur(function () {
  if ($(this).hasClass('green')) {
    let str = $(this).val();
    if (str.indexOf(",") != -1) {
      let arr = str.split(','),
        newArr = [];
      for (let i = 0; i < arr.length; i++) {
        let v = Number(arr[i]);
        newArr.push(v);
      }
      $(this).val(newArr.join()).attr('value', newArr.join());
    } else {
      if (str != "") {
        let v = Number(str);
        $(this).val(v).attr('value', v);
      } else {
        let v = $(this).attr('value');
        $(this).val(v).attr('value', v);
      }
    }
  } else if ($(this).hasClass('red')) {
    let v = $(this).attr('value');
    $(this).val(v).removeClass('red').addClass('green');
  }
});


function biOnInit(config) {
  let type = biGetLanguage();
  changeLanguage(type);
  biSetViewSize(715, 660);
  loadConfig(object);
}

function parseXml(config) {
  let parser = new DOMParser();
  let xmlDoc = parser.parseFromString(config, "text/xml");
  let countrys = xmlDoc.getElementsByTagName('root');
  let o = new Object();
  let oKeys = countrys[0].getAttributeNames();
  for (let i = 0; i < oKeys.length; i++) {
    o[oKeys[i]] = countrys[0].getAttribute(oKeys[i]);
  }
  let arr = [];
  for (let i = 0; i < countrys[0].children.length; i++) {
    let keyss = countrys[0].children[i].getAttributeNames();
    let nodeName = countrys[0].children[i].nodeName;
    let obj = new Object();
    obj.name = nodeName;
    for (let j = 0; j < keyss.length; j++) {
      obj[keyss[j]] = countrys[0].childNodes[i].getAttribute(keyss[j]);
    }
    arr.push(obj);
  }
  o["arr"] = arr;
  return o;
}

/**
 * 判断中英文
 */
function changeLanguage(type) {
  if (type == 1) {
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(en[value])
    });
  } else {
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(cn[value])
    });
  }
}

function clearCanvas() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
}
$('[type=number]').change(function () {

}).blur(function () {
  let max = Number($(this).attr('max'));
  let min = Number($(this).attr('min'));
  let v = Number($(this).val());
  v = v < min ? min : v;
  v = v > max ? max : v;
  $(this).val(v).attr('value', v);
});

class Circle {
  constructor(vx, vy, color, flag, position) {
    this.vx = vx;
    this.vy = vy;
    this.color = color;
    this.flag = flag;
    this.position = position
  }
}

$('#myCanvas').mousemove(function (e) {
  e = e || window.event;
  let width = Number(object.vehicle_width);
  let length = Number(object.vehicle_length);
  if (circleArr.length == 0) return;
  for (let i = 1; i < circleArr.length - 1; i++) {
    let c = circleArr[i];
    if (c.color == "red") continue;
    c.color = "rgb(188, 214, 223)";
  }
  for (let i = 1; i < circleArr.length - 1; i++) {
    let c = circleArr[i];
    let x = center.x + c.vx * 100,
      y = center.y + c.vy * 100;
    if (e.offsetX >= (x - 5) && e.offsetX <= (x + 5) && e.offsetY >= (y - 5) && e.offsetY <= (y + 5)) {
      if (c.color == "red") continue;
      c.color = "rgba(188, 214, 223,.5)";
      break;
    }
  }
  if (flag) {
    let c = findByColor();
    if (c == null) return;
    if ($('#scale_change').attr('scale') == 'small') {
      x = oldX + Number(((e.offsetX - leftLocal) / 30).toFixed(2));
      y = oldY + Number(((e.offsetY - topLocal) / 30).toFixed(2));
    } else {
      x = oldX + Number(((e.offsetX - leftLocal) / 100).toFixed(2));
      y = oldY + Number(((e.offsetY - topLocal) / 100).toFixed(2));
    }
    x = x <= 0 ? 0 : x;
    x = x >= width / 2 ? width / 2 : x;
    y = y <= 0 ? 0 : y;
    y = y >= length ? length : y;
    if (c.flag) x = width / 2;
    c.vx = x;
    c.vy = y;
    change(c);
  };
  draw();
});
$('#myCanvas').mouseleave(function () {
  flag = false;
});
$('#myCanvas').mousedown(function (e) {
  e = e || window.event;
  flag = true;
  leftLocal = e.offsetX;
  topLocal = e.offsetY;
  let isFlag = false;
  for (let i = 1; i < circleArr.length - 1; i++) {
    let c = circleArr[i];
    c.color = "rgb(188, 214, 223)";
  }
  for (let i = 1; i < circleArr.length - 1; i++) {
    let c = circleArr[i];
    let x = center.x + c.vx * 100 * scaleA,
      y = center.y + c.vy * 100 * scaleA;
    if (e.offsetX >= (x - 5) && e.offsetX <= (x + 5) && e.offsetY >= (y - 5) && e.offsetY <= (y + 5)) {
      c.color = "red";
      if (c.flag) {
        $('[name=x]').val((c.vx * 2).toFixed(3));
      } else {
        $('[name=x]').val(c.vx.toFixed(3));
      }
      $('[name=y]').val(c.vy.toFixed(3));
      oldTop = y;
      oldLeft = x;
      oldX = c.vx;
      oldY = c.vy;
      isFlag = true;
      change(c);
      $('[language=add_prev]').removeClass("not_a");
      $('[language=add_next]').removeClass("not_a");
      if (!c.flag) $('[language=remove]').removeClass("not_a");
      break;
    }
  }
  if (!isFlag) {
    for (let i = 1; i < circleArr.length - 1; i++) {
      let c = circleArr[i];
      c.color = "rgb(188, 214, 223)";
    }
  }
  draw();
});
$('#myCanvas').mouseup(function () {
  flag = false;
});

function createCircle(c) {
  let p = new BIPoint(center.x + c.vx * 100 * scaleA, center.y + c.vy * 100 * scaleA);
  drawCircle(p, 4, c.color, 2, ctx);
  if (c.color != "rgb(188, 214, 223)") {
    let text = "(" + c.vx.toFixed(3) + "," + c.vy.toFixed(3) + ")";
    drawText(ctx, text, new BIPoint(p.x - 65, p.y + 10));
  }
}

function findByColor() {
  let c = null;
  for (let i = 0; i < circleArr.length; i++) {
    let a = circleArr[i];
    if (a.color == "red") {
      c = a;
      break;
    }
  }
  return c;
}

function draw() {
  if ($('[name=output_sample_version]').val() == "3") return;
  init();
  let scale = 100;
  for (let i = 0; i < circleArr.length - 1; i++) {
    let c = circleArr[i];
    let c2 = circleArr[i + 1];
    if (i != 0) createCircle(c);
    if (i == 0) {
      let a1 = new BIPoint(center.x + c.vx * scale, center.y + c.vy * scale);
      let a2 = new BIPoint(center.x + c2.vx * scale * scaleA, center.y + c2.vy * scale * scaleA);
      let a3 = new BIPoint(center.x - c2.vx * scale * scaleA, center.y + c2.vy * scale * scaleA);
      drawLine(a1, a2, 1, "black", ctx);
      drawLine(a1, a3, 1, "black", ctx);
    } else if (i > 0 && i < circleArr.length - 2) {
      let a1 = new BIPoint(center.x + c.vx * scale * scaleA, center.y + c.vy * scale * scaleA);
      let a2 = new BIPoint(center.x + c2.vx * scale * scaleA, center.y + c2.vy * scale * scaleA);
      let a3 = new BIPoint(center.x - c.vx * scale * scaleA, center.y + c.vy * scale * scaleA);
      let a4 = new BIPoint(center.x - c2.vx * scale * scaleA, center.y + c2.vy * scale * scaleA);
      drawLine(a1, a2, 1, "black", ctx);
      drawLine(a3, a4, 1, "black", ctx);
    } else {
      let a1 = new BIPoint(center.x + c2.vx * scale, center.y + c2.vy * scale * scaleA);
      let a2 = new BIPoint(center.x + c.vx * scale * scaleA, center.y + c.vy * scale * scaleA);
      let a3 = new BIPoint(center.x - c.vx * scale * scaleA, center.y + c.vy * scale * scaleA);
      drawLine(a1, a2, 1, "black", ctx);
      drawLine(a1, a3, 1, "black", ctx);
    }
  }
  let n = findByColor();
  if (n != null) {
    if (n.flag) {
      $('[name=x]').val((n.vx * 2).toFixed(3));
    } else {
      $('[name=x]').val(n.vx.toFixed(3));
    }

    $('[name=y]').val(n.vy.toFixed(3));
  }
}

function init() {
  clearCanvas();
  let p1 = new BIPoint(0, 52),
    p2 = new BIPoint(canvas.width, 52),
    p3 = new BIPoint(canvas.width / 2, 0),
    p4 = new BIPoint(canvas.width / 2, canvas.height);
  drawLine(p1, p2, 1, "#e9e9e9", ctx);
  drawLine(p3, p4, 1, "#e9e9e9", ctx);
  let x1 = new BIPoint(canvas.width / 2 + 15 * scaleA, 52 - 5);
  let x2 = new BIPoint(canvas.width / 2 + 20 * scaleA, 52);
  let x3 = new BIPoint(canvas.width / 2 + 15 * scaleA, 52 + 5);
  drawLine(x1, x2, 1, "#e9e9e9", ctx);
  drawLine(x2, x3, 1, "#e9e9e9", ctx);
  let y1 = new BIPoint(canvas.width / 2 - 5, 52 + 15 * scaleA);
  let y2 = new BIPoint(canvas.width / 2, 52 + 20 * scaleA);
  let y3 = new BIPoint(canvas.width / 2 + 5, 52 + 15 * scaleA);
  drawLine(y1, y2, 1, "#e9e9e9", ctx);
  drawLine(y2, y3, 1, "#e9e9e9", ctx);
  ctx.font = "10px Arial";
  ctx.fillText("X", x2.x, x2.y - 5);
  ctx.fillText("Y", y2.x - 15, y2.y + 5);
}

//根据某个值排序
function compare(property) {
  return function (a, b) {
    var value1 = a[property];
    var value2 = b[property];
    return value1 - value2;
  }
}

function change(c) {
  let width = Number(object.vehicle_width);
  let length = Number(object.vehicle_length);
  if (c.vx == width / 2) $('[name=x]').next().attr("disabled", true).next().removeAttr('disabled');
  if (c.vx == 0) $('[name=x]').next().removeAttr('disabled');
  if (c.vx < width / 2 && c.vx > 0) {
    if (!c.flag) $('[name=x]').next().removeAttr('disabled').next().removeAttr('disabled');
  }
  if (c.flag) $('[name=x]').next().attr('disabled', true).next().attr('disabled', true);
  if (c.vy == 0) $('[name=y]').next().removeAttr('disabled').next().attr('disabled', true);
  if (c.vy == length) $('[name=y]').next().attr('disabled', true).next().removeAttr('disabled');
  if (c.vy < length && c.vy > 0) {
    $('[name=y]').next().removeAttr('disabled').next().removeAttr('disabled');
  }
}

function xAdd(obj) {
  let width = Number($('[name=vehicle_width]').val());
  let x = Number($('[name=x]').val());
  x += 0.001;
  if (x >= width / 2) x = width / 2;
  $('[name=x]').val(x.toFixed(3));
  let c = findByColor();
  c.vx = x;
  change(c);
  draw();
}

function xSubtract(obj) {
  let x = Number($('[name=x]').val());
  x -= 0.001;
  if (x <= 0) x = 0;
  $('[name=x]').val(x.toFixed(3));
  let c = findByColor();
  c.vx = x;
  change(c);
  draw();
}

function yAdd(obj) {
  let length = Number($('[name=vehicle_length]').val());
  let y = Number($('[name=y]').val());
  y += 0.001;
  if (y >= length) y = length;
  $('[name=y]').val(y.toFixed(3));
  let c = findByColor();
  c.vy = y;
  change(c);
  draw();
}

function ySubtract(obj) {
  let y = Number($('[name=y]').val());
  y -= 0.001;
  if (y <= 0) y = 0;
  $('[name=y]').val(y.toFixed(3));
  let c = findByColor();
  c.vy = y;
  change(c);
  draw();
}

//操作画图
function reset(w, len, arr) {
  circleArr = [];
  let width = Number(w); //1.9
  let length = Number(len); //3.6
  let first = new Circle(0, 0, null, false, "contour_before"); //第一个点
  circleArr.push(first);
  for (let i = 0; i < arr.length; i++) {
    if (arr[i].name == "contour_before") {
      let c = new Circle(arr[i].y * width, arr[i].x * length, "rgb(188, 214, 223)", false, "contour_before");
      circleArr.push(c);
    }
  }
  let center = new Circle(width / 2, length / 2, "rgb(188, 214, 223)", true, ""); //中心点
  circleArr.push(center);
  for (let i = 0; i < arr.length; i++) {
    if (arr[i].name == "contour_after") {
      let c = new Circle(arr[i].y * width, arr[i].x * length, "rgb(188, 214, 223)", false, "contour_after");
      circleArr.push(c);
    }
  }
  let last = new Circle(0, length, null, false, "contour_after"); //最后的点
  circleArr.push(last);
  $('[name=x]').val("").next().attr('disabled', true);
  $('[name=x]').val("").next().next().attr('disabled', true);
  $('[name=y]').val("").next().attr('disabled', true);
  $('[name=y]').val("").next().next().attr('disabled', true);
  draw();
}

function reset2() {
  let arr = [];
  let a1 = {
    name: "contour_before",
    x: "0",
    y: "0.5"
  }
  let a2 = {
    name: "contour_after",
    x: "1",
    y: "0.5"
  }
  arr.push(a1);
  arr.push(a2);
  reset(object.vehicle_width, object.vehicle_length, arr);
}

function addPrev(obj) {
  if ($(obj).hasClass('not_a')) return;
  let c = findByColor();
  let index = -1;
  for (let i = 0; i < circleArr.length; i++) {
    let a = circleArr[i];
    if (c.vx == a.vx && c.vy == a.vy) {
      index = i;
      break;
    }
  }
  let prev = circleArr[index - 1];
  let x = c.vx - (c.vx - prev.vx) / 2;
  let y = c.vy - (c.vy - prev.vy) / 2;
  c.color = "rgb(188, 214, 223)";
  let position = "contour_before";
  if (c.position == "contour_after") position = "contour_after";
  let newCircle = new Circle(x, y, "red", false, position);
  circleArr.splice(index, 0, newCircle);
  draw();
}

function addNext(obj) {
  if ($(obj).hasClass('not_a')) return;
  let c = findByColor();
  let index = -1;
  for (let i = 0; i < circleArr.length; i++) {
    let a = circleArr[i];
    if (c.vx == a.vx && c.vy == a.vy) {
      index = i;
      break;
    }
  }
  let next = circleArr[index + 1];
  let x = c.vx - (c.vx - next.vx) / 2;
  let y = c.vy - (c.vy - next.vy) / 2;
  c.color = "rgb(188, 214, 223)";
  let position = "contour_after";
  if (c.position == "contour_before") position = "contour_before";
  let newCircle = new Circle(x, y, "red", false, position);
  circleArr.splice(index + 1, 0, newCircle);
  draw();
}

function remove(obj) {
  if ($(obj).hasClass('not_a')) return;
  let c = findByColor();
  let index = -1;
  for (let i = 0; i < circleArr.length; i++) {
    let a = circleArr[i];
    if (c.vx == a.vx && c.vy == a.vy) {
      index = i;
      break;
    }
  }
  if (index != -1) circleArr.splice(index, 1);
  draw();
}

$('#myCanvas').click(function (e) {
  e = e || window.event;
  let flag = false;
  for (let i = 0; i < circleArr.length; i++) {
    let c = circleArr[i];
    let x = center.x + c.vx * 100,
      y = center.y + c.vy * 100;
    if (e.offsetX >= (x - 5) && e.offsetX <= (x + 5) && e.offsetY >= (y - 5) && e.offsetY <= (y + 5)) {
      flag = true;
      break;
    }
  }
  let c = findByColor();
  if (!flag && c == null) {
    $('[name=x]').val("").next().attr('disabled', true);
    $('[name=x]').val("").next().next().attr('disabled', true);
    $('[name=y]').val("").next().attr('disabled', true);
    $('[name=y]').val("").next().next().attr('disabled', true);
  }
});



//车子变大变小
function scaleCanvas(obj) {
  let type = $(obj).attr("scale");
  let lang = biGetLanguage();
  let text = "";
  if (type == "large") {
    text = lang == 1 ? "Scale:Large" : "比例:大范围";
    $(obj).attr("scale", "small");
    scaleA = 0.3;
  } else {
    text = lang == 1 ? "Scale:Small" : "比例:小范围";
    $(obj).attr("scale", "large");
    scaleA = 1;
  }
  $(obj).html(text);
  draw();

}

/**
 * 画文本
 * @param {*} ctx 
 * @param {*} text 
 * @param {*} p 
 */
function drawText(ctx, text, p) {
  ctx.font = "10px Arial";
  ctx.fillText(text, p.x, p.y);
}
/**
 * 画线-两点一线
 * @param {*} p1 点
 * @param {*} p2 点
 * @param {*} width 线宽度
 * @param {*} color 颜色
 * @param {*} ctx 画图上下文
 */
function drawLine(p1, p2, width, color, ctx) {
  ctx.beginPath();
  ctx.strokeStyle = color;
  ctx.lineWidth = width;
  ctx.moveTo(p1.x, p1.y);
  ctx.lineTo(p2.x, p2.y);
  ctx.stroke();
}

/**
 * 画矩形
 * @param {*} p 顶点
 * @param {*} s 大小
 * @param {*} color 颜色
 * @param {*} ctx 画图上下文
 */
function drawRect(p, s, color, ctx) {
  ctx.beginPath();
  ctx.rect(p.x, p.y, s.width, s.height);
  ctx.strokeStyle = color;
  ctx.stroke();
}

/**
 * 画圆
 * @param {*} p 圆心
 * @param {*} radius 半径
 * @param {*} color 颜色
 * @param {*} width 线宽
 * @param {*} ctx 画图上下文
 */
function drawCircle(p, radius, color, width, ctx) {
  ctx.lineWidth = width;
  ctx.strokeStyle = color;
  ctx.arc(p.x, p.y, radius, 0, Math.PI * 2, false);
  ctx.stroke();
}
/**
 * 画矩形
 * @param {*} p 顶点
 * @param {*} s 大小
 * @param {*} color 颜色
 * @param {*} ctx 画图上下文
 */
function drawRect(p, s, color, ctx) {
  ctx.beginPath();
  ctx.rect(p.x, p.y, s.width, s.height);
  ctx.strokeStyle = color;
  ctx.stroke();
}

/**
 * 画圆
 * @param {*} p 圆心
 * @param {*} radius 半径
 * @param {*} color 颜色
 * @param {*} width 线宽
 * @param {*} ctx 画图上下文
 */
function drawCircle(p, radius, color, width, ctx) {
  ctx.beginPath();
  ctx.lineWidth = width;
  ctx.strokeStyle = color;
  ctx.arc(p.x, p.y, radius, 0, Math.PI * 2, false);
  ctx.stroke();
}