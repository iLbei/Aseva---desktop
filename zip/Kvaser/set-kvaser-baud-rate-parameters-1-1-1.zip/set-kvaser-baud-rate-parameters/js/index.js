$('input').change(function () {
  if ($(this).attr('type') == 'number') {
    compareVal(this)
  }
  setConfig();
})
function loadConfig(config) {
  if (config == null) return;
  let val = JSON.parse(config);
  val.enabled == "yes" ? $('[name=enabled]').prop('checked', true) : $('[name=enabled]').removeAttr('checked');
  let arr = val.arr;
  for (let k in arr) {
    $(`.container>div:nth-child(` + (Number(k) + 2) + `)`).find('input').each(function () {
      let name = $(this).attr('name');
      $(this).val(arr[k][name]);
    })
  }
}
function setConfig() {
  let text = `<?xml version="1.0" encoding="utf-8"?>`;
  let val = $('[name=enabled]').get(0).checked == true ? "yes" : "no";
  text += `<root enabled="` + val + `">`;
  $('.container>div:not(:nth-child(1))').each(function () {
    text += `<parameterConfig ID="` + $(this).find('span:nth-child(1)').html() + `"`;
    $(this).find('[name]').each(function () {
      let key = $(this).attr('name');
      text += " " + key + "=\"" + $(this).val() + "\"";
    });
    text += " />";
  });
  text += "</root>";
  biSetModuleConfig("set-kvaser-baud-rate-parameters.kvaserconnectremote", text);
}
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(1213, 757);
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value])
  });
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('root');
    let keys = countrys[0].getAttributeNames();
    let obj = new Object();
    for (let i = 0; i < keys.length; i++) {
      obj[keys[i]] = countrys[0].getAttribute(keys[i]);
    };
    let arr2 = [];
    for (let i = 0; i < countrys[0].childNodes.length; i++) {
      let keyss = countrys[0].childNodes[i].getAttributeNames();
      let o = new Object();
      for (let n = 0; n < keyss.length; n++) {
        o[keyss[n]] = countrys[0].childNodes[i].getAttribute(keyss[n]);
      };
      arr2.push(o);
    }
    obj.arr = arr2;
    loadConfig(JSON.stringify(obj));
  }
}
function compareVal(obj) {
  let step = $(obj).attr('step').length - 2;
  let v = parseFloat($(obj).val());
  if (isNaN(v)) { v = Number($(obj).attr('value')); }
  let min = parseFloat($(obj).attr('min')),
    max = parseFloat($(obj).attr('max'));
  v = v < min ? min : v;
  v = v > max ? max : v;
  let value;
  if (step <= -1) {
    value = v.toFixed(0);
  } else {
    value = v.toFixed(step);
  }
  $(obj).val(value);
}