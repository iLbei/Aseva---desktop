var child_config = {};
$('[name]').on('change', function () {
  var val = $(this).val();
  var type = $(this).attr("type");
  if (type == 'checkbox') {
    val = $(this).is(":checked") ? "yes" : "no";
  }
  child_config[$(this).attr("name")] = val;
  setConfig();
});
function loadConfig(config) {
  $("[name]").each(function () {
    var type = $(this).attr("type"),
      val = config[$(this).attr("name")];
    if (type == 'checkbox') {
      $(this).prop('checked', val == 'yes' ? true : false);
    } else {
      $(this).val(val);
    }
  })
}
function setConfig() {
  var file = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root";
  for (var i in child_config) {
    file += " " + i + "=\"" + child_config[i] + "\"";
  }
  file += "/>";
  biSetModuleConfig("default-file-io.plugindefaultfileio", file);
}
function biOnInitEx(config, moduleConfigs) {
  $('[language]').each(function () {
    var value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value]);
  });
  var parser = new DOMParser();
  var xmlDoc = parser.parseFromString(moduleConfigs["default-file-io.plugindefaultfileio"], "text/xml");
  var countrys = xmlDoc.getElementsByTagName('root');
  var keys = countrys[0].attributes;
  for (var i = 0; i < keys.length; i++) {
    child_config[keys[i].nodeName] = keys[i].nodeValue;
  }
  loadConfig(child_config);
}