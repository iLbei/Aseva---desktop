let audio = [],
  obj = {},
  flag = 0;
$(function () {
  $('.video,.bus,.data_password,.audio,.trans').hide();
})
$('a').click(function () {
  $('.trans').show();
  let lang = $(this).attr('language');
  if (lang == 'video') {
    biSetViewSize(979, 496);
  }
  if(lang=='data_password'){
    flag = 0;
    $('[name=password]').val('');
    $('[language="unlock"]').show().attr('disabled',true);
    $('.show').hide();
    $('[name="showCheckbox"]').attr('checked',false)
  }
  $('.' + lang).show();
})
$('.bottom button').click(function () {
  if ($(this).attr('class').indexOf('disable') != -1) {
    $('.top input[type=checkbox]').prop('checked', false);
  } else if ($(this).attr('class').indexOf('restore') != -1) {
    $('.top .default').prop('checked', true);
  }
  $('[name$="signal"]').each(function () {
    signalVal(this);
  })
  setConfig();
})
$('[name$="signal"]').click(function () {
  signalVal(this)
})
function signalVal(obj) {
  if ($(obj).is(':checked')) {
    $(obj).parent().next().find('input').prop('disabled', false).attr('checked', false).siblings().removeClass('gray');
  } else {
    $(obj).parent().next().find('input').prop('disabled', true).attr('checked', false).siblings().addClass('gray');
  }
}
$('[language=unlock]').click(function () {
  flag = 1;
  $(this).hide().next().show();
})
$('[name=showCheckbox]').click(function () {
  $(this).parent().prev().prev().attr('type', $(this).is(":checked") ? 'text' : 'password');
})
$('.close').click(function () {
  if ($(this).parent().parent().attr('class') == 'data_password') {
    let data = localStorage.getItem('data_encryption_key');
    if (data == null) {
      localStorage.setItem('data_encryption_key', $('[name=password]').val())
    }
  }
  biSetViewSize(828, 385);
  $(this).parent().parent().hide();
  $('.trans').hide()
})
$('[name],input,select').on('change', function () {
  let value = $(this).is(':checked') ? 'yes' : 'no';
  let quality = $('[name=quality]:checked').val();
  switch ($(this).attr('name')) {
    case 'online_write_audio':
      biSetGlobalVariable('System.OnlineWriteAudio', value);
      break;
    case 'from_raw_read_audio':
      biSetGlobalVariable('System.FromRawReadAudio', value);
      break;
    case 'offline_from_gen_read_audio':
      biSetGlobalVariable('System.OfflineFromGenReadAudio', value);
      break;
    case 'replay_from_gen_read_audio':
      biSetGlobalVariable('System.ReplayFromGenReadAudio', value);
      break;
    case 'quality':
      biSetGlobalVariable('System.OnlineWriteAudioQuality', quality);
      break;
  }
  setConfig();
});
$('[name=password]').on('input', function () {
  let data = localStorage.getItem('data_encryption_key');
  //  localStorage.setItem('data_encryption_key',$(this).val());
  if (data == $(this).val()) {
    $('[language=unlock]').attr('disabled', false)
  } else if (data == '' || flag == 1) {
    localStorage.setItem('data_encryption_key', $(this).val())
  }
})
function biOnQueriedGlobalParameter(id, value) {
  audio.push(value);
  if (audio.length == 5) loadConfig(obj);
}
function loadConfig(config) {
  //多选框和单选框
  $('[name]').each(function () {
    let name = $(this).attr('name');
    if (config[name] == undefined) return;
    if (name.indexOf('audio') != -1) return;
    if ($(this).is('select')) {
      $(this).val(config[name]);
    } else if ($(this).is('input[type=checkbox]')) {
      config[name] == 'yes' ? $(this).attr('checked', 'checked') : $(this).removeAttr('checked');
    } if (name.indexOf('signal') != -1) {
      if (config[name] == '1') {
        $(this).prop('checked', true).parent().next().find('input').prop('disabled', false).next().removeClass('gray')
      } else if (config[name] == '2') {
        $(this).prop('checked', true);
        $(this).parent().next().find('input').prop('checked', true).removeAttr('disabled');
      } else if (config[name] == 0) {
        $(this).parent().next().find('input').prop('disabled', true).addClass('gray');
      };
    }
  })
  $('[name=quality]').each(function () {
    if ($(this).val() == audio[4]) $(this).prop('checked', true);
  })
  $('[name$=audio]').each(function (i) {
    if (audio[i] == 'yes') $(this).attr('checked', true)
  })
  let video = config['write_video_subindex'].split(',');
  $('.video>.pos select').each(function (i) {
    $(this).val(video[i]);
  })
  $('[language="unlock"]').attr('disabled', true);
}
function setConfig() {
  let file = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root ";
  $('.container [name]').each(function () {
    let name = $(this).attr('name');
    if (name.indexOf('audio') != -1 || name.indexOf('video') != -1) return;
    if (name.indexOf('signal') != -1) {
      file += name + "=\"" + ($(this).is(':checked') ? ($(this).parent().next().find('input').is(":checked") ? 2 : 1) : 0) + "\" ";
    } else {
      file += name + "=\"" + ($(this).is(':checked') ? "yes" : "no") + "\" ";
    }
  })
  $('.bus [name]').each(function () {
    let name = $(this).attr('name');
    if ($(this).is('select')) {
      file += name + "=\"" + $(this).val() + "\" ";
    } else {
      file += name + "=\"" + ($(this).is(':checked') ? "yes" : "no") + "\" ";
    }
  })
  file += "/>";
  biSetModuleConfig("default-file-io.plugindefaultfileio", file);
  let video = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root ";
  $('.container [name$=video]').each(function () {
    video += $(this).attr('name') + "=\"" + ($(this).is(":checked") ? "yes" : "no") + "\" ";
  })
  $('.video>.type select').each(function () {
    video += $(this).attr('name') + "=\"" + $(this).val() + "\" ";
  })
  video += 'write_video_subindex' + "=\"";
  $('.video>.pos select').each(function () {
    video += $(this).val() + ',';
  })
  video = video.substring(0, video.length - 1) + "\" ";
  video += "/>";
  localStorage.setItem('default-video-file-io', video)
}
function biOnInitEx(config, moduleConfigs) {
  audio = [], quality = [];
  biSetViewSize(828, 385);
  biQueryGlobalParameter('System.OnlineWriteAudio', 'no');
  biQueryGlobalParameter('System.FromRawReadAudio', 'no');
  biQueryGlobalParameter('System.OfflineFromGenReadAudio', 'no');
  biQueryGlobalParameter('System.ReplayFromGenReadAudio', 'no');
  biQueryGlobalParameter('System.OnlineWriteAudioQuality', 'normal');
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value]);
  });
  let parser = new DOMParser();
  let video = localStorage.getItem('default-video-file-io');
  let xmlDoc = parser.parseFromString(video, "text/xml");
  let countrys = xmlDoc.getElementsByTagName('root');
  let keys = countrys[0].getAttributeNames();
  for (let i = 0; i < keys.length; i++) {
    obj[keys[i]] = countrys[0].getAttribute(keys[i]);
  }
  for (let key in moduleConfigs) {
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('root');
    let keys = countrys[0].getAttributeNames();
    for (let i = 0; i < keys.length; i++) {
      obj[keys[i]] = countrys[0].getAttribute(keys[i]);
    }
  }
}