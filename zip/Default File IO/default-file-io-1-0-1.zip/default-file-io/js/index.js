let audio = [],
  obj = {},
  flag = 0;
$(function () {
  $('.infomation,.trans').hide();
})
$('a').click(function () {
  let lang = $(this).attr('language');
  if (lang == 'data_password') {
    biConfigDataEncryption();
  } else {
    $('.trans').show();
    if (lang == 'video') {
      biSetViewSize(979, 496);
    }
    $('.' + lang).show();
  }
})
$('.bottom button').click(function () {
  $('[name$="signal"]').each(function () {
    signalVal(this);
  })
  if ($(this).attr('class').indexOf('disable') != -1) {
    $('.top input[type=checkbox]').prop('checked', false);
  } else if ($(this).attr('class').indexOf('restore') != -1) {
    $('.top .default').prop('checked', true);
    $('[name="replay_from_gen_read_signal"]').parent().next().find('input').prop('disabled', false).prop('checked', true).siblings().removeClass('gray');
  }
  $('[name$="audio"]').each(function () {
    audioChange(this);
  })
  setConfig();
})
$('[name$="signal"]').click(function () {
  signalVal(this)
})
function signalVal(obj) {
  if ($(obj).is(':checked')) {
    $(obj).parent().next().find('input').prop('disabled', false).attr('checked', false).siblings().removeClass('gray');
  } else {
    $(obj).parent().next().find('input').prop('disabled', true).attr('checked', false).siblings().addClass('gray');
  }
}
$('.close').click(function () {
  biSetViewSize(828, 385);
  $(this).parent().parent().hide();
  $('.trans').hide()
})
$('[name],input,select').on('change', function () {
  audioChange(this);
  setConfig();
});
function audioChange(obj) {
  let name = $(obj).attr('name');
  let value = $(obj).is(':checked') ? 'yes' : 'no';
  switch (name) {
    case 'online_write_audio':
      biSetGlobalParameter('System.OnlineWriteAudio', value);
      break;
    case 'from_raw_read_audio':
      biSetGlobalParameter('System.FromRawReadAudio', value);
      break;
    case 'offline_from_gen_read_audio':
      biSetGlobalParameter('System.OfflineFromGenReadAudio', value);
      break;
    case 'replay_from_gen_read_audio':
      biSetGlobalParameter('System.ReplayFromGenReadAudio', value);
      break;
    case 'quality':
      let quality = $('[name=quality]:checked').val();
      biSetGlobalParameter('System.OnlineWriteAudioQuality', quality);
      break;
  }
}
function biOnQueriedGlobalParameter(id, value) {
  audio.push(value);
  if (audio.length == 5) loadConfig(obj);
}
function loadConfig(config) {
  $('[name]').each(function () {
    let name = $(this).attr('name');
    if (config[name] == undefined) return;
    if (name.indexOf('audio') != -1) return;
    if ($(this).is('select')) {
      $(this).val(config[name]);
    } else if ($(this).is('input[type=checkbox]')) {
      config[name] == 'yes' ? $(this).attr('checked', 'checked') : $(this).removeAttr('checked');
    } if (name.indexOf('signal') != -1) {
      if (config[name] == '1') {
        $(this).prop('checked', true).parent().next().find('input').prop('disabled', false).next().removeClass('gray')
      } else if (config[name] == '2') {
        $(this).prop('checked', true);
        $(this).parent().next().find('input').prop('checked', true).removeAttr('disabled');
      } else if (config[name] == 0) {
        $(this).parent().next().find('input').prop('disabled', true).addClass('gray');
      };
    }
  })
  $('[name=quality]').each(function () {
    if ($(this).val() == audio[4]) $(this).prop('checked', true);
  })
  $('[name$=audio]').each(function (i) {
    if (audio[i] == 'yes') $(this).prop('checked', true);
  })
  let video = config['write_video_subindex'].split(',');
  $('.video>.pos select').each(function (i) {
    $(this).val(video[i]);
  })
  $('[language="unlock"]').attr('disabled', true);
}
function setConfig() {
  let file = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root ";
  $('.container [name]').each(function () {
    let name = $(this).attr('name');
    if (name.indexOf('audio') != -1 || name.indexOf('video') != -1) return;
    if (name.indexOf('signal') != -1) {
      file += name + "=\"" + ($(this).is(':checked') ? ($(this).parent().next().find('input').is(":checked") ? 2 : 1) : 0) + "\" ";
    } else {
      file += name + "=\"" + ($(this).is(':checked') ? "yes" : "no") + "\" ";
    }
  })
  $('.bus [name]').each(function () {
    let name = $(this).attr('name');
    if ($(this).is('select')) {
      file += name + "=\"" + $(this).val() + "\" ";
    } else {
      file += name + "=\"" + ($(this).is(':checked') ? "yes" : "no") + "\" ";
    }
  })
  file += "/>";
  biSetModuleConfig("default-file-io.plugindefaultfileio", file);
  let video = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root ";
  $('.container [name$=video]').each(function () {
    video += $(this).attr('name') + "=\"" + ($(this).is(":checked") ? "yes" : "no") + "\" ";
  })
  $('.video>.type select').each(function () {
    video += $(this).attr('name') + "=\"" + $(this).val() + "\" ";
  })
  video += 'write_video_subindex' + "=\"";
  $('.video>.pos select').each(function () {
    video += $(this).val() + ',';
  })
  video = video.substring(0, video.length - 1) + "\" ";
  video += "/>";
  localStorage.setItem('default-video-file-io', video)
}
function biOnInitEx(config, moduleConfigs) {
  audio = [], quality = [];
  biSetViewSize(828, 385);
  biQueryGlobalParameter('System.OnlineWriteAudio', 'no');
  biQueryGlobalParameter('System.FromRawReadAudio', 'no');
  biQueryGlobalParameter('System.OfflineFromGenReadAudio', 'no');
  biQueryGlobalParameter('System.ReplayFromGenReadAudio', 'no');
  biQueryGlobalParameter('System.OnlineWriteAudioQuality', 'normal');
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value]);
  });
  let parser = new DOMParser();
  let video = localStorage.getItem('default-video-file-io');
  let xmlDoc = parser.parseFromString(video, "text/xml");
  let countrys = xmlDoc.getElementsByTagName('root');
  let keys = countrys[0].getAttributeNames();
  for (let i = 0; i < keys.length; i++) {
    obj[keys[i]] = countrys[0].getAttribute(keys[i]);
  }
  for (let key in moduleConfigs) {
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('root');
    let keys = countrys[0].getAttributeNames();
    for (let i = 0; i < keys.length; i++) {
      obj[keys[i]] = countrys[0].getAttribute(keys[i]);
    }
  }
}