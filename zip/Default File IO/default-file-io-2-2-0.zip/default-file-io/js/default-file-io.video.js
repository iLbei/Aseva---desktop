var child_config = {};
$('[name],select').on('change', function () {
  var val = $(this).val();
  if ($(this).parents().hasClass("pos")) {
    var subindex = "";
    $('.video>.pos select').each(function () {
      subindex += $(this).val() + ',';
    })
    subindex = subindex.substring(0, subindex.length - 1);
    child_config["write_video_subindex"] = subindex;
  } else {
    child_config[$(this).attr("name")] = val;
  }


  setConfig();
});
function loadConfig(config) {
  $("[name]").each(function () {
    $(this).val(config[$(this).attr("name")]);
  })
  var video = config['write_video_subindex'].split(',');
  console.log(video);
  $('.pos select').each(function (i) {
    $(this).val(video[i]);
  })
}
function setConfig() {
  var file = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root ";
  for (var i in child_config) {
    file += " " + i + "=\"" + child_config[i] + "\"";
  }
  file += "/>";
  biSetModuleConfig("default-video-file-io.plugindefaultvideofileio", file);
}
function biOnInitEx(config, moduleConfigs) {
  $('[language]').each(function () {
    var value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value]);
  });
  var parser = new DOMParser();
  var xmlDoc = parser.parseFromString(moduleConfigs["default-video-file-io.plugindefaultvideofileio"], "text/xml");
  var countrys = xmlDoc.getElementsByTagName('root');
  var keys = countrys[0].attributes;
  for (var i = 0; i < keys.length; i++) {
    child_config[keys[i].nodeName] = keys[i].nodeValue;
  }
  loadConfig(child_config);
}