let cn = {
  lobcEnable: "启用",
  lanesChannel:"车道线通道:",
  objectsChannel:"目标物通道:",
},
  en = {
    lobcEnable: "Enable",
    lanesChannel:"Lanes channel:",
    objectsChannel:"Objects channel:",
  };