var zh = {
  connect: "连接",
  baud_rate: "波特率[bps]:",
  com_port: "端口:",
  address: "附加地址[0x]:",
},
  en = {
    connect: "Connected",
    baud_rate: "Baud rate[bps]:",
    com_port: "COM port:",
    address: "Extra address[0x]:",
  };