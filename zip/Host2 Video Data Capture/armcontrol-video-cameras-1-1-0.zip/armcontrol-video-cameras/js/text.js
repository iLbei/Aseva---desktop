var cn = {
    enabled: "启用",
    CameraFps: "相机原始输出帧率:",
    TxMode: "模式选择:",
    Gop: "I帧间隔:",
    disabled: "(未启用)",
    capture_mode: "采集模式",
    reinjection_mode: "高精度回注模式",
  },
  en = {
    enabled: "Enabled",
    CameraFps: "CameraFps:",
    TxMode: "TxMode:",
    Gop: "Gop:",
    capture_mode: "Capture Mode",
    reinjection_mode: "Reinjection Mode",
    disabled: "(Disabled)"
  };