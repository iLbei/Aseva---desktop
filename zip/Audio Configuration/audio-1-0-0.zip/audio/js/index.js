let driver_id = [],
  driver_name = [],
  record_devices = {},
  replay_devices = {},
  device_id = [],
  device_name = [],
  modObj = {};

$('[name=record_driver]').change(function () {
  $(this).val() == 0 ? $('[name="record_device"]').attr('disabled', true) : $('[name="record_device"]').attr('disabled', false);
})
function loadConfig(config) {
  if (biGetRunningMode() == 1) {
    $('.offline').show();
    $('.online').hide();
  } else {
    $('.offline').hide();
    $('.online').show();
  }
  //多选框和单选框
  $('.container [name]').each(function () {
    let name = $(this).attr('name');
    if (config[name] == 'null') return;
    $(this).val(config[name]);
  })
}
function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root ";
  $('[name]').each(function () {
    text += $(this).attr('name') + "=\"" + $(this).val() + "\" "
  })
  text += "/>";
  biSetModuleConfig("audio.system", text);
}
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(360, 205);
  // 获取音频驱动列表
  biQueryAudioDriversInfo();
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value]);
  });
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('root');
    let keys = countrys[0].getAttributeNames();
    modObj = new Object();
    for (let i = 0; i < keys.length; i++) {
      modObj[keys[i]] = countrys[0].getAttribute(keys[i]);
    }
  }
}
function biOnQueriedAudioDriversInfo(driversInfo) {
}
function BIAudioDriverInfo(driverID, driverName, recordDevices, replayDevices) {
  driver_id = [], driver_name = [];
  driver_id.push(driverID);
  driver_name.push(driverName);
  record_devices = recordDevices;
  replay_devices = replayDevices;
  $('[name="record_device"]').empty();
  for (let i in driver_id) {
    $('[name="record_driver"]').append("<option>" + driver_name[i] + "</option>");
    $('[name="record_driver"]').children().eq($('[name="record_driver"]').children().length - 1).attr('value', driverID);
  }
  for (let i in record_devices) {
    $('[name="record_device"]').append("<option>" + record_devices[i]['deviceName'] + "</option>")
    $('[name="record_device"]').children().eq($('[name="record_device"]').children().length - 1).attr('value', record_devices[i]['deviceName']);
  }
  if (replayDevices.length != 0) {
    // if (driverName.length == 1) {
    $('[name="replay_driver"]').append("<option>" + driverName + "</option>");
    $('[name="replay_driver"]').children().eq($('[name="replay_driver"]').children().length - 1).attr('value', driverID);
    // } else {
    //   for (let i in driverName) {
    //     $('[name="replay_driver"]').append("<option>" + driverName[i] + "</option>");
    //     $('[name="replay_driver"]').children().eq($('[name="replay_driver"]').children().length - 1).attr('value', driverID);
    //   }
    // }
  }
  for (let i in replay_devices) {
    $('[name="replay_device"]').append("<option>" + replay_devices[i]['deviceName'] + "</option>");
    $('[name="replay_device"]').children().eq($('[name="replay_device"]').children().length - 1).attr('value', replay_devices[i]['deviceName']);
  }
  loadConfig(modObj);
  if ($('[name=record_driver]').val() == 'null') {
    $('[name="record_device"]').val('').attr('disabled', true)
  }
}
$('[name = record_driver]').change(function () {
  driverChange();
  setConfig();
})
function driverChange() {
  if ($('[name=record_driver]').val() == 'null') {
    $('[name="record_device"]').val('').attr('disabled', true)
  } else {
    $('[name="record_device"]').attr('disabled', false);
    $('[name="record_device"]').val($('[name="record_device"] option:eq(0)').html());
  }
}
$('[name]').on('change', function () {
  setConfig();
});