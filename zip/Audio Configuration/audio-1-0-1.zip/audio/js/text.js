let cn = {
  audio_recorder:"音频录制",
  driver:"驱动:",
  disabled:"(禁用)",
  device:"设备:",
  config:"无需配置",
  audio_player:"音频播放"
},
en = {
  audio_recorder:"Audio recorder",
  driver:"Driver:",
  disabled:"(Disabled)",
  device:"Device:",
  config:"Unnecessary to configure",
  audio_player:"Audio player"
};