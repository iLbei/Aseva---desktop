var cn = {
    enable: "启用",
    video: "视频",
    transmitMode: "发送模式:",
    Instantaneous: "瞬时",
    Scheduled: "预约"
  },
  en = {
    enable: "Enable",
    video: "Video",
    transmitMode: "Transmit Mode:",
    Instantaneous: "Instantaneous",
    Scheduled: "Scheduled"
  };