$(function () {
  var text = "";
  for (var i = 0; i < 12; i++) {
    text += "<ul class=\"fixclear\"><li class=\"fixclear\"><input type=\"checkbox\" name=\"enable\" id=\"enabled_" + i + "\"><label for=\"enabled_" + i + "\" language=\"enable\"></label></li><li class=\"fixclear\"><span class=\"left\" language=\"transmitMode\"></span><select class=\"right\" name=\"transmitMode\"><option value=\"0\">Instantaneous</option><option value=\"1\">Scheduled</option></select></li></ul>";
  }
  $(".container>div.video").append(text);
})
$('.container').on("change", "[name]", function () {
  setConfig();
});
//保存配置
function setConfig() {
  var text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root>";
  $('.container>.video>ul').each(function (i) {
    text += "<video" + (i + 1) + " ";
    $(this).find('[name]').each(function () {
      var name = $(this).attr("name");
      var val = $(this).val();
      var type = $(this).attr('type');
      if (type == 'checkbox') {
        text += " " + name + "=\"" + ($(this).is(':checked') ? "yes" : "no") + "\"";
      } else if (type == "number") {
        text += " " + name + "=\"" + compareVal(this, val) + "\"";
      } else {
        text += " " + name + "=\"" + val + "\"";
      }
    })
    text += "/>";
  })
  text += "</root>";
  biSetModuleConfig("video-nuvo-transmitter.aspluginvideonuvotransmitter", text);
}
//初始化
function biOnInitEx(config, moduleConfigs) {
  $('[language]').each(function () {
    var value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value])
  });
  for (var key in moduleConfigs) {
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    var child = xmlDoc.getElementsByTagName('root')[0].childNodes;
    var arr = [];
    for (var i = 0; i < child.length; i++) {
      var obj = {};
      var keys = child[i].attributes;
      for (var j in keys) {
        obj[keys[j].nodeName] = keys[j].nodeValue;
      }
      arr.push(obj);
    }
    loadConfig(arr);
  }
}

function loadConfig(arr) {
  if (arr == null) return;
  $('.container>.video>ul').each(function (i) {
    $(this).find("[name]").each(function () {
      var name = $(this).attr("name");
      var val = arr[i][name];
      var type = $(this).attr('type');
      if (type == 'checkbox') {
        $(this).prop('checked', val == 'yes' ? true : false);
      } else if (type == "number") {
        $(this).val(compareVal(this, val));
      } else {
        $(this).val(val);
        if (["server_ip", "local_ip"].includes(name)) {
          reg.test(val) ? $(this).addClass('green').removeClass('red') : $(this).removeClass('green').addClass('red');
        }
      }
    })

  })
}