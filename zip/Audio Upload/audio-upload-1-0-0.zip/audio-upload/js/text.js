var cn = {
  connect: "连接",
  ip: "IP或地址:",
  port: "端口号:"
},
  en = {
    connect: "Connect",
    ip: "IP/Url:",
    port: "Port:"
  };