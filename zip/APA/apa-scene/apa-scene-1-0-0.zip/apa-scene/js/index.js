$('.container [name]').click(function () {
  setConfig();
  biSetGlobalParameter("'APAScene." + $(this).siblings('span').attr('language')+"'", $(this).val());
});
$('button').click(function () {
  let name = $(this).attr('language');
  if (name == 'load') {
    biSelectPath('load', BISelectPathType.OpenFile, { '.csv': '*.csv' });
  } else if (name == 'save') {
    biSelectPath('save', BISelectPathType.Directory, { '.csv': '*.csv' });
  }
})
function biOnSelectedPath(key, path) {
  if (key == 'load') {
    biQueryFileText(path);
  } else if (key == 'save') {
    let text = '',
      date = new Date,
      year = date.getFullYear(),
      month = (date.getMonth() + 1) < 10 ? '0' + (date.getMonth() + 1) : (date.getMonth() + 1),
      day = date.getDate() < 10 ? '0' + date.getDate() : date.getDate(),
      hours = date.getHours() < 10 ? '0' + date.getHours() : date.getHours(),
      minutes = date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes(),
      seconds = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds(),
      fileName = (path.indexOf(':') != -1 ? path.substr(2, 1) : '//')+'apa_scene_' + year + month + day + '-' + hours + '-' + minutes + '-' + seconds + '.csv';
    $('span[language]').each(function () {
      text += $(this).html() + ',';
    })
    text = text.substr(0, text.length - 1) + '\n';
    $('select').each(function () {
      let name = $(this).attr('name');
      text += $('[name=' + name + '] option:selected').html() + ',';
    })
    text = text.substr(0, text.length - 1);
    biWriteFileText(path + fileName, text);
  }
}
function biOnQueriedFileText(text, path) {
  let vals = (text.substr(text.indexOf('\n') + 1)).split(',');
  $('select').each(function (i) {
    let val = 0;
    $(this).find('option').each(function () {
      if ($(this).html() == vals[i]) {
        val = Number($(this).attr('value'));
      }
    })
    $(this).val(val);
  })
  setConfig();
}
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(1084, 144);
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value]);
  });
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('config');
    let keys = countrys[0].getAttributeNames();
    let obj = new Object();
    for (let i = 0; i < keys.length; i++) {
      obj[keys[i]] = countrys[0].getAttribute(keys[i]);
    };
    loadConfig(obj);
  }
}
function loadConfig(val) {
  $('.container [name]').each(function () {
    if(val[$(this).attr('name')]==''||val[$(this).attr('name')]=='null') $(this).val(0);
    $(this).val(val[$(this).attr('name')])
  });
}

function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><config";
  $('.container [name]').each(function () {
    text += " " + $(this).attr('name') + "=\"" + $(this).val() + "\"";
  });
  text += " /></root>";
  biSetModuleConfig("apa-scene.aspluginapaevaluation", text);
}