let aName = '',
  viewSize = new BISize(348, 455),
  language = sessionStorage.getItem("language"),
  cn = {
    not_config: "(未配置)",
    apaEnable: '启动',
    drive_system_signal: "驱动系统",
    driveSystemTorqueControlSignal: "扭矩控制:",
    driveSystemEngineSpeedSignal: "发动机/电机转速:",
    driveSystemVehicleWheelSpeedSignal: "车辆轮速:",
    driveSystemVehicleSpeedSignal: "车辆速度:",
    driveSystemVehicleAccelerationSignal: "车辆加速度:",
    fault_message: "故障信息:",
    DrivingPattern: "驾驶模式:",
    driveSystemAcceleratorPedalPositionSignal: "加速踏板位置信号:",
    break_system_signal: "制动系统",
    breakSystemBrakePedalConditionSignal: "制动踏板状态:",
    breakSystemMasterCylinderPressureSignal: "制动主缸压力:",
    breakSystemAcceleratorPedalPositionSignal: "制动踏板位置信号:",
    breakSystemVehicleDecelerationSignal: "车辆减速度:",
    endurance_mileage: "续航里程",
    enduranceMileageRemainingMileageSignal: "剩余里程:",
    shift_system_signal: "换挡系统",
    shiftSystemGearInformationSignal: "档位信息:",
    automatic_start_and_stop_system: "自动启停系统",
    automaticSystemPowerControlSignal: "上/下电控制:",
    automaticSystemIgnitionExtinguishmentControlSignal: "点火/熄火控制:",
    steering_system_signal: "转向系统",
    steeringSystemSteeringAngleSignal: "方向盘转角:",
    steeringSystemSteeringWheelSpeedSignal: "方向盘转速:",
    steeringSystemSteeringTorqueSignal: "方向盘扭矩:",
    steeringSystemSteeringWheelTorqueSignal: "方向盘转矩信号:",
    parking_system_signal: "驻车系统",
    parkingSystemParkingStateSignal: "驻车状态:",
    parkingSystemParkingRequestSignal: "驻车请求:",
    car_window_system: "门锁车窗系统",
    carWindowDoorLockSignal: "车门锁:",
    carWindowTailDoorLockSignal: "尾门锁:",
    carWindowPowerWindowSignal: "电动车窗:",
    carWindowPowerSunroofSignal: "电动天窗:",
    lighting_system: "灯光系统",
    lightingSystemSteeringLampSignal: "转向灯信号:",
    lightingSystemBrakeLightSignal: "刹车灯信号:",
    lightingSystemBackupLightSignal: "倒车灯信号:",
    lightingSystemClearanceLampSignal: "示廓灯信号:",
    lightingSystemDippedHeadlightSignal: "近光灯信号:",
    lightingSystemDangerAlarmFlashingLightSignal: "危险报警闪光灯信号:",
    indicators: "指标",
    kneadingTimesLimit: "揉库次数限制:",
    deltaDistanceLimit: "Δd 限制:",
    angleOffsetLimit: "角度偏移限制:",
    apaStateSignal: "自动泊车状态:",
    other: "其他信号",
    driverHandMomentSignal: "驾驶员手力矩:",
    slotFrontDistanceSignal: "库位前方距离:",
    slotRearDistanceSignal: "库位后方距离:",
    slotLeftDistanceSignal: "库位左方距离:",
    slotRightDistanceSignal: "库位右方距离:",
    leftFrontWheelDistanceSignal: "左前轮测距:",
    leftRearWheelDistanceSignal: "左后轮测距:",
    rightFrontWheelDistanceSignal: "右前轮测距:",
    rightRearWheelDistanceSignal: "右后轮测距:",
    slotAngleOffsetSignal: "库位角度偏移:",
    apaResultSignal: "自动泊车结果:",
    outputReportPath: "输出路径:",
    empty: "(空)"
  },
  en = {
    not_config: "(Not Configured)",
    apaEnable: "Enable",
    drive_system_signal: "Drive system signal",
    driveSystemTorqueControlSignal: "Torque control:",
    driveSystemEngineSpeedSignal: "Engine speed:",
    driveSystemVehicleWheelSpeedSignal: "Vehicle wheel speed:",
    driveSystemVehicleSpeedSignal: "Vehicle speed:",
    driveSystemVehicleAccelerationSignal: "Acceleration of vehicle:",
    fault_message: "Fault message:",
    driveSystemDrivingPatternSignal: "Driving pattern:",
    driveSystemAcceleratorPedalPositionSignal: "Accelerator pedal position:",
    break_system_signal: "Break system signal",
    breakSystemBrakePedalConditionSignal: "Brake pedal condition:",
    breakSystemMasterCylinderPressureSignal: "Brake the master cylinder pressure:",
    breakSystemAcceleratorPedalPositionSignal: "Accelerator pedal position:",
    breakSystemVehicleDecelerationSignal: "Vehicle deceleration:",
    endurance_mileage: "Endurance mileage",
    enduranceMileageRemainingMileageSignal: "The remaining mileage:",
    shift_system_signal: "Shift system signal",
    shiftSystemGearInformationSignal: "Gear information:",
    automatic_start_and_stop_system: "Automatic start and stop system",
    automaticSystemPowerControlSignal: "Power on/off control:",
    automaticSystemIgnitionExtinguishmentControlSignal: "Ignition/extinguishment control:",
    steeringSystemSteeringAngleSignal: "Steering Angle:",
    steeringSystemSteeringWheelSpeedSignal: "Steering wheel speed:",
    steeringSystemSteeringTorqueSignal: "Steering torque:",
    steeringSystemSteeringWheelTorqueSignal: "Steering wheel torque:",
    parking_system_signal: "Parking system signal",
    parkingSystemParkingStateSignal: "Parking state:",
    parkingSystemParkingRequestSignal: "Parking request:",
    car_window_system: "Car window system",
    carWindowDoorLockSignal: "Door lock:",
    carWindowTailDoorLockSignal: "Tail door lock:",
    carWindowPowerWindowSignal: "Power window:",
    carWindowPowerSunroofSignal: "Power sunroof:",
    lighting_system: "Lighting system",
    lightingSystemSteeringLampSignal: "Steering lamp:",
    lightingSystemBrakeLightSignal: "Brake light:",
    lightingSystemBackupLightSignal: "Backup light:",
    lightingSystemClearanceLampSignal: "Clearance lamp:",
    lightingSystemDippedHeadlightSignal: "Dipped headlight:",
    lightingSystemDangerAlarmFlashingLightSignal: "Danger alarm fashing light:",
    indicators: "Indicators",
    kneadingTimesLimit: "Kneading times limit:",
    deltaDistanceLimit: "Δd limit:",
    angleOffsetLimit: "Angle offset limit:",
    apaStateSignal: "APA State:",
    other: "Other signal",
    driverHandMomentSignal: "Driver hand moment:",
    slotFrontDistanceSignal: "Slot front dist:",
    slotRearDistanceSignal: "Slot rear dist:",
    slotLeftDistanceSignal: "Slot left dist:",
    slotRightDistanceSignal: "Slot right dist:",
    leftFrontWheelDistanceSignal: "Left front wheel dist:",
    leftRearWheelDistanceSignal: "Left rear wheel dist:",
    rightFrontWheelDistanceSignal: "Right front wheel dist:",
    rightRearWheelDistanceSignal: "Right rear wheel dist:",
    slotAngleOffsetSignal: "Slot angle offset:",
    apaResultSignal: "APA result:",
    outputReportPath: "Output path:",
    empty: "(Empty)"
  };
if (language == null) {
  changeLanguage(2);
}
$('input').on({
  'change': function () {
    if ($(this).attr('type') == 'number') {
      compareVal(this);
    }
  },
  'keypress': function (e) {
    if (e.charCode < 45 || e.charCode > 57) {
      return false;
    }
  },
  'keyup': function () {
    setConfig();
  }
});
$('.container [name]').change(function () {
  setConfig();
});
$('[name="apaEnable"]').change(function () {
  checkboxChange(this)
})
$('a').on('click', function () {
  if ($(this).attr('name') == 'outputReportPath') {
    biSelectPath($(this).attr('name'), BISelectPathType.Directory, null);
  } else {
    let originID = '';
    if ($(this).html().indexOf('(') == -1) originID = $(this).attr('value');
    let scale = $(this).attr('scale');
    aName = $(this).attr('name');
    biSelectSignal('name', originID, false, null, true, scale);
  }
})
function biOnSelectedSignal(key, valueSignalInfo, signBitSignalInfo, scale) {
  if (valueSignalInfo == null) {
    $('[name=' + aName + ']').html(Number(language) == 1 ? '(Not Configured)' : '(未配置)').attr({ 'value': '', 'scale': '1' }).removeClass('red green').removeAttr('title');
    setConfig();
  } else if (valueSignalInfo.typeName == undefined) {
    $('[name=' + aName + ']').addClass('red').removeClass('green');
    setConfig();
  } else {
    $('[name=' + aName + ']').attr('scale', scale).html(valueSignalInfo.signalName).attr('value', valueSignalInfo.id).attr('title', valueSignalInfo.typeName + ':' + valueSignalInfo.signalName).addClass('green');
    setConfig();
  }
}
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(1220, 697);
  let type = biGetLanguage();
  changeLanguage(type);
  sessionStorage.setItem("language", type);
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('config');
    let keys = countrys[0].getAttributeNames();
    let obj = new Object();
    for (let i = 0; i < keys.length; i++) {
      obj[keys[i]] = countrys[0].getAttribute(keys[i]);
    };
    loadConfig(JSON.stringify(obj));
  }
}
function loadConfig(config) {
  if (config == null) return;
  let val = JSON.parse(config);
  $('.container [name]').each(function () {
    let name = $(this).attr('name'),
      type = $(this).attr("type");
    if (type == "checkbox") {
      val[name] == "yes" ? $(this).attr('checked', true) : $(this).attr('checked', false);
    } else if (type == "number") {
      let step = $(this).attr('step'),
        len = step.length - 2,
        min = parseFloat($(this).attr('min')),
        max = parseFloat($(this).attr('max'));
      if (val[name] < min) {
        val[name] = min;
      } else if (val[name] > max) {
        val[name] = max;
      }
      $(this).val(val[name] == '' ? $(this).attr('value') : Number(val[name]).toFixed(len <= -1 ? 0 : len));
    } else if ($(this).is('a')) {
      if (val[name] == '' || val[name] == undefined || val[name] == 'null') return;
      if (name != 'outputReportPath') {
        $(this).attr('value', val[name]).attr('scale', val[name + '_scale']);
        biQuerySignalInfo(name, val[name]);
      } else {
        $(this).html(val[name]);
      }
    }
  });
  checkboxChange($('[name=apaEnable]'));
}
function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><config";
  $('.container [name]').each(function () {
    let key = $(this).attr('name');
    if ($(this).attr("type") == "checkbox") {
      text += " " + key + "=\"" + ($(this).get(0).checked ? "yes" : "no") + "\"";
    } else if ($(this).is('a')) {
      if (key != 'outputReportPath') {
        let scale = $(this).attr('scale'),
          val = $(this).attr('value');
        text += " " + key + "=\"" + ($(this).html().indexOf('(') == -1 ? val : 'null') + "\"";
        text += " " + key + "_scale=\"" + (scale != '' ? scale : '') + "\"";
      } else {
        text += " " + key + "=\"" + ($(this).html().indexOf(':') != -1 ? $(this).html() : '') + "\"";
      }
    } else {
      text += " " + key + "=\"" + $(this).val() + "\"";
    }
  });
  text += " /></root>";
  biSetModuleConfig("apa-evaluation.aspluginapaevaluation", text);
}
function biOnSelectedPath(key, path) {
  $('[name=' + key + ']').html(path == null ? (language == 1 ? '(Empty)' : '(空)') : path);
  setConfig();
}
function checkboxChange(obj) {
  if (!$(obj).is(':checked')) {
    $('.container [name]').each(function () {
      $(this).addClass('disabledName');
      if ($(this).attr('type') == 'number') {
        $(this).attr('disabled', true)
      }
    })
    $(".container>div:not('.top') span,.container>div:not('.top') p").each(function(){
      $(this).addClass('disabledLanguage');
    })
  } else {
    $('.container [name]').each(function () {
      $(this).removeClass('disabledName');
      if ($(this).attr('type') == 'number') {
        $(this).attr('disabled', false)
      }
    })
    $(".container>div:not('.top') span,.container>div:not('.top') p").each(function(){
      $(this).removeClass('disabledLanguage');
    })
  }
}
function biOnQueriedSignalInfo(key, signalInfo) {
  if (signalInfo != null) {
    $('[name=' + key + ']').addClass('green').removeClass('red').html(signalInfo.signalName).attr('title', signalInfo.typeName + ':' + signalInfo.signalName)
  } else {
    $('[name=' + key + ']').addClass('red').removeClass('green').html($('[name=' + key + ']').attr('value'));
  }
}
function changeLanguage(type) {
  if (type == 1) { //英文
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(en[value])
    });
  } else { //中文
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(cn[value])
    });
  }
}
function compareVal(obj) {
  let step = $(obj).attr('step').length - 2,
    v = parseFloat($(obj).val()),
    min = parseFloat($(obj).attr('min')),
    max = parseFloat($(obj).attr('max'));
  if (isNaN(v)) { v = Number($(obj).attr('value')) };
  if (v < min) {
    v = min;
  } else if (v > max) {
    v = max;
  }
  $(obj).val(step <= -1 ? v.toFixed(0) : v.toFixed(step));
}