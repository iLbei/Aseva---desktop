let aName = '';
$('input').on({
  'change': function () {
    if ($(this).attr('type') == 'number') {
      compareVal(this);
    }
  },
  'keypress': function (e) {
    if (e.charCode < 45 || e.charCode > 57) {
      return false;
    }
  },
  'keyup': function () {
    setConfig();
  }
});
$('.container [name]').change(function () {
  setConfig();
});
$('[name="apaEnable"]').change(function () {
  checkboxChange(this)
})
$('a').on('click', function () {
  if ($(this).attr('name') == 'outputReportPath') {
    biSelectPath($(this).attr('name'), BISelectPathType.Directory, null);
  } else {
    let originID = '';
    if ($(this).html().indexOf('(') == -1) originID = $(this).attr('value');
    let scale = $(this).attr('scale');
    aName = $(this).attr('name');
    biSelectSignal('name', originID, false, null, true, scale);
  }
})
function biOnSelectedSignal(key, valueSignalInfo, signBitSignalInfo, scale) {
  if (valueSignalInfo == null) {
    $('[name=' + aName + ']').html(Number(language) == 1 ? '(Not Configured)' : '(未配置)').attr({ 'value': '', 'scale': '1' }).removeClass('red green').removeAttr('title');
    setConfig();
  } else if (valueSignalInfo.typeName == undefined) {
    $('[name=' + aName + ']').addClass('red').removeClass('green');
    setConfig();
  } else {
    $('[name=' + aName + ']').attr('scale', scale).html(valueSignalInfo.signalName).attr('value', valueSignalInfo.id).attr('title', valueSignalInfo.typeName + ':' + valueSignalInfo.signalName).addClass('green');
    setConfig();
  }
}
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(1220, 697);
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value])
  });
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('config');
    let keys = countrys[0].getAttributeNames();
    let obj = new Object();
    for (let i = 0; i < keys.length; i++) {
      obj[keys[i]] = countrys[0].getAttribute(keys[i]);
    };
    loadConfig(JSON.stringify(obj));
  }
}
function loadConfig(config) {
  if (config == null) return;
  let val = JSON.parse(config);
  $('.container [name]').each(function () {
    let name = $(this).attr('name'),
      type = $(this).attr("type");
    if (type == "checkbox") {
      val[name] == "yes" ? $(this).attr('checked', true) : $(this).attr('checked', false);
    } else if (type == "number") {
      let step = $(this).attr('step'),
        len = step.length - 2,
        min = parseFloat($(this).attr('min')),
        max = parseFloat($(this).attr('max'));
      if (val[name] < min) {
        val[name] = min;
      } else if (val[name] > max) {
        val[name] = max;
      }
      $(this).val(val[name] == '' ? $(this).attr('value') : Number(val[name]).toFixed(len <= -1 ? 0 : len));
    } else if ($(this).is('a')) {
      if (val[name] == '' || val[name] == undefined || val[name] == 'null') return;
      if (name != 'outputReportPath') {
        $(this).attr('value', val[name]).attr('scale', val[name + '_scale']);
        biQuerySignalInfo(name, val[name]);
      } else {
        $(this).html(val[name]);
      }
    }
  });
  checkboxChange($('[name=apaEnable]'));
}
function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><config";
  $('.container [name]').each(function () {
    let key = $(this).attr('name');
    if ($(this).attr("type") == "checkbox") {
      text += " " + key + "=\"" + ($(this).get(0).checked ? "yes" : "no") + "\"";
    } else if ($(this).is('a')) {
      if (key != 'outputReportPath') {
        let scale = $(this).attr('scale'),
          val = $(this).attr('value');
        text += " " + key + "=\"" + ($(this).html().indexOf('(') == -1 ? val : 'null') + "\"";
        text += " " + key + "_scale=\"" + (scale != '' ? scale : '') + "\"";
      } else {
        text += " " + key + "=\"" + ($(this).html().indexOf(':') != -1 ? $(this).html() : '') + "\"";
      }
    } else {
      text += " " + key + "=\"" + $(this).val() + "\"";
    }
  });
  text += " /></root>";
  biSetModuleConfig("apa-evaluation.aspluginapaevaluation", text);
}
function biOnSelectedPath(key, path) {
  $('[name=' + key + ']').html(path == null ? (language == 1 ? '(Empty)' : '(空)') : path);
  setConfig();
}
function checkboxChange(obj) {
  if (!$(obj).is(':checked')) {
    $('.container [name]').each(function () {
      $(this).addClass('disabledName');
      if ($(this).attr('type') == 'number') {
        $(this).attr('disabled', true)
      }
    })
    $(".container>div:not('.top') span,.container>div:not('.top') p").each(function () {
      $(this).addClass('disabledLanguage');
    })
  } else {
    $('.container [name]').each(function () {
      $(this).removeClass('disabledName');
      if ($(this).attr('type') == 'number') {
        $(this).attr('disabled', false)
      }
    })
    $(".container>div:not('.top') span,.container>div:not('.top') p").each(function () {
      $(this).removeClass('disabledLanguage');
    })
  }
}
function biOnQueriedSignalInfo(key, signalInfo) {
  if (signalInfo != null) {
    $('[name=' + key + ']').addClass('green').removeClass('red').html(signalInfo.signalName).attr('title', signalInfo.typeName + ':' + signalInfo.signalName)
  } else {
    $('[name=' + key + ']').addClass('red').removeClass('green').html($('[name=' + key + ']').attr('value'));
  }
}
function compareVal(obj) {
  let step = $(obj).attr('step').length - 2,
    v = parseFloat($(obj).val()),
    min = parseFloat($(obj).attr('min')),
    max = parseFloat($(obj).attr('max'));
  if (isNaN(v)) { v = Number($(obj).attr('value')) };
  if (v < min) {
    v = min;
  } else if (v > max) {
    v = max;
  }
  $(obj).val(step <= -1 ? v.toFixed(0) : v.toFixed(step));
}