let cn = {
  enabled: "启用",
},
  en = {
    enabled: "Enable",
  };