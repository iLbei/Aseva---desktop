var en = {
    connect: "Connect",
    port: "Port:",
    frequency: "Frequency:"
  },
  cn = {
    connect: "连接",
    port: "端口:",
    frequency: "频率:"
  };