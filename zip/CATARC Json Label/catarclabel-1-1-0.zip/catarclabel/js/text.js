var zh = {
  enabled: "启动",
  object_source: "目标物通道:",
  lane_source: "车道线通道:",
  gnssimu_source: "组合惯导通道:",
  straight_line_radius:"直道半径[m]:"
},
  en = {
    enabled: "Enabled",
    object_source: "Object channel:",
    lane_source: "Lane channel:",
    gnssimu_source: "Gnssimu channel:",
    straight_line_radius:"Straight line radius[m]:"
  };