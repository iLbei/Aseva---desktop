/*----------配置读取与存储-----------*/
// 表单内容改变保存配置
$('[name]').change(function () {
  if ($(this).attr("name") == "enabled") enabledChange();
  setConfig();
});

function enabledChange() {
  if ($("[name=enabled]").is(":checked")) {
    $('.container>ul').find('[language]').removeClass('disabled_a');
    $('.container>ul [name]').attr('disabled', false).removeClass('disabled disabled_background');
  } else {
    $('.container>ul').find('[language]').addClass('disabled_a');
    $('.container>ul [name]').attr('disabled', true).addClass('disabled disabled_background');
  }
}
//保存配置
function setConfig() {
  var text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root ";
  $('.container [name]').each(function () {
    var name = $(this).attr('name');
    var val = $(this).val();
    if ($(this).attr('type') == 'checkbox') {
      text += name + "=\"" + ($(this).is(':checked') ? "yes" : "no") + "\" ";
    } else {
      text += name + "=\"" + val + "\" ";
    }
  });
  text += " />";
  biSetModuleConfig("catarclabel.plugin", text);
}
//初始化
function biOnInitEx(config, moduleConfigs) {
  $('[language]').each(function () {
    var value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value])
  });
  for (var key in moduleConfigs) {
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    var obj = new Object();
    var root = xmlDoc.getElementsByTagName('root');
    var keys = root[0].attributes;
    for (var i = 0; i < keys.length; i++) {
      //获取root自身字节的属性
      obj[keys[i].nodeName] = keys[i].nodeValue;
    }
    loadConfig(obj);
  }
}
function loadConfig(obj) {
  if (obj == null) return;
  $('.container [name]').each(function () {
    var val = obj[$(this).attr('name')];
    var type = $(this).attr('type');
    if (type == 'checkbox') {
      $(this).prop('checked', val == 'yes');
    } else {
      $(this).val(val);
    }
  })
  enabledChange();
}