let viewSize = new BISize(984, 643); //窗口大小
let language = sessionStorage.getItem("language"); //取中英文,用于刷新保存的值
let configuration = "";
let canvas = $('#canvas')[0],
    ctx = canvas.getContext('2d');
let compareArr = ["=", "<", ">=", ">", "<=", "!="];
let id = 0,
    leftLocal = 0,
    topLocal = 0;
let boxArr = [],
    editFlag = false,
    flag = false,
    lineArr = [];
let initTop = 24,
    initLeft = 35,
    initInterval = 10;
let oldLeft = 0,
    oldTop = 0;
let minLeft = 0,
    minTop = 0;
$(function() {});

let binary_operators = {
    "and": {
        name: "and (&)",
        type: 'Logical and'
    },
    "or": {
        name: "or (|)",
        type: 'Logical or'
    },
    "add_signal": {
        name: "add_signal",
        type: 'Add signal'
    },
    "sub_signal": {
        name: "sub_signal",
        type: 'Subtract signal'
    },
    "mul_signal": {
        name: "mul_signal",
        type: 'Multiply signal'
    },
};
$('[name=enabled]').click(function() {
    setConfig();
});
$('[name=rate]').change(function() {
    setConfig();
});
//鼠标移入
canvas.onmousemove = function(e) {
    e = e || window.event;
    if (flag) {
        setTimeout(() => {
            let left = e.clientX - leftLocal + oldLeft;
            let top = e.clientY - topLocal + oldTop;
            left = left < minLeft ? minLeft : left;
            left = left > 0 ? 0 : left;
            top = top < minTop ? minTop : top;
            top = top > 0 ? 0 : top;
            $('.container>.left>div').css({ 'left': left + "px", 'top': top + "px" });
        });
    }
};
//鼠标移开
canvas.onmouseleave = function() {
    flag = false;
};
//鼠标按下
canvas.onmousedown = function(e) {
    e = e || window.event;
    flag = true;
    leftLocal = e.clientX;
    topLocal = e.clientY;
};
//鼠标松开
canvas.onmouseup = function() {
    flag = false;
    oldLeft = $('.container>.left>div').position().left;
    oldTop = $('.container>.left>div').position().top;
};
//方块
class Box {
    constructor(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue) {
        this.width = width;
        this.height = height;
        this.name = name;
        this.type = type;
        this.id = id;
        this.className = className;
        this.rank = rank;
        this.top = top;
        this.left = left;
        this.parentIds = parentIds;
        this.sonIds = sonIds;
        this.isModified = isModified;
        this.typeValue = typeValue;
    }
}
//点
class Point {
    constructor(x, y) {
        this.x = x;
        this.y = y;
    }
}
class Constant extends Box {
    constructor(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue, value) {
        super(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue)
        this.value = value;
    };
}
class SignalOutput extends Box {
    constructor(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue, value) {
        super(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue)
        this.value = value;
    };
}
class InputSignal extends Box {
    constructor(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue, signal, signalName, interpolation) {
        super(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue)
        this.signal = signal;
        this.signalName = signalName;
        this.interpolation = interpolation;
    };
}
class Condition extends Box {
    constructor(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue, first, num1, second, num2, flag) {
        super(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue)
        this.first = first;
        this.num1 = num1;
        this.second = second;
        this.num2 = num2;
        this.flag = flag;
    };
}
class Add extends Box {
    constructor(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue, value) {
        super(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue)
        this.value = value;
    };
}
class Multiply extends Box {
    constructor(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue, value) {
        super(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue)
        this.value = value;
    };
}
class Power extends Box {
    constructor(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue, power, defaultV) {
        super(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue)
        this.power = power;
        this.defaultV = defaultV;
    };
}
class SignalHolder extends Box {
    constructor(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue, value) {
        super(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue)
        this.value = value;
    };
}
class MapNumber extends Box {
    constructor(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue, defaultValue, value, input, output) {
        super(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue)
        this.defaultValue = defaultValue;
        this.value = value;
        this.input = input;
        this.output = output;
    };
}
class OrderLPF extends Box {
    constructor(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue, value) {
        super(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue)
        this.value = value;
    };
}
class Mod extends Box {
    constructor(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue, value) {
        super(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue)
        this.value = value;
    };
}
class Decide extends Box {
    constructor(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue, value) {
        super(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue)
        this.value = value;
    };
}
class ConditionWith extends Box {
    constructor(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue, value) {
        super(width, height, name, type, id, className, rank, top, left, parentIds, sonIds, isModified, typeValue)
        this.value = value;
    };
}

$(".space_a>a").hover(function() {
    let val = $(this).attr('val');
    if (val != undefined) {
        $(this).next().html($(this).html());
        let len = $(this).html().length;
        $(this).next().css('width', len * 10 + "px");
        $(this).next().show();
    }
}, function() {
    $(this).next().hide();
});
//add input signal
function inputSignal(obj) {
    if ($(obj).hasClass('not_a')) return
    $('.shadow').show();
    $('.input_signal').show();
    id++;
    editFlag = false;
}
//add constant
function constantOpen(obj) {
    if ($(obj).hasClass('not_a')) return
    $('.shadow').show();
    $('.constant').show();
    id++;
    editFlag = false;
}
//add output signal
function outputSignal(obj) {
    if (!$(obj).hasClass('not_a')) {
        $('.shadow').show();
        $('.output_signal').show();
        id++;
    }
    editFlag = false;
}
//input signal 关闭
function inputClose(obj) {
    $('.shadow').hide();
    $(obj).parent().parent().hide();
    if ($(obj).parent().next().find('a').html().lastIndexOf('(') == -1) {
        let name = $(obj).parent().next().find('a').html();
        if ($(obj).parent().next().find('a').hasClass('red')) {
            if (name.indexOf(":") != -1) name = name.split(":")[2];
        } else {
            name = name.split(":")[1];
        }

        let val = $(obj).parent().next().find('a').attr('val');
        let interpolation = $('[name=interpolation]').val();
        if (!editFlag) {
            let box = new InputSignal(120, 30, name, "Input signal", id, "blue", 0, 0, 0, [], [], true, 'input', val, name, interpolation);
            boxArr.push(box);
        } else {
            let box = findById($('#border').attr('num'));
            box.signal = val;
            box.name = name;
            box.signalName = name;
            box.interpolation = interpolation;
        }
        boxChange();
    }
    //重置
    $('[name=interpolation]').val('linear');
    $(obj).parent().next().find('a').removeAttr('val');
    $(obj).parent().next().find('a').addClass("red");
    let text = sessionStorage.getItem('language') == 1 ? "(Not configure)" : "(未配置)";
    $(obj).parent().next().find('a').html(text);
    $(obj).parent().next().find('a').removeClass('springgreen');
}
//output 关闭
function outputClose(obj) {
    let value = $(obj).parent().next().find('input').val();
    value = value == "" ? $(obj).parent().next().find('input').attr('value') : value;
    let reg = /^[a-z0-9\-]+$/i;
    if (!reg.test(value)) value = $(obj).parent().next().find('input').attr('value');
    let name = value;
    let className = $('#border').attr('class');
    let num = $('#border').attr('num');
    num = parseInt(num);
    if (className == "blue" || className == "orange") {
        let arr = [num];
        let box = new SignalOutput(120, 30, name, "Output signal", id, "green", -1, 0, 0, arr, [], true, 'output', value);
        boxArr.push(box);
    }
    if (editFlag) {
        let box = findById($('#border').attr('num'));
        box.value = value;
        box.name = name;
    }
    boxChange();
    $(obj).parent().parent().find('[name=outputClose]').val('0');
    $('.shadow').hide();
    $(obj).parent().parent().hide();
}
$('[type=text]').bind('input propertychange', function() {
    let value = $(this).val();
    let v = Number(value);
    if (!isNaN(v) && value != "") $(this).attr('value', value);
});

$('[type=number]').bind('input propertychange', function() {
    let value = $(this).val();
    let v = Number(value);
    if (!isNaN(v) && value != "") {
        $(this).attr('value', value);
    } else if (value != "") {
        let p = $(this).attr('value');
        $(this).val(p);
    }
});
//constant 关闭
function constantClose() {
    $('.shadow').hide();
    $('.constant').hide();
    let v = $('.constant').find('input').val();
    v = Number(v);
    if (isNaN(v)) v = $('.constant').find('input').attr('value');
    let name = v == "" ? $('.constant').find('input').attr('value') : v;
    if (!editFlag) {
        let box = new Constant(120, 30, name, "Input constant", id, "blue", 0, 0, 0, [], [], true, 'constant', v);
        boxArr.push(box);

    } else {
        let box = findById($('#border').attr('num'));
        box.name = name;
        box.value = v;

    }
    boxChange();
    $('[name=constantV]').val('0');
    $('[name=constantV]').attr("value", 0);
}
//unary_operators
$('.unary_operators').find('a').click(function() {
    editFlag = false;
    if ($(this).hasClass('not_a')) return;
    id++;
    let num = $(this).attr('num');
    let type = $(this).attr('type');
    let typeValue = $(this).attr('typeValue');
    if (num == undefined) {
        let name = $(this).attr('language');
        let borderNum = $('#border').attr('num');
        borderNum = parseInt(borderNum);
        let border = findById(borderNum);
        let arr = [borderNum];
        let rank = border.rank == "0" ? 1 : parseInt(border.rank) + 1;
        let box = new Box(90, 30, name, type, id, "orange", rank, 0, 0, arr, [], false, typeValue);
        boxArr.push(box);
        boxChange();
    } else {
        num = parseInt(num);
        $('.shadow').show();
        $('.container>div:eq(' + num + ')').show();
    }
});

//condition
function conditionClose(obj) {
    let num1 = $('[name=num1]').val();
    let num2 = $('[name=num2]').val();
    $('.shadow').hide();
    $(obj).parent().parent().hide();
    if (isNaN(Number(num1)) || isNaN(Number(num2))) {
        //重置
        $('[name=num1]').val('');
        $('[name=num2]').val('');
        $('[name=reset]').removeAttr('checked');
        $('[name=first]').val("0");
        $('[name=second]').val("0");
        return;
    }
    let first = $('[name=first]').val();
    first = parseInt(first);
    let second = $('[name=second]').val();
    second = parseInt(second);
    let flag = $('[name=reset]').get(0).checked;
    let box;
    let type = "Condition with number";
    let borderNum = $('#border').attr('num');
    borderNum = parseInt(borderNum);
    let arr = [borderNum];
    let border = findById(borderNum);
    let rank = border.rank == "0" ? 1 : parseInt(border.rank) + 1;
    if (flag) {
        if (num1 != "" && num2 != "") {
            let name = compareArr[first] + num1 + "(" + compareArr[second] + num2 + ")";
            if (!editFlag) {
                box = new Condition(90, 30, name, type, id, "orange", rank, 0, 0, arr, [], true, 'unary_condition', first, num1, second, num2, true);
            } else {
                let b = findById($('#border').attr('num'));
                b.name = name;
                b.first = first;
                b.num1 = num1;
                b.second = second;
                b.num2 = num2;
                b.flag = true;
            }
        }
    } else {
        if (num1 != "") {
            let name = compareArr[first] + num1;
            if (!editFlag) {
                box = new Condition(90, 30, name, type, id, "orange", rank, 0, 0, arr, [], first, num1, "=", "", false);
            } else {
                let b = findById($('#border').attr('num'));
                b.name = name;
                b.first = first;
                b.num1 = num1;
                b.second = "=";
                b.num2 = "";
                b.flag = false;
            }

        }
    }

    if (box != undefined) {
        boxArr.push(box);
        boxChange();
    }
    //重置
    $('[name=num1]').val('');
    $('[name=num2]').val('');
    $('[name=reset]').removeAttr('checked');
    $('[name=first]').val("0");
    $('[name=second]').val("0");


}
$('.condition').find('[name=reset]').click(function() {
    reset($(this));
});

function reset(obj) {
    if ($(obj).get(0).checked) {
        $(obj).parent().next().children('select').removeAttr('disabled');
        $(obj).parent().next().children('input').removeAttr('disabled');
    } else {
        $(obj).parent().next().children('select').attr('disabled', true);
        $(obj).parent().next().children('input').attr('disabled', true);
    }
}
//add_number
function addClose(obj) {
    $('.shadow').hide();
    $(obj).parent().parent().hide();
    let value = $(obj).parent().parent().find('[name=addValue]').val();
    value = Number(value);
    if (isNaN(value) || value == "") value = $(obj).parent().parent().find('[name=addValue]').attr('value');
    let name = value >= 0 ? "+" + value : value;
    let borderNum = $('#border').attr('num');
    let border = findById(borderNum);
    borderNum = parseInt(borderNum);
    let arr = [borderNum];
    let rank = border.rank == "0" ? 1 : parseInt(border.rank) + 1;
    if (!editFlag) {
        let box = new Add(90, 30, name, "Add / Subtract number", id, "orange", rank, 0, 0, arr, [], true, 'add_number', value);
        boxArr.push(box);
    } else {
        let box = findById($('#border').attr('num'));
        box.value = value;
        box.name = name;
    }
    boxChange();
    $(obj).parent().parent().find('[name=addValue]').val('0');
}
//Multiply
function multiplyClose(obj) {
    $('.shadow').hide();
    $(obj).parent().parent().hide();
    let value = $(obj).parent().parent().find('[name=multiplyValue]').val();
    value = Number(value);
    if (isNaN(value) || value == "") value = $(obj).parent().parent().find('[name=multiplyValue]').attr('value');
    let name = value >= 0 ? "x" + value : "x" + "(" + value + ")";
    let borderNum = $('#border').attr('num');
    borderNum = parseInt(borderNum);
    let arr = [borderNum];
    let border = findById(borderNum);
    let rank = border.rank == "0" ? 1 : parseInt(border.rank) + 1;
    if (!editFlag) {
        let box = new Add(90, 30, name, "Multiply number", id, "orange", rank, 0, 0, arr, [], true, 'mul_number', value);
        boxArr.push(box);
    } else {
        let box = findById($('#border').attr('num'));
        box.value = value;
        box.name = name;
    }

    boxChange();
    $(obj).parent().parent().find('[name=multiplyValue]').val('0');
}
//power
function powerClose(obj) {
    $('.shadow').hide();
    $(obj).parent().parent().hide();
    let power = $(obj).parent().parent().find('[name=power]').val() == "" ? $(obj).parent().parent().find('[name=power]').attr('value') : $(obj).parent().parent().find('[name=power]').val();
    let defaultV = $(obj).parent().parent().find('[name=default]').val() == "" ? $(obj).parent().parent().find('[name=default]').attr('value') : $(obj).parent().parent().find('[name=default]').val();
    if (isNaN(Number(power))) power = $(obj).parent().parent().find('[name=power]').attr('value');
    let name = "^" + power;
    let borderNum = $('#border').attr('num');
    borderNum = parseInt(borderNum);
    let arr = [borderNum];
    let border = findById(borderNum);
    let rank = border.rank == "0" ? 1 : parseInt(border.rank) + 1;
    if (!editFlag) {
        let box = new Power(90, 30, name, "Power", id, "orange", rank, 0, 0, arr, [], true, 'power', power, defaultV);
        boxArr.push(box);
    } else {
        let box = findById($('#border').attr('num'));
        box.power = power;
        box.defaultV = defaultV;
        box.name = name;
    }
    boxChange();
    $(obj).parent().parent().find('[name=power]').val('0');
    $(obj).parent().parent().find('[name=default]').val('0');
}
//holder
function holderClose(obj) {
    $('.shadow').hide();
    $(obj).parent().parent().hide();
    let value = $(obj).parent().parent().find('[name=holderV]').val();
    let min = $(obj).parent().parent().find('[name=holderV]').attr('min');
    let max = $(obj).parent().parent().find('[name=holderV]').attr('max');
    value = value > max ? max : value;
    value = value < min ? min : value;
    let name = "hold " + value + "s";
    let borderNum = $('#border').attr('num');
    borderNum = parseInt(borderNum);
    let arr = [borderNum];
    let border = findById(borderNum);
    let rank = border.rank == "0" ? 1 : parseInt(border.rank) + 1;
    if (!editFlag) {
        let box = new SignalHolder(90, 30, name, "Signal holder", id, "orange", rank, 0, 0, arr, [], true, 'holder', value);
        boxArr.push(box);
    } else {
        let box = findById($('#border').attr('num'));
        box.value = value;
        box.name = name;
    }
    boxChange();
    $(obj).parent().parent().find('[name=holderV]').val('0');
}
//map
function mapClose(obj) {
    $('.shadow').hide();
    $(obj).parent().parent().hide();
    let input = [],
        output = [];
    $('.map>.tent>.table>.body>div').each(function(i, v) {
        if (i > 0 && i < $('.map>.tent>.table>.body>div').length - 1) {
            let int = isNaN(Number($(this).find('[name=input]').val())) == false ? $(this).find('[name=input]').val() : 0;
            input.push(int);
            let out = isNaN(Number($(this).find('[name=output]').val())) == false ? $(this).find('[name=output]').val() : 0;
            output.push(out);
        }
    })
    let defaultValue = $(obj).parent().parent().find('input[name=map]:checked').val();
    let value = $(obj).parent().parent().find('[name=mapValue]').val();
    let borderNum = $('#border').attr('num');
    borderNum = parseInt(borderNum);
    let border = findById(borderNum);
    let arr = [borderNum];
    let rank = border.rank == "0" ? 1 : parseInt(border.rank) + 1;
    if (!editFlag) {
        let box = new MapNumber(90, 30, "map", "Number mapping", id, "orange", rank, 0, 0, arr, [], true, 'map', defaultValue, value, input, output);
        boxArr.push(box);
    } else {
        let box = findById($('#border').attr('num'));
        box.defaultValue = defaultValue;
        box.value = value;
        box.input = input;
        box.output = output;
    }
    boxChange();
    //重置
    $('.map>.tent>div:first-of-type>[name=map]').val('constant');
    $('.map>.tent>div:first-of-type>[name=mapValue]').val('0');
    let n = 1;
    while (n < $('.map>.tent>.table>.body>div').length - 1) {
        $('.map>.tent>.table>.body>div')[n].remove();
        n = 1;
    }
}

function selectOneRow(obj) {
    $('.map>.tent>.table>.body>div').each(function() {
        $(this).children('div:first-of-type').removeClass('blue2');
        $(this).find('input').removeClass('blue1');
    });
    $('.map>.tent>.table>.top>div:first-of-type').removeClass('all');
    $(obj).addClass('blue2');
    $(obj).next().children().addClass('blue1');
    $(obj).next().next().children().addClass('blue1');
}
//监听键盘del键
$('body').keydown(function(event) {
    let e = event || window.event;
    if (e.keyCode == 46) {
        if ($('.map>.tent>.table>.top>div:first-of-type').hasClass('all')) {
            let i = 1;
            while (i < $('.map>.tent>.table>.body>div').length - 1) {
                $('.map>.tent>.table>.body>div')[i].remove();
                i = 1;
            }
        } else {
            if ($('.blue2').parent().next().html() != undefined) {
                $('.blue2').parent().remove();
            }
        }
    }
});

function wipeBlue(obj) {
    $(obj).parent().parent().children('div:first-of-type').removeClass('blue2');
    $(obj).parent().parent().children('div:nth-of-type(2)').children().removeClass('blue1');
    $(obj).parent().parent().children('div:nth-of-type(3)').children().removeClass('blue1');
}

function selectAll() {
    $('.map>.tent>.table>.body>div').each(function() {
        $(this).children('div:first-of-type').addClass('blue2');
        $(this).find('input').addClass('blue1');
    });
    $('.map>.tent>.table>.top>div:first-of-type').addClass('all');
}

function keyPress(obj) {
    if ($(obj).parent().parent().next().html() == undefined) {
        $tableBox = $('.map>.tent>.table>.body>div:first-of-type').clone(true);
        $('.map>.tent>.table>.body').append($tableBox[0]);
    }
}
//filter
function filterClose(obj) {
    $('.shadow').hide();
    $(obj).parent().parent().hide();
    let value = $(obj).parent().parent().find('[name=filterV]').val();
    let min = $(obj).parent().parent().find('[name=filterV]').attr('min');
    let max = $(obj).parent().parent().find('[name=filterV]').attr('max');
    value = value > max ? max : value;
    value = value < min ? min : value;
    let name = value + "s LPF1";
    let borderNum = $('#border').attr('num');
    borderNum = parseInt(borderNum);
    let border = findById(borderNum);
    let rank = border.rank == "0" ? 1 : parseInt(border.rank) + 1;
    let arr = [borderNum];
    if (!editFlag) {
        let box = new OrderLPF(90, 30, name, "1st low pass filter", id, "orange", rank, 0, 0, arr, [], true, 'lpf_1st', value);
        boxArr.push(box);
    } else {
        let box = findById($('#border').attr('num'));
        box.value = value;
        box.name = name;
    }
    boxChange();
    $(obj).parent().parent().find('[name=filterV]').val('0.001');
}
//mod
function modClose(obj) {
    $('.shadow').hide();
    $(obj).parent().parent().hide();
    let value = $(obj).parent().parent().find('[name=modV]').val();
    value = Number(value);
    if (isNaN(value) || value == "") value = $(obj).parent().parent().find('[name=modV]').attr('value');
    let name = "%" + value;
    let borderNum = $('#border').attr('num');
    borderNum = parseInt(borderNum);
    let arr = [borderNum];
    let border = findById(borderNum);
    let rank = border.rank == "0" ? 1 : parseInt(border.rank) + 1;
    if (!editFlag) {
        let box = new Mod(90, 30, name, "Mod number", id, "orange", rank, 0, 0, arr, [], true, 'mod', value);
        boxArr.push(box);
    } else {
        let box = findById($('#border').attr('num'));
        box.value = value;
        box.name = name;
    }

    boxChange();
    $(obj).parent().parent().find('[name=modV]').val('1');
}
//根据id查找box
function findById(id) {
    let box = undefined;
    for (let i = 0; i < boxArr.length; i++) {
        let o = boxArr[i];
        if (o.id == id) {
            box = o;
            break;
        }
    }
    return box;
}

function sortBox(a, b) {
    return a.rank - b.rank;
}
//binary_operators
$('.binary_operators').find('a').click(function() {
    editFlag = false;
    if ($(this).hasClass('not_a')) return;
    id++;
    let type = $(this).attr('type');
    let num = $(this).attr('num');
    let name = $(this).attr('name');
    let typeValue = $(this).attr('typeValue');
    let borders = [],
        arr = [];
    $('.container>.left>div>div').each(function() {
        if ($(this).attr('id') != undefined) {
            let box = findById($(this).attr('num'));
            borders.push(box);
            arr.push(box.id);
        }
    });
    borders.sort(sortBox);
    let node1 = "Node #" + borders[0].id + (borders[0].name.toString().length <= 10 ? " (" + borders[0].name + ")" : "");
    let node2 = "Node #" + borders[1].id + (borders[1].name.toString().length <= 10 ? " (" + borders[1].name + ")" : "");
    let rank = borders[borders.length - 1].rank == "0" ? 1 : parseInt(borders[borders.length - 1].rank) + 1;
    if (num == undefined) {
        let box = new Box(90, 30, name, type, id, "orange", rank, 0, 0, arr, [], false, typeValue);
        boxArr.push(box);
    } else {
        num = parseInt(num);
        switch (num) {
            case 14:
                $('.subtract_signal').find('.node1').html(node1);
                $('.subtract_signal').find('.node2').html(node2);
                break;
            case 15:
                $('.divide').find('.node1').html(node1);
                $('.divide').find('.node2').html(node2);
                break;
            case 16:
                $('.condition_with').find('.node1').html(node1);
                $('.condition_with').find('.node2').html(node2);
                break;
            case 17:
                $('.weighted').find('.node1').html(node1);
                $('.weighted').find('.node2').html(node2);
                break;
            case 18:
                $('.resettable').find('.node1').html(node1);
                $('.resettable').find('.node2').html(node2);
                break;
        }
        $('.shadow').show();
        $('.container>div:eq(' + num + ')').show();
    }
    boxChange();
});

function subtractClose(obj) {
    $('.shadow').hide();
    $(obj).parent().parent().hide();
    let borders = [],
        arr = [];
    $('.container>.left>div>div').each(function() {
        if ($(this).attr('id') != undefined) {
            let box = findById($(this).attr('num'));
            borders.push(box);
            arr.push(box.id);
        }
    });
    let node1 = $(obj).parent().parent().find('.node1').html();
    let node2 = $(obj).parent().parent().find('.node2').html();
    let name = "{" + node1.substring(node1.indexOf('#') + 1, node1.indexOf('#') + 2) + "}-" + "{" + node2.substring(node2.indexOf('#') + 1, node2.indexOf('#') + 2) + "}";
    borders.sort(sortBox);
    let rank = borders[borders.length - 1].rank == "0" ? 1 : parseInt(borders[borders.length - 1].rank) + 1;
    if (!editFlag) {
        let box = new Box(90, 30, name, "Substract signal", id, "orange", rank, 0, 0, arr, [], true, 'sub_signal');
        boxArr.push(box);
    } else {
        let box = findById($('#border').attr('num'));
        box.name = name;
    }
    boxChange();
}

function divideClose(obj) {
    $('.shadow').hide();
    $(obj).parent().parent().hide();
    let borders = [],
        arr = [];
    $('.container>.left>div>div').each(function() {
        if ($(this).attr('id') != undefined) {
            let box = findById($(this).attr('num'));
            borders.push(box);
            arr.push(box.id);
        }
    });
    let node1 = $(obj).parent().parent().find('.node1').html();
    let node2 = $(obj).parent().parent().find('.node2').html();
    let name = "{" + node1.substring(node1.indexOf('#') + 1, node1.indexOf('#') + 2) + "} / " + "{" + node2.substring(node2.indexOf('#') + 1, node2.indexOf('#') + 2) + "}";
    let value = $(obj).parent().parent().find('[name=value]').val() == "" ? "0" : $(obj).parent().parent().find('[name=value]').val();
    borders.sort(sortBox);
    let rank = borders[borders.length - 1].rank == "0" ? 1 : parseInt(borders[borders.length - 1].rank) + 1;
    if (!editFlag) {
        let box = new Decide(90, 30, name, "Devide signal", id, "orange", rank, 0, 0, arr, [], true, 'devide_signal', value);
        boxArr.push(box);
    } else {
        let box = findById($('#border').attr('num'));
        box.name = name;
        box.value = value;
    }

    boxChange();
}

function conditionWithClose(obj) {
    $('.shadow').hide();
    $(obj).parent().parent().hide();
    let borders = [],
        arr = [];
    $('.container>.left>div>div').each(function() {
        if ($(this).attr('id') != undefined) {
            let box = findById($(this).attr('num'));
            borders.push(box);
            arr.push(box.id);
        }
    });
    let value = Number($(obj).parent().parent().find('[name=operator]').val());
    let node1 = $(obj).parent().parent().find(".node1").html();
    node1 = node1.substring(node1.indexOf("#") + 1, node1.indexOf("("));
    node1 = node1.replace(/\s*/g, "");
    let node2 = $(obj).parent().parent().find(".node2").html();
    node2 = node2.substring(node2.indexOf("#") + 1, node2.indexOf("("));
    node2 = node2.replace(/\s*/g, "");
    let name = "{" + node1 + "} " + compareArr[value] + " " + "{" + node2 + "}";
    borders.sort(sortBox);
    let rank = borders[borders.length - 1].rank == "0" ? 1 : parseInt(borders[borders.length - 1].rank) + 1;
    if (!editFlag) {
        let box = new ConditionWith(90, 30, name, "Condition with signal", id, "orange", rank, 0, 0, arr, [], true, 'binary_condition', value);
        boxArr.push(box);
    } else {
        let box = findById($('#border').attr('num'));
        box.name = name;
        box.value = value;
    }
    boxChange();
}

function weightedClose(obj) {
    $('.shadow').hide();
    $(obj).parent().parent().hide();
    let borders = [],
        arr = [];
    $('.container>.left>div>div').each(function() {
        if ($(this).attr('id') != undefined) {
            let box = findById($(this).attr('num'));
            borders.push(box);
            arr.push(box.id);
        }
    });
    let text = $('.weighted').find('.node1').html();
    let node1 = text.substring(text.indexOf("#") + 1, text.indexOf("("));
    node1 = node1.replace(/\s*/g, "");
    let name = "avg {" + node1 + "}";
    borders.sort(sortBox);
    let rank = borders[borders.length - 1].rank == "0" ? 1 : parseInt(borders[borders.length - 1].rank) + 1;
    if (!editFlag) {
        let box = new Box(90, 30, name, "Weighted average", id, "orange", rank, 0, 0, arr, [], true, 'weight_average');
        boxArr.push(box);
    } else {
        let box = findById($('#border').attr('num'));
        box.name = name;
    }

    boxChange();
}

function resettableClose(obj) {
    $('.shadow').hide();
    $(obj).parent().parent().hide();
    let borders = [],
        arr = [];
    $('.container>.left>div>div').each(function() {
        if ($(this).attr('id') != undefined) {
            let box = findById($(this).attr('num'));
            borders.push(box);
            arr.push(box.id);
        }
    });
    let text = $('.resettable').find('.node1').html();
    let node1 = text.substring(text.indexOf("#") + 1, text.indexOf("("));
    node1 = node1.replace(/\s*/g, "");
    let name = "integral {" + node1 + "}";
    borders.sort(sortBox);
    let rank = borders[borders.length - 1].rank == "0" ? 1 : parseInt(borders[borders.length - 1].rank) + 1;
    if (!editFlag) {
        let box = new Box(90, 30, name, "Resetable integeral", id, "orange", rank, 0, 0, arr, [], true, 'reset_integral');
        boxArr.push(box);
    } else {
        let box = findById($('#border').attr('num'));
        box.name = name;
    }

    boxChange();
}
//二元运算符 交换事件
function binary_exchange(obj) {
    let parent = $(obj).parent().parent().parent();
    let node1 = $(parent).find('.node1').html();
    let node2 = $(parent).find('.node2').html();
    $(parent).find('.node1').html(node2);
    $(parent).find('.node2').html(node1);
}

//temary_operators
$('.temary_operators').find('a').click(function() {
    editFlag = false;
    if ($(this).hasClass('not_a')) return;
    id++;
    let num = $(this).attr('num');
    $('.shadow').show();
    let borders = [],
        arr = [];
    $('.container>.left>div>div').each(function() {
        if ($(this).attr('id') != undefined) {
            let box = findById($(this).attr('num'));
            borders.push(box);
            arr.push(box.id);
        }
    });
    let node1 = "Node #" + borders[0].id + " (" + borders[0].name + ")";
    let node2 = "Node #" + borders[1].id + " (" + borders[1].name + ")";
    let node3 = "Node #" + borders[2].id + " (" + borders[2].name + ")";
    switch (num) {
        case "19":
            $('.if_else>.tent .node1').html(node1);
            $('.if_else>.tent .node2').html(node2);
            $('.if_else>.tent .node3').html(node3);
            break;
        case "20":
            $('.in_range>.tent .node1').html(node1);
            $('.in_range>.tent .node2').html(node2);
            $('.in_range>.tent .node3').html(node3);
            break;
        case "21":
            $('.clamp>.tent .node1').html(node1);
            $('.clamp>.tent .node2').html(node2);
            $('.clamp>.tent .node3').html(node3);
            break;
    }
    $('.container>div:eq(' + num + ')').show();
});

function temary_operators(obj, type) {
    $('.shadow').hide();
    $(obj).parent().parent().hide();
    let borders = [];

    $('.container>.left>div>div').each(function() {
        if ($(this).attr('id') != undefined) {
            let box = findById($(this).attr('num'));
            borders.push(box);
        }
    });
    let node1 = $(obj).parent().parent().find('.node1').html();
    let node2 = $(obj).parent().parent().find('.node2').html();
    let node3 = $(obj).parent().parent().find('.node3').html();
    let n1 = node1.substring(node1.indexOf('#') + 1, node1.indexOf('(') - 1);
    let n2 = node2.substring(node2.indexOf('#') + 1, node2.indexOf('(') - 1);
    let n3 = node3.substring(node3.indexOf('#') + 1, node3.indexOf('(') - 1);
    let arr = [borders[0].id, borders[1].id, borders[2].id];
    let name, typeValue;
    switch (type) {
        case "If-else condition":
            typeValue = "ifelse_condition";
            name = "{" + n1 + "}=0?" + "{" + n2 + "}:" + "{" + n3 + "}";
            break;
        case "In-range condition":
            typeValue = "in_range"
            name = "in {" + n2 + "} ~ " + "{" + n3 + "}";
            break;
        case "Clamp signal":
            typeValue = "clamp"
            name = "clamp {" + n2 + "} ~ " + "{" + n3 + "}";
            break;
    }
    borders.sort(sortBox);
    let rank = borders[borders.length - 1].rank == "0" ? 1 : parseInt(borders[borders.length - 1].rank) + 1;
    if (!editFlag) {
        let box = new Box(90, 30, name, type, id, "orange", rank, 0, 0, arr, [], true, typeValue);
        boxArr.push(box);
    } else {
        let box = findById($('#border').attr('num'));
        box.name = name;
    }

    boxChange();
}

function ifElseClose(obj, type) {
    temary_operators(obj, type);
}

function inRangeElseClose(obj, type) {
    temary_operators(obj, type);
}

function clampClose(obj, type) {
    temary_operators(obj, type);
}

//三元运算符 交换事件
function temary_exchange(obj) {
    let className = $(obj).attr('class');
    let parent = $(obj).parent().parent().parent();
    if (className == "swap1") {
        let node1 = $(parent).find('.node1').html();
        let node2 = $(parent).find('.node2').html();
        $(parent).find('.node1').html(node2);
        $(parent).find('.node2').html(node1);
    } else {
        let node2 = $(parent).find('.node2').html();
        let node3 = $(parent).find('.node3').html();
        $(parent).find('.node2').html(node3);
        $(parent).find('.node3').html(node2);
    }
}
//multivariate_operators
$('.multivariate_operators').find('a').click(function() {
    editFlag = false;
    if ($(this).hasClass('not_a')) return;
    id++;
    let type = $(this).attr('type');
    let name = $(this).attr('language');
    let typeValue = $(this).attr('typeValue');
    let borders = [],
        arr = [];
    $('.container>.left>div>div').each(function() {
        if ($(this).attr('id') != undefined) {
            let box = findById($(this).attr('num'));
            borders.push(box);
            arr.push(box.id);
        }
    });
    borders.sort(sortBox);
    let rank = borders[borders.length - 1].rank == "0" ? 1 : parseInt(borders[borders.length - 1].rank) + 1;
    let box = new Box(90, 30, name, type, id, "orange", rank, 0, 0, arr, [], false, typeValue);
    boxArr.push(box);
    boxChange();
});
/**
 * 画线-两点一线
 * @param {*} p1 点
 * @param {*} p2 点
 * @param {*} width 线宽度
 * @param {*} color 颜色
 * @param {*} ctx 画图上下文
 */
function drawLine(arr, ctx, opacity) {
    ctx.beginPath();
    ctx.lineWidth = 1;
    ctx.moveTo(arr[0].x, arr[0].y);
    for (let i = 1; i < arr.length; i++) {
        ctx.lineTo(arr[i].x, arr[i].y);
    }
    ctx.strokeStyle = 'rgba(255, 255, 255, ' + opacity + ')';
    ctx.stroke();
}
//画线
function drawLines(lineArr) {
    clearCanvas();
    for (let i = 0; i < lineArr.length; i++) {
        let line = lineArr[i];
        drawLine(line.arr, ctx, line.opacity);
    }
}

function createBox(box, arr, rank) {
    $box = undefined;
    if (box.type == "Input signal" || box.type == "Input constant") {
        $box = $('.blue').clone(true);
    } else if (box.type == "Output signal") {
        $box = $('.green').clone(true);
    } else {
        $box = $('.orange').clone(true);
    }
    $box.html(box.name)
    $box.css({
        "top": box.top,
        "left": box.left
    });
    if (arr.indexOf(box.id) != -1) {
        $box.attr('id', 'border');
    } else {
        $box.removeAttr('id');
    }

    if (box.parentIds.length != 0) {
        for (let i = 0; i < box.parentIds.length; i++) {
            let arr = [];
            let parent = findById(box.parentIds[i]);
            if (parent == undefined) continue;
            parent.sonIds.push(box.id);
            if (box.rank == -1) {
                if (rank == 0) {
                    arr.push(new Point(parent.width + parent.left, parent.top + parent.height / 2));
                    arr.push(new Point(box.left, box.top + box.height / 2));
                } else {
                    let interval = rank - parent.rank;
                    if (interval == 0) {
                        arr.push(new Point(parent.width + parent.left, parent.top + parent.height / 2));
                        arr.push(new Point(box.left, box.top + box.height / 2));
                    } else {
                        arr.push(new Point(parent.width + parent.left, parent.top + parent.height / 2));
                        arr.push(new Point(parent.width + parent.left + 35 / 2, parent.top + parent.height / 2));
                        arr.push(new Point(parent.width + parent.left + 35 / 2, 12));
                        arr.push(new Point(box.left - 35 / 2, 12));
                        arr.push(new Point(box.left - 35 / 2, box.top + box.height / 2));
                        arr.push(new Point(box.left, box.top + box.height / 2));
                    }
                }
            } else {
                let interval = box.rank - parent.rank;
                if (interval == 1) {
                    arr.push(new Point(parent.width + parent.left, parent.top + parent.height / 2));
                    arr.push(new Point(box.left, box.top + box.height / 2));
                } else {
                    arr.push(new Point(parent.width + parent.left, parent.top + parent.height / 2));
                    arr.push(new Point(parent.width + parent.left + 35 / 2, parent.top + parent.height / 2));
                    arr.push(new Point(parent.width + parent.left + 35 / 2, 12));
                    arr.push(new Point(box.left - 35 / 2, 12));
                    arr.push(new Point(box.left - 35 / 2, box.top + box.height / 2));
                    arr.push(new Point(box.left, box.top + box.height / 2));
                }
            }
            let line = {
                opacity: 0.2,
                id: parent.id + "" + box.id,
                arr: arr
            }
            lineArr.push(line);
        }
    }
    $box.attr('num', box.id);
    $('.container>.left>div').append($box[0]);
}

function mouserOver(obj) {
    $(obj).css('opacity', '1');
    let box = findById($(obj).attr('num'));
    let arr = [];
    for (let i = 0; i < box.parentIds.length; i++) {
        let id = box.parentIds[i] + "" + box.id;
        arr.push(id);
    }
    for (let i = 0; i < lineArr.length; i++) {
        let id = lineArr[i].id;
        if (arr.indexOf(id) != -1) {
            lineArr[i].opacity = 1;
        }
    }
    drawLines(lineArr);
}

function mouserOut(obj) {
    $(obj).css('opacity', '.1');
    let box = findById($(obj).attr('num'));
    let arr = [];
    for (let i = 0; i < box.parentIds.length; i++) {
        let id = box.parentIds[i] + "" + box.id;
        arr.push(id);
    }
    for (let i = 0; i < lineArr.length; i++) {
        let id = lineArr[i].id;
        if (arr.indexOf(id) != -1) {
            lineArr[i].opacity = 0.1;
        }
    }
    drawLines(lineArr);
}


function checkBorder() {
    let borders = [];
    $('.container>.left>div>div').each(function(i, v) {
        if ($(this).attr('id') != undefined) {
            let id = $(this).attr('num');
            let box = findById(id);
            borders.push(box);
        }
    });
    if (borders.length == 1) {
        if (borders[0].className != "green") {
            $('.unary_operators').find('a').each(function() {
                $(this).removeClass('not_a');
            });
            $('.unary_operators').find('p').each(function() {
                $(this).removeClass('not_p');
            });
            $('.signal_i_o').find('a').each(function() {
                $(this).removeClass('not_a');
            });
        } else {
            $('.unary_operators').find('a').each(function() {
                $(this).addClass('not_a');
            });
            $('.unary_operators').find('p').each(function() {
                $(this).addClass('not_p');
            });
            $('[language=output_signal]').addClass('not_a');
        }
        let box = findById(borders[0].id);
        box.isModified ? $('#edit').removeClass('not_a') : $('#edit').addClass('not_a');
        $('#remove').removeClass('not_a');
        $('#id').html(borders[0].id);
        let tt = biGetLanguage() == 1 ? box.type : cn2[box.type];
        $('#type').html(tt);
        $('.binary_operators').find('a').each(function() {
            $(this).addClass('not_a');
        });
        $('.binary_operators').find('p').each(function() {
            $(this).addClass('not_p');
        });
        $('.multivariate_operators').find('a').each(function() {
            $(this).addClass('not_a');
        });
        $('.multivariate_operators').find('p').each(function() {
            $(this).addClass('not_p');
        });
        $('.temary_operators').find('a').each(function() {
            $(this).addClass('not_a');
        });
        $('.temary_operators').find('p').each(function() {
            $(this).addClass('not_p');
        });
    } else if (borders.length != 0) {
        $('#edit').addClass('not_a');
        $('#remove').addClass('not_a');
        let txt = biGetLanguage() == 1 ? "(Not selected)" : "(不能选)";
        $('#id').html(txt);
        $('#type').html(txt);
        let flag = false;
        for (let i = 0; i < borders.length; i++) {
            let box = borders[i];
            if (box.className == "green") {
                flag = true;
                break;
            }
        }
        if (!flag) {
            if (borders.length == 2) {
                $('.binary_operators').find('a').each(function() {
                    $(this).removeClass('not_a');
                });
                $('.binary_operators').find('p').each(function() {
                    $(this).removeClass('not_p');
                });
                $('.temary_operators').find('a').each(function() {
                    $(this).addClass('not_a');
                });
            } else if (borders.length == 3) {
                $('.binary_operators').find('a').each(function() {
                    $(this).addClass('not_a');
                });
                $('.binary_operators').find('p').each(function() {
                    $(this).addClass('not_p');
                });
                $('.temary_operators').find('a').each(function() {
                    $(this).removeClass('not_a');
                });
                $('.temary_operators').find('p').each(function() {
                    $(this).removeClass('not_p');
                });
            } else {
                $('.unary_operators').find('a').each(function() {
                    $(this).addClass('not_a');
                });
                $('.unary_operators').find('a').each(function() {
                    $(this).addClass('not_a');
                });
                $('.binary_operators').find('p').each(function() {
                    $(this).addClass('not_p');
                });
                $('.temary_operators').find('a').each(function() {
                    $(this).addClass('not_a');
                });
                $('.temary_operators').find('p').each(function() {
                    $(this).addClass('not_p');
                });
            }
            $('.signal_i_o').find('a').each(function() {
                $(this).addClass('not_a');
            });
            $('.unary_operators').find('a').each(function() {
                $(this).addClass('not_a');
            });
            $('.unary_operators').find('p').each(function() {
                $(this).addClass('not_p');
            });
            $('[language=output_signal]').addClass('not_a');
            $('[language=remove]').removeClass('not_a');
            $('.multivariate_operators').find('a').each(function() {
                $(this).removeClass('not_a');
            });
            $('.multivariate_operators').find('p').each(function() {
                $(this).addClass('not_p');
            });
        } else {
            $('#remove').removeClass('not_a');
            $('.unary_operators').find('a').each(function() {
                $(this).addClass('not_a');
            });
            $('.unary_operators').find('p').each(function() {
                $(this).addClass('not_p');
            });
            $('.binary_operators').find('a').each(function() {
                $(this).addClass('not_a');
            });
            $('.binary_operators').find('p').each(function() {
                $(this).addClass('not_p');
            });
            $('.temary_operators').find('a').each(function() {
                $(this).addClass('not_a');
            });
            $('.temary_operators').find('p').each(function() {
                $(this).addClass('not_p');
            });
            $('.multivariate_operators').find('a').each(function() {
                $(this).addClass('not_a');
            });
            $('.multivariate_operators').find('p').each(function() {
                $(this).addClass('not_p');
            });
            $('[language=output_signal]').addClass('not_a');
        }
    } else {
        let txt = biGetLanguage() == 1 ? "(Not selected)" : "(不能选)";
        $('#id').html(txt);
        $('#type').html(txt);
        $('.unary_operators').find('a').each(function() {
            $(this).addClass('not_a');
        });
        $('.unary_operators').find('p').each(function() {
            $(this).addClass('not_p');
        });
        $('.binary_operators').find('a').each(function() {
            $(this).addClass('not_a');
        });
        $('.binary_operators').find('p').each(function() {
            $(this).addClass('not_p');
        });
        $('.temary_operators').find('a').each(function() {
            $(this).addClass('not_a');
        });
        $('.temary_operators').find('p').each(function() {
            $(this).addClass('not_p');
        });
        $('[language=output_signal]').addClass('not_a');
        $('#edit').addClass('not_a');
        $('#remove').addClass('not_a');
    }
}
$(".blue").unbind("mousedown").bind("contextmenu", function(e) {
    e.preventDefault();
    return false;
});
$(".blue").unbind("mousedown").bind("mousedown", function(event) {
    if (event.which == 3) { //右键
        if ($(this).attr('id') == undefined) {
            $(this).attr('id', 'border');
        } else {
            $(this).removeAttr('id');
        }
    } else if (event.which == 1) { //左键
        $(this).attr('id', 'border').siblings().removeAttr('id');
    }
    checkBorder();
});
$(".orange").unbind("mousedown").bind("contextmenu", function(e) {
    e.preventDefault();
    return false;
});
$(".orange").unbind("mousedown").bind("mousedown", function(event) {
    if (event.which == 3) { //右键
        if ($(this).attr('id') == undefined) {
            $(this).attr('id', 'border');
        } else {
            $(this).removeAttr('id');
        }
    } else if (event.which == 1) { //左键
        $(this).attr('id', 'border').siblings().removeAttr('id');
    }
    checkBorder();
});
$(".green").unbind("mousedown").bind("contextmenu", function(e) {
    e.preventDefault();
    return false;
});
$(".green").unbind("mousedown").bind("mousedown", function(event) {
    if (event.which == 3) { //右键
        if ($(this).attr('id') == undefined) {
            $(this).attr('id', 'border');
        } else {
            $(this).removeAttr('id');
        }
    } else if (event.which == 1) { //左键
        $(this).attr('id', 'border').siblings().removeAttr('id');
    }
    checkBorder();
});
$('#canvas').click(function() {
    resetting();
    $('.container>.left>div>div').each(function() {
        if ($(this).attr('id') != undefined) $(this).removeAttr('id');
    });
})

//编辑box
function edit(obj) {
    if ($(obj).hasClass('not_a')) return
    let id = $('#border').attr('num');
    let box = findById(id);
    editFlag = true;
    let name = box.name;
    let id1, id2, id3, p1, p2, p3, node1, node2, node3;
    let parentIds = box.parentIds;
    switch (box.type) {
        case "Input signal":
            let arr = box.signal.split(":");
            if (arr[0].indexOf(".dbc") != -1) {
                biQueryBusProtocolFileChannel(arr[0]);
            } else {
                $('.input_signal').find('a').html(arr[1] + ":" + arr[2]);
                $('.input_signal').find('a').addClass('springgreen').removeClass("red");
            }
            $('.input_signal').show();
            $('.input_signal').find('[name=interpolation]').val(box.interpolation);
            $('.input_signal').find('a').attr('val', box.signal);
            break;
        case "Output signal":
            $('.output_signal').show();
            $('.output_signal').find('[name=output_signal_name]').val(box.value);
            break;
        case "Input constant":
            $('.constant').show();
            $('.constant').find('[name=constantV]').val(box.value);
            break;
        case "Condition with number":
            $('.condition').show();
            $('[name=num1]').val(box.num1);
            $('[name=num2]').val(box.num2);
            box.flag ? $('[name=reset]').attr('checked', true) : $('[name=reset]').removeAttr('checked');
            reset($('[name=reset]'));
            $('[name=first]').val(box.first);
            $('[name=second]').val(box.second);
            break;
        case "Add / Subtract number":
            $('.add_number').show();
            $('.add_number').find('[name=addValue]').val(box.value);
            break;
        case "Multiply number":
            $('.multiply_number').show();
            $('.multiply_number').find('[name=multiplyValue]').val(box.value);
            break;
        case "Power":
            $('.power').show();
            $('.power').find('[name=power]').val(box.power);
            $('.power').find('[name=default]').val(box.defaultV);
            break;
        case "Signal holder":
            $('.signal_holder').show();
            $('.signal_holder').find('[name=holderV]').val(box.value);
            break;
        case "Number mapping":
            $('.map').show();
            $('.map>.tent>.table>.body>div:first-of-type').each(function() {
                $(this).remove();
            });
            for (let i = 0; i < box.input.length; i++) {
                $tableBox = $('.map>.tent>.table>.body>div:first-of-type').clone(true);
                $tableBox.find('[name=input]').val(box.input[i]);
                $tableBox.find('[name=output]').val(box.output[i]);
                $('.map>.tent>.table>.body').append($tableBox[0]);
            }
            if (box.defaultValue == "constant") {
                $('.map').find('#map1').removeAttr('checked');
                $('.map').find('#map2').attr('checked', true);
            } else {
                $('.map').find('#map2').removeAttr('checked');
                $('.map').find('#map1').attr('checked', true);
            }
            $('.map').find('[name=mapValue]').val(box.value)
            $tableBox = $('.map>.tent>.table>.body>div:first-of-type').clone(true);
            $('.map>.tent>.table>.body').append($tableBox[0]);
            break;
        case "1st low pass filter":
            $('.filter').show();
            $('.filter').find('[name=filterV]').val(box.value);
            break;
        case "Mod number":
            $('.mod').show();
            $('.mod').find('[name=modV]').val(box.value);
            break;
        case "Substract signal":
            id1 = name.substring(1, name.indexOf('}'));
            id2 = parentIds[0] == id1 ? parentIds[1] : parentIds[0];
            p1 = findById(id1);
            p2 = findById(id2);
            node1 = "Node #" + p1.id + " (" + p1.name + ")";
            node2 = "Node #" + p2.id + " (" + p2.name + ")";
            $('.subtract_signal').show();
            $('.subtract_signal').find('.node1').html(node1);
            $('.subtract_signal').find('.node2').html(node2);
            break;
        case "Devide signal":
            $('.divide').show();
            id1 = name.substring(1, name.indexOf('}'));
            id2 = parentIds[0] == id1 ? parentIds[1] : parentIds[0];
            p1 = findById(id1);
            p2 = findById(id2);
            node1 = "Node #" + p1.id + " (" + p1.name + ")";
            node2 = "Node #" + p2.id + " (" + p2.name + ")";
            $('.divide').find('.node1').html(node1);
            $('.divide').find('.node2').html(node2);
            $('.divide').find('[name=value]').val(box.value);
            break;
        case "Condition with signal":
            $('.condition_with').show();
            id1 = name.substring(1, name.indexOf('}'));
            id2 = parentIds[0] == id1 ? parentIds[1] : parentIds[0];
            p1 = findById(id1);
            p2 = findById(id2);
            node1 = "Node #" + p1.id + " (" + p1.name + ")";
            node2 = "Node #" + p2.id + " (" + p2.name + ")";
            $('.condition_with').find('.node1').html(node1);
            $('.condition_with').find('.node2').html(node2);
            $('[name=operator]').val(box.value);
            break;
        case "Weighted average":
            $('.weighted').show();
            id1 = name.substring(name.indexOf('{') + 1, name.indexOf('}'));
            id2 = parentIds[0] == id1 ? parentIds[1] : parentIds[0];
            p1 = findById(id1);
            p2 = findById(id2);
            node1 = "Node #" + p1.id + " (" + p1.name + ")";
            node2 = "Node #" + p2.id + " (" + p2.name + ")";
            $('.weighted').find('.node1').html(node1);
            $('.weighted').find('.node2').html(node2);
            break;
        case "Resetable integeral":
            $('.resettable').show();
            id1 = name.substring(name.indexOf('{') + 1, name.indexOf('}'));
            id2 = parentIds[0] == id1 ? parentIds[1] : parentIds[0];
            p1 = findById(id1);
            p2 = findById(id2);
            node1 = "Node #" + p1.id + " (" + p1.name + ")";
            node2 = "Node #" + p2.id + " (" + p2.name + ")";
            $('.resettable').find('.node1').html(node1);
            $('.resettable').find('.node2').html(node2);
            break;
        case "If-else condition":
            $('.if_else').show();
            p1 = findById(parentIds[0]);
            p2 = findById(parentIds[1]);
            p3 = findById(parentIds[2]);
            node1 = "Node #" + p1.id + " (" + p1.name + ")";
            node2 = "Node #" + p2.id + " (" + p2.name + ")";
            node3 = "Node #" + p3.id + " (" + p3.name + ")";
            $('.if_else>.tent .node1').html(node1);
            $('.if_else>.tent .node2').html(node2);
            $('.if_else>.tent .node3').html(node3);
            break;
        case "In-range condition":
            $('.in_range').show();
            p1 = findById(parentIds[0]);
            p2 = findById(parentIds[1]);
            p3 = findById(parentIds[2]);
            node1 = "Node #" + p1.id + " (" + p1.name + ")";
            node2 = "Node #" + p2.id + " (" + p2.name + ")";
            node3 = "Node #" + p3.id + " (" + p3.name + ")";
            $('.in_range>.tent .node1').html();
            $('.in_range>.tent .node2').html();
            $('.in_range>.tent .node3').html();
            break;
        case "Clamp signal":
            $('.clamp').show();
            p1 = findById(parentIds[0]);
            p2 = findById(parentIds[1]);
            p3 = findById(parentIds[2]);
            node1 = "Node #" + p1.id + " (" + p1.name + ")";
            node2 = "Node #" + p2.id + " (" + p2.name + ")";
            node3 = "Node #" + p3.id + " (" + p3.name + ")";
            $('.clamp>.tent .node1').html();
            $('.clamp>.tent .node2').html();
            $('.clamp>.tent .node3').html();
            break;
    }
}

//获取总线协议文件绑定的通道
function biOnQueriedBusProtocolFileChannel(busFileProtocolID, busChannel) {
    if (busChannel == 0) {
        let val = $('.input_signal').find('a').attr("val");
        $('.input_signal').find('a').html(val);
        $('.input_signal').find('a').removeClass('springgreen').addClass("red");
    } else {
        let arr = $('.input_signal').find('a').attr("val").split(":");
        $('.input_signal').find('a').html(arr[2]);
        $('.input_signal').find('a').addClass('springgreen').removeClass("red");
    }
}
//移除box
function remove(obj) {
    if ($(obj).hasClass('not_a')) return
    let arr = [];
    //选出选中的节点
    $('.container>.left>div>div').each(function() {
        if ($(this).attr('id') != undefined) {
            let id = $(this).attr('num');
            let box = findById(id);
            arr.push(box);
        }
    });
    arr.sort(sortBox);
    let indexArr = [];
    for (let i = 0; i < arr.length; i++) {
        let box = arr[i];
        let id = box.id;
        if (box.rank == -1) {
            arr.splice(i, 1);
            deleteById(box.id);
            indexArr.push(id);
            i--;
        }
    }
    for (let i = boxArr.length - 1; i >= 0; i--) {
        let box = boxArr[i];
        let arr2 = box.sonIds;
        let flag = false;
        for (let k = arr2.length - 1; k >= 0; k--) {
            let box = findById(arr2[k]);
            if (box != undefined) {
                flag = true;
            } else {
                boxArr.splice(arr2[k], 1);
                arr.splice(arr2[k], 1);
                arr2.splice(k, 1);
            }
        }
        for (let j = 0; j < arr.length; j++) {
            if (box.id == arr[j].id && !flag) {
                indexArr.push(box.id);
                arr.splice(j, 1);
                boxArr.splice(i, 1);
                break;
            }
        }
    }
    $('.container>.left>div>div').each(function() {
        if ($(this).attr('id') != undefined) {
            let id = $(this).attr('num');
            if (indexArr.indexOf(Number(id)) != -1) {
                $(this).remove();
            }
        }
    });
    if (arr.length != 0) {
        let txt = biGetLanguage() == 1 ? "Can't remove some nodes because of dependency." : "无法移除被依赖的节点.";
        let t = sessionStorage.getItem('language') == 1 ? "Notice" : "消息";
        biAlert(txt, t);
    }
    resetting();
    boxChange();
    setConfig();
}

function deleteById(id) {
    for (let i = 0; i < boxArr.length; i++) {
        let box = boxArr[i];
        if (id == box.id) {
            boxArr.splice(i, 1);
            break;
        }
    }
}
//重置
function resetting() {
    $('#edit').addClass('not_a');
    $('#remove').addClass('not_a');
    let txt = biGetLanguage() == 1 ? "(Not selected)" : "(不能选)";
    $('#id').html(txt);
    $('#type').html(txt);
    $('.signal_i_o').find('a').each(function() {
        $(this).removeClass('not_a');
    });
    $('[language=output_signal]').addClass('not_a');
    $('.unary_operators').find('a').each(function() {
        $(this).addClass('not_a');
    });
    $('.unary_operators').find('p').each(function() {
        $(this).addClass('not_p');
    });
    $('.binary_operators').find('a').each(function() {
        $(this).addClass('not_a');
    });
    $('.binary_operators').find('p').each(function() {
        $(this).addClass('not_p');
    });
    $('.temary_operators').find('a').each(function() {
        $(this).addClass('not_a');
    });
    $('.temary_operators').find('p').each(function() {
        $(this).addClass('not_p');
    });
    $('.multivariate_operators').find('a').each(function() {
        $(this).addClass('not_a');
    });
    $('.multivariate_operators').find('p').each(function() {
        $(this).addClass('not_p');
    });
}
//改变box位置
function boxChange() {
    let borderArr = [];
    $('.container>.left>div>div').each(function() {
        let num = $(this).attr('num');
        num = parseInt(num);
        if ($(this).attr('id') != undefined) borderArr.push(num);
    });
    $('.container>.left>div>div').each(function() {
        $(this).remove();
    });
    lineArr = [];
    let blueArr = [],
        orangeArr = [],
        greenArr = [];
    let maxLen = 0;
    for (let i = 0; i < boxArr.length; i++) {
        let box = boxArr[i];
        if (box.className == "blue") {
            blueArr.push(box);
        } else if (box.className == "orange") {
            orangeArr.push(box);
        } else {
            greenArr.push(box);
        }
    }

    let newOrangeArr = [];
    for (let i = 0; i < orangeArr.length; i++) {
        let arr = [],
            flag = false;
        for (let j = 0; j < orangeArr.length; j++) {
            let box = orangeArr[j];
            if (box.rank == (i + 1)) {
                arr.push(box);
                flag = true;
            }
        }
        if (!flag) {
            break;
        }
        newOrangeArr.push(arr);
    }
    for (let i = 0; i < newOrangeArr.length; i++) {
        let arr = newOrangeArr[i];
        if (arr.length > maxLen) maxLen = arr.length;
    }
    if (blueArr.length > maxLen) maxLen = blueArr.length;
    let len = newOrangeArr.length != 0 ? 90 : 0;
    if (greenArr.length != 0) {
        let m = initLeft + 120 + initLeft + (newOrangeArr.length) * (len + initLeft) + 120 + 20;
        if (m > 750) {
            minLeft = 750 - m;
            $('.container>.left>div').css({ "width": m + "px" });
            canvas.width = m;
        } else if (canvas.width > 750) {
            $('.container>.left>div').css({ "width": 750 + "px", "left": 0 + "px" });
            canvas.width = 750;
            minLeft = 0;
        }
    } else if (newOrangeArr.length != 0) {
        let box = newOrangeArr[newOrangeArr.length - 1][0];
        let m = initLeft + 120 + (parseInt(box.rank) - 1) * 125 + initLeft + 90 + 20;
        if (m > 750) {
            minLeft = 750 - m;
            $('.container>.left>div').css({ "width": m + "px" });
            canvas.width = m;
        } else if (canvas.width > 750) {
            $('.container>.left>div').css({ "width": 750 + "px", "left": 0 + "px" });
            canvas.width = 750;
            minLeft = 0;
        }
    }
    let h = initTop + (initInterval + 30) * (maxLen - 1) + 30 + 20;
    if (h > 622) {
        minTop = 622 - h;
        $('.container>.left>div').css({ "height": h + "px" });
        canvas.height = h;
    } else if (canvas.height > 622) {
        $('.container>.left>div').css({ "height": 622 + "px", "top": 0 + "px" });
        canvas.height = 622;
        minTop = 0
    }
    let blueLen = blueArr.length;
    if (blueLen > maxLen) maxLen = blueLen;
    let greenLen = greenArr.length;
    if (greenLen > maxLen) maxLen = greenLen;
    //blue
    for (let i = 0; i < blueArr.length; i++) {
        let box = blueArr[i],
            top;
        if (blueLen == maxLen) {
            top = initTop + (initInterval + box.height) * i;
        } else {
            let scale = maxLen / blueLen;
            top = initTop + (scale - 1) * 20 + i * scale * 40
        }
        box.top = top;
        box.left = initLeft;
        createBox(box, borderArr, newOrangeArr.length);
    }
    //orange
    for (let i = 0; i < newOrangeArr.length; i++) {
        let arr = newOrangeArr[i];
        for (let j = 0; j < arr.length; j++) {
            let box = arr[j],
                top;
            if (arr.length == maxLen) {
                top = initTop + (initInterval + box.height) * j;
            } else {
                let scale = maxLen / arr.length;
                top = initTop + (scale - 1) * 20 + j * scale * 40;
            }
            let width = (parseInt(box.rank) - 1) * 125;
            box.top = top;
            box.left = initLeft + 120 + width + initLeft;
            createBox(box, borderArr, newOrangeArr.length);
        }
    }
    //green
    for (let i = 0; i < greenArr.length; i++) {
        let box = greenArr[i],
            top;
        if (greenLen == maxLen) {
            top = initTop + (initInterval + box.height) * i;
        } else {
            let scale = maxLen / greenLen;
            top = initTop + (scale - 1) * 20 + i * scale * 40;
        }
        box.top = top;
        box.left = initLeft + box.width + initLeft + (newOrangeArr.length) * (len + initLeft);
        createBox(box, borderArr, newOrangeArr.length);
    }
    drawLines(lineArr);
    setConfig();
}
//清除画布
function clearCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
}


$('[name=rate]').blur(function() {
    let min = $(this).attr('min');
    let max = $(this).attr('max');
    let v = $(this).val();
    v = v > max ? max : v;
    v = v < min ? min : v;
    $(this).val(v);
});
if (language == null) {
    changeLanguage(0);
}
$('[type=enabled]').click(function() {
    setConfig();
});
/**
 * 判断中英文
 */
function changeLanguage(type) {
    if (type == 1) {
        $('[language]').each(function() {
            let value = $(this).attr('language');
            $(this).html(en[value])
        });
    } else {
        $('[language]').each(function() {
            let value = $(this).attr('language');
            $(this).html(cn[value])
        });
    }
}
/**
 * 加载配置
 */
function loadConfig(config) {
    if (config == null) return
    let obj = JSON.parse(config);
    obj.enabled == "yes" ? $('.container>.right [name=enabled]').attr('checked', true) : $('.container>.right [name=enabled]').removeAttr('checked');
    $('.container>.right [name=rate]').val(obj.rate);
}
/**
 * 写配置
 */

function setConfig() {
    let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
    text += "<root enabled=\"" + ($('.container>.right [name=enabled]').get(0).checked ? "yes" : "no") + "\" rate=\"" + $('.container>.right [name=rate]').val() + "\">";
    let blueArr = [],
        orangeArr = [],
        greenArr = [];
    for (let i = 0; i < boxArr.length; i++) {
        let box = boxArr[i];
        if (box.className == "blue") {
            blueArr.push(box);
        } else if (box.className == "orange") {
            orangeArr.push(box);
        } else {
            greenArr.push(box);
        }
    }
    if (blueArr.length != 0) {
        text += "<input>";
        for (let i = 0; i < blueArr.length; i++) {
            let box = blueArr[i];
            let typeValue = box.typeValue;
            if (typeValue == "constant") {
                text += "<node id=\"" + box.id + "\" type=\"" + box.typeValue + "\" value=\"" + box.value + "\" />";
            } else {
                text += "<node id=\"" + box.id + "\" type=\"" + box.typeValue + "\" signal=\"" + box.signal + "\"  nearest=\"" + box.interpolation + "\" />";
            }
        }
        text += "</input>";
    } else {
        text += "<input />";
    }
    if (greenArr.length != 0) {
        text += "<output>";
        for (let i = 0; i < greenArr.length; i++) {
            let box = greenArr[i];
            text += "<node id=\"" + box.id + "\" type=\"" + box.typeValue + "\" name=\"" + box.value + "\" source=\"" + box.parentIds[0] + "\" />";
        }
        text += "</output>";
    } else {
        text += "<output />";
    }
    let newOrangeArr = [];
    for (let i = 0; i < orangeArr.length; i++) {
        let arr = [],
            flag = false;
        for (let j = 0; j < orangeArr.length; j++) {
            let box = orangeArr[j];
            if (box.rank == (i + 1)) {
                arr.push(box);
                flag = true;
            }
        }
        if (!flag) {
            break;
        }
        newOrangeArr.push(arr);
    }
    for (let i = 0; i < newOrangeArr.length; i++) {
        let arr = newOrangeArr[i];
        text += "<layer>";
        for (let j = 0; j < arr.length; j++) {
            let box = arr[j];
            text += nodeText(box);
        }
        text += "</layer>";
    }

    text += "</root>";
    biSetModuleConfig("signal-calculation.system", text);
}

function nodeText(box) {
    let text = "";
    let id = box.id;
    let typeValue = box.typeValue;
    let parentIds = box.parentIds;
    if (box.typeValue == "abs" ||
        box.typeValue == "ceiling" ||
        box.typeValue == "floor" ||
        box.typeValue == "round" ||
        box.typeValue == "average" ||
        box.typeValue == "integral"
    ) {
        text = "<node id=\"" + id + "\" type=\"" + typeValue + "\" source=\"" + parentIds[0] + "\" />";
        return text;
    }
    if (box.typeValue == "and" ||
        box.typeValue == "or" ||
        box.typeValue == "add_signal" ||
        box.typeValue == "sub_signal" ||
        box.typeValue == "mul_signal" ||
        box.typeValue == "weight_average" ||
        box.typeValue == "reset_integral"
    ) {
        text = "<node id=\"" + id + "\" type=\"" + typeValue + "\" source1=\"" + parentIds[0] + "\" source2=\"" + parentIds[1] + "\" />";
        return text;
    }
    if (box.typeValue == "ifelse_condition" ||
        box.typeValue == "in_range" ||
        box.typeValue == "clamp"
    ) {
        text = "<node id=\"" + id + "\" type=\"" + typeValue + "\" source1=\"" + parentIds[0] + "\" source2=\"" + parentIds[1] + "\" source3=\"" + parentIds[2] + "\" />";
        return text;
    }
    if (box.typeValue == "min" ||
        box.typeValue == "max"
    ) {
        let n = parentIds[0] + "," + parentIds[1] + "," + parentIds[2];
        text = "<node id=\"" + id + "\" type=\"" + typeValue + "\">" + n + "</node>";
        return text;
    }

    switch (box.typeValue) {
        case "unary_condition":
            text = "<node id=\"" + id + "\" type=\"" + typeValue + "\" source=\"" + parentIds[0] + "\" compare=\"" + box.first + "\" values=\"" + box.num1 + "\" use_reset=\"" + (box.flag ? "yes" : "no") + "\" reset_compare=\"" + (box.second) + "\" reset_values=\"" + (box.flag ? null : box.num2) + "\" />";
            break;
        case "add_number":
            text = "<node id=\"" + id + "\" type=\"" + typeValue + "\" source=\"" + parentIds[0] + "\" value=\"" + box.value + "\" />";
            break;
        case "mul_number":
            text = "<node id=\"" + id + "\" type=\"" + typeValue + "\" source=\"" + parentIds[0] + "\" value=\"" + box.value + "\" />";
            break;
        case "power":
            text = "<node id=\"" + id + "\" type=\"" + typeValue + "\" source=\"" + parentIds[0] + "\" value=\"" + box.power + "\" default=\"" + box.defaultV + "\" />";
            break;
        case "holder":
            text = "<node id=\"" + id + "\" type=\"" + typeValue + "\" source=\"" + parentIds[0] + "\" duration=\"" + box.value + "\" />";
            break;
        case "map":
            text = "<node id=\"" + id + "\" type=\"" + typeValue + "\" source=\"" + parentIds[0] + "\" duration=\"" + box.value + "\" />";
            break;
        case "lpf_1st":
            text = "<node id=\"" + id + "\" type=\"" + typeValue + "\" source=\"" + parentIds[0] + "\" time_coef=\"" + box.value + "\" />";
            break;
        case "mod":
            text = "<node id=\"" + id + "\" type=\"" + typeValue + "\" source=\"" + parentIds[0] + "\" mod_number=\"" + box.value + "\" />";
            break;
        case "devide_signal":
            text = "<node id=\"" + id + "\" type=\"" + typeValue + "\" source1=\"" + parentIds[0] + "\" source2=\"" + parentIds[1] + "\" default=\"" + box.value + "\" />";
            break;
        case "binary_condition":
            text = "<node id=\"" + id + "\" type=\"" + typeValue + "\" source1=\"" + parentIds[0] + "\" source2=\"" + parentIds[1] + "\" compare=\"" + box.value + "\" />";
            break;
    }
    return text;
}

/**
 * 选择信号
 * @param {} obj 
 */
let idName = null; //选择的元素的id名
function onClick(obj) {
    let originID = null;
    if ($(obj).html().lastIndexOf('(') == -1) {
        originID = $(obj).attr("val");
    }
    idName = obj;
    biSelectSignal("TargetSignal", originID, false, null, false, 1, "[m]");
}

function biOnSelectedSignal(key, valueInfo, signBitInfo, scale) {
    if (key == "TargetSignal") {
        let text = null;
        if (valueInfo == null) {
            text = biGetLanguage() == 1 ? "(Not configured)" : "(未配置)";
            $(idName).removeClass('springgreen').addClass('red');
            $(idName).html(text);
            $(idName).removeAttr("val");
        } else {
            $(idName).html(valueInfo.typeName + ":" + valueInfo.signalName);
            $(idName).attr("val", valueInfo.id);
            $(idName).addClass('springgreen').removeClass('red');
        }
    }
}


function biOnInitEx(config, moduleConfigs) {
    let type = biGetLanguage();
    changeLanguage(type);
    sessionStorage.setItem("language", type);
    configuration = config;
    biSetViewSize(984, 643);
    let obj = new Object();
    for (let key in moduleConfigs) {
        let parser = new DOMParser();
        let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
        let countrys = xmlDoc.getElementsByTagName('root');
        let keys = countrys[0].getAttributeNames();
        for (let i = 0; i < keys.length; i++) {
            obj[keys[i]] = countrys[0].getAttribute(keys[i]);
        }
        let num = 0;
        for (let i = 0; i < countrys[0].childNodes.length; i++) {
            let ele = countrys[0].childNodes[i];
            let rank = 0;
            if (i > 1) rank = i - 1;
            for (let j = 0; j < ele.childNodes.length; j++) {
                let id = parseInt(ele.childNodes[j].getAttribute("id"));
                if (id > num) num = id;
                let type = ele.childNodes[j].getAttribute("type");
                let box;
                if (type == "constant") {
                    let v = ele.childNodes[j].getAttribute("value");
                    let name = v == "" ? 0 : v;
                    box = new Constant(120, 30, name, "Input constant", id, "blue", 0, 0, 0, [], [], true, type, v);
                } else if (type == "input") {
                    let signal = ele.childNodes[j].getAttribute("signal");
                    let interpolation = ele.childNodes[j].getAttribute("nearest");
                    let arr = signal.split(":")
                    box = new InputSignal(120, 30, arr[2], "Input signal", id, "blue", 0, 0, 0, [], [], true, type, signal, arr[2], interpolation);
                } else if (type == "output") {
                    let slot = ele.childNodes[j].getAttribute("name");
                    let source = ele.childNodes[j].getAttribute("source");
                    box = new SignalOutput(120, 30, slot, "Output signal", id, "green", -1, 0, 0, [source], [], true, type, slot);
                } else if (type == "unary_condition") {
                    let source = ele.childNodes[j].getAttribute("source");
                    let compare = ele.childNodes[j].getAttribute("compare");
                    let values = ele.childNodes[j].getAttribute("values");
                    let use_reset = ele.childNodes[j].getAttribute("use_reset");
                    let reset_compare = ele.childNodes[j].getAttribute("reset_compare");
                    let reset_values = ele.childNodes[j].getAttribute("reset_values");
                    let name = compareArr[Number(compare)] + values + "(" + compareArr[Number(reset_compare)] + reset_values + ")";
                    box = new Condition(90, 30, name, "Condition with number", id, "orange", rank, 0, 0, [source], [], true, type, compare, values, reset_compare, reset_values, (use_reset == "yes" ? true : false));
                } else if (type == "add_number") {
                    let source = ele.childNodes[j].getAttribute("source");
                    let value = ele.childNodes[j].getAttribute("value");
                    let name = value >= 0 ? "+" + value : value;
                    box = new Add(90, 30, name, "Add / Subtract number", id, "orange", rank, 0, 0, [source], [], true, type, value);
                } else if (type == "mul_number") {
                    let source = ele.childNodes[j].getAttribute("source");
                    let value = ele.childNodes[j].getAttribute("value");
                    let name = value >= 0 ? "+" + value : value;
                    box = new Add(90, 30, name, "Multiply number", id, "orange", rank, 0, 0, [source], [], true, type, value);
                } else if (type == "abs") {
                    let source = ele.childNodes[j].getAttribute("source");
                    box = new Box(90, 30, "abs", "Absolute", id, "orange", rank, 0, 0, [source], [], false, type);
                } else if (type == "power") {
                    let source = ele.childNodes[j].getAttribute("source");
                    let value = ele.childNodes[j].getAttribute("value");
                    let defaul = ele.childNodes[j].getAttribute("default");
                    let name = "^" + value;
                    box = new Power(90, 30, name, "Power", id, "orange", rank, 0, 0, [source], [], true, type, value, defaul);
                } else if (type == "holder") {
                    let source = ele.childNodes[j].getAttribute("source");
                    let duration = ele.childNodes[j].getAttribute("duration");
                    let name = "hold " + duration + "s";
                    box = new SignalHolder(90, 30, name, "Signal holder", id, "orange", rank, 0, 0, [source], [], true, type, duration);
                } else if (type == "ceiling") {
                    let source = ele.childNodes[j].getAttribute("source");
                    box = new Box(90, 30, "ceil", "Ceiling", id, "orange", rank, 0, 0, [source], [], false, type);
                } else if (type == "floor") {
                    let source = ele.childNodes[j].getAttribute("source");
                    box = new Box(90, 30, "floor", "Floor", id, "orange", rank, 0, 0, [source], [], false, type);
                } else if (type == "round") {
                    let source = ele.childNodes[j].getAttribute("source");
                    box = new Box(90, 30, "round", "Round", id, "orange", rank, 0, 0, [source], [], false, type);
                } else if (type == "average") {
                    let source = ele.childNodes[j].getAttribute("source");
                    box = new Box(90, 30, "avg", "Average", id, "orange", rank, 0, 0, [source], [], false, type);
                } else if (type == "integral") {
                    let source = ele.childNodes[j].getAttribute("source");
                    box = new Box(90, 30, "integral", "Integral", id, "orange", rank, 0, 0, [source], [], false, type);
                } else if (type == "map") {
                    let source = ele.childNodes[j].getAttribute("source");
                    let defaultValue = ele.childNodes[j].getAttribute("default_mode_passthrough");
                    let value = ele.childNodes[j].getAttribute("default_constant");
                    let map_values = ele.childNodes[j].getAttribute("map_values");
                    let arr = map_values.split(",");
                    let input = [],
                        output = [];
                    for (let i = 0; i < arr.length; i++) {
                        if (i % 2 == 0) input.push(arr[i]);
                        if (i % 2 != 0) output.push(arr[i]);
                    }
                    box = new MapNumber(90, 30, "map", "Number mapping", id, "orange", rank, 0, 0, [source], [], true, 'map', defaultValue, value, input, output);
                } else if (type == "lpf_1st") {
                    let source = ele.childNodes[j].getAttribute("source");
                    let time_coef = ele.childNodes[j].getAttribute("time_coef");
                    let name = time_coef + "s LPF1";
                    box = new OrderLPF(90, 30, name, "1st low pass filter", id, "orange", rank, 0, 0, [source], [], true, 'lpf_1st', time_coef);
                } else if (type == "mod") {
                    let source = ele.childNodes[j].getAttribute("source");
                    let mod_number = ele.childNodes[j].getAttribute("mod_number");
                    let name = "%" + mod_number;
                    box = new Mod(90, 30, name, "Mod number", id, "orange", 1, 0, 0, [source], [], true, 'mod', mod_number);
                } else if (type == "and" || type == "or" || type == "add_signal" || type == "sub_signal" || type == "mul_signal") {
                    let source1 = ele.childNodes[j].getAttribute("source1");
                    let source2 = ele.childNodes[j].getAttribute("source2");
                    let name = binary_operators[type].name;
                    let typeV = binary_operators[type].type;
                    box = new Box(90, 30, name, typeV, id, "orange", rank, 0, 0, [source1, source2], [], false, type);
                } else if (type == "devide_signal") {
                    let source1 = ele.childNodes[j].getAttribute("source1");
                    let source2 = ele.childNodes[j].getAttribute("source2");
                    let value = ele.childNodes[j].getAttribute("default");
                    let name = "{" + source1 + "}/" + "{" + source2 + "}";
                    box = new Decide(90, 30, name, "Devide signal", id, "orange", rank, 0, 0, [source1, source2], [], true, 'devide_signal', value);
                } else if (type == "binary_condition") {
                    let source1 = ele.childNodes[j].getAttribute("source1");
                    let source2 = ele.childNodes[j].getAttribute("source2");
                    let compare = ele.childNodes[j].getAttribute("compare");
                    let name = "{" + source1 + "} " + compareArr[Number(compare)] + " " + "{" + source2 + "}";
                    box = new ConditionWith(90, 30, name, "Condition with signal", id, "orange", rank, 0, 0, [source1, source2], [], true, 'binary_condition', compare);
                } else if (type == "weight_average") {
                    let source1 = ele.childNodes[j].getAttribute("source1");
                    let source2 = ele.childNodes[j].getAttribute("source2");
                    box = new Box(90, 30, "avg{" + source1 + "}", "Weighted average", id, "orange", rank, 0, 0, [source1, source2], [], true, type);
                } else if (type == "reset_integral") {
                    let source1 = ele.childNodes[j].getAttribute("source1");
                    let source2 = ele.childNodes[j].getAttribute("source2");
                    box = new Box(90, 30, "integral{" + source1 + "}", "Resettable integeral", id, "orange", rank, 0, 0, [source1, source2], [], true, type);
                } else if (type == "ifelse_condition") {
                    let source1 = ele.childNodes[j].getAttribute("source1");
                    let source2 = ele.childNodes[j].getAttribute("source2");
                    let source3 = ele.childNodes[j].getAttribute("source3");
                    let name = "{" + source1 + "}=0?" + "{" + source2 + "}:" + "{" + source3 + "}";
                    box = new Box(90, 30, name, "If-else condition", id, "orange", rank, 0, 0, [source1, source2, source3], [], false, type);
                } else if (type == "in_range") {
                    let source1 = ele.childNodes[j].getAttribute("source1");
                    let source2 = ele.childNodes[j].getAttribute("source2");
                    let source3 = ele.childNodes[j].getAttribute("source3");
                    let name = "in {" + source2 + "} ~ " + "{" + source3 + "}";
                    box = new Box(90, 30, name, "In-range condition", id, "orange", rank, 0, 0, [source1, source2, source3], [], false, type);
                } else if (type == "clamp") {
                    let source1 = ele.childNodes[j].getAttribute("source1");
                    let source2 = ele.childNodes[j].getAttribute("source2");
                    let source3 = ele.childNodes[j].getAttribute("source3");
                    let name = "clamp {" + source2 + "} ~ " + "{" + source3 + "}";
                    box = new Box(90, 30, name, "Clamp signal", id, "orange", rank, 0, 0, [source1, source2, source3], [], false, type);
                } else if (type == "min") {
                    let arr = ele.childNodes[j].textContent.split(",");
                    box = new Box(90, 30, "min", "Minimum", id, "orange", rank, 0, 0, arr, [], false, type);
                } else if (type == "max") {
                    let arr = ele.childNodes[j].textContent.split(",");
                    box = new Box(90, 30, "max", "Maximum", id, "orange", rank, 0, 0, arr, [], false, type);
                }
                boxArr.push(box);
            }
        }
        id = num;
        loadConfig(JSON.stringify(obj));
        boxChange();
    }
}