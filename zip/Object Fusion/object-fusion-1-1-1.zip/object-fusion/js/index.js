let language = sessionStorage.getItem("language"); //取中英文,用于刷新保存的值
$(function () {
  $('.container>div:nth-of-type(1)>input').each(function (i, v) {
    $(this).attr("disabled", true);
  });
  checkBoxChange();
});
$('[type=checkbox]').click(function () {
  checkBoxChange();
});
$('[name]').change(function () {
  setConfig();
});
$('[type=text]').bind("input propertychange", function () {
  let value = $(this).val();
  let v = Number(value);
  if (value.indexOf(",") == -1 && value.indexOf(".") == -1) {
    isNaN(v) ? $(this).addClass('red') : $(this).removeClass('red');
  }
  if (value.indexOf(".") != -1) {
    let a = value.split(".");
    if (a.length > 2) {
      $(this).addClass('red')
    } else {
      if (a[0].indexOf(',') == -1) {
        if (a[0] == "" || a[1] == "" || isNaN(Number(a[0])) || isNaN(Number(a[1]))) {
          $(this).addClass('red');
        } else {
          $(this).removeClass('red');
        }
      } else {
        let b = a[0].split(","),
          flag;
        for (let i = 0; i < b.length; i++) {
          if (isNaN(Number(b[i]))) {
            flag = true;
            break;
          }
        }
        if (flag || a[1] == "" || isNaN(Number(a[1]))) {
          $(this).addClass('red');
        } else {
          $(this).removeClass('red');
        }
      }
    }
  }
  if (value.indexOf(",") != -1 && value.indexOf(".") == -1) {
    let a = value.split(","),
      flag = false;
    for (let i = 0; i < a.length; i++) {
      if (isNaN(Number(a[i]))) {
        flag = true;
        break;
      }
    }
    flag ? $(this).addClass('red') : $(this).removeClass('red');
  }
  $(this).attr('value', value);
  setConfig();
});
$('input[type=number]').each(function () {
  checkNumber(this);
})
$('input[type=text]').on({
  'blur': function () {
    let total = 0,
      name = $(this).attr('name'),
      flag = false;
    $('[name=' + name + ']').each(function () {
      let a = $(this).val().replace(/,/g, "");
      if ($(this).val() == "" || $(this).hasClass('red') || a.indexOf("-") != -1) flag = true;
      total += Number(a);
    });
    if (total != 0 && !flag) {
      $('[name=' + name + ']').each(function () {
        let b = $(this).val().replace(/,/g, "");
        let a = accMul((Number(b) / total).toFixed(3), 100);
        $(this).val(Number(b) + "(" + a + "%)");
      });
    }
  },
  'focus': function () {
    let name = $(this).attr('name');
    $('[name=' + name + ']').each(function () {
      let val = $(this).attr('value');
      if (val < 0) val = 0;
      $(this).val(val);
    });
  }
})
function accMul(arg1, arg2) {
  var m = 0,
    s1 = arg1.toString(),
    s2 = arg2.toString();
  try { m += s1.split(".")[1].length } catch (e) { }
  try { m += s2.split(".")[1].length } catch (e) { }
  return Number(s1.replace(".", "")) * Number(s2.replace(".", "")) / Math.pow(10, m)
}
function checkBoxChange() {
  let arr = [];
  $('.container>div:nth-of-type(1)>input').each(function (i, v) {
    if (!$(this).get(0).checked || $(this).attr('disabled') != undefined) {
      arr.push(i);
    }
  });
  $('[name=exist_selected_index]').each(function (i, v) {
    if (arr.indexOf(i) != -1) {
      $(this).attr('disabled', true);
    } else {
      $(this).removeAttr('disabled');
    }
  });
  $('.container>div').each(function (i) {
    let name = $(this).attr('class');
    if (name == undefined || name.indexOf('_') == -1) return;
    let total = 0;
    $(this).find("[name='" + name + "']").each(function (j) {
      if (arr.indexOf(j) != -1) {
        $(this).attr('disabled', true).val('0');
      } else {
        $(this).removeAttr('disabled').removeClass('red');
      }
      let a = ($(this).val()).substr(0, $(this).val().indexOf('('));
      total += Number(a);
    })
    $(this).find("[name='" + name + "']").each(function (j) {
      let val = Number(($(this).val()).substr(0, $(this).val().indexOf('(')));
      let a = total == 0 ? 0 : accMul((val / total).toFixed(3), 100);
      $(this).val(val + "(" + a + "%)").attr('value', val);
    })
  })
  setConfig();
}
function changeOutChannel(obj) {
  let a = $(obj).find("option:selected").text();
  if (a.indexOf(":") != -1) {
    $(obj).val("-1");
  }
}
function loadConfig(config) {
  if (config == null) return;
  biQueryChannelNames("1", "obj-sensor-sample-v6", 12);
  let val = JSON.parse(config);
  $('[name=out_channel]').val(val['out_channel']);
  $('[name=frequency]').val(val['frequency']);
  $('[name=output_mode]').each(function () {
    $(this).val() == val['output_mode'] ? $(this).prop('checked', true) : $(this).prop('checked', false);
  });
  let f = parseFloat(val['fusion_distance']).toFixed(1);
  let s = parseFloat(val['separation_distance']).toFixed(1);
  $('[name=fusion_distance]').val(f);
  $('[name=separation_distance]').val(s);
  let arr1 = val['in_channels'];
  $('[name=in_channels]').each(function (i, v) {
    let n = (arr1.split('0')).length - 1;
    if (n > 1) return;
    if (arr1.indexOf(i.toString()) != -1) $(this).attr('checked', true);
  });

  let arr2 = val['exist_selected_index'].split(",");
  $('[name=exist_selected_index]').each(function (i, v) {
    $(this).val(arr2[i]);
  });
  let arr3 = val['classification_weight'].split(","),
    flag3 = false,
    total3 = 0;
  for (let i = 0; i < arr3.length; i++) {
    if (arr3[i] == "" || isNaN(Number(arr3[i]))) {
      flag3 = true;
      break;
    }
    total3 += Number(arr3[i]);
  }
  $('[name=classification_weight]').each(function (i, v) {
    if (arr3[i] != "" && isNaN(Number(arr3[i]))) {
      $(this).addClass('red');
    } else if (arr3[i] == "") {
      $(this).val(arr3[i]);
    } else if (!flag3 && total3 != 0) {
      let a = accMul((Number(arr3[i]) / total3).toFixed(3), 100);
      $(this).val(arr3[i] + "(" + a + "%)").attr('value', arr3[i]);
    }
  });
  let arr4 = val['position_weight'].split(","),
    flag4 = false,
    total4 = 0;
  for (let i = 0; i < arr4.length; i++) {
    if (arr4[i] == "" || isNaN(Number(arr4[i]))) {
      flag4 = true;
      break;
    }
    total4 += Number(arr4[i]);
  }
  $('[name=position_weight]').each(function (i, v) {
    if (arr4[i] != "" && isNaN(Number(arr4[i]))) {
      $(this).addClass('red');
    } else if (arr4[i] == "") {
      $(this).val(arr4[i]);
    } else if (!flag4 && total4 != 0) {
      let a = accMul((Number(arr4[i]) / total4).toFixed(3), 100);
      $(this).val(arr4[i] + "(" + a + "%)").attr('value', arr4[i]);
    }
  });

  let arr5 = val['velocity_weight'].split(","),
    flag5 = false,
    total5 = 0;
  for (let i = 0; i < arr5.length; i++) {
    if (arr5[i] == "" || isNaN(Number(arr5[i]))) {
      flag5 = true;
      break;
    }
    total5 += Number(arr5[i]);
  }
  $('[name=velocity_weight]').each(function (i, v) {
    if (arr5[i] != "" && isNaN(Number(arr5[i]))) {
      $(this).addClass('red');
    } else if (arr5[i] == "") {
      $(this).val(arr5[i]);
    } else if (!flag5 && total5 != 0) {
      let a = accMul((Number(arr5[i]) / total5).toFixed(3), 100);
      $(this).val(arr5[i] + "(" + a + "%)").attr('value', arr5[i]);
    }
  });

  let arr6 = val['size_weight'].split(","),
    flag6 = false,
    total6 = 0;
  for (let i = 0; i < arr6.length; i++) {
    if (arr6[i] == "" || isNaN(Number(arr6[i]))) {
      flag6 = true;
      break;
    }
    total6 += Number(arr6[i]);
  }
  $('[name=size_weight]').each(function (i, v) {
    if (arr6[i] != "" && isNaN(Number(arr6[i]))) {
      $(this).addClass('red');
    } else if (arr6[i] == "") {
      $(this).val(arr6[i]);
    } else if (!flag6 && total6 != 0) {
      let a = accMul((Number(arr6[i]) / total6).toFixed(3), 100);
      $(this).val(arr6[i] + "(" + a + "%)").attr('value', arr6[i]);
    }
  });
}
function biOnQueriedChannelNames(key, channelNames) {
  biPrint(JSON.stringify(channelNames))
  if (key == "1") {
    let channel = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L"];
    let arr = [],
      i = 0;
    for (let key in channelNames) {
      if (channelNames[key] != '' && channelNames[key] != null) {
        arr.push(i);
      };
      i++;

    }
    $(".container>div:first-of-type>input").each(function (i, v) {
      biPrint(arr.indexOf(i) != -1)
      if (arr.indexOf(i) != -1) $(this).removeAttr('disabled');
    });
    let type = biGetLanguage();
    $('[name=out_channel]').children().each(function (i, v) {
      let value = Number($(this).attr('value'));
      let language = $(this).attr('language');
      if (arr.indexOf(value) != -1) {
        let t = type == 1 ? "Disabled" : "禁用";
        $(this).html(channel[value] + ": " + t);
      } else {
        let t = type == 1 ? en[language] : cn[language];
        $(this).html(t);
      }
    });
    checkBoxChange();
  }
}
function checkNumber(obj) {
  let step = $(obj).attr('step').length - 2;
  let v = Number($(obj).val());
  let value;
  if (!isNaN(v) && $(obj).val() != "") {
    let min = parseFloat($(obj).attr('min')),
      max = parseFloat($(obj).attr('max'));
    v = v < min ? min : v;
    v = v > max ? max : v;
    if (step <= -1) {
      value = v.toFixed(0);
    } else {
      value = v.toFixed(step);
    }
  } else {
    value = $(obj).attr('value');
  }
  $(obj).val(value).attr('value', value)
  return Number(value)
}
function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root ";
  let arrInChannels = [],
    arrExist = [],
    arrClass = [],
    arrPos = [],
    arrVel = [],
    arrSize = [];
  $('[name=in_channels]').each(function (i, v) {
    if ($(this).get(0).checked) arrInChannels.push(i);
  });
  text += "in_channels=\"" + arrInChannels.toString() + "\"";

  $('[name=exist_selected_index]').each(function () {
    arrExist.push($(this).val());
  });
  text += " exist_selected_index=\"" + arrExist.toString() + "\"";

  $('[name=classification_weight]').each(function () {
    let val = $(this).val();
    val = val.replace(",", "");
    let v = val.indexOf("(") == -1 ? val : val.substring(0, val.indexOf("("));
    arrClass.push(v);
  });
  text += " classification_weight=\"" + arrClass.toString() + "\"";

  $('[name=velocity_weight]').each(function () {
    let val = $(this).val();
    val = val.replace(",", "");
    let v = val.indexOf("(") == -1 ? val : val.substring(0, val.indexOf("("));
    arrVel.push(v);
  });
  text += " velocity_weight=\"" + arrVel.toString() + "\"";

  $('[name=position_weight]').each(function () {
    let val = $(this).val();
    val = val.replace(",", "");
    let v = val.indexOf("(") == -1 ? val : val.substring(0, val.indexOf("("));
    arrPos.push(v);
  });
  text += " position_weight=\"" + arrPos.toString() + "\"";
  $('[name=size_weight]').each(function () {
    let val = $(this).val();
    val = val.replace(",", "");
    let v = val.indexOf("(") == -1 ? val : val.substring(0, val.indexOf("("));
    arrSize.push(v);
  });
  text += " size_weight=\"" + arrSize.toString() + "\"";
  text += " out_channel=\"" + $('[name=out_channel]').val() + "\"";
  text += " frequency=\"" + $('[name=frequency]').val() + "\"";
  text += " output_mode=\"" + $('input[name=output_mode]:checked').val() + "\"";
  text += " fusion_distance=\"" + (checkNumber($('[name=fusion_distance]')).toFixed(1)) + "\"";
  text += " separation_distance=\"" + (checkNumber($('[name=separation_distance]')).toFixed(1)) + "\"";
  text += " />";
  biSetModuleConfig("object-fusion.pluginobjectfusion", text);
}
function biOnInitEx(config, moduleConfigs) {
  (610, 716);
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value])
  });
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    console.log(moduleConfigs[key]);
    let countrys = xmlDoc.getElementsByTagName('root');
    let keys = countrys[0].getAttributeNames();
    let obj = new Object();
    for (let i = 0; i < keys.length; i++) {
      obj[keys[i]] = countrys[0].getAttribute(keys[i]);
    };
    loadConfig(JSON.stringify(obj));
  }
}