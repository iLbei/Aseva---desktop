let reg = /^([1-9]|([1-9][0-9])|(1[0-9][0-9])|(2[0-4][0-9])|(25[0-5]))(\.([0-9]|([1-9][0-9])|(1[0-9][0-9])|(2[0-4][0-9])|(25[0-5]))){3}$/;

//正则验证 ip
$('input[type=text]').on("keyup", function () {
  let val = $(this).val();
  if ($(this).attr("name") == "server_ip") {
    reg.test(val) ? $(this).addClass('green').attr("value", $(this).val()).removeClass('red') : $(this).removeClass('green').addClass('red');
  } else if ($(this).attr("name") == "bus_msgid") {
    !isNaN(val) ? $(this).addClass('green').attr("value", $(this).val()).removeClass('red') : $(this).removeClass('green').addClass('red');
  }
  if (!$(this).hasClass('red')) setConfig();
}).blur(function () {
  if ($(this).val() == "" || $(this).hasClass('red')) {
    $(this).val($(this).attr('value')).addClass('green').removeClass('red');
  } else {
    setConfig();
  }
})

//有canvas画图的情况
$('input[type=number]').on({
  'keypress': function (e) {
    if (e.charCode == 101 || e.charCode == 43) {
      return false;
    }
  },
  "input": function () {
    setConfig();
  },
  "change": function () {
    $(this).val(compareVal(this, $(this).val()));
  }
})
//有input type=number 情况下比较大小
function compareVal(obj, val) {
  let step = $(obj).attr('step'),
    v = Number(val),
    min = Number($(obj).attr('min')),
    max = Number($(obj).attr('max'));
  if (isNaN(v)) { v = Number($(obj).attr('value')); }
  v = v < min ? min : v;
  v = v > max ? max : v;
  return v.toFixed(step.length > 2 ? step.length - 2 : 0)
}

/*----------配置读取与存储-----------*/
$(function () {
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value])
  });
})
// 表单内容改变保存配置
$('[name]').change(function () {
  if ($(this).attr("name") != "server_ip") {
    setConfig();
  }
});
//保存配置
function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root>";
  for (let i = 1; i <= 6; i++) {
    $('.container>div').each(function () {
      let tag = $(this).find('p').attr("language") + i;
      text += "<" + tag;
      $(this).find('ul.fixclear:eq(' + (i - 1) + ') [name]').each(function () {
        let name = $(this).attr("name");
        let val = $(this).val();
        let type = $(this).attr('type');
        if (type == 'checkbox') {
          text += " " + name + "=\"" + ($(this).is(':checked') ? "yes" : "no") + "\"";
        } else if (type == "number") {
          text += " " + name + "=\"" + compareVal(this, val) + "\"";
        } else {
          text += " " + name + "=\"" + val + "\"";
        }
      })
      text += "/>";
    })
  }
  text += "</root>";
  console.log(text);
  biSetModuleConfig("data-reinjection.asplugindatareinjection", text);
}
//初始化
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(1135, 679);
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value])
  });
  let arr = [[], [], [], [], [], []];
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");

    let child = xmlDoc.getElementsByTagName('root')[0].childNodes;
    for (let i = 1; i <= 6; i++) {
      for (let count = i * 3 - 3; count < i * 3; count++) {
        let obj = {};
        let keys = child[count].getAttributeNames();
        for (let j in keys) {
          obj[keys[j]] = child[count].getAttribute(keys[j]);
        }
        switch (count % 3) {
          case 0: {
            arr[i - 1]["bus"] = obj;
            break;
          }
          case 1: {
            arr[i - 1]["video"] = obj;
            break;
          }
          case 2: {
            arr[i - 1]["ethernet"] = obj;
            break;
          }
        }
      }
    }
    loadConfig(arr);
  }
}
function loadConfig(arr) {
  if (arr == null) return;
  $('.container>div').each(function () {
    let parentName = $(this).find("p").attr("language");
    $(this).find("[name]").each(function () {
      let i = $(this).parents("ul.fixclear").index() - 1;
      let name = $(this).attr("name");
      let val = arr[i][parentName][name];
      let type = $(this).attr('type');
      if (type == 'checkbox') {
        $(this).prop('checked', val == 'yes' ? true : false);
      } else if (type == "number") {
        $(this).val(compareVal(this, val));
      } else {
        $(this).val(val);
        if (name == "server_ip") {
          reg.test(val) ? $(this).addClass('green').removeClass('red') : $(this).removeClass('green').addClass('red');
        } else if (name == "bus_msgid") {
          !isNaN(val) ? $(this).addClass('green').removeClass('red') : $(this).removeClass('green').addClass('red');
        }
      }
    })

  })
}