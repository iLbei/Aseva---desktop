var reg = /^([1-9]|([1-9][0-9])|(1[0-9][0-9])|(2[0-4][0-9])|(25[0-5]))(\.([0-9]|([1-9][0-9])|(1[0-9][0-9])|(2[0-4][0-9])|(25[0-5]))){3}$/;

$(function () {
  var text = "";
  for (var i = 0; i < 10; i++) {
    text += "<ul class=\"fixclear\"><li><input type=\"checkbox\" name=\"enable\" id=\"enabled_" + i + "\"><label for=\"enabled_" + i + "\" language=\"enable\"></label><input type=\"number\" value=\"42\" name=\"data_offset\" step=\"1\" max=\"1400\" min=\"0\" class=\"right\"><span language=\"data_offset\" class=\"right\"></span></li><li><span language=\"local_ip\"></span><input type=\"text\" name=\"local_ip\" value=\"192.168.0.201\"><input type=\"number\" name=\"local_port_num\" class=\"right\" value=\"5002\" max=\"65535\" min=\"0\" step=\"1\"><span language=\"local_port_num\" class=\"right\"></span></li><li><span language=\"server_ip\"></span><input type=\"text\" name=\"server_ip\" value=\"192.168.1.100\"><input type=\"number\" name=\"server_port_num\" class=\"right\" value=\"5001\" max=\"65535\" min=\"0\" step=\"1\"><span language=\"server_port_num\" class=\"right\"></span></li></ul>";
  }
  $(".container>div.ethernet").append(text);
})

//正则验证 ip
$('.container').on("keyup", "input[type=text]", function () {
  var val = $(this).val();
  if (["server_ip", "local_ip"].includes($(this).attr("name"))) {
    reg.test(val) ? $(this).addClass('green').attr("value", $(this).val()).removeClass('red') : $(this).removeClass('green').addClass('red');
  }
  if (!$(this).hasClass('red')) setConfig();
}).on("blur", "input[type=text]", function () {
  if ($(this).val() == "" || $(this).hasClass('red')) {
    $(this).val($(this).attr('value')).addClass('green').removeClass('red');
  } else {
    setConfig();
  }
})

$('.container').on("change", "input[type=number]", function () {
  $(this).val(compareVal(this, $(this).val()));
}).on('input', "input[type=number]", function (e) {
  if (e.which == undefined) {
    var step = $(this).attr("step").length - 2;
    var val = Number($(this).val());
    $(this).val(step > 0 ? val.toFixed(step) : val);
  }
  setConfig();
}).on('keypress', "input[type=number]", function (e) {
  if (!(e.charCode >= 48 && e.charCode <= 57) && !(e.charCode == 45 || e.charCode == 46)) return false;
})

//有input type=number 情况下比较大小
function compareVal(obj, val) {
  var step = $(obj).attr('step').length > 2 ? $(obj).attr('step').length - 2 : 0,
    v = Number(val),
    newVal = 0;
  if (isNaN(v)) {
    newVal = Number($(obj).attr('value'));
  } else {
    var min = Number($(obj).attr('min')),
      max = Number($(obj).attr('max'));
    v = v < min ? min : v;
    v = v > max ? max : v;
    if (step > 0) {
      newVal = Math.round(Math.abs(v) * Math.pow(10, step)) / Math.pow(10, step);
      if (v < 0) newVal = -newVal;
    } else {
      newVal = Math.floor(v);
    }
  }
  return step > 0 ? newVal.toFixed(step) : newVal;
}

/*----------配置读取与存储-----------*/
// 表单内容改变保存配置
$('.container').on("change", "[name]", function () {
  if (!["server_ip", "local_ip"].includes($(this).attr("name"))) {
    setConfig();
  }
});
//保存配置
function setConfig() {
  var text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root>";
  $('.container>.ethernet>ul').each(function (i) {
    text += "<ethernet" + (i + 1) + " ";
    $(this).find('[name]').each(function () {
      var name = $(this).attr("name");
      var val = $(this).val();
      var type = $(this).attr('type');
      if (type == 'checkbox') {
        text += " " + name + "=\"" + ($(this).is(':checked') ? "yes" : "no") + "\"";
      } else if (type == "number") {
        text += " " + name + "=\"" + compareVal(this, val) + "\"";
      } else {
        text += " " + name + "=\"" + val + "\"";
      }
    })
    text += "/>";
  })
  text += "</root>";
  biSetModuleConfig("lidar-transmitter.aspluginlidartransmitter", text);
}
//初始化
function biOnInitEx(config, moduleConfigs) {
  $('[language]').each(function () {
    var value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value])
  });
  for (var key in moduleConfigs) {
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    var child = xmlDoc.getElementsByTagName('root')[0].childNodes;
    var arr = [];
    for (var i = 0; i < child.length; i++) {
      var obj = {};
      var keys = child[i].attributes;
      for (var j in keys) {
        obj[keys[j].nodeName] = keys[j].nodeValue;
      }
      arr.push(obj);
    }
    loadConfig(arr);
  }
}

function loadConfig(arr) {
  if (arr == null) return;
  $('.container>.ethernet>ul').each(function (i) {
    $(this).find("[name]").each(function () {
      var name = $(this).attr("name");
      var val = arr[i][name];
      var type = $(this).attr('type');
      if (type == 'checkbox') {
        $(this).prop('checked', val == 'yes' ? true : false);
      } else if (type == "number") {
        $(this).val(compareVal(this, val));
      } else {
        $(this).val(val);
        if (["server_ip", "local_ip"].includes(name)) {
          reg.test(val) ? $(this).addClass('green').removeClass('red') : $(this).removeClass('green').addClass('red');
        }
      }
    })

  })
}