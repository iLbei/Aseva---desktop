var not_config = "",
  dialogConfig = [],
  lanes = [
    [],
    [],
    [],
    [],
    [],
    [],
    [],
    []
  ],
  color_sv = [
    [],
    [],
    [],
    [],
    [],
    [],
    [],
    []
  ],
  class_sv = [
    [],
    [],
    [],
    [],
    [],
    [],
    [],
    []
  ];
$('.alias').click(function () {
  $(this).hide();
  $(this).next().show();
  index = $(this).parent().parent().parent().index();
  $(this).next().val($(this).text()).select();
});

$('[name=alias]').blur(function () {
  $(this).hide();
  $(this).prev().show();
  if ($(this).val().trim().length == 0) return;
  $(this).prev().text($(this).val());
  changeVal();
  setConfig();
})

$("body").keydown(function (e) {
  var i = $(".white").index() + 1;
  if (e.keyCode == 13) {
    $(".c" + i).find("[name=alias]").hide();
    $(".c" + i).find(".alias").show();
    if ($(".c" + i).find("[name=alias]").val().trim().length == 0) return;
    $(".c" + i).find(".alias").val($(".c" + i).find("[name=alias]").val());
    setConfig();
  }
})
$('.top button').click(function () {
  $(this).addClass('white').siblings().removeClass('white');
  var num = $(this).index();
  $('.container>.content>div:eq(' + num + ')').show().siblings().hide();
  changeVal();
  setConfig();
});

/**
 * 画多边形
 * @param {} arr 点
 * @param {*} color 颜色 
 * @param {*} ctx 上下文
 */
function drawPolygon(arr, color, ctx) {
  ctx.beginPath();
  ctx.moveTo(arr[0].x, arr[0].y);
  ctx.lineTo(arr[1].x, arr[1].y);
  ctx.lineTo(arr[2].x, arr[2].y);
  ctx.strokeStyle = color;
  ctx.closePath();
  ctx.stroke();
}

function draw(obj, scale, w, l) {
  var width = 15 * w,
    length = 15.2 * l;
  var canvas = $(obj).find('.canvas')[0];
  var ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  var p1 = new BIPoint(canvas.width / 2, 0);
  var p2 = new BIPoint(canvas.width / 2, canvas.height);
  var p3 = new BIPoint(0, 48);
  var p4 = new BIPoint(canvas.width, 48);
  drawLine(p1, p2, 1, "#e9e9e9", ctx);
  drawLine(p3, p4, 1, "#e9e9e9", ctx);
  var size = new BISize(width * scale, length * scale);
  var p5 = new BIPoint(canvas.width / 2 - width / 2 * scale, 48);
  drawRect(p5, size, "black", ctx);
  var p6 = new BIPoint(canvas.width / 2, 48);
  var p7 = new BIPoint(canvas.width / 2 - width / 2 * scale, 48 + length / 4 * scale);
  var p8 = new BIPoint(canvas.width / 2 + width / 2 * scale, 48 + length / 4 * scale);
  var arr = [p6, p7, p8];
  drawPolygon(arr, "black", ctx);
  var x = $(obj).find('.coor').find('[name=camera_offset_x]').val();
  var y = $(obj).find('.coor').find('[name=camera_offset_y]').val();
  var yaw = $(obj).find('.coor').find('[name=camera_offset_yaw]').val();
  p8 = new BIPoint(canvas.width / 2 - y * 15 * scale, 48 - (24 + x * 24 / 1.5) * scale);
  var p9 = new BIPoint(canvas.width / 2 - y * 15 * scale, 48 - x * 24 / 1.5 * scale);
  var p10 = new BIPoint(canvas.width / 2 - (15 + y * 15) * scale, 48 - x * 24 / 1.5 * scale);
  ctx.save();
  ctx.translate(p9.x, p9.y);
  ctx.rotate(Math.PI / 180 * (0 - yaw));
  p1 = new BIPoint(p8.x - p9.x, p8.y - p9.y);
  p2 = new BIPoint(p9.x - p9.x, p9.y - p9.y);
  p3 = new BIPoint(p10.x - p9.x, p10.y - p9.y);
  ctx.beginPath();
  ctx.moveTo(p1.x, p1.y);
  ctx.lineTo(p2.x, p2.y);
  ctx.lineTo(p3.x, p3.y);
  ctx.strokeStyle = "#32cd32";
  ctx.stroke();
  ctx.restore();
}
$('[name]').change(function () {
  if ($(this).attr("name") != "alias") {
    changeVal();
    setConfig();
    restore();
  }
});

//正则判断是否是数字
function NumberCheck(num) {
  var re = /^\d*\.{0,1}\d*$/;
  if (num == "") return null;
  return re.exec(num) != null ? num : null;
}
//检查文本框的值
function checkTextValue(obj) {
  var str = $(obj).val();
  if (str.indexOf(',') != -1) {
    var flag = false;
    var arr = str.split(","),
      newArr = [];;
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] == "") {
        flag = true;
        break;
      }
      var v = Number(arr[i]);
      if (arr[i] != "") {
        if (isNaN(v)) {
          flag = true;
          break;
        }
      }
      newArr.push(v);
    }
    if (flag) {
      $(obj).addClass('red').removeClass('green');
    } else {
      $(obj).addClass('green').attr('value', newArr.join());
    }
  } else {
    var v = Number(str);
    if (!isNaN(v) && str != "") { //green
      $(obj).addClass('green').attr('value', v);
    } else if (str != "") { //red
      $(obj).addClass('red').removeClass('green');
    } else if (str == "" && $(obj).hasClass('bar')) {
      $(obj).attr('value', "");
    }
  }

}
$('[type=text]').bind("input propertychange", function () {
  if ($(this).attr('name') == "alias") return;
  checkTextValue($(this));
  changeVal();
  setConfig();
}).blur(function () {
  if ($(this).attr('name') == "alias") return;
  if ($(this).hasClass('green')) {
    var str = $(this).val();
    if (str.indexOf(",") != -1) {
      var arr = str.split(','),
        newArr = [];
      for (var i = 0; i < arr.length; i++) {
        var v = Number(arr[i]);
        newArr.push(v);
      }
      $(this).val(newArr.join()).attr('value', newArr.join());
    } else {
      if (str != "") {
        var v = Number(str);
        $(this).val(v).attr('value', v);
      } else {
        var v = $(this).attr('value');
        $(this).val(v).attr('value', v);
      }
    }
  } else if ($(this).hasClass('red')) {
    var v = $(this).attr('value');
    $(this).val(v).removeClass('red').addClass('green');
  }
  changeVal();
  setConfig();
});

function changeInput(obj) {
  var max = Number($(obj).attr('max'));
  var min = Number($(obj).attr('min'));
  var v = $(obj).val();
  if (v < min || v > max) return;
  var par = $(obj).parent().parent().parent().parent().parent().parent().parent();
  var scale = $(par).find('.scale_change').attr("scale") == "large" ? 1 : 0.3;
  draw(par, scale, subject_width, subject_length);
  changeVal();
  setConfig();
}

function changeYawInput(obj) {
  var max = Number($(obj).attr('max'));
  var min = Number($(obj).attr('min'));
  var v = $(obj).val();
  if (v < min || v > max) return;
  var par = $(obj).parent().parent().parent().parent().parent().parent();
  var scale = $(par).find('.scale_change').attr("scale") == "large" ? 1 : 0.3;
  draw(par, scale, subject_width, subject_length);
  changeVal();
  setConfig();
  restore();
}

function change(obj) {
  var par = $(obj).parent().parent().parent().parent().parent().parent().parent();
  var scale = $(par).find('.scale_change').attr("scale") == "large" ? 1 : 0.3;
  draw(par, scale, subject_width, subject_length);
  changeVal();
  setConfig();
  restore();
}

function changeYaw(obj) {
  var par = $(obj).parent().parent().parent().parent().parent().parent();
  var scale = $(par).find('.scale_change').attr("scale") == "large" ? 1 : 0.3;
  draw(par, scale, subject_width, subject_length);
  changeVal();
  setConfig();
  restore();
}

function restore() {
  $('.container>.content>div').each(function () {
    if (!$(this).is(':hidden')) {
      if (!$(this).find('[name=alias]').is(':hidden')) {
        $(this).find('[name=alias]').hide();
        $(this).find('.alias').show();
        $(this).find('.alias').text($(this).find('[name=alias]').val());
      }
    }
  });
}
var index = -1;


function compareVal(obj, val) {
  var step = $(obj).attr('step').length > 2 ? $(obj).attr('step').length - 2 : 0,
    v = Number(val);
  if (isNaN(val) || !Boolean(val)) {
    newVal = Number($(obj).attr('value'));
  } else {
    var v = Number(val);
    var min = Number($(obj).attr('min')),
      max = Number($(obj).attr('max'));
    v = v < min ? min : v;
    v = v > max ? max : v;
    if (step > 0) {
      newVal = Math.round((Math.abs(v) * Math.pow(10, step)).toFixed(1)) / Math.pow(10, step);
      if (v < 0) newVal = -newVal;
    } else {
      newVal = Math.floor(v);
    }
  }
  return step > 0 ? newVal.toFixed(step) : newVal;
}

//车子变大变小
function scaleCanvas(obj) {
  var type = $(obj).attr("scale");
  var lang = biGetLanguage();
  var text = "";
  var scale = 0;
  if (type == "large") {
    text = lang == 1 ? "Scale: Large" : "比例: 大范围";
    $(obj).attr("scale", "small");
    scale = 0.3;
  } else {
    text = lang == 1 ? "Scale: Small" : "比例: 小范围";
    $(obj).attr("scale", "large");
    scale = 1;
  }
  $(obj).text(text);
  draw($(obj).parent().parent().parent(), scale, subject_width, subject_length);
}

function openChildDialog(obj) {
  var name = $(obj).prev().attr("language");
  var i = $(obj).parent().parent().parent().parent().parent().index();
  var title = "";
  switch (name) {
    case "line_type_v": {
      title = biGetLanguage() == 1 ? "Other line types" : "其他类型";
      biOpenChildDialog("lane-sensor-by-can.line_type.html", title, new BISize(405, 160), i);
      break;
    }
    case "line_color_v": {
      title = biGetLanguage() == 1 ? "Other color types" : "其他颜色";
      biOpenChildDialog("lane-sensor-by-can.line_color.html", title, new BISize(330, 123), i);
      break;
    }
  }
}

function headMode(obj) {
  $(obj).parent().parent().parent().parent().parent().parent().next().find('.box').each(function () {
    var type = biGetLanguage();
    var text = $(obj).val() == "Clothoid" ? (type == 1 ? "Heading Angle [rad]:" : "航向角[rad]") : (type == 1 ? "First order parameter:" : "一阶参数");
    $(this).children('.right').children('.first').text(text);
  });
}

function curvMode(obj) {
  $(obj).parent().parent().parent().parent().parent().parent().next().find('.box').each(function () {
    var type = biGetLanguage();
    var text = $(obj).val() == "Clothoid" ? (type == 1 ? "Curvature [1/m]:" : "曲率[1/m]") : (type == 1 ? "Second order parameter:" : "二阶参数");
    $(this).children('.right').children('.second').text(text);
  });
}

function diffMode(obj) {
  $(obj).parent().parent().parent().parent().parent().parent().next().find('.box').each(function () {
    var type = biGetLanguage();
    var text = $(obj).val() == "Clothoid" ? (type == 1 ? "Differential of Curvature [1/m2]:" : "曲率微分[1/m2]") : (type == 1 ? "Third order parameter:" : "三阶参数");
    $(this).children('.right').children('.third').text(text);
  });
}
var indexFile = -1;
//导入
function importFile(obj) {
  var filter = {
    ".asmc": "ASEva Module Configuration (*.asmc)"
  };
  indexFile = $(obj).parent().parent().parent().parent().index();
  biSelectPath("OpenFilePath", BISelectPathType.OpenFile, filter);
}

function biOnSelectedPath(key, path) {
  if (path == null) {
    return;
  }

  if (key == "CreateFilePath") {
    var text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root ";
    for (var j in dialogConfig[indexFile]) {
      if (j != "eArr") {
        text += j + "=\"" + dialogConfig[indexFile][j] + "\" ";
      };
    }
    text += ">"
    for (var j in dialogConfig[indexFile]["eArr"]) {
      text += "<" + dialogConfig[indexFile]["eArr"][j]["nodeName"] + " ";
      for (var k in dialogConfig[indexFile]["eArr"][j]) {
        if (k != "nodeName") text += k + "=\"" + dialogConfig[indexFile]["eArr"][j][k] + "\" ";
      }
      text += "/>"
    }
    text += "</root>";
    var xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root type=\"lane-sensor-config-v2\">";
    xml += getEncode64(text);
    xml += "</root>";
    biWriteFileText(path, xml);
  } else if (key == "OpenFilePath") {
    biQueryFileText(path);
  }
}

function biOnQueriedFileText(textInfo, path) {
  var parser = new DOMParser();
  var xmlDoc = parser.parseFromString(textInfo, "text/xml");
  var countrys = xmlDoc.getElementsByTagName('root');
  var type = $(countrys).attr('type');
  if (type != "lane-sensor-config-v2") {
    var txt = language == 1 ? "The file is not for lane sensor configuration" : "该文件不是用于车道传感器配置的";
    var title = language == 1 ? "Error" : "错误";
    biAlert(txt, title);
    return
  }
  var text = getDecode(countrys[0].textContent);
  if (textInfo != "") {
    parser = new DOMParser();
    xmlDoc = parser.parseFromString(text, "text/xml");
    countrys = xmlDoc.getElementsByTagName('root');
    var o = new Object();
    var oKeys = countrys[0].attributes;
    for (var i = 0; i < oKeys.length; i++) {
      o[oKeys[i].nodeName] = oKeys[i].nodeValue;
    }
    var arr = [];
    class_sv[indexFile] = [], color_sv[indexFile] = [], lanes[indexFile] = [];
    for (var i = 0; i < countrys[0].childNodes.length; i++) {
      var eKeys = countrys[0].childNodes[i].attributes;
      var nodeName = countrys[0].childNodes[i].nodeName;
      var eObj = new Object();
      for (var n = 0; n < eKeys.length; n++) {
        eObj["nodeName"] = nodeName;
        eObj[eKeys[n].nodeName] = eKeys[n].nodeValue;
      }
      if (nodeName == "class_sv") {
        class_sv[indexFile].push(eObj);
      } else if (nodeName == "color_sv") {
        color_sv[indexFile].push(eObj);
      } else if (nodeName == "line") {
        lanes[indexFile].push(eObj);
      }
    }
    o["eArr"] = arr;
    var obj = $('.container>.content>div:eq(' + indexFile + ')');
    loadSingle(obj, o, indexFile);
    $('.container>.content>div:eq(' + indexFile + ')').find('.color').text(otherColor.join(":"));
    $('.container>.content>div:eq(' + indexFile + ')').find('.type').text(otherType.join(":"));
  }
  changeVal();
  setConfig();
}

//导出
function exportFile(obj) {
  var filter = {
    ".asmc": "ASEva Module Configuration (*.asmc)"
  };
  indexFile = $(obj).parent().parent().parent().parent().index();
  biSelectPath("CreateFilePath", BISelectPathType.CreateFile, filter);
}
/**
 * 画线-两点一线
 * @param {*} p1 点
 * @param {*} p2 点
 * @param {*} width 线宽度
 * @param {*} color 颜色
 * @param {*} ctx 画图上下文
 */
function drawLine(p1, p2, width, color, ctx) {
  ctx.beginPath();
  ctx.lineWidth = width;
  ctx.moveTo(p1.x, p1.y);
  ctx.lineTo(p2.x, p2.y);
  ctx.closePath();
  ctx.strokeStyle = color;
  ctx.stroke();
}
/**
 * 画矩形
 * @param {*} p 顶点
 * @param {*} s 大小
 * @param {*} color 颜色
 * @param {*} ctx 画图上下文
 */
function drawRect(p, s, color, ctx) {
  ctx.beginPath();
  ctx.rect(p.x, p.y, s.width, s.height);
  ctx.strokeStyle = color;
  ctx.stroke();
}
/**
 * 
 * @param {*} origin 原点
 * @param {*} color 颜色
 * @param {*} ctx 画图上下文
 * @param {*} radius 半径
 */
function drawArc(origin, color, ctx, radius, e, s) {
  ctx.beginPath();
  ctx.lineWidth = 1;
  ctx.strokeStyle = color;
  ctx.arc(origin.x, origin.y, radius, e, s, false);
  ctx.stroke();
}
/**
 * 画多边形
 * @param {} arr 点
 * @param {*} color 颜色 
 * @param {*} ctx 上下文
 */
function drawPolygon(arr, color, ctx) {
  ctx.beginPath();
  ctx.moveTo(arr[0].x, arr[0].y);
  ctx.lineTo(arr[1].x, arr[1].y);
  ctx.lineTo(arr[2].x, arr[2].y);
  ctx.strokeStyle = color;
  ctx.closePath();
  ctx.stroke();
}


function addBox(obj) {
  $box = $('.box').clone(true);
  $(obj).parent().next().append($box[0]);
  changeVal();
  setConfig();
}

function remove(obj) {
  $(obj).parent().parent().parent().remove();
  changeVal();
  setConfig();
}

function textChange(obj) {
  var val = $(obj).val().replace(/\s+/g, "");
  if (NumberCheck(val) != null) {
    $(obj).attr('val', val);
  }
}
//选择报文
var bus = undefined;

function selectBus(obj) {
  var originID = $(obj).text().lastIndexOf('(') != -1 ? null : $(obj).attr('val');
  bus = obj;
  restore();
  biSelectBusMessage("TargetMessage", originID);
}

function biOnSelectedBusMessage(key, info) {
  var type = biGetLanguage();
  if (key == "TargetMessage") {
    if (info == null) {
      $(bus).removeAttr("val");
      $(bus).text(not_config);
      $(bus).css("color", "red");
    } else {
      $(bus).attr("val", info.id);
      $(bus).text(info.name);
      $(bus).css("color", "#1e7b1e");
    }
  }
  changeVal();
  setConfig();
}

//选择信号
var signal = undefined; //选择的当前元素

function selectSignal(obj, flag) {
  if ($(obj).css("color").indexOf("169") != -1) return;
  var originID = null;
  if ($(obj).text().lastIndexOf('(') == -1) originID = $(obj).attr('val');
  var scale = 1;
  var scaleName = $(obj).attr('type');
  if (scaleName != undefined) {
    scale = $(obj).attr(scaleName);
  }
  signal = obj;
  restore();
  var key = "TargetSignal";
  var unit = $(obj).attr("unit");
  biSelectSignal(key, originID, false, null, flag, scale, "[" + unit + "]");
}

function biOnSelectedSignal(key, valueInfo, signBitInfo, scale) {
  if (valueInfo == null) {
    var type = $(signal).attr("type");
    $(signal).text(not_config);
    $(signal).parent().removeAttr("title");
    $(signal).removeAttr('val');
    $(signal).removeClass('green');
    $(signal).attr(type, "null");
  } else if (valueInfo.typeName == undefined) {
    $(signal).addClass('red').removeClass('green').text(valueInfo.id);
  } else {
    var type = $(signal).attr("type");
    var arr = valueInfo.id.split(":");
    $(signal).text(valueInfo.signalName);
    $(signal).attr("val", valueInfo.id);
    $(signal).parent().attr("title", arr[1] + ":" + arr[2]);
    if (type != undefined) {
      $(signal).attr(type, ["null", ""].includes(scale) ? 1 : scale);
    }
    $(signal).addClass('green');
  }
  changeVal();
  setConfig();
}

function biOnQueriedBusMessageInfo(key, info) {
  var arr = key.split(":");
  var a = $('.container>.content>div:eq(' + Number(arr[1]) + ')').find('.sampling_msg_id');
  if (arr[0] == "TargetMessage") {
    if (info == null) {
      $(a).text($(a).attr('val'));
      $(a).css("color", "red");
    } else {
      $(a).attr("val", info.id);
      $(a).text(info.name);
      $(a).css("color", "#1e7b1e");
    }
  }
  changeVal();
  setConfig();
}
/**
 * 加载配置
 */
function loadConfig(arr) {
  if (arr == null) return;
  $('.container>.content>div').each(function (i, v) {
    var obj = arr[i];
    loadSingle($(this), obj, i);
  });
  //获取本车width,length
  biQueryGlobalVariable("Subject.VehicleWidth", null);
  biQueryGlobalVariable("Subject.VehicleLength", null);
}
var idNameArr = [];

var subject_width = -1,
  subject_length = -1;


function loadSingle(div, obj, i) {
  $(div).find("[language=lane_line]").siblings(".content").children("div:not(:first-child)").remove();
  $(div).find('.alias').text(obj['alias'].trim().length == 0 ? "Lane Sensor" : obj['alias']);
  $(div).children('.left').find('[name]').each(function () {
    var value = $(this).attr('name');
    var type = $(this).attr('type');
    if (type == "checkbox") {
      if (obj[value] == "yes") $(this).prop('checked', true);
    } else if (type == "number") {
      $(this).val(compareVal(this, obj[value]));
    } else {
      $(this).val(obj[value]);
    }
  });
  headMode($(div).find('[name=heading_mode]'));
  curvMode($(div).find('[name=curvature_mode]'));
  diffMode($(div).find('[name=curvature_diff_mode]'));
  var originID = obj["sampling_msg_id"] == "null" ? null : obj["sampling_msg_id"];
  if (originID != null) {
    $(div).find('.sampling_msg_id').attr('val', originID);
    biQueryBusMessageInfo("TargetMessage:" + i, originID);
  }
  if (class_sv[i].length == 0) {
    $(div).find('[name=solid]').val("");
    $(div).find('[name=dash]').val("");
  } else {
    $(div).find('[name=solid]').val((class_sv[i][1]["values"] == "null" ? "" : class_sv[i][1]["values"]));
    $(div).find('[name=dash]').val((class_sv[i][0]["values"] == "null" ? "" : class_sv[i][0]["values"]));
  }
  if (color_sv[i].length == 0) {
    $(div).find('[name=white]').val("");
    $(div).find('[name=yellow]').val("");
  } else {
    $(div).find('[name=white]').val((color_sv[i][0]["values"] == "null" ? "" : color_sv[i][0]["values"]));
    $(div).find('[name=yellow]').val((color_sv[i][1]["values"] == "null" ? "" : color_sv[i][1]["values"]));
  }
  var class_p = "",
    color_p = "";
  for (var j = 2; j < class_sv[i].length; j++) {
    class_p += class_sv[i][j]["values"] + ":";
  }
  $(div).children('.bottom').children('.type').text(class_p);
  for (var j = 2; j < color_sv[i].length; j++) {
    color_p += color_sv[i][j]["values"] + ":";
  }
  $(div).children('.bottom').children('.color').text(color_p);
  for (var n = 0; n < lanes[i].length; n++) {
    var line = lanes[i][n];
    $box = $(div).children('.right').children('.content').children('div:first-of-type').clone(true);
    $box.find('a').each(function () {
      var className = $(this).attr('signalName');
      if (Boolean(line[className]) && className != "right" && line[className] != "null" && line[className] != "undefined") {
        $(this).attr('val', line[className]);
        // var arr = line[className].split(":");
        // if (arr[0].indexOf(".dbc") != -1) {
        biQuerySignalInfo(i + "|" + n + "|" + className, line[className]);
        // } else {
        //   $(this).text(arr[arr.length - 1]);
        //   $(this).addClass('green');
        //   $(this).parent().attr("title", arr[1] + ":" + arr[2]);
        // }
        var tt = $(this).attr('type');
        if (tt != undefined) $(this).attr(tt, line[tt]);
      }
    });
    $box.find("[name=detected_values]").attr("value", line["detected_values"]).val(line["detected_values"]);
    $(div).children('.right').children('.content').append($box[0]);
  }
  checkRearFront($(div).find('[name=rear_bound]'), $(div).find('[name=front_bound]'));
}

function biOnQueriedGlobalVariable(id, value) {
  if (id == "Subject.VehicleWidth") subject_width = Number(value);
  if (id == "Subject.VehicleLength") subject_length = Number(value);
  if (subject_length != -1 && subject_width != -1) {
    $('.container>.content>div').each(function (i, v) {
      draw($(this), 1, subject_width, subject_length);
    });
  }
}

//获取总线协议文件绑定的通道
function biOnQueriedBusProtocolFileChannel(busFileProtocolID, busChannel) {

}

function biOnQueriedSignalInfo(key, signalID) {
  if (key.indexOf("|") != -1) {
    if (signalID != null) {
      var arr = key.split("|");
      var content = $('.container>.content>div:eq(' + arr[0] + ')').children('.right').children('.content');
      var n = parseInt(arr[1]) + 1;
      $(content).children('div:eq(' + n + ')').find('.' + arr[2]).text(signalID.signalName).
      addClass('green');
      $(content).children('div:eq(' + n + ')').find('.' + arr[2]).parent().attr("title", signalID.typeName + ":" + signalID.signalName);
    } else {
      var arr = key.split("|");
      var content = $('.container>.content>div:eq(' + arr[0] + ')').children('.right').children('.content');
      var n = parseInt(arr[1]) + 1;
      var val = $(content).children('div:eq(' + n + ')').find('.' + arr[2]).attr("val");
      $(content).children('div:eq(' + n + ')').find('.' + arr[2]).text(val).addClass('red').attr("title", val);
    }
  }
}

function checkRearFront(obj1, obj2) {
  var b2 = Number($(obj2).val()),
    b1 = Number($(obj1).val());
  if (b2 > b1) {
    $(obj2).prev().removeClass('red');
    $(obj1).prev().removeClass('red');
  } else {
    $(obj2).prev().addClass('red');
    $(obj1).prev().addClass('red');
  }
  changeVal();
  setConfig();
}

function checkRear(obj) {
  var f = $(obj).parent().next().find('[name=front_bound]');
  checkRearFront(obj, f);
}

function checkFront(obj) {
  var r = $(obj).parent().prev().find('[name=rear_bound]');
  checkRearFront(r, obj);
}

function changeVal() {
  var i = $(".white").index();
  dialogConfig[i] = {
    "eArr": []
  };
  $(".c" + (i + 1) + ">.left [name]").each(function () {
    var name = $(this).attr('name');
    if (!["solid", "dash", "white", "yellow"].includes[name]) {
      var val = $(this).val();
      var type = $(this).attr('type');
      if (type == 'checkbox') {
        val = $(this).is(':checked') ? "yes" : "no";
      } else if (type == "number") {
        val = compareVal(this, val);
      } else if ($(this).is("a")) {
        if ($(this).hasClass("sampling_msg_id")) {
          val = Boolean($(this).attr('val')) ? $(this).attr('val') : "null";
        }
      } else if (name == "alias") {
        val = $(this).prev().text();
      }
      dialogConfig[i][name] = val;
    }
  })
  lanes[i] = [];
  $(".c" + (i + 1) + ">.right .content>.box:not(:first-child)").each(function () {
    var lane = {};
    $(this).find('a').each(function () {
      var className = $(this).attr('signalName');
      if (className != undefined) {
        var val = $(this).attr('val') == undefined ? null : $(this).attr('val');
        if (className != "right") lane[className] = val;
        var type = $(this).attr('type');
        if (type != undefined) {
          lane[type] = $(this).attr(type);
        }
      }
    });
    lane["detected_values"] = $(this).find('[name=detected_values]').attr('value');
    lane["nodeName"] = "line";
    lanes[i].push(lane);
  })

  for (var j in lanes[i]) {
    dialogConfig[i]["eArr"].push(lanes[i][j])
  }
  for (var j in color_sv[i]) {
    if (color_sv[i][j]["type"] == 2) {
      color_sv[i][j]["values"] = $(".container>.content>div").eq(i).find("[name=white]").val()
    } else if (color_sv[i][j]["type"] == 3) {
      color_sv[i][j]["values"] = $(".container>.content>div").eq(i).find("[name=yellow]").val()
    }
    dialogConfig[i]["eArr"].push(color_sv[i][j]);
  }
  for (var j in class_sv[i]) {
    if (class_sv[i][j]["type"] == 2) {
      class_sv[i][j]["values"] = $(".container>.content>div").eq(i).find("[name=dash]").val()
    } else if (class_sv[i][j]["type"] == 3) {
      class_sv[i][j]["values"] = $(".container>.content>div").eq(i).find("[name=solid]").val()
    }
    dialogConfig[i]["eArr"].push(class_sv[i][j])
  }
}
/**
 * 写配置
 */
function setConfig() {
  var text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root>";
  for (var i in dialogConfig) {
    text += "<c" + (Number(i) + 1) + " ";
    for (var j in dialogConfig[i]) {
      if (j != "eArr") {
        text += j + "=\"" + dialogConfig[i][j] + "\" ";
      };
    }
    text += ">"
    for (var j in dialogConfig[i]["eArr"]) {
      text += "<" + dialogConfig[i]["eArr"][j]["nodeName"] + " ";
      for (var k in dialogConfig[i]["eArr"][j]) {
        if (k != "nodeName") text += k + "=\"" + dialogConfig[i]["eArr"][j][k] + "\" ";
      }
      text += "/>"
    }
    text += "</c" + (Number(i) + 1) + ">";
  }
  text += "</root>";
  biSetModuleConfig("lane-sensor-by-can.pluginsensor", text);
}

function biOnInitEx(config, moduleConfigs) {
  if (biGetLanguage() == 1) { //英文
    $('[language]').each(function () {
      var value = $(this).attr('language');
      $(this).text(en[value]);
      not_config = "<Not Configured>";
    });
  } else { //中文
    $('[language]').each(function () {
      var value = $(this).attr('language');
      $(this).text(cn[value]);
      not_config = "<未配置>";
    });
  }
  $(".c1").show();
  for (var key in moduleConfigs) {
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    var countrys = xmlDoc.getElementsByTagName('root');
    for (var i = 0; i < countrys[0].childNodes.length; i++) {
      var nodeName = countrys[0].childNodes[i].nodeName;
      var conu = xmlDoc.getElementsByTagName(nodeName);
      var keyss = conu[0].attributes;
      var obj = {};
      for (var j = 0; j < keyss.length; j++) {
        obj[keyss[j].nodeName] = keyss[j].nodeValue;
      }
      for (var k = 0; k < conu[0].childNodes.length; k++) {
        var eKeys = conu[0].childNodes[k].attributes;
        var nodeName = conu[0].childNodes[k].nodeName;
        var eObj = new Object();
        for (var n = 0; n < eKeys.length; n++) {
          eObj["nodeName"] = nodeName;
          eObj[eKeys[n].nodeName] = eKeys[n].nodeValue;
        }
        if (nodeName == "class_sv") {
          class_sv[i].push(eObj);
        } else if (nodeName == "color_sv") {
          color_sv[i].push(eObj);
        } else {
          lanes[i].push(eObj);
        }
      }
      if (class_sv[i].length == 0) {
        class_sv[i].push({
          nodeName: "class_sv",
          type: "2",
          values: "null"
        }, {
          nodeName: "class_sv",
          type: "3",
          values: "null"
        })
      }
      if (color_sv[i].length == 0) {
        color_sv[i].push({
          nodeName: "color_sv",
          type: "2",
          values: "null"
        }, {
          nodeName: "color_sv",
          type: "3",
          values: "null"
        })
      }
      obj["eArr"] = [];
      dialogConfig.push(obj);
    }
  }
  loadConfig(dialogConfig);
}

function biOnClosedChildDialog() {
  var color = JSON.parse(biGetLocalVariable("lane_sensor_by_can_color"));
  var classConfig = JSON.parse(biGetLocalVariable("lane_sensor_by_can_class"));
  if (Boolean(color)) {
    color_sv[$(".white").index()] = color;
  } else if (Boolean(classConfig)) {
    class_sv[$(".white").index()] = classConfig;
  };
  changeVal();
  setConfig();
}

$('input[type=number]').on({
  "change": function () {
    $(this).val(compareVal(this, $(this).val()));
  },
  'input': function (e) {
    if (e.which == undefined) {
      var step = $(this).attr("step").length - 2;
      var val = Number($(this).val());
      $(this).val(step > 0 ? val.toFixed(step) : val);
    }
    changeVal();
    setConfig();
  },
  'keypress': function (e) {
    if (!(e.charCode >= 48 && e.charCode <= 57) && !(e.charCode == 45 || e.charCode == 46)) {
      return false;
    }
  }
})