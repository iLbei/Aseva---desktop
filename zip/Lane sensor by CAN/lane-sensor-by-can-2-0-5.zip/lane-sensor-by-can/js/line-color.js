var dialogConfig = [], colorArr = [], dialogIndex = 0;
//正则判断是否是数字
function NumberCheck(num) {
  var re = /^\d*\.{0,1}\d*$/;
  if (num == "") return null;
  return re.exec(num) != null ? num : null;
}
//检查文本框的值
function checkTextValue(obj) {
  var str = $(obj).val();
  if (str.indexOf(',') != -1) {
    var flag = false;
    var arr = str.split(","),
      newArr = [];;
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] == "") {
        flag = true;
        break;
      }
      var v = Number(arr[i]);
      if (arr[i] != "") {
        if (isNaN(v)) {
          flag = true;
          break;
        }
      }
      newArr.push(v);
    }
    if (flag) {
      $(obj).addClass('red').removeClass('green');
    } else {
      $(obj).addClass('green').attr('value', newArr.join());
    }
  } else {
    var v = Number(str);
    if (!isNaN(v) && str != "") { //green
      $(obj).addClass('green').attr('value', v);
    } else if (str != "") { //red
      $(obj).addClass('red').removeClass('green');
    } else if (str == "" && $(obj).hasClass('bar')) {
      $(obj).attr('value', "");
    }
  }

}
$('[type=text]').bind("input propertychange", function () {
  checkTextValue($(this));
  for (var i in colorArr) {
    if (colorArr[i]["type"] == $(this).attr("name")) colorArr[i]["values"] = $(this).val() == "" ? "null" : $(this).val();
  }
  setConfig();
}).blur(function () {
  if ($(this).attr('name') == "alias") return;
  if ($(this).hasClass('green')) {
    var str = $(this).val();
    if (str.indexOf(",") != -1) {
      var arr = str.split(','),
        newArr = [];
      for (var i = 0; i < arr.length; i++) {
        var v = Number(arr[i]);
        newArr.push(v);
      }
      $(this).val(newArr.join()).attr('value', newArr.join());
    } else {
      if (str != "") {
        var v = Number(str);
        $(this).val(v).attr('value', v);
      } else {
        var v = $(this).attr('value');
        $(this).val(v).attr('value', v);
      }
    }
  } else if ($(this).hasClass('red')) {
    var v = $(this).attr('value');
    $(this).val(v).removeClass('red').addClass('green');
  }
});

function setConfig() {
  var text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root>";
  for (var i in dialogConfig) {
    text += "<c" + (Number(i) + 1) + " ";
    for (var j in dialogConfig[i]) {
      if (j != "eArr") {
        text += j + "=\"" + dialogConfig[i][j] + "\" ";
      };
    }
    text += ">"
    for (var j in dialogConfig[i]["eArr"]) {
      text += "<" + dialogConfig[i]["eArr"][j]["nodeName"] + " ";
      for (var k in dialogConfig[i]["eArr"][j]) {
        if (k != "nodeName") text += k + "=\"" + dialogConfig[i]["eArr"][j][k] + "\" ";
      }
      text += "/>"
    }
    if (i == dialogIndex) {
      for (var j in colorArr) {
        text += "<" + colorArr[j]["nodeName"] + " ";
        for (var k in colorArr[j]) {
          if (k != "nodeName") text += k + "=\"" + colorArr[j][k] + "\" ";
        }
        text += "/>"
      }
    }
    text += "</c" + (Number(i) + 1) + ">";
  }
  text += "</root>";
  biSetModuleConfig("lane-sensor-by-can.pluginsensor", text);
  biSetLocalVariable("lane_sensor_by_can_color", JSON.stringify(colorArr));
}

function biOnInitEx(config, moduleConfigs) {
  dialogIndex = config;
  if (biGetLanguage() == 1) {
    $('[language]').each(function () {
      var value = $(this).attr('language');
      $(this).html(en[value])
    });
  } else {
    $('[language]').each(function () {
      var value = $(this).attr('language');
      $(this).html(cn[value])
    });
  }
  for (var key in moduleConfigs) {
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    var countrys = xmlDoc.getElementsByTagName('root');
    for (var i = 0; i < countrys[0].childNodes.length; i++) {
      var nodeName = countrys[0].childNodes[i].nodeName;
      var conu = xmlDoc.getElementsByTagName(nodeName);
      var keyss = conu[0].attributes;
      var obj = new Object();
      for (var j = 0; j < keyss.length; j++) {
        obj[keyss[j].nodeName] = keyss[j].nodeValue;
      }
      var cArr = [];
      for (var k = 0; k < conu[0].childNodes.length; k++) {
        var eKeys = conu[0].childNodes[k].attributes;
        var nodeName = conu[0].childNodes[k].nodeName;
        var eObj = new Object();
        for (var n = 0; n < eKeys.length; n++) {
          eObj["nodeName"] = nodeName;
          eObj[eKeys[n].nodeName] = eKeys[n].nodeValue;
        }
        if (nodeName == "color_sv" && i == config) {
          colorArr.push(eObj);
        } else {
          cArr.push(eObj);
        }
      }
      obj["eArr"] = cArr;
      dialogConfig.push(obj);
    }
  }
  $('input').each(function () {
    var name = $(this).attr("name");
    var count = 0;
    for (var i in colorArr) {
      if (colorArr[i]["type"] == name) {
        count++;
        return;
      };
    }
    if (count == 0) {
      colorArr.push({
        "nodeName": "color_sv",
        "type": name,
        "values": "null"
      })
    }
  })
  for (var i in colorArr) {
    $("input[name=" + colorArr[i]["type"] + "]").val(colorArr[i]["values"] == "null" ? "" : colorArr[i]["values"]);
  }
}