var reg = /^[a-zA-Z]:/,//true\ false/
  text = "",
  input_file = [],
  erropath = "";

$('[name]').on('change', function () {
  setConfig();
});
$('button').click(function () {
  if (input_file.length == 0) {
    biAlert(erropath);
  } else {
    setConfig();
    biSetViewConfig(text);
    biRunStandaloneTask("XMprivacy protection", "xmprivacyprotection-task.pluginxmpp", text);
  }
})

function setConfig() {
  text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root ";
  $('[name]').each(function () {
    var name = $(this).attr('name');
    if ($(this).is('input[type=checkbox]')) {
      text += name + "=\"" + ($(this).is(":checked") ? 'yes' : 'no') + "\" ";
    }
  });
  text += "dataPath=\"" + input_file.join(",") + "\" ";
  text += "/>";
  biSetModuleConfig("xmprivacy-protection.pluginxmpp", text);
}
function biOnInitEx(config, moduleConfigs) {
  biQuerySessionList(true);
  var lang = biGetLanguage() == 1 ? en : cn;
  $('[language]').each(function () {
    var value = $(this).attr('language');
    $(this).text(lang[value])
  });
  erropath = lang["erropath"];
  text = moduleConfigs["xmprivacy-protection.pluginxmpp"];
  var parser = new DOMParser();
  var xmlDoc = parser.parseFromString(text, "text/xml");
  var conf = xmlDoc.getElementsByTagName('root');
  var keys = conf[0].attributes;
  var obj = {};
  for (var i = 0; i < keys.length; i++) {
    obj[keys[i].nodeName] = keys[i].nodeValue == "null" ? "" : keys[i].nodeValue;
  }
  loadConfig(obj);
}

function biOnQueriedSessionList(list, filtered) {
  for (var i in list) {
    biQuerySessionPath(list[i]);
  }
}

function biOnQueriedSessionPath(path, session) {
  input_file.push(path);
}


function loadConfig(obj) {
  $('.container [name]').each(function () {
    var val = obj[$(this).attr('name')];
    var type = $(this).attr('type');
    if (type == 'checkbox') {
      $(this).prop('checked', val == 'yes');
    }
  })
}