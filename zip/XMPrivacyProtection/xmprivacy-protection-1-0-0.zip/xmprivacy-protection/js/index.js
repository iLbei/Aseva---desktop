var reg = /^[a-zA-Z]:/,//true\ false/
  dataPath = '',
  text = "";

$('[name]').on('change', function () {
  setConfig();
});
$('button').click(function () {
  setConfig();
  biSetViewConfig(text);
  biRunStandaloneTask("XMprivacy protection", "xmprivacyprotection-task.pluginxmpp", text);
})

function setConfig() {
  text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root ";
  $('[name]').each(function () {
    var name = $(this).attr('name');
    if ($(this).is('input[type=checkbox]')) {
      text += name + "=\"" + ($(this).is(":checked") ? 'yes' : 'no') + "\" ";
    }
  });
  text += "dataPath=\"" + dataPath + "\" ";
  text += "/>";
  biSetModuleConfig("xmprivacy-protection.pluginxmpp", text);
}
function biOnInitEx(config, moduleConfigs) {
  dataPath = biGetDataPath() + (reg.test(biGetDataPath()) ? "\\" : "/");
  var lang = biGetLanguage() == 1 ? en : cn;
  $('[language]').each(function () {
    var value = $(this).attr('language');
    $(this).text(lang[value])
  });
  text = moduleConfigs["xmprivacy-protection.pluginxmpp"];
  var parser = new DOMParser();
  var xmlDoc = parser.parseFromString(text, "text/xml");
  var conf = xmlDoc.getElementsByTagName('root');
  var keys = conf[0].attributes;
  var obj = {};
  for (var i = 0; i < keys.length; i++) {
    obj[keys[i].nodeName] = keys[i].nodeValue == "null" ? "" : keys[i].nodeValue;
  }
  loadConfig(obj);
}
function loadConfig(obj) {
  $('.container [name]').each(function () {
    var val = obj[$(this).attr('name')];
    var type = $(this).attr('type');
    if (type == 'checkbox') {
      $(this).prop('checked', val == 'yes');
    }
  })
}