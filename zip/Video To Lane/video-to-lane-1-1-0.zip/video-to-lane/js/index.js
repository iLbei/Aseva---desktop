let viewSize = new BISize(300, 137);; //窗口大小
let language = sessionStorage.getItem("language"); //取中英文,用于刷新保存的值

let cn = {
  Performance: "*)当车速可用时，性能得到改善。",
  disabled: "(禁用)",
  front_left_video_channel: "左前轮摄像头:",
  front_right_video_channel: "右前轮摄像头:",
  front_out_channel: "前输出通道:",
  rear_left_video_channel: "左后轮摄像头:",
  rear_right_video_channel: "右后轮摄像头:",
  rear_out_channel: "后输出通道:",
  lane_sen_a: "车道线传感器 A",
  lane_sen_b: "车道线传感器 B",
  lane_sen_c: "车道线传感器 C",
  lane_sen_d: "车道线传感器 D",
  lane_sen_e: "车道线传感器 E",
  lane_sen_f: "车道线传感器 F",
  lane_sen_g: "车道线传感器 G",
  lane_sen_h: "车道线传感器 H",
  video_frame_a: "视频帧 A",
  video_frame_b: "视频帧 B",
  video_frame_c: "视频帧 C",
  video_frame_d: "视频帧 D",
  video_frame_e: "视频帧 E",
  video_frame_f: "视频帧 F",
  video_frame_g: "视频帧 G",
  video_frame_h: "视频帧 H",
  video_frame_i: "视频帧 I",
  video_frame_j: "视频帧 J",
  video_frame_k: "视频帧 K",
  video_frame_l: "视频帧 L",
  video_frame_m: "视频帧 M",
  video_frame_n: "视频帧 N",
  video_frame_o: "视频帧 O",
  video_frame_p: "视频帧 P",
  video_frame_q: "视频帧 Q",
  video_frame_r: "视频帧 R",
  video_frame_s: "视频帧 S",
  video_frame_t: "视频帧 T",
  video_frame_u: "视频帧 U",
  video_frame_v: "视频帧 V",
  video_frame_w: "视频帧 W",
  video_frame_x: "视频帧 X",
};
let en = {
  disabled: "(Disabled)",
  front_left_video_channel: "Front left wheel camera:",
  front_right_video_channel: "Front right wheel camera:",
  front_out_channel: "Front output channel:",
  rear_left_video_channel: "Rear left wheel camera:",
  rear_right_video_channel: "Front right wheel camera:",
  rear_out_channel: "Rear output channel:",
  lane_sen_a: "Lane sensor A",
  lane_sen_b: "Lane sensor B",
  lane_sen_c: "Lane sensor C",
  lane_sen_d: "Lane sensor D",
  lane_sen_e: "Lane sensor E",
  lane_sen_f: "Lane sensor F",
  lane_sen_g: "Lane sensor G",
  lane_sen_h: "Lane sensor H",
  video_frame_a: "Video Frame A",
  video_frame_b: "Video Frame B",
  video_frame_c: "Video Frame C",
  video_frame_d: "Video Frame D",
  video_frame_e: "Video Frame E",
  video_frame_f: "Video Frame F",
  video_frame_g: "Video Frame G",
  video_frame_h: "Video Frame H",
  video_frame_i: "Video Frame I",
  video_frame_j: "Video Frame J",
  video_frame_k: "Video Frame K",
  video_frame_l: "Video Frame L",
  video_frame_m: "Video Frame M",
  video_frame_n: "Video Frame N",
  video_frame_o: "Video Frame O",
  video_frame_p: "Video Frame P",
  video_frame_q: "Video Frame Q",
  video_frame_r: "Video Frame R",
  video_frame_s: "Video Frame S",
  video_frame_t: "Video Frame T",
  video_frame_u: "Video Frame U",
  video_frame_v: "Video Frame V",
  video_frame_w: "Video Frame W",
  video_frame_x: "Video Frame X",
  Performance: "*)Performance improved while vehicle speed available."
};
$('select').change(function () {
  setConfig();
});
function changeLanguage(type) {
  if (type == 1) {
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(en[value])
    });
  } else {
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(cn[value])
    });
  }
}
function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root";
  $('select').each(function () {
    text += " " + $(this).attr('name') + "=\"" + $(this).val() + "\"";
  })
  text += "/>";
  biSetModuleConfig("video-to-lane.pluginvideotolane", text);
}

function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(400, 290);
  let type = biGetLanguage();
  changeLanguage(type);
  sessionStorage.setItem("language", type);
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('root');
    let keys = countrys[0].getAttributeNames();
    let obj = new Object();
    for (let i = 0; i < keys.length; i++) {
      obj[keys[i]] = countrys[0].getAttribute(keys[i]);
    };
    loadConfig(JSON.stringify(obj));
  }
}
function loadConfig(config) {
  if (config == null) return;
  let val = JSON.parse(config);
  $('select').each(function () {
    $(this).val(val[$(this).attr('name')])
  })
}
