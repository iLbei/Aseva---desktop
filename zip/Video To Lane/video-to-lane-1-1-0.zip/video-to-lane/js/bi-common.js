﻿// 2020/6/16: 首个版本
// 2020/8/21: 插件2.0支持。调用未实现的功能函数弹异常。标准化注释
// 2020/8/27: 插件2.1支持
// 2020/10/20: 插件2.3支持

// 构造函数 //////////////////////////////////////////////////////////////////

/**
 * 二维尺寸构造函数
 * @param {Number} width 宽度
 * @param {Number} height 高度
 */
function BISize(width, height) {
    this.width = width;
    this.height = height;
}

/**
 * 二维点构造函数
 * @param {Number} x x轴坐标
 * @param {Number} y y轴坐标
 */
function BIPoint(x, y) {
    this.x = x;
    this.y = y;
}

/**
 * 通用样本构造函数
 * @param {String} protocol 样本协议
 * @param {Number} channel 样本通道，可为null
 * @param {Date} session 所属session
 * @param {Number} time 在session中的相对时间戳，单位秒
 * @param {Array} values 样本值
 */
function BIGeneralSample(protocol, channel, session, time, values) {
    this.protocol = protocol;
    this.channel = channel;
    this.session = session;
    this.time = time;
    this.values = values;
}

/**
 * 通用样本对构造函数
 * @param {BIGeneralSample} sample1 较早的最近样本
 * @param {Number} weight1 sample1的权重
 * @param {BIGeneralSample} sample2 较晚的最近样本
 * @param {Number} weight2 sample2的权重
 */
function BIGeneralSamplePair(sample1, weight1, sample2, weight2) {
    this.sample1 = sample1;
    this.weight1 = weight1;
    this.sample2 = sample2;
    this.weight2 = weight2;
}

/**
 * 总线报文信息构造函数
 * @param {String} id 总线报文ID
 * @param {String} protocol 报文所属协议
 * @param {Number} idInProtocol 在协议中的ID
 * @param {String} name 报文名称
 */
function BIBusMessageInfo(id, protocol, idInProtocol, name) {
    this.id = id;
    this.protocol = protocol;
    this.idInProtocol = idInProtocol;
    this.name = name;
}

/**
 * 信号信息构造函数
 * @param {String} id 信号ID
 * @param {String} category 信号所属大类
 * @param {String} typeID 信号所属小类ID
 * @param {String} typeName 信号小类名称
 * @param {String} signalName 信号名称
 */
function BISignalInfo(id, category, typeID, typeName, signalName) {
    this.id = id;
    this.category = category;
    this.typeID = typeID;
    this.typeName = typeName;
    this.signalName = signalName;
}

// 枚举类型 //////////////////////////////////////////////////////////////////

/* 语言 */
var BILanguage = {
    English: 1, // 英文
    Chinese: 2, // 中文
}

/* 运行平台 */
var BIPlatform = {
    ClientWindows: 1, // Windows客户端
    ClientLinux: 2, // Linux客户端
    Web: 3, // Web端
}

/* 运行模式 */
var BIRunningMode = {
    Offline: 1, // 离线模式（含回放模式）
    Online: 2, // 在线模式
}

/* 选择路径类型 */
var BISelectPathType = {
    OpenFile: 1, // 用于打开文件
    CreateFile: 2, // 用于创建文件
    Directory: 3, // 用于获取文件夹路径
    MultipleFiles: 4, // 用于获取多个文件路径
};

/* 独立任务运行结果 */
var BITaskResult = {
    RunOK: 1, // 运行成功
    RunFailed: 2, // 运行失败
    TaskTypeNotFound: 3, // 无法找到任务类型
    TaskInitFailed: 4, // 任务初始化失败
    NotIdle: 5, // 非空闲状态无法运行
}

// 功能函数 //////////////////////////////////////////////////////////////////

/**
 * 未实现功能函数
 * @param {String} funcName 函数名称
 */
function biUnim(funcName) {
}

/**
 * 添加窗口至工作空间
 * @param {String} windowTypeID 窗口类型ID
 * @param {String} config 窗口配置
 * @param {Boolean} newWorkspaceIfNeeded 若空间不足是否在新工作空间中添加
 */
function biAddWindow(windowTypeID, config, newWorkspaceIfNeeded) {
    biUnim("biAddWindow");
}

/**
 * 弹出对话框显示消息
 * @param {Any} msg 需要显示的消息
 * @param {String} title 对话框标题
 */
function biAlert(msg, title) {
    biUnim("biAlert");
}

/**
 * 以只读模式打开文件
 * @param {String} path 打开文件路径
 * @return {Number} 文件标识符，若打开失败则返回null
 */
function biFileOpen(path) {
    biUnim("biFileOpen");
    return null;
}

/**
 * 以只写模式创建文件
 * @param {String} path 创建文件路径
 * @return {Number} 文件标识符，若打开失败则返回null
 */
function biFileCreate(path) {
    biUnim("biFileCreate");
    return null;
}

/** 从文件读取一行文本
 * @param {Number} handle 文件标识符
 * @return {String} 读取的一行文本，若已读完或文件异常则返回null
 */
function biFileReadLine(handle) {
    biUnim("biFileReadLine");
    return null;
}

/**
 * 写一行文本至文件
 * @param {Number} handle 文件标识符
 * @param {String} text 需要写入的文本
 */
function biFileWriteLine(handle, text) {
    biUnim("biFileWriteLine");
}

/**
 * 关闭文件（在页面关闭时会自动关闭该页面关联的所有文件）
 * @param {Number} handle 文件标识符
 */
function biFileClose(handle) {
    biUnim("biFileClose");
}

/**
 * 获取指定协议、通道、时间对应的通用样本对
 * @param {String} protocol 样本协议
 * @param {Number} channel 样本通道，可为null
 * @param {Date} session 所属session
 * @param {Number} time 在session中的相对时间戳，单位秒
 * @param {Number} maxGap 与前后帧间的最大时间差，单位秒
 * @return {BIGeneralSamplePair} 目标的通用样本对，若找不到有效数据则返回null
 */
function biGetGeneralSamplePair(protocol, channel, session, time, maxGap) {
    biUnim("biGetGeneralSamplePair");
    return null;
}

/**
 * 获取当前软件指定使用的语言
 * @return {BILanguage} 语言
 */
function biGetLanguage() {
    biUnim("biGetLanguage");
    return null;
}

/**
 * 获取运行当前脚本的平台
 * @return {BIPlatform} 运行平台
 */
function biGetPlatform() {
    biUnim("biGetPlatform");
    return null;
}

/**
 * 获取当前的运行模式
 * @return {BIRunningMode} 运行模式
 */
function biGetRunningMode() {
    biUnim("biGetRunningMode");
    return null;
}

/**
 * 文件是否存在
 * @param {String} path 文件路径
 * @return {Boolean} 文件是否存在
 */
function biIsFileExist(path) {
    biUnim("biIsFileExist");
    return null;
}

/**
 * 文件夹是否存在
 * @param {String} path 文件夹路径
 * @return {Boolean} 文件夹是否存在
 */
function biIsDirectoryExist(path) {
    biUnim("biIsDirectoryExist");
    return null;
}

/**
 * 打开对话框
 * @param {String} dialogTypeID 对话框类型ID
 * @param {String} config 对话框配置
 */
function biOpenDialog(dialogTypeID, config) {
    biUnim("biOpenDialog");
}

/**
 * 打开HTML对话框
 * @param {String} entryName HTML对话框入口名称（无需加.html）
 * @param {String} config HTML对话框配置
 */
function biOpenHTMLDialog(entryName, config) {
    biUnim("biOpenHTMLDialog");
}

/**
 * 打印消息至Debugger
 * @param {Any} msg 打印的消息
 */
function biPrint(msg) {
    biUnim("biPrint");
}

/**
 * 获取总线报文信息，获取完毕后会回调biOnQueriedBusMessageInfo
 * @param {String} key 用于确定获取报文的标识符，与biOnQueriedBusMessageInfo的输入key一致
 * @param {String} busMessageID 总线报文ID
 */
function biQueryBusMessageInfo(key, busMessageID) {
    biUnim("biQueryBusMessageInfo");
}

/**
 * 获取指定协议下指定数目的所有通道名称，获取完毕后会回调biOnQueriedChannelNames
 * @param {String} key 用于确定获取通道协议的标识符，与biOnQueriedChannelNames的输入key一致
 * @param {String} protocol 协议名，如"vehicle-sample-v4"，视频通道协议名为video
 * @param {Number} channelCount 需要获取的通道数目(有效范围1~64)，如4表示获取0~3(A~D)通道名称，输入null表示获取唯一通道名称
 */
function biQueryChannelNames(key, protocol, channelCount) {
    biUnim("biQueryChannelNames");
}

/**
 * 获取session列表，获取完毕后会回调biOnQueriedSessionList
 * @param {Boolean} filtered 是否为筛选后的列表
 */
function biQuerySessionList(filtered) {
    biUnim("biQuerySessionList");
}

/**
 * 获取信号信息，获取完毕后会回调biOnQueriedSignalInfo
 * @param {String} key 用于确定获取信号的标识符，与biOnQueriedSignalInfo的输入key一致
 * @param {String} signalID 信号ID
 */
function biQuerySignalInfo(key, signalID) {
    biUnim("biQuerySignalInfo");
}

/**
 * 运行独立任务，运行后会回调biOnResultOfStandaloneTask
 * @param {String} key 用于确定运行任务的标识符，与biOnResultOfStandaloneTask的输入key一致
 * @param {String} taskTypeID 任务类型ID
 * @param {String} config 任务配置
 */
function biRunStandaloneTask(key, taskTypeID, config) {
    biUnim("biRunStandaloneTask");
}

/**
 * 打开选择总线报文对话框，选择完毕后会回调biOnSelectedBusMessage
 * @param {String} key 用于确定选择报文的标识符，与biOnSelectedBusMessage的输入key一致
 * @param {String} originID 初始选择的总线报文ID
 */
function biSelectBusMessage(key, originID) {
    biUnim("biSelectBusMessage");
}

/**
 * 打开对话框选择路径，选择完毕后会回调biOnSelectedPath(es)
 * @param {String} key 用于确定选择路径的标识符，与biOnSelectedPath(es)的输入key一致
 * @param {BISelectPathType} type 选择路径的类型，当类型为OpenFile/CreateFile/MultipleFiles时下述filter有效
 * @param {Dictionary} filter 文件后缀筛选，null表示不筛选；键为以'.'开头的全小写后缀，值为文字说明
 */
function biSelectPath(key, type, filter) {
    biUnim("biSelectPath");
}

/**
 * 打开选择信号对话框，选择完毕后会回调biOnSelectedSignal
 * @param {String} key 用于确定选择信号的标识符，与biOnSelectedSignal的输入key一致
 * @param {String} originValueID 初始选择的值信号ID
 * @param {Boolean} withSignBit 是否需要选择符号位信号
 * @param {String} originSignBitID 初始选择的符号位信号ID，仅当withSignBit为true时有效
 * @param {Boolean} withScale 是否需要配置值系数
 * @param {Number} originScale 初始的值系数，仅当withScale为true时有效
 * @param {String} unit 值单位，仅当withScale为true时有效
 */
function biSelectSignal(key, originValueID, withSignBit, originSignBitID, withScale, originScale, unit) {
    biUnim("biSelectSignal");
}

/**
 * 更新指定ID模块的配置
 * @param {String} moduleClassID 需要更新的模块类别ID
 * @param {String} config 模块配置信息
 */
function biSetModuleConfig(moduleClassID, config) {
    biUnim("biSetModuleConfig");
}

// 回调函数 //////////////////////////////////////////////////////////////////

/**
 * 在获取页面配置信息时被调用
 * @return {String} 配置信息
 */
function biOnGetConfig() {
    return null;
}

/**
 * 在获取页面尺寸时被调用
 * @return {BISize} 页面尺寸
 */
function biOnGetViewSize() {
    return null;
}

/**
 * 在初始化时被调用，与biOnInitEx二选一实现即可
 * @param {String} config 页面配置信息
 */
function biOnInit(config) {
}

/**
 * 在初始化时被调用，与biOnInit二选一实现即可
 * @param {String} config 页面配置信息
 * @param {Dictionary} moduleConfigs 关联模块的配置信息，键为模块类别ID，值为模块配置信息
 */
function biOnInitEx(config, moduleConfigs) {
}

/**
 * 在调用biQueryBusMessageInfo返回结果后被调用
 * @param {String} key 用于确定获取报文的标识符
 * @param {BIBusMessageInfo} busMessageInfo 获取的总线报文信息，若获取失败则为null
 */
function biOnQueriedBusMessageInfo(key, busMessageInfo) {
}

/**
 * 在调用biQueryChannelNames返回结果后被调用
 * @param {String} key 用于确定获取通道协议的标识符
 * @param {Dictionary} channelNames 获取的通道名称信息，键为通道协议，值为通道名称（null表示该通道无效）
 */
function biOnQueriedChannelNames(key, channelNames) {
}

/**
 * 在调用biQuerySessionList返回结果后被调用
 * @param {Array} list session列表，数组元素都为Date类型
 * @param {Boolean} filtered 是否为筛选后的列表
 */
function biOnQueriedSessionList(list, filtered) {
}

/**
 * 在调用biQuerySignalInfo返回结果后被调用
 * @param {String} key 用于确定获取信号的标识符
 * @param {BISignalInfo} signalInfo 获取的信号信息，若获取失败则为null
 */
function biOnQueriedSignalInfo(key, signalInfo) {
}

/**
 * 在关闭页面前被调用
 */
function biOnRelease() {
}

/**
 * 在开始session时被调用，用于重置数据缓存等
 */
function biOnReset() {
}

/**
 * 在调用biRunStandaloneTask返回结果后被调用
 * @param {String} key 用于确定运行任务的标识符
 * @param {BITaskResult} result 任务运行结果
 */
function biOnResultOfStandaloneTask(key, result) {
}

/**
 * 在调用biSelectBusMessage返回结果后被调用
 * @param {String} key 用于确定选择报文的标识符
 * @param {BIBusMessageInfo} busMessageInfo 选择的总线报文信息，当在对话框中点击删除后则为null
 */
function biOnSelectedBusMessage(key, busMessageInfo) {
}

/**
 * 在调用biSelectPath返回结果后被调用 (type为OpenFile/CreateFile/Directory时)
 * @param {String} key 用于确定选择路径的标识符
 * @param {String} path 选择的路径，若取消则为null
 */
function biOnSelectedPath(key, path) {
}

/**
 * 在调用biSelectPath返回结果后被调用 (type为MultipleFiles时)
 * @param {String} key 用于确定选择路径的标识符
 * @param {Array} pathes 选择的路径列表，数组元素都为String，若取消则为null
 */
function biOnSelectedPathes(key, pathes) {
}

/**
 * 在调用biSelectSignal返回结果后被调用
 * @param {String} key 用于确定选择信号的标识符
 * @param {BISignalInfo} valueSignalInfo 选择的值信号信息，当在对话框中点击删除后则为null
 * @param {BISignalInfo} signBitSignalInfo 选择的符号位信号信息，当在对话框中点击删除后或withSignBit为false时为null
 * @param {Number} scale 配置的值系数，当在对话框中点击删除后或withScale为false时为null
 */
function biOnSelectedSignal(key, valueSignalInfo, signBitSignalInfo, scale) {
}

/**
 * 在设置兴趣点时间时被调用
 * @param {Date} session 兴趣点所在session
 * @param {Number} time 兴趣点在该session中的相对时间戳，单位秒
 */
function biOnSetInterest(session, time) {
}