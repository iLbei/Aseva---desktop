let viewSize = new BISize(300, 137);; //窗口大小
let language = sessionStorage.getItem("language"); //取中英文,用于刷新保存的值
$('select').change(function () {
  setConfig();
});
function changeLanguage(type) {
  if (type == 1) {
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(en[value])
    });
  } else {
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(cn[value])
    });
  }
}
function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root";
  $('select').each(function () {
    text += " " + $(this).attr('name') + "=\"" + $(this).val() + "\"";
  })
  text += "/>";
  biSetModuleConfig("video-to-lane.pluginvideotolane", text);
}

function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(400, 290);
  let type = biGetLanguage();
  changeLanguage(type);
  sessionStorage.setItem("language", type);
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('root');
    let keys = countrys[0].getAttributeNames();
    let obj = new Object();
    for (let i = 0; i < keys.length; i++) {
      obj[keys[i]] = countrys[0].getAttribute(keys[i]);
    };
    loadConfig(JSON.stringify(obj));
  }
}
function loadConfig(config) {
  if (config == null) return;
  let val = JSON.parse(config);
  $('select').each(function () {
    $(this).val(val[$(this).attr('name')])
  })
}
