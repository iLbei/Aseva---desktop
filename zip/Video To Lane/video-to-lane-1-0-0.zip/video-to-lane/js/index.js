let viewSize = new BISize(300, 137);; //窗口大小
let language = sessionStorage.getItem("language"); //取中英文,用于刷新保存的值

let cn = {
    out_channel: "输出通道:",
    Performance: "*)当车速可用时，性能得到改善",
    disabled: "(禁用)",
    lane_sen_a: "车道线传感器 A",
    lane_sen_b: "车道线传感器 B",
    lane_sen_c: "车道线传感器 C",
    lane_sen_d: "车道线传感器 D",
};
let en = {
    disabled: "(Disabled)",
    lane_sen_a: "Lane sensor A",
    lane_sen_b: "Lane sensor B",
    lane_sen_c: "Lane sensor C",
    lane_sen_d: "Lane sensor D",
    out_channel: "Output channel:",
    Performance: "*)Performance improved while vehicle speed available"
};
$('select').change(function () {
    setConfig();
});
function changeLanguage(type) {
    if (type == 1) {
        $('[language]').each(function () {
            let value = $(this).attr('language');
            $(this).html(en[value])
        });
    } else {
        $('[language]').each(function () {
            let value = $(this).attr('language');
            $(this).html(cn[value])
        });
    }
}
function setConfig() {
    let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root";
    text += " out_channel" + "=\"" + $('[name=out_channel]').val() + "\"";
    text += "/>";
    biSetModuleConfig("video-to-lane.pluginvideotolane", text);
}

function biOnInitEx(config, moduleConfigs) {
    biSetViewSize(330, 81);
    let type = biGetLanguage();
    changeLanguage(type);
    sessionStorage.setItem("language", type);
    for (let key in moduleConfigs) {
        let parser = new DOMParser();
        let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
        let countrys = xmlDoc.getElementsByTagName('root');
        let keys = countrys[0].getAttributeNames();
        let obj = new Object();
        for (let i = 0; i < keys.length; i++) {
            obj[keys[i]] = countrys[0].getAttribute(keys[i]);
        };
        loadConfig(JSON.stringify(obj));
    }
}
function loadConfig(config) {
    if (config == null) return;
    let val = JSON.parse(config);
    console.log(val);
    $('[name=out_channel]').val(val['out_channel']);
}
