let viewSize = new BISize(456, 390); //窗口大小
let language = sessionStorage.getItem("language"); //取中英文,用于刷新保存的值
let configuration;
$(function () {
    $('.content>div').each(function () {
        draw($(this));
    });
});

function draw(obj) {
    let canvas = $(obj).find('.canvas')[0];
    let ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    let p1 = new BIPoint(canvas.width / 2, 0);
    let p2 = new BIPoint(canvas.width / 2, canvas.height);
    let p3 = new BIPoint(0, 67 + 50);
    let p4 = new BIPoint(canvas.width, 67 + 50);
    drawLine(p1, p2, 1, "#e9e9e9", ctx);
    drawLine(p3, p4, 1, "#e9e9e9", ctx);
    let size = new BISize(30, 70);
    let p5 = new BIPoint(canvas.width / 2 - 15, 67 + 50);
    drawRect(p5, size, "black", ctx);
    let p6 = new BIPoint(canvas.width / 2, 67 + 50);
    let p7 = new BIPoint(canvas.width / 2 - 15, 67 + 25 + 50);
    let p8 = new BIPoint(canvas.width / 2 + 15, 67 + 25 + 50);
    let arr = [p6, p7, p8];
    drawPolygon(arr, "black", ctx);
    let origin_x = $(obj).find('[name=origin_x]').val();
    let origin_y = $(obj).find('[name=origin_y]').val();
    let xScale = origin_x * 24 / 1.5,
        yScale = 15 * origin_y;
    p1 = new BIPoint(canvas.width / 2 - yScale, 67 - xScale - 24 + 50);
    p2 = new BIPoint(canvas.width / 2 - yScale, 67 - xScale + 50);
    p3 = new BIPoint(canvas.width / 2 - 15 - yScale, 67 - xScale + 50);
    ctx.beginPath();
    ctx.lineWidth = 1;
    ctx.moveTo(p1.x, p1.y);
    ctx.lineTo(p2.x, p2.y);
    ctx.lineTo(p3.x, p3.y);
    ctx.strokeStyle = "#32cd32";
    ctx.stroke();
    ///////////////////////////////////
    let pos_x = Number($(obj).find('[name=pos_x]').val());
    let pos_y = Number($(obj).find('[name=pos_y]').val());
    let yaw = Number($(obj).find('[name=orient]').val());
    let pScale_x = pos_x * 24 / 1.5,
        pScale_y = pos_y * 15;
    let p = new BIPoint(p6.x - pScale_y, p6.y - pScale_x);
    let num1 = p.y - Math.sin(Math.PI / 180 * 15) * p.x,
        num2 = p.y - Math.sin(Math.PI / 180 * 15) * (canvas.width - p.x);
    p1 = new BIPoint(0, num1);
    p2 = new BIPoint(canvas.width, num2);
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.rotate(Math.PI / 180 * (0 - yaw));
    p1 = new BIPoint(p1.x - p.x, num1 - p.y);
    p2 = new BIPoint(p2.x - p.x, num2 - p.y);
    p = new BIPoint(p.x - p.x, p.y - p.y);
    drawArc(p, "#9a79dd", ctx, 10, (2 - 1 / 180 * 15) * Math.PI, (1 + 1 / 180 * 15) * Math.PI);
    drawLine(p1, p, 1, "#9a79dd", ctx);
    drawLine(p2, p, 1, "#9a79dd", ctx);
    ctx.restore();
}
/**
 * 画半圆
 * @param {*} origin 原点
 * @param {*} color 颜色
 * @param {*} ctx 画图上下文
 * @param {*} radius 半径
 */
function drawArc(origin, color, ctx, radius, e, s) {
    ctx.beginPath();
    ctx.lineWidth = 1;
    ctx.strokeStyle = color;
    ctx.arc(origin.x, origin.y, radius, e, s, true);
    ctx.stroke();
}
/**
 * 画多边形
 * @param {} arr 点
 * @param {*} color 颜色 
 * @param {*} ctx 上下文
 */
function drawPolygon(arr, color, ctx) {
    ctx.beginPath();
    ctx.moveTo(arr[0].x, arr[0].y);
    ctx.lineTo(arr[1].x, arr[1].y);
    ctx.lineTo(arr[2].x, arr[2].y);
    ctx.strokeStyle = color;
    ctx.closePath();
    ctx.stroke();
}

$('select').change(function () {
    setConfig();
});

$('input').change(function () {
    setConfig();
});


function xyChange(obj) {
    $(obj).val(Number(checkNumber(obj)).toFixed(2))
    draw($(obj).parent().parent().parent().parent().parent().parent());
}
function xyChangeInput(obj) {
    let max = Number($(obj).attr('max'));
    let min = Number($(obj).attr('min'));
    let v = Number($(obj).val());
    if (v < min || v > max) return
    draw($(obj).parent().parent().parent().parent().parent().parent());
}

function lChange(obj) {
    $(obj).val(Number(checkNumber(obj)).toFixed(1))
    draw($(obj).parent().parent().parent().parent());
}
function lChangeInput(obj) {
    let max = Number($(obj).attr('max'));
    let min = Number($(obj).attr('min'));
    let v = Number($(obj).val());
    if (v < min || v > max) return
    draw($(obj).parent().parent().parent().parent());
}

/**
 * 画线-两点一线
 * @param {*} p1 点
 * @param {*} p2 点
 * @param {*} width 线宽度
 * @param {*} color 颜色
 * @param {*} ctx 画图上下文
 */
function drawLine(p1, p2, width, color, ctx) {
    ctx.beginPath();
    ctx.lineWidth = width;
    ctx.moveTo(p1.x, p1.y);
    ctx.lineTo(p2.x, p2.y);
    // ctx.closePath();
    ctx.strokeStyle = color;
    ctx.stroke();
}
/**
 * 画矩形
 * @param {*} p 顶点
 * @param {*} s 大小
 * @param {*} color 颜色
 * @param {*} ctx 画图上下文
 */
function drawRect(p, s, color, ctx) {
    ctx.beginPath();
    ctx.rect(p.x, p.y, s.width, s.height);
    ctx.strokeStyle = color;
    ctx.stroke();
}
function checkNumber(obj) {
    let step = $(obj).attr('step').length - 2;
    let v = Number($(obj).val());
    let value;
    if (!isNaN(v) && $(obj).val() != "") {
        let min = parseFloat($(obj).attr('min')),
            max = parseFloat($(obj).attr('max'));
        v = v < min ? min : v;
        v = v > max ? max : v;
        if (step <= -1) {
            value = v.toFixed(0);
        } else {
            value = v.toFixed(step);
        }
    } else {
        value = $(obj).attr('value');
    }
    $(obj).val(value);
    return value;
}
let cn = {
    rear_left: "左后",
    rear_right: "右后",
    front_left: "左前",
    front_right: "右前",
    output_channel: "输出通道:",
    origin: "原点 [m]:",
    can_channel: "CAN 通道: ",
    position: "位置 [m]:",
    orie: "方向 [deg]:",
    output_raw_vel: "输出原始速度和加速度",
    disabled: "(禁用)",
    obj_sen_a: "目标物传感器 A",
    obj_sen_b: "目标物传感器 B",
    obj_sen_c: "目标物传感器 C",
    obj_sen_d: "目标物传感器 D",
    obj_sen_e: "目标物传感器 E",
    obj_sen_f: "目标物传感器 F",
    obj_sen_g: "目标物传感器 G",
    obj_sen_h: "目标物传感器 H",
    obj_sen_i: "目标物传感器 I",
    obj_sen_j: "目标物传感器 J",
    obj_sen_k: "目标物传感器 K",
    obj_sen_l: "目标物传感器 L",
},
    en = {
        disabled: "(Disabled)",
        obj_sen_a: "Object sensor A",
        obj_sen_b: "Object sensor B",
        obj_sen_c: "Object sensor C",
        obj_sen_d: "Object sensor D",
        obj_sen_e: "Object sensor E",
        obj_sen_f: "Object sensor F",
        obj_sen_g: "Object sensor G",
        obj_sen_h: "Object sensor H",
        obj_sen_i: "Object sensor I",
        obj_sen_j: "Object sensor J",
        obj_sen_k: "Object sensor K",
        obj_sen_l: "Object sensor L",
        rear_left: "Rear Left",
        rear_right: "Rear Right",
        front_left: "Front Left",
        front_right: "Front Right",
        output_channel: "Output channel:",
        origin: "Origin [m]:",
        can_channel: "CAN Channel: ",
        position: "Position [m]:",
        orie: "Orientation [deg]:",
        output_raw_vel: "Output raw velocity and acceleration"
    };

if (language != null) {
    changeLanguage(language);
}
/**
 * 判断中英文
 */
function changeLanguage(type) {
    if (type == 1) { //英文
        $('[language]').each(function () {
            let value = $(this).attr('language');
            $(this).html(en[value])
        });
    } else { //中文
        $('[language]').each(function () {
            let value = $(this).attr('language');
            $(this).html(cn[value])
        });
    }
}
/**
 * 加载配置
 */
function loadConfig(config) {
    if (config == null) return
    let obj = JSON.parse(config);
    let vals = obj["arr"];
    $('.content>div').each(function (i, v) {
        let val = vals[i];
        $(this).find('[name]').each(function () {
            let value = $(this).attr('name'),
                type = $(this).attr("type");
            if (type == "checkbox") {
                val[value] == "yes" ? $(this).attr('checked', true) : $(this).attr('checked', false);
            } else if (type == "number") {
                let step = $(this).attr('step').length - 2;
                let v = parseFloat(val[value]);
                if (step <= -1) {
                    $(this).val(v.toFixed(0));
                } else {
                    $(this).val(v.toFixed(step));
                }
            } else {
                let v = val[value] == "null" ? "" : val[value]
                $(this).val(v);
            }
        });
        draw($(this));
    });
    if (obj["output_raw_vel"] == "yes") $('[name=output_raw_vel]').attr("checked", true);
}


/**
 * 写配置
 */

function setConfig() {
    let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
    let m = $('[name=output_raw_vel]').get(0).checked ? "yes" : "no";
    text += "<root output_raw_vel" + "=\"" + m + "\"" + ">";
    $('.content>div').each(function () {
        let clas = $(this).attr("class");
        text += "<" + clas + " ";
        $(this).find('[name]').each(function () {
            let key = $(this).attr('name'),
                type = $(this).attr("type");
            if (type == "checkbox") {
                let n = $(this).get(0).checked ? "yes" : "no";
                text += " " + key + "=\"" + n + "\"";
            } else if (type == "number") {
                let step = $(this).attr('step').length - 2;
                let v = Number($(this).val());
                let value;
                if (!isNaN(v) && $(this).val() != "") {
                    let min = parseFloat($(this).attr('min')),
                        max = parseFloat($(this).attr('max'));
                    v = v < min ? min : v;
                    v = v > max ? max : v;
                    if (step <= -1) {
                        value = v.toFixed(0);
                    } else {
                        value = v.toFixed(step);
                    }
                } else {
                    value = $(this).attr('value');
                }
                text += " " + key + "=\"" + value + "\"";
            } else {
                let v = $(this).val() == "" ? null : $(this).val();
                text += " " + key + "=\"" + v + "\"";
            }
        });
        text += "/>";
    });
    text += "</root>"
    console.log(text);
    biSetModuleConfig("srr3-i-o.plugindelphiradars", text);
}

function biOnInitEx(config, moduleConfigs) {
    biSetViewSize(462, 390)
    let type = biGetLanguage();
    changeLanguage(type);
    sessionStorage.setItem("language", type);
    configuration = config;
    for (let key in moduleConfigs) {
        let parser = new DOMParser();
        let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
        let countrys = xmlDoc.getElementsByTagName('root');
        let o = new Object();
        let arr = [];
        for (let i = 0; i < countrys[0].childNodes.length; i++) {
            let nodeName = countrys[0].childNodes[i].nodeName;
            let conu = xmlDoc.getElementsByTagName(nodeName);
            let keyss = conu[0].getAttributeNames();
            let obj = new Object();
            for (let j = 0; j < keyss.length; j++) {
                obj[keyss[j]] = conu[0].getAttribute(keyss[j]);
            }
            arr.push(obj);
        }
        o["arr"] = arr;
        let g = countrys[0].getAttributeNames();
        o["output_raw_vel"] = countrys[0].getAttribute(g[0]);
        loadConfig(JSON.stringify(o));
        biPrint(JSON.stringify(o))
        biPrint(352)
    }
}