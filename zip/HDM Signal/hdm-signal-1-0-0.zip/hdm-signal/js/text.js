var zh = {
  hdm_enable: "启用",
  gnssIMUChannel: "GNSS-IMU通道:",
  disabled: "(禁用)"
},
  en = {
    hdm_enable: "Enable",
    gnssIMUChannel: "GNSS-IMU channel:",
    disabled: "(Disabled)"
  };