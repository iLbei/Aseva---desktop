var cn = {
    enable: "启用",
    video_data_channel: "视频数据通道:",
    video_target_channel: "视频目标通道:",
    bus_target_channel: "总线目标通道:",
    bus_data_channel: "总线数据通道:",
    bus_msgid: "报文ID:",
    ethernet: "以太网",
    bus: "总线",
    video: "视频"
  },
  en = {
    enable: "Enabled",
    video_data_channel: "Video data channel:",
    video_target_channel: "Target video channel:",
    bus_target_channel: "Target bus channel:",
    bus_data_channel: "Bus data channel:",
    bus_msgid: "Message ID:",
    ethernet: "Ethernet",
    bus: "Bus",
    video: "Video"
  };