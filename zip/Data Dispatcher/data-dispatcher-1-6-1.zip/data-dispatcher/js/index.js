var reg = /^([1-9]|([1-9][0-9])|(1[0-9][0-9])|(2[0-4][0-9])|(25[0-5]))(\.([0-9]|([1-9][0-9])|(1[0-9][0-9])|(2[0-4][0-9])|(25[0-5]))){3}$/;
$(function () {
  var bus = "",
    video = "",
    ethernet = "",
    general = "";
  for (var i = 0; i < 12; i++) {
    bus += "<ul class=\"fixclear\"><li><input type=\"checkbox\" name=\"enable\" id=\"enabled_bus_" + i + "\"><label for=\"enabled_bus_" + i + "\" language=\"enable\"></label></li><li><span class=\"left\" language=\"bus_data_channel\"></span><input class=\"right\" type=\"number\" name=\"bus_data_channel\" value=\"1\" step=\"1\" max=\"24\" min=\"1\"></li><li><span class=\"left\" language=\"bus_target_channel\"></span><input class=\"right\" type=\"number\" name=\"bus_target_channel\" value=\"1\" step=\"1\" max=\"24\" min=\"1\"></li><li><span class=\"left\" language=\"transmit_mode\"></span><select class=\"right\" name=\"transmit_mode\"><option value=\"0\">Instantaneous</option><option value=\"1\">Scheduled</option></select></li><li><span class=\"left\" language=\"server_posix_offset\"></span><input class=\"right\" type=\"number\" name=\"server_posix_offset\" max=\"100000\" min=\"0\" value=\"1000\" step=\"0.1\"></li></ul>";
    video += "<ul class=\"fixclear\"><li><input type=\"checkbox\" name=\"enable\" id=\"enabled_video_" + i + "\"><label for=\"enabled_video_" + i + "\" language=\"enable\"></label></li><li><span class=\"left\" language=\"video_data_channel\"></span><select class=\"right\" name=\"video_data_channel\"><option value=\"0\">Channel A</option><option value=\"1\">Channel B</option><option value=\"2\">Channel C</option><option value=\"3\">Channel D</option><option value=\"4\">Channel E</option><option value=\"5\">Channel F</option><option value=\"6\">Channel G</option><option value=\"7\">Channel H</option><option value=\"8\">Channel I</option><option value=\"9\">Channel J</option><option value=\"10\">Channel K</option><option value=\"11\">Channel L</option><option value=\"12\">Channel M</option><option value=\"13\">Channel N</option><option value=\"14\">Channel O</option><option value=\"15\">Channel P</option><option value=\"16\">Channel Q</option><option value=\"17\">Channel R</option><option value=\"18\">Channel S</option><option value=\"19\">Channel T</option><option value=\"20\">Channel U</option><option value=\"21\">Channel V</option><option value=\"22\">Channel W</option><option value=\"23\">Channel X</option></select></li><li><span class=\"left\" language=\"video_target_channel\"></span><select class=\"right\" name=\"video_target_channel\"><option value=\"0\">Channel A</option><option value=\"1\">Channel B</option><option value=\"2\">Channel C</option><option value=\"3\">Channel D</option><option value=\"4\">Channel E</option><option value=\"5\">Channel F</option><option value=\"6\">Channel G</option><option value=\"7\">Channel H</option><option value=\"8\">Channel I</option><option value=\"9\">Channel J</option><option value=\"10\">Channel K</option><option value=\"11\">Channel L</option><option value=\"12\">Channel M</option><option value=\"13\">Channel N</option><option value=\"14\">Channel O</option><option value=\"15\">Channel P</option><option value=\"16\">Channel Q</option><option value=\"17\">Channel R</option><option value=\"18\">Channel S</option><option value=\"19\">Channel T</option><option value=\"20\">Channel U</option><option value=\"21\">Channel V</option><option value=\"22\">Channel W</option><option value=\"23\">Channel X</option></select></li><li><span class=\"left\" language=\"transmit_mode\"></span><select class=\"right\" name=\"transmit_mode\"><option value=\"0\">Instantaneous</option><option value=\"1\">Scheduled</option></select></li><li><span class=\"left\" language=\"server_posix_offset\"></span><input class=\"right\" type=\"number\" name=\"server_posix_offset\" max=\"100000\" min=\"0\" value=\"1000\" step=\"0.1\"></li></ul>";
    ethernet += "<ul class=\"fixclear\"><li><input type=\"checkbox\" name=\"enable\" id=\"enabled_ethernet_" + i + "\"><label for=\"enabled_ethernet_" + i + "\" language=\"enable\"></label></li><li><div><span class=\"left\" language=\"bus_msgid\"></span><input class=\"left\" type=\"text\" name=\"bus_msgid\"></div><div><span class=\"left\">Src IP:</span><input type=\"text\" name=\"srcIP\" value=\"192.168.0.201\" class=\"green\" class=\"left\"></div><div><input type=\"text\" name=\"srcPort\" class=\"right\" ><span class=\"right\">Src Port:</span></div></li><li class=\"fixclear\"><span class=\"left\" language=\"bus_data_channel\"></span><input class=\"left\" type=\"number\" name=\"bus_data_channel\" value=\"1\" step=\"1\" max=\"24\" min=\"1\"> <input class=\"right\" type=\"number\" name=\"bus_target_channel\" value=\"1\" step=\"1\" max=\"24\" min=\"1\"><span class=\"right\" language=\"bus_target_channel\"></span></li><li><span class=\"left\" language=\"transmit_mode\"></span><select class=\"left\" name=\"transmit_mode\"><option value=\"0\">Instantaneous</option><option value=\"1\">Scheduled</option></select><input class=\"right\" type=\"number\" name=\"server_posix_offset\" max=\"100000\" min=\"0\" value=\"1000\" step=\"0.1\"><span class=\"right\" language=\"server_posix_offset\"></span></li><li><span language=\"packet_loss_rate\" class=\"left\"></span><input type=\"number\" name=\"packet_loss_rate\" max=\"99.99\" min=\"0\" step=\"0.01\" class=\"left\"></li><li><span language=\"cutoff_time_length\"></span><input type=\"number\" name=\"cutoff_time_length\" min=\"0\" step=\"0.1\"><input type=\"number\" name=\"cutoff_start_time\" min=\"0\" class=\"right\" step=\"0.1\"><span language=\"cutoff_start_time\" class=\"right\"></span></li></ul>";
    general += "<ul><li><input type=\"checkbox\" name=\"enable\" id=\"enabled_general_" + i + "\"><label for=\"enabled_general_" + i + "\" language=\"enable\"></label></li><li><span class=\"left\" language=\"protocolName\"></span><input class=\"right\" type=\"text\" name=\"protocolName\"></li><li><span class=\"left\" language=\"transmit_mode\"></span><select class=\"right\" name=\"transmit_mode\"><option value=\"0\">Instantaneous</option><option value=\"1\">Scheduled</option></select></li><li><span class=\"left\" language=\"server_posix_offset\"></span><input class=\"right\" type=\"number\" name=\"server_posix_offset\" max=\"100000\" min=\"0\" value=\"1000\" step=\"0.1\"></li><li></li></ul>";
  }
  $(".bus").append(bus);
  $(".video").append(video);
  $(".ethernet").append(ethernet);
  $(".general").append(general);

})
//正则验证 ip
$('.container').on("keyup", "input[type=text]", function () {
  var val = $(this).val();
  var name = $(this).attr("name");
  if (name == "bus_msgid") {
    !isNaN(val) ? $(this).addClass('green').attr("value", $(this).val()).removeClass('red') : $(this).removeClass('green').addClass('red');
  } else if (name == "srcIP") {
    reg.test(val) ? $(this).addClass('green').attr("value", $(this).val()).removeClass('red') : $(this).removeClass('green').addClass('red');
  } else if (name == "srcPort") {
    checkPort(this);
  }
  if (!$(this).hasClass('red')) setConfig();
}).blur(function () {
  if ($(this).val() == "" || $(this).hasClass('red')) {
    $(this).val($(this).attr('value')).addClass('green').removeClass('red');
  } else {
    setConfig();
  }
})

function checkPort(obj) {
  var val = $(obj).val();
  if (val.indexOf(",") != -1) {
    try {
      val.split(",").forEach(function (item) {
        if (isNaN(Number(item))) {
          throw "error";
        } else {
          $(obj).addClass("green").removeClass("red");
        }
      });
    } catch (e) {
      $(obj).addClass("red").removeClass("green");
    }
  } else {
    if (isNaN(val)) {
      $(obj).addClass("red").removeClass("green");
    } else {
      $(obj).addClass("green").addClass("red");
    }
  }
}
$(".container").on("change", "input[type=number]", function () {
  $(this).val(compareVal(this, $(this).val()));
})

$(".container").on("input", "input[type=number]", function (e) {
  if (e.which == undefined) {
    var step = $(this).attr("step").length - 2;
    var val = Number($(this).val());
    $(this).val(step > 0 ? val.toFixed(step) : val);
  }
  setConfig();
})

$(".container").on("keypress", "input[type=number]", function (e) {
  if (!(e.charCode >= 48 && e.charCode <= 57) && !(e.charCode == 45 || e.charCode == 46)) {
    return false;
  }
})

/*--------------不能使用统一的替换！---------------*/
//有input type=number 情况下比较大小
function compareVal(obj, val) {
  var step = $(obj).attr('step').length > 2 ? $(obj).attr('step').length - 2 : 0,
    v = Number(val),
    newVal = 0;
  if (isNaN(v)) {
    newVal = Number($(obj).attr('value'));
  } else {
    var min = Number($(obj).attr('min'));
    if (!["cutoff_time_length", "cutoff_start_time"].includes($(obj).attr("name"))) {
      var max = Number($(obj).attr('max'));
      v = v > max ? max : v;
    }
    v = v < min ? min : v;
    if (step > 0) {
      newVal = Math.round(Math.abs(v) * Math.pow(10, step)) / Math.pow(10, step);
      if (v < 0) newVal = -newVal;
    } else {
      newVal = Math.floor(v);
    }
  }
  return step > 0 ? newVal.toFixed(step) : newVal;
}


/*----------配置读取与存储-----------*/
// 表单内容改变保存配置
$(".container").on("change", "[name]", function () {
  if (!["server_ip", "local_ip"].includes($(this).attr("name"))) {
    setConfig();
  }
});
//保存配置
function setConfig() {
  var text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root>";
  for (var i = 1; i <= $(".container>div.bus>ul").length; i++) {
    $('.container>div').each(function () {
      var tag = $(this).find('p').attr("language") + i;
      text += "<" + tag;
      $(this).find('ul:eq(' + (i - 1) + ') [name]').each(function () {
        var name = $(this).attr("name");
        var val = $(this).val();
        var type = $(this).attr('type');
        if (type == 'checkbox') {
          text += " " + name + "=\"" + ($(this).is(':checked') ? "yes" : "no") + "\"";
        } else if (type == "number") {
          text += " " + name + "=\"" + compareVal(this, val) + "\"";
        } else {
          text += " " + name + "=\"" + val + "\"";
        }
      })
      text += "/>";
    })
  }
  text += "</root>";
  biSetModuleConfig("data-dispatcher.asplugindatadispatcher", text);
}
//初始化
function biOnInitEx(config, moduleConfigs) {
  $('[language]').each(function () {
    var value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value])
  });
  var arr = [];
  for (var i = 0; i < $(".container>div.bus>ul").length; i++) {
    arr.push([]);
  }
  for (var key in moduleConfigs) {
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    var child = xmlDoc.getElementsByTagName('root')[0].childNodes;
    for (var i = 1; i <= $(".container>div.bus>ul").length; i++) {
      for (var count = i * 4 - 4; count < i * 4; count++) {
        var obj = {};
        var keys = child[count].attributes;
        for (var j in keys) {
          obj[keys[j].nodeName] = keys[j].nodeValue;
        }
        switch (count % 4) {
          case 0: {
            arr[i - 1]["bus"] = obj;
            break;
          }
          case 1: {
            arr[i - 1]["video"] = obj;
            break;
          }
          case 2: {
            arr[i - 1]["ethernet"] = obj;
            break;
          }
          case 3: {
            arr[i - 1]["general"] = obj;
            break;
          }
        }
      }
    }
    loadConfig(arr);
  }
}

function loadConfig(arr) {
  if (arr == null) return;
  $('.container>div').each(function () {
    var parentName = $(this).find("p").attr("language");
    $(this).find("[name]").each(function () {
      var i = $(this).parents("ul").index() - 1;
      var name = $(this).attr("name");
      var val = arr[i][parentName][name];
      var type = $(this).attr('type');
      if (type == 'checkbox') {
        $(this).prop('checked', val == 'yes' ? true : false);
      } else if (type == "number") {
        $(this).val(compareVal(this, val));
      } else {
        if (val != "") {
          $(this).val(val);
          if ("bus_msgid" == name) {
            !isNaN(val) ? $(this).addClass('green').removeClass('red') : $(this).removeClass('green').addClass('red');
          } else if ("srcPort" == name) {
            checkPort(this);
          }
        }
      }
    })
  })
}