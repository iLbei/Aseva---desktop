var reg = /^([1-9]|([1-9][0-9])|(1[0-9][0-9])|(2[0-4][0-9])|(25[0-5]))(\.([0-9]|([1-9][0-9])|(1[0-9][0-9])|(2[0-4][0-9])|(25[0-5]))){3}$/;
var configs = [];
$(function () {
  var lang = biGetLanguage() == 1 ? en : cn;
  $('[language]').each(function () {
    var value = $(this).attr('language');
    $(this).text(lang[value]);
  });
})
//正则验证 ip
$('.container').on("keyup", "input[type=text]", function () {
  var val = $(this).val();
  var name = $(this).attr("name");
  if (name == "bus_msgid") {
    !isNaN(val) ? $(this).addClass('green').attr("value", $(this).val()).removeClass('red') : $(this).removeClass('green').addClass('red');
  } else if (name == "srcIP") {
    reg.test(val) ? $(this).addClass('green').attr("value", $(this).val()).removeClass('red') : $(this).removeClass('green').addClass('red');
  } else if (name == "srcPort") {
    checkPort(this);
  }
  if (!$(this).hasClass('red')) changeVal(this);
}).blur(function () {
  if ($(this).val() == "" || $(this).hasClass('red')) {
    $(this).val($(this).attr('value')).addClass('green').removeClass('red');
  } else {
    changeVal(this);
  }
})

//tab分页
$(".item>li").click(function () {
  $(this).addClass("active").siblings().removeClass("active");
  var i = $(".active").index();
  getContentVal(i);
})

function getContentVal(i) {
  $('.content>div').each(function () {
    var parentName = $(this).find("p").attr("language");
    $(this).find("[name]").each(function () {
      var name = $(this).attr("name");
      var val = configs[i][parentName][name];
      var type = $(this).attr('type');
      if (type == 'checkbox') {
        $(this).prop('checked', val == 'yes' ? true : false);
      } else if (type == "number") {
        $(this).val(compareVal(this, val));
      } else {
        if (val != "") {
          $(this).val(val);
          if ("bus_msgid" == name) {
            !isNaN(val) ? $(this).addClass('green').removeClass('red') : $(this).removeClass('green').addClass('red');
          } else if ("srcPort" == name) {
            checkPort(this);
          }
        } else {
          $(this).val("");
        }
      }
    })
  })
}

function checkPort(obj) {
  var val = $(obj).val();
  if (val.indexOf(",") != -1) {
    try {
      val.split(",").forEach(function (item) {
        if (isNaN(Number(item))) {
          throw "error";
        } else {
          $(obj).addClass("green").removeClass("red");
        }
      });
    } catch (e) {
      $(obj).addClass("red").removeClass("green");
    }
  } else {
    if (isNaN(val)) {
      $(obj).addClass("red").removeClass("green");
    } else {
      $(obj).addClass("green").addClass("red");
    }
  }
}
$(".container").on("change", "input[type=number]", function () {
  $(this).val(compareVal(this, $(this).val()));
})

$(".container").on("input", "input[type=number]", function (e) {
  if (e.which == undefined) {
    var step = $(this).attr("step").length - 2;
    var val = Number($(this).val());
    $(this).val(step > 0 ? val.toFixed(step) : val);
  }
  changeVal(this);
})

$(".container").on("keypress", "input[type=number]", function (e) {
  if (!(e.charCode >= 48 && e.charCode <= 57) && !(e.charCode == 45 || e.charCode == 46)) {
    return false;
  }
})

/*--------------不能使用统一的替换！---------------*/
//有input type=number 情况下比较大小
function compareVal(obj, val) {
  var step = $(obj).attr('step').length > 2 ? $(obj).attr('step').length - 2 : 0,
    v = Number(val),
    newVal = 0;
  if (isNaN(v)) {
    newVal = Number($(obj).attr('value'));
  } else {
    var min = Number($(obj).attr('min'));
    if (!["cutoff_time_length", "cutoff_start_time"].includes($(obj).attr("name"))) {
      var max = Number($(obj).attr('max'));
      v = v > max ? max : v;
    }
    v = v < min ? min : v;
    if (step > 0) {
      newVal = Math.round(Math.abs(v) * Math.pow(10, step)) / Math.pow(10, step);
      if (v < 0) newVal = -newVal;
    } else {
      newVal = Math.floor(v);
    }
  }
  return step > 0 ? newVal.toFixed(step) : newVal;
}

/*----------配置读取与存储-----------*/
// 表单内容改变保存配置
$(".container").on("change", "[name]", function () {
  if (!["server_ip", "local_ip"].includes($(this).attr("name"))) {
    changeVal(this);
  }
});

function changeVal(obj) {
  var i = $(".active").index();
  var key = $(obj).parents("ul").parent().find('p').attr("language");
  var name = $(obj).attr("name");
  var val = $(obj).val();
  var type = $(obj).attr('type');
  if (type == 'checkbox') {
    configs[i][key][name] = $(obj).is(':checked') ? "yes" : "no";
  } else if (type == "number") {
    configs[i][key][name] = compareVal(obj, val);
  } else {
    configs[i][key][name] = val;
  }
  setConfig();
}

//保存配置
function setConfig() {
  var text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root>";
  for (var i = 0; i < configs.length; i++) {
    for (let j in configs[i]) {
      text += "<" + j + (i + 1);
      for (let k in configs[i][j]) {
        text += " " + k + "=\"" + configs[i][j][k] + "\"";
      }
      text += "/>";
    }
  }
  text += "</root>";
  biSetModuleConfig("data-dispatcher.asplugindatadispatcher", text);
}
//初始化
function biOnInitEx(config, moduleConfigs) {
  var lang = biGetLanguage() == 1 ? en : cn;
  $('[language]').each(function () {
    var value = $(this).attr('language');
    $(this).text(lang[value]);
  });
  for (var i = 0; i < $(".item>li").length; i++) {
    configs.push([]);
  }
  for (var key in moduleConfigs) {
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    var child = xmlDoc.getElementsByTagName('root')[0].childNodes;
    for (var i = 1; i <= configs.length; i++) {
      for (var count = i * 4 - 4; count < i * 4; count++) {
        var obj = {};
        var keys = child[count].attributes;
        for (var j in keys) {
          obj[keys[j].nodeName] = keys[j].nodeValue;
        }
        switch (count % 4) {
          case 0: {
            configs[i - 1]["bus"] = obj;
            break;
          }
          case 1: {
            configs[i - 1]["video"] = obj;
            break;
          }
          case 2: {
            configs[i - 1]["ethernet"] = obj;
            break;
          }
          case 3: {
            configs[i - 1]["general"] = obj;
            break;
          }
        }
      }
    }
    loadConfig();
  }
}

function loadConfig() {
  if (configs == null) return;
  getContentVal($(".active").index());
}