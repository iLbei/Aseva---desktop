var cn = {
  rpEnable: "启用",
  not_config:"<未配置>",
  staticObjectsJsonFile:"静态目标物文件(JSON):",
  gnssImuInputChannel:"交通信息样本输出通道:",
},
  en = {
    rpEnable: "Enabled",
    not_config:"<Not configured>",
    staticObjectsJsonFile:"Static Object File (JSON):",
    gnssImuInputChannel:"GNSS-IMU Input Channel:",
  };