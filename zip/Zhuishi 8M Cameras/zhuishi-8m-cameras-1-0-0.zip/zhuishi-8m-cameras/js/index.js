let channels = [];
$('[name]').change(function () {
  if($(this).attr('name')=='ip') return;
  setConfig();
});
function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root";
  text += " enabled" + "=\"" + ($('[name=connect]').get(0).checked == true ? "yes" : "no") + "\"";
  text += " ip" + "=\"" + $('[name=ip]').val() + "\"";
  if($('[name=port]').val() != ''){
    let min = Number($('[name=port]').attr('min'));
    let max = Number($('[name=port]').attr('max'));
    if(Number($('[name=port]').val())>max ){
      text += " port" + "=\"" + max + "\"";
    }else if(Number($('[name=port]').val())<min ){
      text += " port" + "=\"" + min + "\"";
    }else if($('[name=port]').val()=='' ){
      text += " port" + "=\"\"";
    }else{
      text += " port" + "=\"" + $('[name=port]').val() + "\"";
    }
  }
  text += " dataPath=\"\"";
  text +="/>";
  biSetModuleConfig("zhuishi-8m-cameras.pluginzhuishi", text);
}
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(365, 100);
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage()==1?en[value]:cn[value])
  });
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let obj = new Object();
    let root = xmlDoc.getElementsByTagName('root');
    let keys = root[0].getAttributeNames();
    for (let i = 0; i < keys.length; i++) {
      if (root[0].getAttribute(keys[i]) == "null") {
        obj[keys[i]] = "";
      } else {
        obj[keys[i]] = root[0].getAttribute(keys[i]);
      }
    }
    loadConfig(obj);
  }
}
function loadConfig(val) {
  if (val == null) return;
  $('[name=ip]').val(val['ip']).addClass('green');
  $('[name=port]').val(val['port']);
  if (val['enabled'] == "yes") $('[name=connect]').attr('checked', true);
}
$('input[type=number]').on({
  'blur': function () {
    $(this).val(compareVal(this));
  },
  'input':function (e) {
    setConfig();
  },
  'keypress': function (e) {
    setConfig()
    if (e.charCode == 43) return false;
  }
});
$('[type=text]').on("keyup", function () {
  let reg = /^([1-9]|([1-9][0-9])|(1[0-9][0-9])|(2[0-4][0-9])|(25[0-5]))(\.([0-9]|([1-9][0-9])|(1[0-9][0-9])|(2[0-4][0-9])|(25[0-5]))){3}$/;
  let val = $(this).val();
  reg.test(val) ? $(this).addClass('green').attr('value', val).removeClass('red') : $(this).removeClass('green').addClass('red');
  if (!$(this).hasClass('red')) setConfig();
}).blur(function () {
  if ($(this).val() == "" || $(this).hasClass('red')) {
    $(this).val($(this).attr('value')).addClass('green').removeClass('red');
  }else{
    setConfig();
  }
})
function compareVal(obj) {
  let step = $(obj).attr('step').length - 2;
  let v = parseFloat($(obj).val());
  if (isNaN(v)) { v = Number($(obj).attr('value')); }
  let min = parseFloat($(obj).attr('min')),
    max = parseFloat($(obj).attr('max'));
  v = v < min ? min : v;
  v = v > max ? max : v;
  return step <= -1 ? v.toFixed(0) : v.toFixed(step);
}