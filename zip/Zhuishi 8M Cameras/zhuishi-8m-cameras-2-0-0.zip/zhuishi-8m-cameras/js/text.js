var cn = {
  connect: "启用",
  ip: "IP地址:",
  port: "端口号:"
},
  en = {
    connect: "Enabled",
    ip: "IP:",
    port: "Port:"
  };