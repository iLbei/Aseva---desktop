var en = {
    connect_rs485: "Connect RS485",
    com: "COM:",
    mode_name: "Mode Name:"
  },
  cn = {
    connect_rs485: "连接RS485",
    com: "端口:",
    mode_name: "型号名:"
  };