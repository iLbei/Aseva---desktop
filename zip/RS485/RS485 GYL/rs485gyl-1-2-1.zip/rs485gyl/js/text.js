var en = {
    connect_rs485: "Connect",
    com: "COM:",
    mode_name: "Mode Name:"
  },
  cn = {
    connect_rs485: "连接",
    com: "端口:",
    mode_name: "型号名:"
  };