var not_config = "";

$('[name]').click(function () {
  setConfig();
});

$('[name=enabled]').click(function () {
  if ($(this).get(0).checked) {
    enAbled();
    if ($('.message_id').text().indexOf(not_config) != -1) $('.message_id').addClass('red');
  } else {
    disAbled();
  }
});

$('[name=ldw_gt_signal_checked]').click(function () {
  clickLdwGTSignalChecked(this);
  setConfig();
});

$('input[type=number]').on({
  "change": function () {
    $(this).val(compareVal(this, $(this).val()));
  },
  'input': function (e) {
    if (e.which == undefined) {
      var step = $(this).attr("step").length - 2;
      var val = Number($(this).val());
      $(this).val(step > 0 ? val.toFixed(step) : val);
    }
    setConfig();
  },
  'keypress': function (e) {
    if (!(e.charCode >= 48 && e.charCode <= 57) && !(e.charCode == 45 || e.charCode == 46)) {
      return false;
    }
  }
})

$('[type=text]').bind("input propertychange", function () {
  checkTextValue($(this));
  setConfig();
}).blur(function () {
  if ($(this).hasClass('green')) {
    var str = $(this).val();
    if (str.indexOf(",") != -1) {
      var arr = str.split(','),
        newArr = [];
      for (var i = 0; i < arr.length; i++) {
        var v = Number(arr[i]);
        newArr.push(v);
      }
      $(this).val(newArr.join()).attr('value', newArr.join());
    } else {
      if (str != "") {
        var v = Number(str);
        $(this).val(v).attr('value', v);
      } else {
        var v = $(this).attr('value');
        $(this).val(v).attr('value', v);
      }
    }
  } else if ($(this).hasClass('red')) {
    var v = $(this).attr('value');
    $(this).val(v).removeClass('red').addClass('green');
  }
  setConfig();
});

//检查文本框的值
function checkTextValue(obj) {
  var str = $(obj).val();
  if (str.indexOf(',') != -1) {
    var flag = false;
    var arr = str.split(","),
      newArr = [];;
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] == "") {
        flag = true;
        break;
      }
      var v = Number(arr[i]);
      if (arr[i] != "") {
        if (isNaN(v)) {
          flag = true;
          break;
        }
      }
      newArr.push(v);
    }
    if (flag) {
      $(obj).addClass('red').removeClass('green');
    } else {
      $(obj).addClass('green').attr('value', newArr.join());
    }
  } else {
    var v = Number(str);
    if (!isNaN(v) && str != "") { //green
      $(obj).addClass('green').attr('value', v);
    } else if (str != "") { //red
      $(obj).addClass('red').removeClass('green');
    }
  }

}

function clickLdwGTSignalChecked(obj) {
  if (!$(obj).get(0).checked) {
    $('.container>div:nth-of-type(4)').find('[name]').each(function () {
      $(this).removeAttr("disabled").removeClass("disabled_background");
    });
    $('.container>div:nth-of-type(4)').find('span,a,p,label').each(function () {
      $(this).removeClass("disabled_a");
    });
    $('.container>div:nth-of-type(5)').find('input[type=text]').each(function () {
      $(this).attr("disabled", true).addClass("disabled_background");
    });
    $('.container>div:nth-of-type(5)').find('p,a,span,label').each(function () {
      $(this).addClass("disabled_a");
    });
  } else {
    $('.container>div:nth-of-type(4)').find('[name]').each(function () {
      $(this).attr("disabled", true).addClass("disabled_background");
    });
    $('.container>div:nth-of-type(4)').find('p,a,span,label').each(function () {
      $(this).addClass("disabled_a");
    });
    $('.container>div:nth-of-type(5)').find('input[type=text]').each(function () {
      $(this).removeAttr("disabled").removeClass("disabled_background");
    });
    $('.container>div:nth-of-type(5)').find('span,a,p,label').each(function () {
      $(this).removeClass("disabled_a");
    });
  }
  setConfig();
}

function compareVal(obj, val) {
  var step = $(obj).attr('step').length > 2 ? $(obj).attr('step').length - 2 : 0,
    v = Number(val);
  if (isNaN(val) || !Boolean(val)) {
    newVal = Number($(obj).attr('value'));
  } else {
    var v = Number(val);
    var min = Number($(obj).attr('min')),
      max = Number($(obj).attr('max'));
    v = v < min ? min : v;
    v = v > max ? max : v;
    if (step > 0) {
      newVal = Math.round((Math.abs(v) * Math.pow(10, step)).toFixed(1)) / Math.pow(10, step);
      if (v < 0) newVal = -newVal;
    } else {
      newVal = Math.floor(v);
    }
  }
  return step > 0 ? newVal.toFixed(step) : newVal;
}

/**
 * 禁用表单元素
 */
function disAbled() {
  $('.container>div:not(:first-of-type)').find("span,a,p,label").addClass("disabled_a");
  $('.container>div:not(:first-of-type) [type=number]').each(function () {
    $(this).next().children('div').hide();
  });
  $('.container>div:not(:first-of-type) [name]').attr("disabled", true).addClass("disabled_background");
}
/**
 * 启用
 */
function enAbled() {
  // if ($('.message_id').text().indexOf(not_config) != -1) $('.message_id').addClass('red');
  $('.container>div:not(:first-of-type) [name]').removeAttr("disabled").removeClass("disabled_background");
  $('.container>div:not(:first-of-type)').find("a,span,p,label").removeClass("disabled_a");
  clickLdwGTSignalChecked($('[name=ldw_gt_signal_checked]'));
}
/**
 * 选择报文
 */
$('.message_id').click(function () {
  if (!$('[name=enabled]').get(0).checked) return;
  var originID = $(this).text().indexOf(not_config) != -1 ? null : $(this).attr('val');
  biSelectBusMessage("TargetMessage", originID);
});

function biOnSelectedBusMessage(key, info) {
  if (key == "TargetMessage") {
    if (info == null) {
      $('#message_id').removeAttr("val title").text(not_config).removeClass('green');
    } else {
      $('#message_id').attr({
        "val": info.id,
        "title": info.id
      }).text(info.name).addClass('green');
    }
  }
  setConfig();
}
/**
 * 加载配置
 */
function loadConfig(val) {
  $('[name]').each(function () {
    var value = $(this).attr('name');
    var type = $(this).attr('type');
    if (type == 'checkbox') {
      if (val[value] == "True" || val[value] == "yes") $(this).attr('checked', true);
    } else if (type == 'number') {
      $(this).val(compareVal(this, val[value]));
    } else if ($(this).is('select')) {
      $(this).val(val[value]);
    } else if (type == 'text') {
      var v = val[value] == "null" ? "" : val[value];
      if (value != "ldw_dtlc_level1" && value != "ldw_ttlc_level1") {
        v = val[value].substring(0, val[value].lastIndexOf(","));
      }
      $(this).val(v).attr('value', v);
    }
  });
  $('a').each(function () {
    var id = $(this).attr('id');
    if (id == "message_id" && val[id] != 'null') {
      $(this).attr('val', val[id]);
      biQueryBusMessageInfo("TargetMessage", val[id]);
    } else if (val[id] != "null") {
      biQuerySignalInfo(id, val[id]);
      $(this).attr('val', val[id]);
      if ($(this).hasClass('red')) {
        $(this).text(val[id]);
      } else {
        $(this).addClass('green');
        $(this).text(val[id].substring(val[id].lastIndexOf(":") + 1));
      }
    }

  });
  if ($('[name=enabled]').is(":checked")) {
    enAbled();
    if ($('.message_id').text().indexOf(not_config) != -1) $('.message_id').addClass('red');
  } else {
    disAbled();
  }
}

function biOnQueriedSignalInfo(key, signalInfo) {
  if (signalInfo != null) {
    $('#' + key).addClass('green').removeClass('red');
    $('#' + key).parent().attr('title', signalInfo.typeName + ':' + signalInfo.signalName);
  } else {
    $('#' + key).addClass('red').removeClass('green').text($('#' + key).attr('val'));
  }
}
/**
 * 写配置
 */

function setConfig() {
  var text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root";
  text += " sensor_source" + "=\"" + $('select').val() + "\"";
  text += " message_id" + "=\"" + ($('#message_id').attr('val') == undefined ? "null" : $('.message_id').attr('val')) + "\"";
  $('[name]').each(function () {
    var key = $(this).attr('name');
    if ($(this).attr('type') == "checkbox") {
      var val = null;
      if (key == "ldw_always_enable" || key == "lka_always_enable") {
        val = $(this).get(0).checked == true ? "True" : "False";
      } else {
        val = $(this).get(0).checked == true ? "yes" : "no";
      }
      text += " " + key + "=\"" + val + "\"";
    } else if ($(this).attr('type') == "number") {
      text += " " + key + "=\"" + compareVal(this, $(this).val()) + "\"";
    } else if ($(this).attr('type') == "text") {
      if (key == "ldw_dtlc_level1" || key == "ldw_ttlc_level1") {
        if ($(this).hasClass("green")) {
          var vv = $(this).attr("value");
          var reg = new RegExp(",", "g");
          var res = vv.replace(reg, "");
          text += " " + key + "=\"" + res + "\"";
        }
      } else {
        text += " " + key + "=\"" + ($(this).val() == "" ? "null" : $(this).val() + ",") + "\"";
      }
    }
  });
  $('a').each(function () {
    var idName = $(this).attr('id');
    if (idName != "message_id") {
      var val = $(this).attr('val') == undefined ? "null" : $(this).attr('val');
      text += " " + idName + "=\"" + val + "\"";
    }
  });
  text += " />";
  biSetModuleConfig("ldw-lka-evaluation.adasevaluation", text);
}

/**
 * 选择信号
 * @param {} obj 
 */
var idName = null; //选择的元素的id名
function onClick(obj) {
  if (!$('[name=enabled]').get(0).checked) return;
  if ($(obj).hasClass("disabled_a")) return;
  var originID = null;
  if ($(obj).text().indexOf(not_config) == -1) originID = $(obj).attr('val');
  idName = "#" + $(obj).attr('id');
  var scale = $(obj).attr('scaleVal');
  scale = parseInt(scale);
  biSelectSignal("TargetSignal", originID, false, null, false, scale, "[m]");
}

function biOnSelectedSignal(key, valueInfo, signBitInfo, scale) {
  if (key == "TargetSignal") {
    if (valueInfo == null) {
      $(idName).removeClass('green');
      $(idName).text(not_config);
      $(idName).removeAttr('val');
      $(idName).parent().removeAttr('title');
    } else if (valueInfo.typeName == undefined) {
      $(idName).addClass('red').removeClass('green');
    } else {
      $(idName).text(valueInfo.signalName);
      $(idName).attr("val", valueInfo.id);
      $(idName).attr('scaleVal', scale);
      $(idName).addClass('green');
      $(idName).parent().attr('title', valueInfo.typeName + ':' + valueInfo.signalName)
    }
  }
  setConfig();
}

function biOnQueriedBusMessageInfo(key, busMessageInfo) {
  if (busMessageInfo == null) {
    $('#message_id').text($('#message_id').attr('val'));
    $('#message_id').removeClass('green').addClass('red');
  } else {
    $('#message_id').attr("val", busMessageInfo.id);
    $('#message_id').text(busMessageInfo.name);
    $('#message_id').addClass('green');
    $('#message_id').parent().attr('title', busMessageInfo.id)
  }
  setConfig();
}

function biOnInitEx(config, moduleConfigs) {
  var flag = biGetLanguage() == 1;
  var lang = flag ? en : cn;
  $('[language]').each(function () {
    var value = $(this).attr('language');
    $(this).text(lang[value])
  });
  not_config = lang["not_config"];
  if (!flag) {
    $('.container>div:nth-of-type(3)>div>div>div').css('width', '235px');
    $('.container>div:nth-of-type(3)>.right>div>div').css('width', '215px');
  }
  for (var key in moduleConfigs) {
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    var countrys = xmlDoc.getElementsByTagName('root');
    var keys = countrys[0].attributes;
    var obj = new Object();
    for (var i = 0; i < keys.length; i++) {
      obj[keys[i].nodeName] = keys[i].nodeValue;
    };
    loadConfig(obj);
  }
}