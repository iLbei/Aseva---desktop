let cn = {
  inputPath: "数据路径:",
  pixelFormat: "像素格式:",
  pixel_Format: "像素格式转换",
  not_config:"(未配置)"
},
  en = {
    inputPath: "Data path:",
    pixelFormat: "Pixel format:",
    pixel_Format: "Pixel Format",
    not_config:"(Not configured)"
  };