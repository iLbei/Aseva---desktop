var not_config = "",
  reg = /^[a-zA-Z]:/;
$("a[name=inputPath]").click(function () {
  biSelectPath("inputPath", BISelectPathType.Directory, null);
})
function biOnSelectedPath(key, path) {
  if (path == null) {
    $('[name=' + key + ']').removeAttr('title').html(not_config);
  } else {
    $('[name=' + key + ']').attr('title', path + (reg.test(path) ? '\\' : '\/')).html(path + (reg.test(path) ? '\\' : '\/'));
  };
  setConfig();
}
$('button').on({
  'click': function () {
    var task_config = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><config ";
    $('a').each(function () {
      var name = $(this).attr('name');
      var value = $(this).html();
      task_config += name + "=\"" + value + "\" ";
    });
    $('select').each(function () {
      var name = $(this).attr('name');
      task_config += name + "=\"" + $(this).val() + "\" ";
    })
    task_config += "/></root>";
    // if ($("[name=pixelFormat]").val() != 0 && $("[name=inputPath]").html().indexOf(not_config) != -1) {
      if ($("[name=pixelFormat]").val() != 0) {
      biRunStandaloneTask("Pixel Format", "pixel-format-convert-task.aspluginpixelformatconvert", task_config)
    }
  }
})
/*----------配置读取与存储-----------*/
// 表单内容改变保存配置
$('[name]').change(function () {
  setConfig();
});
//保存配置
function setConfig() {
  var text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><config ";
  $('.container [name]').each(function () {
    var name = $(this).attr('name');
    var val = $(this).val();
    var type = $(this).attr('type');
    if (type == 'checkbox') {
      text += name + "=\"" + ($(this).is(':checked') ? "yes" : "no") + "\" ";
    } else if (type == "number") {
      text += name + "=\"" + compareVal(this, val) + "\" ";
    } else if ($(this).is("a")) {
      text += name + "=\"" + $(this).html() + "\" ";
    } else {
      text += name + "=\"" + val + "\" ";
    }
  });
  text += " /></root>";
  biSetModuleConfig("pixel-format-convert.aspluginpixelformatconvert", text);
}
//初始化
function biOnInitEx(config, moduleConfigs) {
  switch (biGetUIBackend()) {
    case 3: { // Winform
      $('body').css("background", "rgb(240,240,240)");
      break;
    }
    case 4: { // WPF
      $('body').css("background", "rgb(255,255,255)");
      break;
    }
    default: { //others
      $('body').css("background", "rgb(250,250,250)");
    }
  }
  if (biGetLanguage() == 1) {
    $('[language]').each(function () {
      var value = $(this).attr('language');
      $(this).html(en[value]);
    });
    not_config = "(Not configured)";
  } else {
    $('[language]').each(function () {
      var value = $(this).attr('language');
      $(this).html(cn[value]);
      not_config = "(未配置)";
    });
  }
  for (var key in moduleConfigs) {
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    var obj = new Object();
    var root = xmlDoc.getElementsByTagName('root');
    var keys = root[0].childNodes[0].attributes;
    for (var i = 0; i < keys.length; i++) {
      //获取root自身字节的属性
      obj[keys[i].nodeName] = keys[i].nodeValue;
    }
    loadConfig(obj);
  }
}
function loadConfig(obj) {
  if (obj == null) return;
  $('.container [name]').each(function () {
    var val = obj[$(this).attr('name')];
    var type = $(this).attr('type');
    if (type == 'checkbox') {
      $(this).prop('checked', val == 'yes' ? true : false);
    } else if (type == "number") {
      $(this).val(compareVal(this, val));
    } else if ($(this).is('a')) {
      $(this).attr("title", val == "" || val == "null" ? not_config : val).html(val == "" || val == "null" ? not_config : val);
    } else {
      $(this).val(val);
    }
  })
}