var cn = {
  inputPath: "数据路径:",
  pixelFormat: "像素格式:",
  pixel_Format: "像素格式转换",
  not_config:"<未配置>",
  resizeScale:"缩放大小:",
  videoChannels:"视频通道",
  local:"本地"
},
  en = {
    inputPath: "Data path:",
    pixelFormat: "Pixel format:",
    pixel_Format: "Pixel format",
    not_config:"<Not configured>",
    resizeScale:"Resize scale:",
    videoChannels:"Video channels",
    local:"Local"
  };