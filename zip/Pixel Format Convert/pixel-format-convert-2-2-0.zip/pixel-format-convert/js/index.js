var not_config = "",
  reg = /^[a-zA-Z]:/,
  data = { "start_posix_time": "", "time_ratio": "" },
  split = "",
  start_posix_time = [],
  time_ratio = [];
$("a[name=inputPath]").click(function () {
  biSelectPath("inputPath", BISelectPathType.Directory, null);
})

function biOnSelectedPath(key, path) {
  data = { "start_posix_time": "", "time_ratio": "" };
  start_posix_time = [];
  time_ratio = [];
  if (path == null) {
    $('[name=' + key + ']').removeAttr('title').text(not_config);
  } else {
    $('[name=' + key + ']').attr('title', path + split).text(path + split);
    biQueryDirsInDirectory(path);
  }
  $("[name=start_posix_time],[name=time_ratio]").attr({ "checked": false });
  // setTimeout(function () {
  // utcDis()
  // }, 250)
  setConfig();
}
// function utcDis() {
//   console.log(start_posix_time,time_ratio);
//   if (start_posix_time.length == 0) {
//     $("[name=start_posix_time]").attr({ "disabled": true }).next().addClass("disabled_a");
//   } else {
//     $("[name=start_posix_time]").attr({ "disabled": false }).next().removeClass("disabled_a");
//   }
//   if (time_ratio.length == 0) {
//     $("[name=time_ratio]").attr({ "disabled": true }).next().addClass("disabled_a")
//   } else {
//     $("[name=time_ratio]").attr({ "disabled": false }).next().removeClass("disabled_a");
//   }
// }
$('button').on({
  'click': function () {
    var task_config = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><config ";
    $('a').each(function () {
      var name = $(this).attr('name');
      var value = $(this).text();
      task_config += name + "=\"" + value + "\" ";
    })
    $('select').each(function () {
      var name = $(this).attr('name');
      task_config += name + "=\"" + $(this).val() + "\" ";
    })
    var videoChannels = "";
    $(".container>ul>li:nth-child(4) input:checked").each(function () {
      videoChannels += $(this).attr("value") + ",";
    });
    task_config += "videoChannels=\"" + videoChannels.substring(0, videoChannels.length - 1) + "\" ";
    task_config += "/></root>";
    if ($("[name=pixelFormat]").val() != 0) {
      biRunStandaloneTask("Pixel Format", "pixel-format-convert-task.aspluginpixelformatconvert", task_config)
    }
  }
})
/*----------配置读取与存储-----------*/
// 表单内容改变保存配置
$('[name],input').change(function () {
  if ($(this).attr("type") == "checkbox") {
    var name = $(this).attr("name");
    switch (name) {
      case "start_posix_time": {
        data[name] = $(this).is(":checked") ? start_posix_time : "null";
        break;
      }
      case "time_ratio": {
        data[name] = $(this).is(":checked") ? time_ratio : "null";
        break;
      }
      default:
        break;
    }
  }
  setConfig();
});
//保存配置
function setConfig() {
  var text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><config ";
  $('.container [name]').each(function () {
    var name = $(this).attr('name');
    var val = $(this).val();
    var type = $(this).attr('type');
    if (type == 'checkbox') {
      text += name + "=\"" + ($(this).is(":checked") ? (Array.isArray(data[name]) ? data[name].join(",") : data[name]) : "null") + "\" ";
    } else if ($(this).is("a")) {
      text += name + "=\"" + ($(this).text().indexOf(not_config) == -1 ? $(this).text() : "") + "\" ";
    } else {
      text += name + "=\"" + val + "\" ";
    }
  });
  var videoChannels = "";
  $(".container>ul>li:nth-child(4) input:checked").each(function () {
    videoChannels += $(this).attr("value") + ",";
  });
  text += "videoChannels=\"" + videoChannels.substring(0, videoChannels.length - 1) + "\" ";
  text += " /></root>";
  biSetModuleConfig("pixel-format-convert.aspluginpixelformatconvert", text);
}

//初始化
function biOnInitEx(config, moduleConfigs) {
  var lang = biGetLanguage() == 1 ? en : cn;
  $('[language]').each(function () {
    var value = $(this).attr('language');
    $(this).text(lang[value]);
  });
  not_config = lang["not_config"];
  for (var key in moduleConfigs) {
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    var obj = {};
    var root = xmlDoc.getElementsByTagName('root');
    var keys = root[0].childNodes[0].attributes;
    for (var i = 0; i < keys.length; i++) {
      //获取root自身字节的属性
      obj[keys[i].nodeName] = keys[i].nodeValue;
    }
    loadConfig(obj);
  }
}

function biOnQueriedDirsInDirectory(dirs, path) {
  var lists = dirs[0].split("\n");
  for (var i of lists) {
    biQueryFileExist(i + split + "meta.xml");
  }
}

function biOnQueriedFileExist(exist, path) {
  if (exist) {
    biQueryFileText(path);
  }
}

function biOnQueriedFileText(text, path) {
  var parser = new DOMParser();
  var xmlDoc = parser.parseFromString(text, "text/xml");
  var root = xmlDoc.getElementsByTagName('root');
  var posix = root[0].getAttribute("start_posix_utc");
  var ratio = root[0].getAttribute("time_ratio_to_utc");
  start_posix_time.push(posix);
  time_ratio.push(ratio);
}

function loadConfig(obj) {
  if (obj == null) return;
  $('.container [name]').each(function () {
    var val = obj[$(this).attr('name')];
    var type = $(this).attr('type');
    if (type == 'checkbox') {
      $(this).prop('checked', val != 'null' && val ? true : false);
    } else if ($(this).is('a')) {
      if (val.trim().length > 0 && val != "null") {
        $(this).attr("title", val).text(val);
        split = reg.test(val) ? "\\" : "/";
        biQueryDirsInDirectory(val);
      } else {
        $(this).text(not_config);
      }
    } else {
      $(this).val(val);
    }
  });
  if (obj["videoChannels"].length > 0) {
    if (obj["videoChannels"].length > 2 && obj["videoChannels"].indexOf(",") != -1) {
      var val = obj["videoChannels"].split(",");
      for (let i in val) {
        $(".container>ul>li:nth-child(4) input[value=" + val[i] + "]").attr("checked", true);
      }
    } else if (obj["videoChannels"].length <= 2 && obj["videoChannels"].indexOf(",") == -1) {
      $(".container>ul>li:nth-child(4) input[value=" + obj["videoChannels"] + "]").attr("checked", true);
    }
  }
  setTimeout(function () {
    data = { "start_posix_time": start_posix_time, "time_ratio": time_ratio };
  // utcDis();
  }, 300)
}