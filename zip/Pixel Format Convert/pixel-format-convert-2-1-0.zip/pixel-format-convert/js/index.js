var not_config = "",
  reg = /^[a-zA-Z]:/;
$("a[name=inputPath]").click(function () {
  biSelectPath("inputPath", BISelectPathType.Directory, null);
})

function biOnSelectedPath(key, path) {
  if (path == null) {
    $('[name=' + key + ']').removeAttr('title').text(not_config);
  } else {
    $('[name=' + key + ']').attr('title', path + (reg.test(path) ? '\\' : '\/')).text(path + (reg.test(path) ? '\\' : '\/'));
  }
  setConfig();
}
$('button').on({
  'click': function () {
    var task_config = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><config ";
    $('a').each(function () {
      var name = $(this).attr('name');
      var value = $(this).text();
      task_config += name + "=\"" + value + "\" ";
    })
    $('select').each(function () {
      var name = $(this).attr('name');
      task_config += name + "=\"" + $(this).val() + "\" ";
    })
    var videoChannels = "";
    $(".container>ul>li:nth-child(4) input:checked").each(function () {
      videoChannels += $(this).attr("value") + ",";
    });
    task_config += "videoChannels=\"" + videoChannels.substring(0, videoChannels.length - 1) + "\" ";
    task_config += "/></root>";
    if ($("[name=pixelFormat]").val() != 0) {
      biRunStandaloneTask("Pixel Format", "pixel-format-convert-task.aspluginpixelformatconvert", task_config)
    }
  }
})
/*----------配置读取与存储-----------*/
// 表单内容改变保存配置
$('[name],input').change(function () {
  setConfig();
});
//保存配置
function setConfig() {
  var text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><config ";
  $('.container [name]').each(function () {
    var name = $(this).attr('name');
    var val = $(this).val();
    var type = $(this).attr('type');
    if (type == 'checkbox') {
      text += name + "=\"" + ($(this).is(':checked') ? "yes" : "no") + "\" ";
    } else if (type == "number") {
      text += name + "=\"" + compareVal(this, val) + "\" ";
    } else if ($(this).is("a")) {
      text += name + "=\"" + ($(this).text().indexOf(not_config) == -1 ? $(this).text() : "") + "\" ";
    } else {
      text += name + "=\"" + val + "\" ";
    }
  });
  var videoChannels = "";
  $(".container>ul>li:nth-child(4) input:checked").each(function () {
    videoChannels += $(this).attr("value") + ",";
  });
  text += "videoChannels=\"" + videoChannels.substring(0, videoChannels.length - 1) + "\" ";
  text += " /></root>";
  biSetModuleConfig("pixel-format-convert.aspluginpixelformatconvert", text);
}

//初始化
function biOnInitEx(config, moduleConfigs) {
  var lang = biGetLanguage() == 1 ? en : cn;
  $('[language]').each(function () {
    var value = $(this).attr('language');
    $(this).text(lang[value]);
  });
  not_config = lang["not_config"];
  for (var key in moduleConfigs) {
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    var obj = {};
    var root = xmlDoc.getElementsByTagName('root');
    var keys = root[0].childNodes[0].attributes;
    for (var i = 0; i < keys.length; i++) {
      //获取root自身字节的属性
      obj[keys[i].nodeName] = keys[i].nodeValue;
    }
    loadConfig(obj);
  }
}

function loadConfig(obj) {
  if (obj == null) return;
  $('.container [name]').each(function () {
    var val = obj[$(this).attr('name')];
    var type = $(this).attr('type');
    if (type == 'checkbox') {
      $(this).prop('checked', val == 'yes' ? true : false);
    } else if (type == "number") {
      $(this).val(compareVal(this, val));
    } else if ($(this).is('a')) {
      if (val.trim().length > 0 && val != "null") {
        $(this).attr("title", val).text(val);
      } else {
        $(this).text(not_config);
      }
    } else {
      $(this).val(val);
    }
  });
  if (obj["videoChannels"].length > 0) {
    if (obj["videoChannels"].indexOf(",") != -1) {
      var val = obj["videoChannels"].split(",");
      for (let i in val) {
        $(".container>ul>li:nth-child(4) input[value=" + val[i] + "]").attr("checked", true);
      }
    }
  }
}