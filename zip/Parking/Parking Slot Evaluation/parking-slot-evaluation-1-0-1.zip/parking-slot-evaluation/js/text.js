var cn = {
  evaEnable: "启用",
  not_config:"<未配置>"
},
  en = {
    evaEnable: "Enabled",
    not_config:"<Not Configured>"
  };