var cn = {
  wlan_enable: "启用",
  profileName: "网络名称:"
},
  en = {
    wlan_enable: "Enabled",
    profileName: "Profile Name:"
  };