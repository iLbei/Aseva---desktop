var cn = {
  enable: "启用",
  comPort:"Com端口号:",
  comBaudRate:"Com波特率:",
  protocolName:"协议名:"
},
  en = {
    enable: "Enable",
    comPort:"Com Port:",
    comBaudRate:"Com Baud Rate:",
    protocolName:"Protocol Name:"
  };