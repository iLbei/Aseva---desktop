var dialogConfig = {};
function checkTxt(obj) {
  if ($(obj).val() != "") {
    if (!$(obj).prev().hasClass("green")) $(obj).prev().addClass("green");
  } else {
    $(obj).prev().removeClass("green");
  }
}

function checkText(obj) {
  var val = $(obj).val();
  var filter =
    /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  if (filter.test(val)) {
    if (!$(obj).prev().hasClass("green")) $(obj).prev().addClass("green");
  } else {
    $(obj).prev().removeClass("green");
  }
}
$(".mail>.content")
  .find("[name=enabled]")
  .click(function () {
    checkMail();
  });
$(".mail [type=text],.mail [type=password]").bind(
  "input propertychange",
  function () {
    var name = $(this).attr("name");
    if (name == "from" || name == "to") {
      checkText($(this));
    } else {
      checkTxt($(this));
    }
  }
);

function checkMail() {
  var flag = $(".mail>.content").find("[name=enabled]").get(0).checked;
  $(".mail>.content>div:not(:first-of-type)").each(function () {
    $(this)
      .find("[name]")
      .each(function () {
        !flag ? $(this).attr("disabled", true).addClass("disabled_background") : $(this).removeAttr("disabled").removeClass("disabled_background");
      });
    $(this)
      .find("span")
      .each(function () {
        !flag ? $(this).addClass("not_span") : $(this).removeClass("not_span");
      });
  });
  if (flag) {
    $("p").removeClass("not_span");
  } else {
    $("p").addClass("not_span");
  }
}

$("button").click(function () {
  $(".mail [name]").each(function () {
    var name = $(this).attr("name");
    var type = $(this).attr("type");
    if (name != "" && name != "remember") {
      var v = "";
      if (type == "checkbox") {
        v = $(this).is(":checked") ? "yes" : "no";
      } else if (type != "button" && type != "password") {
        v = $(this).val();
      } else if (type == "password" && $(this).val() != "") {
        if ($("[name=remember]").is(":checked")) {
          v = "[[SRC]]" + $(this).val() + "[[SRC]]";
        } else {
          v = $(this).val();
        }

      }
      dialogConfig.mail[name] = v;
    }
    // });
    // var pwd = $("[name=password]").val();
    //   var flag = $("[name=remember]").get(0).checked;
    //   if (pwd != "" && pwd != undefined && !flag) {
    //     sessionStorage.setItem("event_pwd", pwd);
  })
  biSetLocalVariable("event_configuration", JSON.stringify(dialogConfig));
  setConfig();
  biCloseChildDialog();
})
/**
 * 设置配置
 * @param {*} object
 */
function setConfig() {
  var arrBox = dialogConfig.arr;
  var textInfo = '<?xml version="1.0" encoding="utf-8"?>';
  textInfo +=
    '<root location_source="' + dialogConfig.location_source + '"' + ">";
  for (var i = 0; i < arrBox.length; i++) {
    var box = arrBox[i];
    textInfo += '<e name="' + box.name + '"';
    textInfo += ' enabled="' + box.enabled + '"';
    textInfo += ' condition="' + box.condition + '"';
    textInfo += ' send_mail="' + box.send_mail + '"';
    textInfo += ' binding_video="' + box.binding_video + '"';
    textInfo += ' binding_obj_sensor="' + box.binding_obj_sensor + '"';
    textInfo += ' binding_lane_sensor="' + box.binding_lane_sensor + '"';
    textInfo += ' rec_bus_enabled="' + box.rec_bus_enabled + '"';
    textInfo += ' rec_bus_positive="' + box.rec_bus_positive + '"';
    textInfo += ' rec_bus_negative="' + box.rec_bus_negative + '"';
    if (box.tablesigArr.length == 0 && box.transmsgArr.length == 0) {
      textInfo += " />";
    } else {
      textInfo += " >";
      for (var j = 0; j < box.tablesigArr.length; j++) {
        var tablesig = box.tablesigArr[j];
        textInfo += '<tablesig name="' + tablesig.name + '"';
        textInfo += ' signal="' + tablesig.signal + '"';
        textInfo += ' scale="' + tablesig.scale + '"/>';
      }
      for (var j = 0; j < box.transmsgArr.length; j++) {
        var transmsg = box.transmsgArr[j];
        textInfo += '<transmsg ch="' + transmsg.ch + '"';
        textInfo += ' id="' + transmsg.id + '"';
        textInfo += ' data="' + transmsg.data + '"/>';
      }
      textInfo += "</e>";
    }
  }
  textInfo += "<mail_config";
  var mail = dialogConfig.mail;
  for (var i in mail) {
    textInfo += " " + i + '="' + mail[i] + '"';
  }
  textInfo += " /></root>";
  biSetModuleConfig("event.system", textInfo);
}

function biOnInitEx(config, moduleConfigs) {
  dialogIndex = config;
  if (biGetLanguage() == 1) {
    $("[language]").each(function () {
      var value = $(this).attr("language");
      $(this).html(en[value]);
    });
  } else {
    $("[language]").each(function () {
      var value = $(this).attr("language");
      $(this).html(cn[value]);
    });
  }
  for (var key in moduleConfigs) {
    xmlParse(moduleConfigs[key]);
  }
}

function xmlParse(text) {
  if (text == null) return;
  var parser = new DOMParser();
  var xmlDoc = parser.parseFromString(text, "text/xml");
  var countrys = xmlDoc.getElementsByTagName("root");
  var object = new Object();
  object.location_source = $(countrys).attr("location_source");
  var arr = [];
  for (var i = 0; i < countrys[0].children.length; i++) {
    var keyss = countrys[0].children[i].attributes;
    var obj = new Object();
    for (var j = 0; j < keyss.length; j++) {
      obj[keyss[j].nodeName] = keyss[j].nodeValue;
    }
    var arr2 = [],
      arr3 = [];
    for (var n = 0; n < countrys[0].children[i].children.length; n++) {
      var o = new Object();
      var keysss = countrys[0].children[i].children[n].attributes;
      for (var m = 0; m < keysss.length; m++) {
        o[keysss[m].nodeName] = keysss[m].nodeValue;
      }
      if (o.name != undefined) {
        arr2.push(o);
      } else {
        arr3.push(o);
      }
    }
    if (obj.from == undefined) {
      obj.tablesigArr = arr2;
      obj.transmsgArr = arr3;
      arr.push(obj);
    } else {
      object.mail = obj;
    }
  }
  object.arr = arr;
  dialogConfig = object;
  loadConfig();
}

function loadConfig() {
  $(".mail [name]").each(function () {
    var name = $(this).attr("name");
    var type = $(this).attr("type");
    if (type == "checkbox" && name != "remember") {
      dialogConfig.mail[name] == "yes" ?
        $(this).attr("checked", true) :
        $(this).removeAttr("checked");
    } else if (type == "password") {
      if (dialogConfig.mail[name] != undefined) {
        var v = dialogConfig.mail[name];
        // var t = v.split("[[ENC]]");
        // if (v.indexOf("[[ENC]]") != -1) {
        //   $(this).val(t[1]);
        //   $(".mail").find("[name=remember]").attr("checked", true);
        // }
        // if (v.indexOf("[[SRC]]") != -1) {
        //   var t2 = v.split("[[SRC]]");
        //   $(this).val(t2[1]);
        //   $(".mail").find("[name=remember]").attr("checked", true);
        // }
        v.replace(/\[\[SRC\]\]|\[\[ENC\]\]/g, "");
        // $(this).val(v.replace(/\[\[SRC\]\]/g, ""));
        $(this).val("*********");
        $(".mail").find("[name=remember]").attr("checked", true);
      }
      checkTxt($(this));
    } else {
      var text =
        dialogConfig.mail[name] == "null" ? "" : dialogConfig.mail[name];
      $(this).val(text);
      if (name == "from" || name == "to") {
        checkText($(this));
      } else {
        checkTxt($(this));
      }
    }
  });
  var flag = $("[name=remember]").get(0).checked;
  //   if (!flag) {
  //     var pwd = sessionStorage.getItem("event_pwd");
  //     if (pwd != undefined) $("[name=password]").val(pwd);
  //     checkTxt($("[name=password]"));
  //   }
  checkMail();
}