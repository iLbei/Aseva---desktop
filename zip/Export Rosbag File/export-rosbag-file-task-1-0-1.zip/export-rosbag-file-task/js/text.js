var cn = {
    Enabled: "启用",
    export_data_path: "Rosbag导出路径:",
    not_config: "<未配置>",
    export:"导出Rosbag"
  },
  en = {
    Enabled: "Enabled",
    export_data_path: "Export Rosbag File Path:",
    not_config: "<Not Configured>",
    export:"Export Rosbag"
  };