var zh = {
  enableNOASceneExtract: "启用",
  sceneOffset: "起始偏移[秒]:",
  sceneLength: "场景长度[秒]:",
},
  en = {
    enableNOASceneExtract: "Enable",
    sceneOffset: "Start offset [s]:",
    sceneLength: "Scene length [s]:",
  };