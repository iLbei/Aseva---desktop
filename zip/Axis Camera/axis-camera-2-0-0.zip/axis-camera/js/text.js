let cn = {
  ip: "IP地址",
  connect: "连接",
  user: "用户名",
  pass: "密码",
},
  en = {
    ip: "IP address",
    connect: "Connect",
    user: "User name",
    pass: "Password",
  };