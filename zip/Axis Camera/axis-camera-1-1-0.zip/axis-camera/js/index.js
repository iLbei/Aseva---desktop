let language = sessionStorage.getItem("language");
$('[type=checkbox]').click(function () {
  $('.all').removeClass('flag');
  setConfig()
});

$('body').keydown(function (event) {
  let e = event || window.event;
  if (e.keyCode == 46) {
    if ($('.all').hasClass('flag')) {
      let i = 0;
      while (i < $('.table>div>div').length - 1) {
        $('.table>div>div')[i].remove();
        i = 0;
      }
      $('[name=connect]').removeAttr('checked');
      $('[name=connect]').attr("disabled", "disabled").next().addClass('disabled');
    } else {
      let obj = $('.blue2');
      if ($(obj).html() != undefined) {
        let next = $(obj).parent().next();
        if ($(next).html() != undefined) $(obj).parent().remove();
        let i = $('.table>div>div').length;
        if (i == 1) {
          $('[name=connect]').removeAttr('checked');
          $('[name=connect]').attr("disabled", "disabled").next().addClass('disabled');
        }
      }
    }
  }
  $('.all').removeClass('flag');
  setConfig();
});

/**
 * 文本框输入字符
 * @param {*} obj  当前元素
 */

function keyUp(obj) {
  let val = "<div class=\"fixclear input\"><div onclick=\"onClick(this)\" class=\"select\"></div><div><input type=\"text\" name=\"ip\" id=\"\"></div><div><input type=\"text\" name=\"user\" id=\"\"></div><div><input type=\"text\" name=\"pass\" id=\"\"></div></div>";
  let flag = $(obj).parent().parent().next()[0];
  if (!flag) {
    $(obj).parents().find('.table>div').append(val);
  }
  $('.all').removeClass('flag');
}

/**
 * 文本框点击
 * @param {*}  
 */
function inputClick(obj) {
  $('[type=text]').each(function () {
    $(this).removeClass('blue');
  });
  $('.input>div').each(function () {
    $(this).removeClass('blue');
  });
  $(obj).addClass('blue').parent().removeClass('blue2')
  $('.select').each(function () {
    $(this).removeClass('blue2');
  });
  $('.all').removeClass('flag');
}
function removeBlue(obj) {
  $(obj).removeClass('blue')
}

$('#table').on('click', '.input>div:nth-child(1)', function () {
  onClick(this);
})
$('#table').on('click', '.input>div>input', function (e) {
  inputClick(this)
})
$('#table').on('keydown', 'input', function () {
  keyUp(this)
});
$('#table').on('input', '.table input', function () {
  setConfig();
  $(this).removeClass('blue')
})
$('#table').on('blur', '.table input[name="ip"]', function () {
  let count = 0;
  $('input[name="ip"]').each(function () { if ($(this).val() == "") { count++ } })
  if (count == $('.table>div>div').length) {
    $('[name="connect"]').attr('disabled', true).prop('checked', false).next().addClass('disabled')
  } else {
    $('[name="connect"]').attr('disabled', false).next().removeClass('disabled')
  }
})
/**
 * 表格最左边点击事件
 */
function onClick(obj) {
  if (!$(obj).hasClass('all')) {
    $('.select').each(function () {
      $(this).removeClass('blue2').siblings().children().removeClass('blue');
    });
    $(obj).addClass('blue2').siblings().children().addClass('blue');
    $('.all').removeClass('flag');
  } else {
    $('.table>div>div').each(function () {
      $(this).children("div:first-of-type").addClass('blue2');
      $(this).find('input').addClass('blue');
    });
    $(obj).addClass('flag');
  }
}

/**
 *  页面加载时,读取本地配置
 */
function loadConfig(config) {
  if (config == null) return;
  let val = JSON.parse(config);
  val.connect == "yes" ? $('[type=checkbox]').attr('checked', true).prop('checked', true) : $('[type=checkbox]').removeAttr('checked');
  let arr = val.arr;
  $('.table>div').html("")
  for (let i = 0; i < arr.length; i++) {
    let v = arr[i];
    let val = "<div class=\"fixclear input\"><div onclick=\"onClick(this)\" class=\"select\"></div><div><input type=\"text\" value=\"" + v.ip + "\" name=\"ip\" id=\"\"></div><div><input type=\"text\" value=\"" + v.user + "\" name=\"user\" id=\"\"></div><div><input type=\"text\" value=\"" + v.pass + "\" name=\"pass\" id=\"\"></div></div>";
    $('.table>div').append(val);
  }
  let valLast = "<div class=\"fixclear input\"><div onclick=\"onClick(this)\" class=\"select\"></div><div><input type=\"text\" name=\"ip\" id=\"\"></div><div><input type=\"text\" name=\"user\" id=\"\"></div><div><input type=\"text\" name=\"pass\" id=\" \"></div></div>";
  $('.table>div').append(valLast);
  let i = $('.table>div>div').length;
  if (i == 1) {
    $('[name=connect]').removeAttr('checked');
    $('[name=connect]').attr("disabled", "disabled").next().addClass('disabled');
  } else {
    $('[name=connect]').attr("disabled", false).next().removeClass('disabled');
  }
}
$(function () {
  let i = $('.table>div>div').length;
  if (i == 1) {
    $('[name=connect]').removeAttr('checked');
    $('[name=connect]').attr("disabled", "disabled").next().addClass('disabled');
  } else {
    $('[name=connect]').attr("disabled", false).next().removeClass('disabled');
  }
})
if (language != null) {
  changeLanguage(language);
}

/**
 * 写配置
 */

function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
  let val = $('[type=checkbox]').get(0).checked == true ? "yes" : "no";
  text += "<root connect=\"" + val + "\" start_end_interval=\"20\">";
  $('.table>div>div:not(:last-of-type)').each(function () {
    text += "<addr";
    $(this).find('[name]').each(function () {
      let key = $(this).attr('name');
      text += " " + key + "=\"" + $(this).val() + "\"";
    });
    text += " />";
  });
  text += "</root>";
  biSetModuleConfig("axis-camera.axiscamera", text);
}
/**
 * 判断中英文
 */
function changeLanguage(type) {
  if (type == 1) {
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(en[value])
    });
  } else {
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(cn[value])
    });
  }
}

function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(490, 235)
  let type = biGetLanguage();
  changeLanguage(type);
  sessionStorage.setItem("language", type);
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('root');
    let keys = countrys[0].getAttributeNames();
    let obj = new Object();
    for (let i = 0; i < keys.length; i++) {
      obj[keys[i]] = countrys[0].getAttribute(keys[i]);
    };
    let arr2 = [];
    for (let i = 0; i < countrys[0].childNodes.length; i++) {
      let keyss = countrys[0].childNodes[i].getAttributeNames();
      let o = new Object();
      for (let n = 0; n < keyss.length; n++) {
        o[keyss[n]] = countrys[0].childNodes[i].getAttribute(keyss[n]);
      };
      arr2.push(o);
    }
    obj.arr = arr2;
    loadConfig(JSON.stringify(obj));
  }
}
