var zh = {
  not_config: "<Empty>",
  detectionEnable: "Enable",
  detectionVideoChannel: "Detection camera:",
  confidenceThresh: "Confidence thresh:",
  nmsThresh: "NMS thresh:",
  objectThresh: "Object thresh:",
  modelPath: "Model path:",
  classNamesPath: "Class names path:",
  usingCUDA: "Using CUDA:"
},
  en = {
    not_config: "<Empty>",
    detectionEnable: "Enable",
    detectionVideoChannel: "Detection camera:",
    confidenceThresh: "Confidence thresh:",
    nmsThresh: "NMS thresh:",
    objectThresh: "Object thresh:",
    modelPath: "Model path:",
    classNamesPath: "Class names path:",
    usingCUDA: "Using CUDA:"
  };