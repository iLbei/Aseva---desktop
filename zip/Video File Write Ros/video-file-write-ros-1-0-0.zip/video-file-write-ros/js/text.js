var cn = {
  enabled: "启用",
  video0:"视频通道1:",
  video1:"视频通道2:",
  video2:"视频通道3:",
  video3:"视频通道4:",
},
  en = {
    enabled: "Enabled",
    video0:"Video CH1:",
    video1:"Video CH2:",
    video2:"Video CH3:",
    video3:"Video CH4:",
  };