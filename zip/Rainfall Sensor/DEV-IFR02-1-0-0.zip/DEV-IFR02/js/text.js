var zh = {
  connect: "连接",
  com_br: "波特率[bps]:",
  com_port: "端口:",
},
  en = {
    connect: "Connect",
    com_br: "Baud Rate [bps]:",
    com_port: "COM Port:",
  };