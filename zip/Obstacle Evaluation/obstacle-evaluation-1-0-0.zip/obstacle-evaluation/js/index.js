
$('input[type=number]').on({
  'blur': function (e) {
    $(this).val(compareVal(this, $(this).val()));
  },
  'keypress': function (e) {
    if (e.charCode == 101 || e.charCode == 43) {
      return false;
    }
  },
  "input": function () {
    setConfig();
  }
})
//有input type=number 情况下比较大小
function compareVal(obj, val) {
  let step = $(obj).attr('step'),
    v = Number(val),
    min = Number($(obj).attr('min')),
    max = Number($(obj).attr('max'));
  if (isNaN(v)) { v = Number($(obj).attr('value')); }
  v = v < min ? min : v;
  v = v > max ? max : v;
  return v.toFixed(step.length > 2 ? step.length - 2 : 0)
}


/*----------配置读取与存储-----------*/
function enabledChange() {
  if ($("[name=oeEnable]").is(":checked")) {
    $('.container>ul').find('span').removeClass('disabled');
    $('.container>ul [name]').attr('disabled', false).removeClass('disabled');
  } else {
    $('.container>ul').find('span').addClass('disabled');
    $('.container>ul [name]').attr('disabled', true).addClass('disabled');
  }
}
// 表单内容改变保存配置
$('[name]').change(function () {
  if ($(this).attr("name") == "oeEnable") enabledChange();
  setConfig();
});
//保存配置
function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><config ";
  $('.container [name]').each(function () {
    let name = $(this).attr('name');
    let val = $(this).val();
    if ($(this).attr('type') == 'checkbox') {
      text += name + "=\"" + ($(this).is(':checked') ? "yes" : "no") + "\" ";
    } else if ($(this).attr("type") == "number") {
      text += name + "=\"" + compareVal(this, val) + "\" ";
    } else {
      text += name + "=\"" + val + "\" ";
    }
  });
  text += "/></root>";
  biSetModuleConfig("obstacle-evaluation.aspluginobstacleevaluation", text);
}
//初始化
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(296, 698);
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value])
  });
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let obj = new Object();
    let root = xmlDoc.getElementsByTagName('config');
    let keys = root[0].getAttributeNames();
    for (let i = 0; i < keys.length; i++) {
      //获取root自身字节的属性
      obj[keys[i]] = root[0].getAttribute(keys[i]);
    }
    loadConfig(obj);
  }
}
function loadConfig(obj) {
  if (obj == null) return;
  $('.container [name]').each(function () {
    let val = obj[$(this).attr('name')];
    let type = $(this).attr('type');
    if (type == 'checkbox') {
      $(this).prop('checked', val == 'yes' ? true : false);
    } else if (type == "number") {
      $(this).val(compareVal(this, val));
    } else {
      $(this).val(val);
    }
  })
  enabledChange();
}
