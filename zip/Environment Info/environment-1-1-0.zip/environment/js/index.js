let viewSize = new BISize(557, 653),
  idName = null; //选择的元素的id名
$('a').on({
  'mouseover': function (e) {
    if (!$(this).hasClass('not_a') && !$(this).hasClass('red')) {
      $(this).attr('title', $(this).attr('val'))
    };
  }
})
$('select').change(function () {
  changeClassMode(this);
  setConfig();
})
$('[type=number]').on(
  {
    'change': function () {
      setConfig();
    },
    'blur': function () {
      compare(this);
    }
  }
)
$('[language="not_config"]').on('mousedown', function (e) {
  if ($(this).hasClass('not_a')) return;
  if (1 == e.which || 3 == e.which) {
    selectSignals(this);
  }
})
$('[type=checkbox]').click(function () {
  setConfig();
});
$('[type=text]').bind('input propertychange', function () {
  checkTextValue(this)
}).on('blur', function () {
  let str = $(this).val();
  let v = Number(str);
  if (isNaN(v) || str == "") {
    $(this).val(" ").addClass('green');
  }
  setConfig();
})
function loadConfig(config) {
  if (config == null) return
  let obj = JSON.parse(config);
  obj.enabled == "yes" ? $('[name=enabled]').attr('checked', true) : $('[name=enabled]').removeAttr('checked');
  // 下拉框
  $('select').each(function () {
    if (typeof ($(this).attr('name')) == 'undefined') {
      $(this).val($(this).find('option').attr('value'));
    } else {
      $(this).val(obj[$(this).attr('name')]);
    }
    changeClassMode(this);
  })

  // 输入框
  $('[type=text]').each(function () {
    if (obj[$(this).attr('name')] == 'null') {
      $(this).val('')
    } else {
      $(this).val(obj[$(this).attr('name')]).addClass('green');
    }

  })
  // number值
  $('[type=number]').each(function () {
    let step = $(this).attr('step').length - 2;
    let name = $(this).attr('name');
    let v = parseFloat(obj[name]);
    if (step <= -1) {
      $(this).val(v.toFixed(0));
    } else {
      $(this).val(v.toFixed(step));
    }
  })
  // checkbox
  obj.connect_rs485 == 'yes' ? $('[name=connect_rs485]').attr('checked', true) : $('[name=connect_rs485]').removeAttr('checked');
  // (Not configure)
  $('a').each(function (i) {
    let key = typeof ($(this).attr('scale')) == 'undefined' ? $(this).attr('name') : $(this).attr('name') + '_value';
    if (obj[key] == 'null' || obj[key] == undefined) {
      $(this).html(biGetLanguage() == 1 ? "(Not configured)" : "(未配置)")
    } else {
      let arr = obj[key].split(':');
      if (typeof ($(this).attr('scale')) == 'undefined') {
        $(this).html(arr[2]).attr('val', obj[key]);
      } else {
        let scale = key + '_scale';
        $(this).html(arr[2]).attr({ 'val': obj[key], 'scale': obj[scale] });
      }
      if (!$(this).hasClass('not_a') && $(this).html().indexOf('(') == -1) {
        let name = $(this).attr('name');
        biQuerySignalInfo(name, obj[key]);
      }
    }
  });
}
function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root ";
  // enabled配置
  let m = $('[name=enabled]').is(':checked') ? "yes" : "no";
  text += " " + $('[name=enabled]').attr('name') + "=\"" + m + "\" ";
  //下拉框配置
  $('select').each(function () {
    if ($(this).attr('name') != undefined) {
      text += " " + $(this).attr('name') + "=\"" + $(this).val() + "\" ";
      changeClassMode($(this).attr('name'))
    }
  })
  //文本框配置
  $('[type=text]').each(function () {
    text += " " + $(this).attr('name') + "=\"" + $(this).val() + "\" ";
  })
  // number配置
  $('[type=number]').each(function () {
    let step = $(this).attr('step').length - 2;
    let val = Number($(this).val());
    let value;
    if (!isNaN(val) && $(this).val() != "") {
      let min = parseFloat($(this).attr('min')),
        max = parseFloat($(this).attr('max'));
      val = val < min ? min : val;
      val = val > max ? max : val;
      if (step <= -1) {
        value = val.toFixed(0);
      } else {
        value = val.toFixed(step);
      }
    } else {
      value = $(this).attr('value');
    }
    text += " " + $(this).attr('name') + "=\"" + value + "\" ";
  })
  //复选框配置
  let c = $('[name=connect_rs485]').is(':checked') ? "yes" : "no";
  text += " " + $('[name=connect_rs485]').attr('name') + "=\"" + c + "\" ";
  // Not configured配置
  $('a').each(function () {
    if ($(this).attr('name') == 'temperature' || $(this).attr('name') == 'illumination' || $(this).attr('name') == 'windspeed') {
      text += " " + $(this).attr('name') + '_value' + "=\"" + $(this).attr('val') + "\" ";
      if ($(this).attr('scale') != 'undefined') {
        text += " " + $(this).attr('name') + '_scale' + "=\"" + $(this).attr('scale') + "\" "
      }
    } else {
      text += " " + $(this).attr('name') + "=\"" + $(this).attr('val') + "\" ";
    }
  })
  text += " />";
  console.log(text);
  biSetModuleConfig("environment.pluginenvironment", text);
}
function changeClassMode(obj) {
  let name = ' ';
  if ($(obj).attr('name') == 'temperature_source') {
    name = '[name=temperature_type]';
    if ($(obj).val() == "Signal") {
      $(name).removeAttr('disabled', true);
      $(name).next().removeClass('not_a');
      if ($(name).html().indexOf('(') == -1) {
        biQuerySignalInfo('temperature', $('[name=temperature]').attr('val'));
      }
    } else {
      $(name).attr('disabled', true);
      $(name).next().addClass('not_a').removeClass('red green');
    }
  } else if ($(obj).attr('name') == 'illumination_source') {
    name = '[name=illumination]'
    if ($(obj).val() == "Signal") {
      $(name).removeClass('not_a');
      if ($(name).html().indexOf('(') == -1) {
        biQuerySignalInfo('illumination', $('[name=illumination]').attr('val'));
      }
    } else {
      $(name).addClass('not_a').removeClass('red green');
    }
  }
  else if ($(obj).attr('name') == 'windspeed_source') {
    name = '[name=windspeed]'
    if ($(obj).val() == "Signal") {
      $(name).removeClass('not_a');
      if ($(name).html().indexOf('(') == -1) {
        biQuerySignalInfo('windspeed', $('[name=windspeed]').attr('val'));
      } else {
        $(name).removeClass('red green')
      }
    } else {
      $(name).addClass('not_a').removeClass('red green');
    }
  }
}
function checkTextValue(obj) {
  let str = $(obj).val();
  let v = Number(str);
  if (!isNaN(v)) {
    $(obj).addClass('green').attr('value', v);
  } else if (isNaN(v)) {
    $(obj).removeClass('green').addClass('red');
  }
}
function compare(obj) {
  let step = Number($(obj).attr('step').length - 2) > 0 ? Number($(obj).attr('step').length - 2) : 0;
  let max = Number($(obj).attr('max')).toFixed(step);
  let min = Number($(obj).attr('min')).toFixed(step);
  let val = Number(!isNaN($(obj).val()) ? $(obj).val() : $(obj).attr('value'));
  if (Number($(obj).val()) > max) {
    $(obj).val(max).removeClass('red green');
  } else if (Number($(obj).val()) < min) {
    $(obj).val(min).removeClass('red green');
  } else {
    $(obj).val(val.toFixed(step))
  }
}
function selectSignals(obj) {
  let originID = null;
  if ($(obj).html().lastIndexOf('(') == -1) originID = $(obj).attr("val");
  idName = obj;
  if ($(obj).attr('scale') != undefined) {
    let scale = parseInt($(obj).attr('scale'));
    if ($(obj).attr('name') == 'temperature') {
      biSelectSignal("TargetSignal", originID, false, null, true, scale, "[°]");
    } else if ($(obj).attr('name') == 'illumination') {
      biSelectSignal("TargetSignal", originID, false, null, true, scale, "[lux]");
    } else if ($(obj).attr('name') == 'windspeed') {
      biSelectSignal("TargetSignal", originID, false, null, true, scale, "[m/s]");
    }
  } else {
    biSelectSignal("TargetSignal", originID, false, null, false, 1, "[°]");
  }
}
function biOnSelectedSignal(key, valueInfo, signBitInfo, scale) {
  if (key == "TargetSignal") {
    let text = null;
    if (valueInfo == null) {
      text = biGetLanguage() == 1 ? "(Not configured)" : "(未配置)";
      $(idName).removeClass('red green').html(text).attr("val", '');
    } else if (valueInfo.typeName != undefined) {
      $(idName).html(valueInfo.signalName);
      $(idName).attr("val", valueInfo.id);
      $(idName).addClass('green').attr('scale', scale);
    }
  }
  setConfig()
}
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(557, 653);
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value])
  });
  for (let key in moduleConfigs) {
    let parser = new DOMParser();//创建一个空的xml文档对象
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");//把名为modeleConfigs的字符串载入到解析器中
    let countrys = xmlDoc.getElementsByTagName('root');//获取setconfig里面的root标签
    let keys = countrys[0].getAttributeNames();//获取root标签的属性名
    let obj = new Object();
    for (let i = 0; i < keys.length; i++) {
      obj[keys[i]] = countrys[0].getAttribute(keys[i]);
    }
    loadConfig(JSON.stringify(obj));
  }
}
function biOnQueriedSignalInfo(key, signalInfo) {
  if (signalInfo != null) {
    $('[name=' + key + ']').addClass('green').removeClass('red');
  } else {
    $('[name=' + key + ']').addClass('red').removeClass('green').html($('#' + key).attr('val'));
    $('[name=' + key + ']').removeAttr('title');
  }
  setConfig();
}