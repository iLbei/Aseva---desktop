var idName = null,not_config=""; //选择的元素的id名
$('a').on({
  'mouseover': function (e) {
    if (!$(this).hasClass('not_a') && !$(this).hasClass('red')) {
      $(this).attr('title', $(this).attr('val'))
    };
  }
})
$('select').change(function () {
  changeClassMode(this);
})
$("[name]").change(function () { setConfig() });
$('[type=number]').on('blur', function () {
  $(this).val(compareVal(this, $(this).val()))
}
)
$('[language="not_config"]').on('mousedown', function (e) {
  if ($(this).hasClass('not_a')) return;
  if (1 == e.which || 3 == e.which) {
    selectSignals(this);
  }
})
$('[type=text]').bind('input propertychange', function () {
  checkTextValue(this)
}).on('blur', function () {
  var str = $(this).val();
  var v = Number(str);
  if (isNaN(v) || str == "") {
    $(this).val(" ").addClass('green');
  }
})
function loadConfig(config) {
  if (config == null) return;
  config.enabled == "yes" ? $('[name=enabled]').attr('checked', true) : $('[name=enabled]').removeAttr('checked');
  // 下拉框
  $('select').each(function () {
    if (typeof ($(this).attr('name')) == 'undefined') {
      $(this).val($(this).find('option').attr('value'));
    } else {
      $(this).val(config[$(this).attr('name')]);
    }
    changeClassMode(this);
  })

  // 输入框
  $('[type=text]').each(function () {
    if (config[$(this).attr('name')] == 'null') {
      $(this).val('')
    } else {
      $(this).val(config[$(this).attr('name')]).addClass('green');
    }

  })
  // number值
  $('[type=number]').each(function () {
    var step = $(this).attr('step').length - 2;
    var name = $(this).attr('name');
    var v = parseFloat(config[name]);
    if (step <= -1) {
      $(this).val(v.toFixed(0));
    } else {
      $(this).val(v.toFixed(step));
    }
  })
  // checkbox
  config.connect_rs485 == 'yes' ? $('[name=connect_rs485]').attr('checked', true) : $('[name=connect_rs485]').removeAttr('checked');
  // (Not configure)
  $('a').each(function (i) {
    var key = typeof ($(this).attr('scale')) == 'undefined' ? $(this).attr('name') : $(this).attr('name') + '_value';
    if (config[key] == 'null' || config[key] == undefined) {
      $(this).text(not_config);
    } else {
      var arr = config[key].split(':');
      if (typeof ($(this).attr('scale')) == 'undefined') {
        $(this).text(arr[2]).attr('val', config[key]);
      } else {
        var scale = key + '_scale';
        $(this).text(arr[2]).attr({ 'val': config[key], 'scale': config[scale] });
      }
      if (!$(this).hasClass('not_a') && $(this).text().indexOf('(') == -1) {
        var name = $(this).attr('name');
        biQuerySignalInfo(name, config[key]);
      }
    }
  });
}
function setConfig() {
  var text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root ";
  // enabled配置
  var m = $('[name=enabled]').is(':checked') ? "yes" : "no";
  text += " " + $('[name=enabled]').attr('name') + "=\"" + m + "\" ";
  //下拉框配置
  $('select').each(function () {
    if ($(this).attr('name') != undefined) {
      text += " " + $(this).attr('name') + "=\"" + $(this).val() + "\" ";
      changeClassMode($(this).attr('name'))
    }
  })
  //文本框配置
  $('[type=text]').each(function () {
    text += " " + $(this).attr('name') + "=\"" + $(this).val() + "\" ";
  })
  // number配置
  $('[type=number]').each(function () {
    var step = $(this).attr('step').length - 2;
    var val = Number($(this).val());
    var value;
    if (!isNaN(val) && $(this).val() != "") {
      var min = parseFloat($(this).attr('min')),
        max = parseFloat($(this).attr('max'));
      val = val < min ? min : val;
      val = val > max ? max : val;
      if (step <= -1) {
        value = val.toFixed(0);
      } else {
        value = val.toFixed(step);
      }
    } else {
      value = $(this).attr('value');
    }
    text += " " + $(this).attr('name') + "=\"" + value + "\" ";
  })
  //复选框配置
  var c = $('[name=connect_rs485]').is(':checked') ? "yes" : "no";
  text += " " + $('[name=connect_rs485]').attr('name') + "=\"" + c + "\" ";
  // Not configured配置
  $('a').each(function () {
    if ($(this).attr('name') == 'temperature' || $(this).attr('name') == 'illumination' || $(this).attr('name') == 'windspeed') {
      text += " " + $(this).attr('name') + '_value' + "=\"" + $(this).attr('val') + "\" ";
      if ($(this).attr('scale') != 'undefined') {
        text += " " + $(this).attr('name') + '_scale' + "=\"" + $(this).attr('scale') + "\" "
      }
    } else {
      text += " " + $(this).attr('name') + "=\"" + $(this).attr('val') + "\" ";
    }
  })
  text += " />";
  biSetModuleConfig("environment.pluginenvironment", text);
}
function changeClassMode(obj) {
  var name = ' ';
  if ($(obj).attr('name') == 'temperature_source') {
    name = '[name=temperature_type]';
    if ($(obj).val() == "Signal") {
      $(name).removeAttr('disabled', true);
      $(name).next().removeClass('not_a');
      if ($(name).text().indexOf('(') == -1) {
        biQuerySignalInfo('temperature', $('[name=temperature]').attr('val'));
      }
    } else {
      $(name).attr('disabled', true);
      $(name).next().addClass('not_a').removeClass('red green');
    }
  } else if ($(obj).attr('name') == 'illumination_source') {
    name = '[name=illumination]'
    if ($(obj).val() == "Signal") {
      $(name).removeClass('not_a');
      if ($(name).text().indexOf('(') == -1) {
        biQuerySignalInfo('illumination', $('[name=illumination]').attr('val'));
      }
    } else {
      $(name).addClass('not_a').removeClass('red green');
    }
  }
  else if ($(obj).attr('name') == 'windspeed_source') {
    name = '[name=windspeed]'
    if ($(obj).val() == "Signal") {
      $(name).removeClass('not_a');
      if ($(name).text().indexOf('(') == -1) {
        biQuerySignalInfo('windspeed', $('[name=windspeed]').attr('val'));
      } else {
        $(name).removeClass('red green')
      }
    } else {
      $(name).addClass('not_a').removeClass('red green');
    }
  }
}
function checkTextValue(obj) {
  var str = $(obj).val();
  var v = Number(str);
  if (!isNaN(v)) {
    $(obj).addClass('green').attr('value', v);
  } else if (isNaN(v)) {
    $(obj).removeClass('green').addClass('red');
  }
}
function compareVal(obj, val) {
  var step = $(obj).attr('step').length > 2 ? $(obj).attr('step').length - 2 : 0,
    v = Number(val),
    newVal = 0;
  if (isNaN(v)) {
    newVal = Number($(obj).attr('value'));
  } else {
    var min = Number($(obj).attr('min')),
      max = Number($(obj).attr('max'));
    v = v < min ? min : v;
    v = v > max ? max : v;
    newVal = Math.round(Math.abs(v) * Math.pow(10, step)) / Math.pow(10, step);
    if (v < 0) newVal = -newVal;
  }
  return newVal.toFixed(step);
}
function selectSignals(obj) {
  var originID = null;
  if ($(obj).text().lastIndexOf('(') == -1) originID = $(obj).attr("val");
  idName = obj;
  if ($(obj).attr('scale') != undefined) {
    var scale = parseInt($(obj).attr('scale'));
    if ($(obj).attr('name') == 'temperature') {
      biSelectSignal("TargetSignal", originID, false, null, true, scale, "[°]");
    } else if ($(obj).attr('name') == 'illumination') {
      biSelectSignal("TargetSignal", originID, false, null, true, scale, "[lux]");
    } else if ($(obj).attr('name') == 'windspeed') {
      biSelectSignal("TargetSignal", originID, false, null, true, scale, "[m/s]");
    }
  } else {
    biSelectSignal("TargetSignal", originID, false, null, false, 1, "[°]");
  }
}
function biOnSelectedSignal(key, valueInfo, signBitInfo, scale) {
  if (key == "TargetSignal") {
    var text = null;
    if (valueInfo == null) {
      $(idName).removeClass('red green').text(not_config).attr("val", '');
    } else if (valueInfo.typeName != undefined) {
      $(idName).text(valueInfo.signalName).attr("title",valueInfo.signalName);
      $(idName).attr("val", valueInfo.id);
      $(idName).addClass('green').attr('scale', scale);
    }
  }
  setConfig();
}
function biOnInitEx(config, moduleConfigs) {
  $('[language]').each(function () {
    var value = $(this).attr('language');
    if(biGetLanguage() == 1){
      not_config = "<Not Configured>";
       $(this).text(en[value]);
    }else{
      not_config = "<未配置>";
      $(this).text(cn[value]);
    }
  });
  for (var key in moduleConfigs) {
    var parser = new DOMParser();//创建一个空的xml文档对象
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");//把名为modeleConfigs的字符串载入到解析器中
    var countrys = xmlDoc.getElementsByTagName('root');//获取setconfig里面的root标签
    var keys = countrys[0].attributes;//获取root标签的属性名
    var obj = new Object();
    for (var i = 0; i < keys.length; i++) {
      obj[keys[i].nodeName] = keys[i].nodeValue;
    }
    loadConfig(obj);
  }
}
function biOnQueriedSignalInfo(key, signalInfo) {
  if (signalInfo != null) {
    $('[name=' + key + ']').addClass('green').removeClass('red');
  } else {
    $('[name=' + key + ']').addClass('red').removeClass('green').text($('#' + key).attr('val'));
    $('[name=' + key + ']').removeAttr('title');
  }
  setConfig();
}