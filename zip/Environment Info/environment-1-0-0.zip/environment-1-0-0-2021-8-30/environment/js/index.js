let viewSize = new BISize(557, 653); //窗口大小
let language = sessionStorage.getItem("language"); //取中英文,用于刷新保存的值
let configuration = "";
let base = new Base64();
let cn = {
    Enabled: "启用",
    source_Selection: "数据源选择",
    weather_type: "天气类型：",
    temperature: "温度：",
    humidity: "相对温度：",
    pressure: "气压：",
    visibility: "能见度：",
    illumination: "光照：",
    wind_speed: "风速：",
    wind_direction: "风向：",
    disaster: "灾害：",
    road_name: "道路名称：",
    speed_limit: "限速：",
    road_type: "道路类型：",
    road_surface: "路面状况：",
    road_traffic: "道路交通状况：",
    lane_traffic: "车道交通状况：",
    spots: "场所：",
    typhoon: "(台风、龙卷风、闪电、冰雹等)",
    tunnel: "(隧道、事故、路口、桥等)",
    left: "左车道：",
    current: "本车道：",
    right: "右车道：",
    open: "畅通：",
    slow: "缓慢：",
    crowded: "拥挤：",
    reverse: "逆向：",
    devices: "设备接入",
    connect_rs: "连接RS485",
    web: "网络获取",
    data_holder: "数据保持：",
    sec: "[秒]",
    manual: "手动标记",
    baidu: "百度地图",
    seniverse: "心知天气",
    gaode: "高德地图",
    signal: "信号值",
    rs485: "RS485传感器",
    signals: "信号配置",
    not_config: "(未配置)",
    pm25: "PM 2.5：",
    pm10: "PM 10："
},
    en = {
        Enabled: "Enabled:",
        source_Selection: "source Selection:",
        weather_type: "Weather type:",
        temperature: "Temperature:",
        humidity: "Humidity:",
        pressure: "Pressure:",
        visibility: "Visibility:",
        illumination: "Illumination:",
        wind_speed: "wind speed:",
        wind_direction: "Wind direction:",
        disaster: "Disaster:",
        road_name: "Road name:",
        speed_limit: "Speed limit:",
        road_type: "Road type:",
        road_surface: "Road surface:",
        road_traffic: "Road traffic:",
        lane_traffic: "Lane traffic:",
        spots: "Spots:",
        typhoon: "(Typhoon, tornado, lightning, hail, etc)",
        tunnel: "(Tunnel, accident, crossing. bridge, etc)",
        left: "Left:",
        current: "Current:",
        right: "Right:",
        open: "Open:",
        slow: "Slow:",
        crowded: "Crowded:",
        reverse: "Reverse:",
        devices: "Devices",
        connect_rs: "Connect RS485",
        web: "Web",
        data_holder: "Data Holder:",
        sec: "[sec]",
        manual: "Manual",
        baidu: "Baidu",
        seniverse: "Seniverse",
        gaode: "Gaode",
        signal: "Signal",
        rs485: "RS485",
        signals: "Signals",
        not_config: "(Not configured)",
        pm25: "PM 2.5:",
        pm10: "PM 10:"
    };

if (language != null) {
    changeLanguage(language);
}
/**
 * 判断中英文
 */
function changeLanguage(type) {
    if (type == 1) {
        $('[language]').each(function () {
            let value = $(this).attr('language');
            $(this).html(en[value])
        });
    } else {
        $('[language]').each(function () {
            let value = $(this).attr('language');
            $(this).html(cn[value])
        });
    }
}
/**
 * 加载配置
 */
let arrA = [];
let aIndex = '';
function loadConfig(config) {
    if (config == null) return
    let obj = JSON.parse(config);
    obj.enabled == "yes" ? $('[name=enabled]').attr('checked', true) : $('[name=enabled]').removeAttr('checked');
    // (Not configure)
    let arr;
    $('a').each(function (i) {
        let key;
        if ($(this).html() == 'null') {
            $(this).html(biGetLanguage() == 1 ? "(Not configured)" : "(未配置)")
        }
        if (typeof ($(this).attr('scale')) == 'undefined') {
            key = $(this).attr('name');
            arr = obj[key].split(':');
            $(this).html(arr[2]).attr('val', obj[key]);
        } else {
            key = $(this).attr('name') + '_value';
            let scale = $(this).attr('name') + '_scale';
            arr = obj[key].split(':');
            $(this).html(arr[2]).attr({ 'val': obj[key], 'scale': obj[scale] });
        }
        arrA.push($('a').eq(i).attr('name'))
        $(this).hasClass('not_a') ? $(this).css('color', '#5B5A5A') : ($(this).html().lastIndexOf('(') == -1 ? $(this).css('color', '#008000') : $(this).css('color', '#0000FF'))
    });
    for (var i = 0; i < arrA.length; i++) {
        (function (i) {
            let name = '[name=' + arrA[i] + ']';
            let arr = '';
            if (typeof ($(name).attr('scale')) == 'undefined') {
                name = arrA[i];
            } else {
                name = arrA[i] + '_value';
            }
            arr = obj[name].split(':');
            aIndex = i;
            biQueryBusProtocolFileChannel(arr[0]);
        })(i);
    }

    // 下拉框
    $('select').each(function () {
        if (typeof ($(this).attr('name')) == 'undefined') {
            $(this).val($(this).find('option').attr('value'));
        } else {
            $(this).val(obj[$(this).attr('name')]);
        }
        changeClassMode(this);
    })

    // 输入框
    $('[type=text]').each(function () {
        if (obj[$(this).attr('name')] == 'null') {
            $(this).val('')
        } else {
            $(this).val(obj[$(this).attr('name')]).css('color', '#008000');
        }

    })
    // number值
    $('[type=number]').each(function () {
        let step = $(this).attr('step').length - 2;
        let name = $(this).attr('name');
        let v = parseFloat(obj[name]);
        if (step <= -1) {
            $(this).val(v.toFixed(0));
        } else {
            $(this).val(v.toFixed(step));
        }
    })
    // checkbox
    obj.connect_rs485 == 'yes' ? $('[name=connect_rs485]').attr('checked', true) : $('[name=connect_rs485]').removeAttr('checked');
}

/**
 * 写配置
 */
function setConfig() {
    let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root ";
    // enabled配置
    let m = $('[name=enabled]').is(':checked') ? "yes" : "no";
    text += " " + $('[name=enabled]').attr('name') + "=\"" + m + "\" ";
    //下拉框配置
    $('select').each(function () {
        if ($(this).attr('name') != undefined) {
            text += " " + $(this).attr('name') + "=\"" + $(this).val() + "\" ";
            changeClassMode($(this).attr('name'))
        }
    })
    //文本框配置
    $('[type=text]').each(function () {
        text += " " + $(this).attr('name') + "=\"" + $(this).val() + "\" ";
    })
    // number配置
    $('[type=number]').each(function () {
        let step = $(this).attr('step').length - 2;
        let val = Number($(this).val());
        let value;
        if (!isNaN(val) && $(this).val() != "") {
            let min = parseFloat($(this).attr('min')),
                max = parseFloat($(this).attr('max'));
            val = val < min ? min : val;
            val = val > max ? max : val;
            if (step <= -1) {
                value = val.toFixed(0);
            } else {
                value = val.toFixed(step);
            }
        } else {
            value = $(this).attr('value');
        }
        text += " " + $(this).attr('name') + "=\"" + value + "\" ";
    })
    //复选框配置
    let c = $('[name=connect_rs485]').is(':checked') ? "yes" : "no";
    text += " " + $('[name=connect_rs485]').attr('name') + "=\"" + c + "\" ";
    // Not configured配置
    $('a').each(function () {
        if ($(this).attr('name') == 'temperature' || $(this).attr('name') == 'illumination' || $(this).attr('name') == 'windspeed') {
            text += " " + $(this).attr('name') + '_value' + "=\"" + $(this).attr('val') + "\" ";
            if ($(this).attr('scale') != 'undefined') {
                text += " " + $(this).attr('name') + '_scale' + "=\"" + $(this).attr('scale') + "\" "
            }
        } else {
            text += " " + $(this).attr('name') + "=\"" + $(this).attr('val') + "\" ";
        }
    })
    text += " />";
    biSetModuleConfig("environment.pluginenvironment", text);
}

////////////各事件//////////////////
//鼠标经过a标签，显示提示框
let timer = '';
$('a').on({
    'mouseover': function (e) {
        if ($(this).hasClass('not_a')) return;
        let obj = this;
        let flag = $(this).html().indexOf('(') == -1 ? 'true' : 'false';
        timer = setTimeout(function () {
            if (flag == "true") {
                $(obj).next('.tips').html($(obj).attr('val'));
                let x = e.pageX - 10 - parseInt($(obj).next('.tips').css('width')) / 2;
                let y = e.pageY - 420;

                $(obj).next('.tips').css({ 'top': y + 'px', 'left': x + 'px', 'display': 'block' });
            }
        }, 1000)
        setTimeout(function () {
            $('a').each(function () {
                $(this).stop(true)
            })
            $(obj).next().css('display', 'none');
        }, 6000)
    },
    'mouseout':function () {
        clearTimeout(timer)
        $(this).next('.tips').hide();
    }
})

//下拉框改变
function changeClassMode(obj) {
    let name = ' ';
    if ($(obj).attr('name') == 'temperature_source') {
        name = '[name=temperature_type]';
        if ($(obj).val() == "Signal") {
            $(name).removeAttr('disabled', true);
            $(name).next().removeClass('not_a');
            $(name).next().html().indexOf('(') == -1 ? ($(name).next().html().indexOf(':') != -1 ? $(name).next().css('color', 'red') : $(name).next().css('color', '#008000')) : $(name).next().css('color', '#0000FF');
        } else {
            $(name).attr('disabled', true);
            $(name).next().addClass('not_a').css('color', '#5B5A5A');
        }
    } else if ($(obj).attr('name') == 'illumination_source') {
        name = '[name=illumination]'
        if ($(obj).val() == "Signal") {
            $(name).removeClass('not_a');
            $(name).html().indexOf('(') == -1 ? ($(name).html().indexOf(':') != -1 ? $(name).css('color', 'red') : $(name).css('color', '#008000')) : $(name).css('color', '#0000FF')
        } else {
            $(name).css('color', '#5B5A5A').addClass('not_a');
        }
    }
    else if ($(obj).attr('name') == 'windspeed_source') {
        name = '[name=windspeed]'
        if ($(obj).val() == "Signal") {
            $(name).removeClass('not_a');
            if ($(name).html().indexOf('(') == -1) {
                $(name).html().indexOf(':') != -1 ? $(name).css('color', 'red') : $(name).css('color', '#008000')
            } else { $(name).css('color', '#0000FF') }
        } else {
            $(name).css('color', '#5B5A5A').addClass('not_a');
        }
    }
}
$('select').change(function () {
    changeClassMode(this);
    setConfig();
})
$('[type=number').change(function(){
    setConfig();
    console.log(2);
})
//检查文本框的值
$('[type=text]').bind('input propertychange', function () {
    checkTextValue(this)
}).on('blur', function () {
    let str = $(this).val();
    let v = Number(str);
    if (isNaN(v) || str == "") {
        $(this).val(" ").addClass('green');
    }
    setConfig();
})

function checkTextValue(obj) {
    let str = $(obj).val();
    let v = Number(str);
    if (!isNaN(v)) {
        $(obj).addClass('green').attr('value', v);
    } else if (isNaN(v)) {
        $(obj).removeClass('green').addClass('red');
    }
}
//number失去焦点比大小
$('input[type=number]').on('blur', function () {
    compare(this);
})
function compare(obj) {
    let step = Number($(obj).attr('step').length - 2) > 0 ? Number($(obj).attr('step').length - 2) : 0;
    let max = Number($(obj).attr('max')).toFixed(step);
    let min = Number($(obj).attr('min')).toFixed(step);
    let val = Number(!isNaN($(obj).val())? $(obj).val():$(obj).attr('value'));
    if (Number($(obj).val()) > max) {
        $(obj).val(max).removeClass('red green');
    } else if (Number($(obj).val()) < min) {
        $(obj).val(min).removeClass('red green');
    } else {
        $(obj).val(val.toFixed(step))
    }
}
//点击选择信号
$('[language="not_config"]').on('mousedown', function (e) {
    if ($(this).hasClass('not_a')) return;
    if (1 == e.which || 3 == e.which) {
        selectSignals(this);
    }
})
$('[type=checkbox]').click(function () {
    setConfig();
});
/**
 * 选择信号
 * @param {} obj 
 */
let idName = null; //选择的元素的id名
// NotConfigured点击的弹窗
function selectSignals(obj) {
    let originID = null;
    if ($(obj).html().lastIndexOf('(') == -1) originID = $(obj).attr("val");
    idName = obj;
    if ($(obj).attr('scale') != undefined) {
        let scale = parseInt($(obj).attr('scale'));
        if ($(obj).attr('name') == 'temperature') {
            biSelectSignal("TargetSignal", originID, false, null, true, scale, "[°]");
        } else if ($(obj).attr('name') == 'illumination') {
            biSelectSignal("TargetSignal", originID, false, null, true, scale, "[lux]");
        } else if ($(obj).attr('name') == 'windspeed') {
            biSelectSignal("TargetSignal", originID, false, null, true, scale, "[m/s]");
        }
    } else {
        biSelectSignal("TargetSignal", originID, false, null, false, 1, "[°]");
    }
}

function biOnSelectedSignal(key, valueInfo, signBitInfo, scale) {
    if (key == "TargetSignal") {
        let text = null;
        if (valueInfo == null) {
            text = biGetLanguage() == 1 ? "(Not configured)" : "(未配置)";
            $(idName).css('color', '#0000FF').html(text).attr("val", '');
        } else {
            $(idName).html(valueInfo.signalName);
            $(idName).attr("val", valueInfo.id);
            $(idName).css('color', '#008000').attr('scale', scale);
        }
    }
    setConfig()
}

function biOnInitEx(config, moduleConfigs) {
    biSetViewSize(557,653);
    let type = biGetLanguage();
    changeLanguage(type);
    sessionStorage.setItem("language", type);
    configuration = moduleConfigs;
    for (let key in moduleConfigs) {
        let parser = new DOMParser();//创建一个空的xml文档对象
        let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");//把名为modeleConfigs的字符串载入到解析器中
        let countrys = xmlDoc.getElementsByTagName('root');//获取setconfig里面的root标签
        let keys = countrys[0].getAttributeNames();//获取root标签的属性名
        let obj = new Object();
        for (let i = 0; i < keys.length; i++) {
            obj[keys[i]] = countrys[0].getAttribute(keys[i]);
        }
        loadConfig(JSON.stringify(obj));
        if ($('a').html() == 'null') {
            $('a').html(biGetLanguage() == 1 ? "(Not configured)" : "(未配置)");
        }
    }
}
function biSetViewConfig() {
    return configuration;
}

function biOnStartSession() {
}
function biSetViewSize() {
    return viewSize;
}

function biSetViewSize(width, height) {
     biUnimplemented("biSetViewSize");
 }
function Base64() {

    // private property
    _keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

    // public method for encoding
    this.encode = function (input) {
        var output = "";
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        var i = 0;
        input = _utf8_encode(input);
        while (i < input.length) {
            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);
            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;
            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            } else if (isNaN(chr3)) {
                enc4 = 64;
            }
            output = output +
                _keyStr.charAt(enc1) + _keyStr.charAt(enc2) +
                _keyStr.charAt(enc3) + _keyStr.charAt(enc4);
        }
        return output;
    }

    // public method for decoding
    this.decode = function (input) {
        var output = "";
        var chr1, chr2, chr3;
        var enc1, enc2, enc3, enc4;
        var i = 0;
        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
        while (i < input.length) {
            enc1 = _keyStr.indexOf(input.charAt(i++));
            enc2 = _keyStr.indexOf(input.charAt(i++));
            enc3 = _keyStr.indexOf(input.charAt(i++));
            enc4 = _keyStr.indexOf(input.charAt(i++));
            chr1 = (enc1 << 2) | (enc2 >> 4);
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            chr3 = ((enc3 & 3) << 6) | enc4;
            output = output + String.fromCharCode(chr1);
            if (enc3 != 64) {
                output = output + String.fromCharCode(chr2);
            }
            if (enc4 != 64) {
                output = output + String.fromCharCode(chr3);
            }
        }
        output = _utf8_decode(output);
        return output;
    }

    // private method for UTF-8 encoding
    _utf8_encode = function (string) {
        string = string.replace(/\r\n/g, "\n");
        var utftext = "";
        for (var n = 0; n < string.length; n++) {
            var c = string.charCodeAt(n);
            if (c < 128) {
                utftext += String.fromCharCode(c);
            } else if ((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            } else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }

        }
        return utftext;
    }

    // private method for UTF-8 decoding
    _utf8_decode = function (utftext) {
        var string = "";
        var i = 0;
        var c = c1 = c2 = 0;
        while (i < utftext.length) {
            c = utftext.charCodeAt(i);
            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            } else if ((c > 191) && (c < 224)) {
                c2 = utftext.charCodeAt(i + 1);
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                i += 2;
            } else {
                c2 = utftext.charCodeAt(i + 1);
                c3 = utftext.charCodeAt(i + 2);
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                i += 3;
            }
        }
        return string;
    }
}

//选择报文
function biOnQueriedBusProtocolFileChannel(busFileProtocolID, busChannel) {
    for (let i = 0; i <= aIndex; i++) {
        let name = '[name=' + arrA[i] + ']';
        if (busChannel == 0 && $(name).attr('val').indexOf(busFileProtocolID) != -1 && $(name).attr('val').indexOf('dbc') != -1) {
            $(name).html($(name).attr('val'))
            if ($(name).hasClass('not_a')) {
                $(name).css('color', '#5B5A5A')
            } else {
                $(name).css('color', 'red')
            }
        }
    }
}

