window.hasOpenWindow = false;
let vehicle = [];
$(function () {
  $(document).find("select,input:not([name=alias])").click(function () {
    $("#displayLabel").css("display", "block");
    $("[name=alias]").css("display", "none");
  })

  $("[name=alias]").on("change", function () {
    $("#displayLabel").text($("[name=alias]").val());
  })
})
$('input[type=number]').on({
  'change': function () {
    compareVal(this);
    let name = $(this).attr('name');
    if (name == 'antenna_x' || name == 'antenna_y') {
      draw();
    }
  },
  'blur': function () {
    compareVal(this);
    let name = $(this).attr('name');
    if (name == 'antenna_x' || name == 'antenna_y') {
      draw();
    }
  },
  'input': function (e) {
    if (e.which == undefined) {
      draw();
    }
  }
})
$('[name]').change(function () {
  setConfig();
})
function compareVal(obj) {
  let step = $(obj).attr('step').length - 2;
  let v = parseFloat($(obj).val());
  if (isNaN(v)) { v = Number($(obj).attr('value')); }
  let min = parseFloat($(obj).attr('min')),
    max = parseFloat($(obj).attr('max'));
  v = v < min ? min : v;
  v = v > max ? max : v;
  let value;
  if (step <= -1) {
    value = v.toFixed(0);
  } else {
    value = v.toFixed(step);
  }
  $(obj).val(value);
  return value;
}

function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root";
  let obj = new Object();
  $('.container [name]').each(function () {
    let key = $(this).attr('name');
    if ($(this).attr('type') == "checkbox") {
      let val = $(this).get(0).checked == true ? "yes" : "no";
      text += " " + key + "=\"" + val + "\"";
      obj[key] = val;
    } else if ($(this).attr('type') == 'radio' && $(this).is(":checked")) {
      text += " " + key + "=\"" + $(this).val() + "\"";
      obj[key] = $(this).val();
    } else if ($(this).attr('type') != 'radio') {
      text += " " + key + "=\"" + $(this).val() + "\"";
      obj[key] = $(this).val();
    }
  });
  text += " />";
  biSetModuleConfig("com--nmea-0183-.pluginnmea", text);
}
function draw() {
  if(vehicle.length < 2) return;
  console.log(vehicle.length);
  console.log(vehicle[0], vehicle[1]);
  console.log(Number(vehicle[0]));
  console.log(Number(vehicle[0]) * 10);
  let canvas = document.getElementById('myCanvas');
  let ctx = canvas.getContext('2d');
  let p1 = new BIPoint(0, 35),
    p2 = new BIPoint(canvas.width, 35),
    p3 = new BIPoint(canvas.width / 2, 0),
    p4 = new BIPoint(canvas.width / 2, canvas.height),
    p5 = new BIPoint(canvas.width / 2 - Number(vehicle[0]) * 10, 35),
    p6 = new BIPoint(canvas.width / 2, 35),
    p7 = new BIPoint(canvas.width / 2 - Number(vehicle[0]) *10,  35+Number(vehicle[1]) * 15),
    p8 = new BIPoint(canvas.width / 2 + Number(vehicle[0]) * 10, 35+Number(vehicle[1]) * 15),
    s = new BISize(Number(vehicle[0]) * 20, Number(vehicle[1]) * 50),
    x = Number($('[name=antenna_x]').val()),
    y = Number($('[name=antenna_y]').val()),
    p9 = new BIPoint(canvas.clientWidth / 2 - y * 15, 38 - (24 + x * 24 / 1.5)),
    p10 = new BIPoint(canvas.clientWidth / 2 - y * 15, 35 - x * 24 / 1.5),
    p11 = new BIPoint(canvas.clientWidth / 2 - (15 + y * 15), 35 - x * 24 / 1.5);
  console.log(p5, s);
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawLine(p1, p2, 1, "#e9e9e9", ctx);
  drawLine(p3, p4, 1, "#e9e9e9", ctx);
  drawRect(p5, s, "black", ctx);
  let arr = [p6, p7, p8];
  drawPolygon(arr, "black", ctx);
  drawLine(p9, p10, 1, '#32cd32', ctx);
  drawLine(p10, p11, 1, '#32cd32', ctx);
}
/**
 * 画多边形
 * @param {} arr 点
 * @param {*} color 颜色 
 * @param {*} ctx 上下文
 */
function drawPolygon(arr, color, ctx) {
  ctx.beginPath();
  ctx.moveTo(arr[0].x, arr[0].y);
  ctx.lineTo(arr[1].x, arr[1].y);
  ctx.lineTo(arr[2].x, arr[2].y);
  ctx.strokeStyle = color;
  ctx.closePath();
  ctx.stroke();
}
/**
 * 画线-两点一线
 * @param {*} p1 点
 * @param {*} p2 点
 * @param {*} width 线宽度
 * @param {*} color 颜色
 * @param {*} ctx 画图上下文
 */
function drawLine(p1, p2, width, color, ctx) {
  ctx.beginPath();
  ctx.lineWidth = width;
  ctx.moveTo(p1.x, p1.y);
  ctx.lineTo(p2.x, p2.y);
  ctx.closePath();
  ctx.strokeStyle = color;
  ctx.stroke();
}
/**
 * 画矩形
 * @param {*} p 顶点
 * @param {*} s 大小
 * @param {*} color 颜色
 * @param {*} ctx 画图上下文
 */
function drawRect(p, s, color, ctx) {
  ctx.beginPath();
  ctx.rect(p.x, p.y, s.width, s.height);
  ctx.strokeStyle = color;
  ctx.stroke();
}
/**
 * 画圆
 * @param {*} p 圆心
 * @param {*} radius 半径 
 * @param {*} color 颜色
 * @param {*} width 线宽
 * @param {*} ctx 画图上下文
 */
function drawCircle(p, radius, color, width, ctx) {
  ctx.beginPath();
  ctx.lineWidth = width;
  ctx.strokeStyle = color;
  ctx.arc(p.x, p.y, radius, 0, Math.PI * 2, false);
  ctx.stroke();
}

function displayInput() {
  $("#displayLabel").css("display", "none");
  $("[name=alias]").css("display", "block");
}
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(407, 671);
  
  biQueryGlobalVariable('Subject.VehicleWidth', '3.2');
  biQueryGlobalVariable('Subject.VehicleHeight', '3.8');
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value]);
  });
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let obj = new Object();
    let root = xmlDoc.getElementsByTagName('root');
    let keys = root[0].getAttributeNames();
    for (let i = 0; i < keys.length; i++) {
      if (root[0].getAttribute(keys[i]) == "null") {
        obj[keys[i]] = "";
      } else {
        obj[keys[i]] = root[0].getAttribute(keys[i]);
      }
    }
    loadConfig(JSON.stringify(obj));
  }
}
function loadConfig(config) {
  if (config == null) return;
  let val = JSON.parse(config);
  $('[name]').each(function () {
    let type = $(this).attr('type');
    let value = val[$(this).attr('name')];
    if (type == 'checkbox') {
      if (value == "yes") $(this).attr('checked', true);
    } else if (type == 'radio') {
      if (value == $(this).val()) {
        $(this).prop("checked", true);
      }
    } else if (type == 'number') {
      let len = $(this).attr('step').length - 2;
      $(this).val(Number(value).toFixed(len >= 1 ? len : 0))
    } else {
      $(this).val(value);
    }
  });
  $('#displayLabel').html(val['alias']);
}
function biOnQueriedGlobalVariable(id, value) {
  vehicle.push(value);
  draw();
}