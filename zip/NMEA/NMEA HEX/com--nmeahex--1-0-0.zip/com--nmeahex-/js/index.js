window.hasOpenWindow = false;
let language = sessionStorage.getItem("language"); //取中英文,用于刷新保存的值
let cn = {
    connect: "连接",
    com_port: "COM端口号:",
    com_baud_rate: "COM端口波特率:",
    output_channel: "输出通道:",
    device_part: "设备",
    device_type: "设备类型:",
    processing_part: "处理",
    b48: "4800 波特",
    b96: "9600 波特",
    b192: "19200 波特",
    b384: "38400 波特",
    b576: "57600 波特",
    b1152: "115200 波特",
    b2304: "230400 波特",
    b4608: "460800 波特",
    disabled: "(禁用)",
    gnss_imu_a: "GNSS-IMU 传感器 A",
    gnss_imu_b: "GNSS-IMU 传感器 B",
    gnss_imu_c: "GNSS-IMU 传感器 C",
    gnss_imu_d: "GNSS-IMU 传感器 D",
    gnss_imu_e: "GNSS-IMU 传感器 E",
    gnss_imu_f: "GNSS-IMU 传感器 F",
    yaw_rate: '横摆率:',
    pitch_offset: "俯仰偏移:",
    roll_offset: "横滚偏移:",
    novatel_imu_type:"诺瓦太IMU型:",
    time_type:"时间类型:",
    heading_offset:"航向偏移量:",
    pos:"位置(m):",
    connect_gps_comm:"连接GPS COM端口",
    send_command:"发送指令",
    com2_port:"COM2端口号:",
    connect_comm:"连接指令:"
},
    en = {
        b48: "4800 Baud",
        b96: "9600 Baud",
        b192: "19200 Baud",
        b384: "38400 Baud",
        b576: "57600 Baud",
        b1152: "115200 Baud",
        b2304: "230400 Baud",
        b4608: "460800 Baud",
        disabled: "(Disabled)",
        gnss_imu_a: "GNSS-IMU Sensor A",
        gnss_imu_b: "GNSS-IMU Sensor B",
        gnss_imu_c: "GNSS-IMU Sensor C",
        gnss_imu_d: "GNSS-IMU Sensor D",
        gnss_imu_e: "GNSS-IMU Sensor E",
        gnss_imu_f: "GNSS-IMU Sensor F",
        connect: "Connect",
        com_port: "COM port:",
        com2_port:"COM2 port:",
        com_baud_rate: "COM baud rate:",
        output_channel: "Output channel:",
        device_part: "Device",
        device_type:"Device type:",
        processing_part: "Processing",
        pitch_angle_offset: "Pitch angle offset:",
        yaw_rate: "Yaw rate offset:",
        pitch_offset: "Pitch offset:",
        roll_offset: "Roll offset:",
        novatel_imu_type:"Novatel IMU type:",
        time_type:"Time type:",
        heading_offset:"Heading Offset:",
        pos:"Pos(m):",
        connect_gps_comm:"Connect GPS Comm",
        send_command:"Send Command",
        connect_comm:"Connect command:"
    }
window.onload = function () {
    if (language != null) {
        changeLanguage(language);
    }
    $(document).find("select,input:not([name=alias])").click(function () {
        $("#displayLabel").css("display", "block");
        $("[name=alias]").css("display", "none");
    })

    $("[name=alias]").on("change", function () {
        $("#displayLabel").text($("[name=alias]").val());
    })
    draw();
}

$('input[type=number]').on({
    'change': function () {
        compareVal(this);
        let name = $(this).attr('name');
        if (name == 'antenna_x' || name == 'antenna_y') {
            draw();
        }
    },
    'blur': function () {
        compareVal(this);
        let name = $(this).attr('name');
        if (name == 'antenna_x' || name == 'antenna_y') {
            draw();
        }
    },
    'input': function (e) {
        if (e.which == undefined) {
            draw();
        }
    }
})
$('[name]').change(function () {
    setConfig();
})
function compareVal(obj) {
    let step = $(obj).attr('step').length - 2;
    let v = parseFloat($(obj).val());
    if (isNaN(v)) { v = Number($(obj).attr('value')); }
    let min = parseFloat($(obj).attr('min')),
        max = parseFloat($(obj).attr('max'));
    v = v < min ? min : v;
    v = v > max ? max : v;
    let value;
    if (step <= -1) {
        value = v.toFixed(0);
    } else {
        value = v.toFixed(step);
    }
    $(obj).val(value);
    return value;
}
function changeLanguage(type) {
    if (type == 1) {
        $('[language]').each(function () {
            let value = $(this).attr('language');
            $(this).html(en[value])
        });
    } else {
        $('[language]').each(function () {
            let value = $(this).attr('language');
            $(this).html(cn[value])
        });
    }
}

function setConfig() {
    let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root";
    let obj = new Object();
    $('.container [name]').each(function () {
        let key = $(this).attr('name');
        if ($(this).attr('type') == "checkbox") {
            let val = $(this).get(0).checked == true ? "yes" : "no";
            text += " " + key + "=\"" + val + "\"";
            obj[key] = val;
        } else if ($(this).attr('type') == 'radio' && $(this).is(":checked")) {
            text += " " + key + "=\"" + $(this).val() + "\"";
            obj[key] = $(this).val();
        } else if ($(this).attr('type') != 'radio') {
            text += " " + key + "=\"" + $(this).val() + "\"";
            obj[key] = $(this).val();
        }
    });
    text += " />";
    biSetModuleConfig("com--nmeahex-.aspluginnmeahex", text);
}
function draw() {
    let canvas = document.getElementById('myCanvas');
    let ctx = canvas.getContext('2d');
    let p1 = new BIPoint(0, 45),
        p2 = new BIPoint(canvas.width, 45),
        p3 = new BIPoint(canvas.width / 2, 0),
        p4 = new BIPoint(canvas.width / 2, canvas.height),
        p5 = new BIPoint(canvas.width / 2 - 15, 45),
        p6 = new BIPoint(canvas.width / 2, 45),
        p7 = new BIPoint(canvas.width / 2 - 15, 62),
        p8 = new BIPoint(canvas.width / 2 + 15, 62),
        s = new BISize(30, 50),
        x = Number($('[name=antenna_x]').val()),
        y = Number($('[name=antenna_y]').val()),
        p9 = new BIPoint(canvas.clientWidth / 2 - y * 15, 45 - (24 + x * 24 / 1.5)),
        p10 = new BIPoint(canvas.clientWidth / 2 - y * 15, 45 - x * 24 / 1.5),
        p11 = new BIPoint(canvas.clientWidth / 2 - (15 + y * 15), 45 - x * 24 / 1.5);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawLine(p1, p2, 1, "#e9e9e9", ctx);
    drawLine(p3, p4, 1, "#e9e9e9", ctx);
    drawRect(p5, s, "black", ctx);
    let arr = [p6, p7, p8];
    drawPolygon(arr, "black", ctx);
    drawLine(p9, p10, 1, '#32cd32', ctx);
    drawLine(p10, p11, 1, '#32cd32', ctx);
}
/**
 * 画多边形
 * @param {} arr 点
 * @param {*} color 颜色 
 * @param {*} ctx 上下文
 */
function drawPolygon(arr, color, ctx) {
    ctx.beginPath();
    ctx.moveTo(arr[0].x, arr[0].y);
    ctx.lineTo(arr[1].x, arr[1].y);
    ctx.lineTo(arr[2].x, arr[2].y);
    ctx.strokeStyle = color;
    ctx.closePath();
    ctx.stroke();
}
/**
 * 画线-两点一线
 * @param {*} p1 点
 * @param {*} p2 点
 * @param {*} width 线宽度
 * @param {*} color 颜色
 * @param {*} ctx 画图上下文
 */
function drawLine(p1, p2, width, color, ctx) {
    ctx.beginPath();
    ctx.lineWidth = width;
    ctx.moveTo(p1.x, p1.y);
    ctx.lineTo(p2.x, p2.y);
    ctx.closePath();
    ctx.strokeStyle = color;
    ctx.stroke();
}
/**
 * 画矩形
 * @param {*} p 顶点
 * @param {*} s 大小
 * @param {*} color 颜色
 * @param {*} ctx 画图上下文
 */
function drawRect(p, s, color, ctx) {
    ctx.beginPath();
    ctx.rect(p.x, p.y, s.width, s.height);
    ctx.strokeStyle = color;
    ctx.stroke();
}
/**
 * 画圆
 * @param {*} p 圆心
 * @param {*} radius 半径 
 * @param {*} color 颜色
 * @param {*} width 线宽
 * @param {*} ctx 画图上下文
 */
function drawCircle(p, radius, color, width, ctx) {
    ctx.beginPath();
    ctx.lineWidth = width;
    ctx.strokeStyle = color;
    ctx.arc(p.x, p.y, radius, 0, Math.PI * 2, false);
    ctx.stroke();
}

function displayInput() {
    $("#displayLabel").css("display", "none");
    $("[name=alias]").css("display", "block");
}
function biOnInitEx(config, moduleConfigs) {
    biSetViewSize(407, 637);
    let type = biGetLanguage();
    changeLanguage(type);
    sessionStorage.setItem("language", type);
    for (let key in moduleConfigs) {
        let parser = new DOMParser();
        let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
        let obj = new Object();
        let root = xmlDoc.getElementsByTagName('root');
        let keys = root[0].getAttributeNames();
        for (let i = 0; i < keys.length; i++) {
            if (root[0].getAttribute(keys[i]) == "null") {
                obj[keys[i]] = "";
            } else {
                obj[keys[i]] = root[0].getAttribute(keys[i]);
            }
        }
        loadConfig(JSON.stringify(obj));
    }
}
function loadConfig(config) {
    if (config == null) return;
    let val = JSON.parse(config);
    $('.container [name]').each(function () {
        let type=$(this).attr('type');
        let value = val[$(this).attr('name')];
        if (type == 'checkbox') {
            if (value == "yes") $(this).attr('checked', true);
        } else if (type == 'radio') {
            if (value == $(this).val()) {
                $(this).prop("checked", true);
            }
        }  else if (type == 'number') {
            let len = $(this).attr('step').length-2;
            $(this).val(Number(value).toFixed(len>=1?len:0))
        }else {
            $(this).val(value);
        }
    });
    $('#displayLabel').html(val['alias']);
    draw();
}
