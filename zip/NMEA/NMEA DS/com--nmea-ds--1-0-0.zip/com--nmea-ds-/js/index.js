window.hasOpenWindow = false;
let vehicle = [];
$('input[type=number]').on({
  'change': function () {
    $(this).val(compareVal(this));
    let name = $(this).attr('name');
    if (name == 'antenna_x' || name == 'antenna_y' || name == 'orientation_offset') {
      draw();
    }
  },
  'blur': function () {
    $(this).val(compareVal(this));
    let name = $(this).attr('name');
    if (name == 'antenna_x' || name == 'antenna_y' || name == 'orientation_offset') {
      draw();
    }
  },
  'input': function (e) {
    if (e.which == undefined) {
      draw();
    }
    setConfig();
  }
})
$('[name]').change(function () {
  setConfig();
})
$('[name=alias]').on({
  'keydown': function (e) {
    if (e.which == 13) {
      $(this).hide().prev().show().html($(this).val());
    }
    setConfig();
  },
  'blur': function () {
    $(this).hide().prev().show().html($(this).val());
    setConfig();
  }
})
function compareVal(obj) {
  let step = $(obj).attr('step').length - 2;
  let v = parseFloat($(obj).val());
  if (isNaN(v)) { v = Number($(obj).attr('value')); }
  let min = parseFloat($(obj).attr('min')),
    max = parseFloat($(obj).attr('max'));
  v = v < min ? min : v;
  v = v > max ? max : v;
  return v.toFixed(step <= -1 ? 0 : step);
}

function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root";
  $('.container [name]').each(function () {
    let key = $(this).attr('name');
    let type = $(this).attr('type');
    if (type == "checkbox") {
      let val = $(this).get(0).checked == true ? "yes" : "no";
      text += " " + key + "=\"" + val + "\"";
    } else if (type == 'radio' && $(this).is(":checked")) {
      text += " " + key + "=\"" + $(this).val() + "\"";
    } else if (type == 'number') {
      text += " " + key + "=\"" + compareVal(this) + "\"";
    } else if($(this).is('a')){
      text += " " + key + "=\"" + $(this).html()+ "\"";
    } else {
      text += " " + key + "=\"" + $(this).val() + "\"";
    }
  });
  text += " />";
  biSetModuleConfig("com--nmea-ds-.pluginnmea", text);
}
function draw() {
  if (vehicle.length < 2) return;
  let canvas = $('#myCanvas')[0];
  let ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  let h = canvas.height / 4
  let p1 = new BIPoint(0, h),
    p2 = new BIPoint(canvas.width, h),
    p3 = new BIPoint(canvas.width / 2, 0),
    p4 = new BIPoint(canvas.width / 2, canvas.height),
    p5 = new BIPoint(canvas.width / 2 - Number(vehicle[0]) * 8, h),
    p6 = new BIPoint(canvas.width / 2, h),
    p7 = new BIPoint(canvas.width / 2 - Number(vehicle[0]) * 8, Number(vehicle[1]) * 15 + 35),
    p8 = new BIPoint(canvas.width / 2 + Number(vehicle[0]) * 8, Number(vehicle[1]) * 15 + 35),
    s = new BISize(Number(vehicle[0]) * 16, Number(vehicle[1]) * 46);
  drawLine(p1, p2, 1, "#e9e9e9", ctx);
  drawLine(p3, p4, 1, "#e9e9e9", ctx);
  drawRect(p5, s, "black", ctx);
  let arr = [p6, p7, p8];
  drawPolygon(arr, "black", ctx);
  let x = Number($('[name=antenna_x]').val());
  let y = Number($('[name=antenna_y]').val());
  let yaw = Number($('[name=orientation_offset]').val());
  p8 = new BIPoint(canvas.width / 2 - y * 15, h - (24 + x * 24 / 1.5));
  let p9 = new BIPoint(canvas.width / 2 - y * 15, h - x * 24 / 1.5);
  let p10 = new BIPoint(canvas.width / 2 - (15 + y * 15), h - x * 24 / 1.5);
  ctx.save();
  ctx.translate(p9.x, p9.y);
  ctx.rotate(Math.PI / 180 * (0 - yaw));
  p1 = new BIPoint(p8.x - p9.x, p8.y - p9.y);
  p2 = new BIPoint(p9.x - p9.x, p9.y - p9.y);
  p3 = new BIPoint(p10.x - p9.x, p10.y - p9.y);
  ctx.beginPath();
  ctx.moveTo(p1.x, p1.y);
  ctx.lineTo(p2.x, p2.y);
  ctx.lineTo(p3.x, p3.y);
  ctx.strokeStyle = "#32cd32";
  ctx.stroke();
  ctx.restore();
}
/**
 * 画多边形
 * @param {} arr 点
 * @param {*} color 颜色 
 * @param {*} ctx 上下文
 */
function drawPolygon(arr, color, ctx) {
  ctx.beginPath();
  ctx.moveTo(arr[0].x, arr[0].y);
  ctx.lineTo(arr[1].x, arr[1].y);
  ctx.lineTo(arr[2].x, arr[2].y);
  ctx.strokeStyle = color;
  ctx.closePath();
  ctx.stroke();
}
/**
 * 画线-两点一线
 * @param {*} p1 点
 * @param {*} p2 点
 * @param {*} width 线宽度
 * @param {*} color 颜色
 * @param {*} ctx 画图上下文
 */
function drawLine(p1, p2, width, color, ctx) {
  ctx.beginPath();
  ctx.lineWidth = width;
  ctx.moveTo(p1.x, p1.y);
  ctx.lineTo(p2.x, p2.y);
  ctx.closePath();
  ctx.strokeStyle = color;
  ctx.stroke();
}
/**
 * 画矩形
 * @param {*} p 顶点
 * @param {*} s 大小
 * @param {*} color 颜色
 * @param {*} ctx 画图上下文
 */
function drawRect(p, s, color, ctx) {
  ctx.beginPath();
  ctx.rect(p.x, p.y, s.width, s.height);
  ctx.strokeStyle = color;
  ctx.stroke();
}
/**
 * 画圆
 * @param {*} p 圆心
 * @param {*} radius 半径 
 * @param {*} color 颜色
 * @param {*} width 线宽
 * @param {*} ctx 画图上下文
 */
function drawCircle(p, radius, color, width, ctx) {
  ctx.beginPath();
  ctx.lineWidth = width;
  ctx.strokeStyle = color;
  ctx.arc(p.x, p.y, radius, 0, Math.PI * 2, false);
  ctx.stroke();
}

function displayInput() {
  $("#displayLabel").css("display", "none");
  $("[name=alias]").css("display", "block");
}
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(407, 671);
  biQueryGlobalVariable('Subject.VehicleWidth', '1.6');
  biQueryGlobalVariable('Subject.VehicleHeight', '1.9');
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value]);
  });
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let obj = new Object();
    let root = xmlDoc.getElementsByTagName('root');
    let keys = root[0].getAttributeNames();
    for (let i = 0; i < keys.length; i++) {
      if (root[0].getAttribute(keys[i]) == "null") {
        obj[keys[i]] = "";
      } else {
        obj[keys[i]] = root[0].getAttribute(keys[i]);
      }
    }
    loadConfig(obj);
  }
}
function loadConfig(config) {
  if (config == null) return;
  $('[name]').each(function () {
    let type = $(this).attr('type');
    let value = config[$(this).attr('name')];
    if (type == 'checkbox') {
      if (value == "yes") $(this).attr('checked', true);
    } else if (type == 'radio') {
      if (value == $(this).val()) {
        $(this).prop("checked", true);
      }
    } else if (type == 'number') {
      let len = $(this).attr('step').length - 2;
      $(this).val(Number(value).toFixed(len >= 1 ? len : 0))
    } else {
      $(this).val(value);
    }
  });
  $('#displayLabel').html(config['alias']);
}
function biOnQueriedGlobalVariable(id, value) {
  vehicle.push(value);
  draw();
}