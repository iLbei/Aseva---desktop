let index = 0,
  vehicle = [],
  channelList = [],
  deviceList = [],
  param_type = [],
  videoCodec = [],
  error = "",
  reset = "",
  device = [],
  deviceListOrder = [],
  intrinsics = false,
  points = [];
$(function () {
  for (let i = 65; i <= 88; i++) {
    $('.video_channel_list').append(`<li id="` + (i - 65) + `">
    <ul class="fixclear">
      <li class="fixclear">
        <span class="left">`+ String.fromCharCode(i) + `</span>
        <a href="javascript:;" language="cha" name='name' class="left channel">Channel `+ String.fromCharCode(i) + `</a>
        <input type="text" name="" class="channelInput">
        <a href="javascript:;" class="right" language="extrinsics"></a>
        <a href="javascript:;" pan class="right" language="intrinsics"></a>
      </li>
      <li class="fixclear">
        <span class="left" language="basic"></span>
        <input type="checkbox" name="invert">
        <span language="invert"></span>
        <input type="checkbox" name="vflip">
        <span language="vflip"></span>
        <input type="checkbox" name="undistort">
        <span class="disabled" language="undistort"></span>
        <a href="javascript:;" class="right" language="reset"></a>
      </li>
      <li>
        <span class="left" language="rectify"></span>
        <input type="checkbox" name="rectify_roll" disabled>
        <span language="roll" class="disabled"></span>
        <input type="checkbox" name="rectify_pitch" disabled>
        <span language="pitch" class="disabled"></span>
        <input type="checkbox" name="rectify_yaw" disabled>
        <span language="yaw" class="disabled"></span>
        <a href="javascript:;" class="right" language="switch"></a>
      </li>
    </ul>
  </li>`);
    channelList.push([{ name: "Channel " + String.fromCharCode(i), param_type: "normal" }, {}]);
    $('.normal>div.right').append("<canvas class=\"canvas\" width=\"218\" height=\"324\"></canvas>");
  }
  $('[language]').each(function () {
    let value = $(this).attr('language');
    if (biGetLanguage() == 1) {
      error = 'Invalid calibration parameter file.';
      reset = "Reset the video channel parameters?";
      $(this).html(en[value])
    } else {
      error = '无效的标定参数文件';
      reset = "是否重置该视频通道参数？";
      $(this).html(cn[value])
    }
  });
})
/*------------------Video devices------------------*/
//点击视频设备左边的红色圆点改变颜色
$('.video_list').on('click', 'li span.icon', function () {
  if ($(this).hasClass('bcRed')) {
    $(this).removeClass('bcRed').addClass('bcGreen');
    deviceList[deviceListOrder[$(this).parent().index()]]['enabled'] = 'yes';
  } else if ($(this).hasClass('bcGreen')) {
    $(this).removeClass('bcGreen').addClass('bcRed');
    deviceList[deviceListOrder[$(this).parent().index()]]['enabled'] = 'no';
  }
  setConfig();
  mapChannelChange()
})
$('.video_list').on('change', '[name]', function () {
  let name = $(this).attr('name');
  let index = deviceListOrder[$(this).parent().parent().parent().index()];
  if ($(this).is('select')) {
    if (name == 'channel') {
      index = deviceListOrder[$(this).parent().parent().parent().parent().index()];
      mapChannelChange();
      deviceList[index][name] = $(this).val();
    } else if (name == 'input_mode') {
      deviceList[index]['input_width'] = $(this).find('option:selected').attr('input_width');
      deviceList[index]['input_height'] = $(this).find('option:selected').attr('input_height');
      deviceList[index]['input_codec'] = $(this).find('option:selected').attr('input_codec');
    } else {
      deviceList[index][name] = $(this).val();
    }
  } else if ($(this).attr('type') == 'checkbox') {
    deviceList[index][name] = $(this).is(':checked') ? 'yes' : 'no';
  }
})
function mapChannelChange() {
  let arr = [[], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], [], []];
  $('.video_list>li').each(function () {
    if ($(this).children('span.icon').hasClass('bcGreen')) {
      arr[Number($(this).find('[name=channel]').val())].push($(this).index());
      $(this).find('[name=channel]').prev().removeClass('red');
    } else if ($(this).find('span.icon').hasClass('bcRed')) {
      $(this).find('[name=channel]').prev().removeClass('red');
    }
  })
  for (let i in arr) {
    if (arr[i].length > 1) {
      for (let j in arr[i]) {
        $('.video_list>li').eq(arr[i][j]).find('[name=channel]').prev().addClass('red');
      }
      $('.video_list>li').eq(arr[i][0]).find('[name=channel]').prev().removeClass('red');
    }
  }
}
// 获取视频设备
function biOnQueriedVideoDevicesInfo(devicesInfo) {
  let devices = JSON.parse(JSON.stringify(devicesInfo)),
    device2 = JSON.parse(JSON.stringify(deviceList)),
    deviceExistIndex = [],
    deviceExist = [],
    deviceIndex = [];
  // aspro里面有设备
  for (let i = 0; i < deviceList.length; i++) {
    let deviceName = deviceList[i].cam_type + ' ' + deviceList[i].local_id;
    for (let j in devicesInfo) {
      let deviceInfoName = devicesInfo[j].type + ' ' + devicesInfo[j].localID;
      // 如果aspro里和获取到的设备一样，就把他删掉，留着已经移除的设备变灰色
      if (deviceInfoName == deviceName) {
        devices.splice(j, 1, '')
        //删除掉aspro里面已经存在的设备,留下新增设备但是aspro里面没有的
        deviceIndex.push(i);
        //将aspro里面存在的设备放在deviceexist里面,方便读取数据
        deviceExist.push(deviceList[i]);
        deviceExistIndex.push(Number(j));
        deviceListOrder.push(Number(i));
      }
    }
  }
  // 读取到设备,aspro里面也有,读取数据
  for (let i = 0; i < deviceExistIndex.length; i++) {
    let k = deviceExistIndex[i];
    let name = devicesInfo[k].type + ' ' + devicesInfo[k].localID + (devicesInfo[k].description ? (' (' + devicesInfo[k].description + ')') : ""),
      supportedModes = devicesInfo[k]['supportedModes'],
      mode = '';
    for (let j in supportedModes) {
      let width = supportedModes[j]['size']['width'];
      let height = supportedModes[j]['size']['height'];
      mode += `<option value="` + width + 'x' + height + videoCodec[supportedModes[j]['codec']] + `" input_width="` + width + `" input_height="` + height + `" input_codec="` + supportedModes[j]['codec'] + `">`;
      mode += width + `x` + height + ` ` + videoCodec[supportedModes[j]['codec']];
      mode += `</option>`;
    }
    let option = '';
    $('a.channel').each(function (i) {
      option += "<option value=\"" + i + "\">" + $(this).html() + "</option>";
    })

    $('.video_list').append(`<li class="fixclear">
          <span class="left icon"></span>
          <ul class="left">
            <li class="fixclear">
              <div class="left">
                <span class="name" cam_type="`+ devicesInfo[k].type + `" local_id="` + devicesInfo[k].localID + `" title="` + name + `">` + name + `</span>
              </div>
              <div class="right"><span language="channel"></span>
                <select name="channel">
                 `+ option + `
                </select>
              </div>
            </li>
            <li>
              <span language="input_mode"></span>
              <select name="input_mode">
                `+ mode + `
              </select>
              <span language="recfps"></span>
              <select name="fps">
                <option value="10">10fps</option>
                <option value="12">12fps</option>
                <option value="15">15fps</option>
                <option value="16">16fps</option>
                <option value="18">18fps</option>
                <option value="20">20fps</option>
                <option value="24">24fps</option>
                <option value="25">25fps</option>
                <option value="30">30fps</option>
                <option value="33">33fps</option>
                <option value="36">36fps</option>
                <option value="40">40fps</option>
                <option value="45">45fps</option>
                <option value="48">48fps</option>
                <option value="50">50fps</option>
                <option value="60">60fps</option>
                <option value="72">72fps</option>
                <option value="75">75fps</option>
                <option value="80">80fps</option>
                <option value="90">90fps</option>
                <option value="96">96fps</option>
                <option value="100">100fps</option>
                <option value="108">108fps</option>
                <option value="120">120fps</option>
              </select>
              <input type="checkbox" name="aligned_fps">
              <span language="aligned"></span></li>
          </ul>
        </li>` );
  }
  // 读取到设备,但aspro里面没有,新增设备
  for (let i = 0; i < devices.length; i++) {
    if (devices[i] != '') {
      let name = devicesInfo[k].type + ' ' + devicesInfo[k].localID + ' ' + '(' + devicesInfo[k].description + ')',
        supportedModes = devicesInfo[k]['supportedModes'],
        mode = '';
      for (let j in supportedModes) {
        let width = supportedModes[j]['size']['width'];
        let height = supportedModes[j]['size']['height'];
        mode += `<option value="` + width + 'x' + height + videoCodec[supportedModes[j]['codec']] + `" input_width="` + width + `" input_height="` + height + `" input_codec="` + supportedModes[j]['codec'] + `">`;
        mode += width + `x` + height + ` ` + videoCodec[supportedModes[j]['codec']];
        mode += `</option>`;
      }
      let option = '';
      $('a.channel').each(function (i) {
        option += "<option value=\"" + i + "\">" + $(this).html() + "</option>";
      })

      $('.video_list').append(`<li class="fixclear">
          <span class="left icon"></span>
          <ul class="left">
            <li class="fixclear">
              <div class="left">
                <span class="name" cam_type="`+ devicesInfo[k].type + `" local_id="` + devicesInfo[k].localID + `" title="` + name + `">` + name + `</span>
              </div>
              <div class="right"><span language="channel"></span>
                <select name="channel">
                 `+ option + `
                </select>
              </div>
            </li>
            <li>
              <span language="input_mode"></span>
              <select name="input_mode">
                `+ mode + `
              </select>
              <span language="recfps"></span>
              <select name="fps">
                <option value="10">10fps</option>
                <option value="12">12fps</option>
                <option value="15">15fps</option>
                <option value="16">16fps</option>
                <option value="18">18fps</option>
                <option value="20">20fps</option>
                <option value="24">24fps</option>
                <option value="25">25fps</option>
                <option value="30">30fps</option>
                <option value="33">33fps</option>
                <option value="36">36fps</option>
                <option value="40">40fps</option>
                <option value="45">45fps</option>
                <option value="48">48fps</option>
                <option value="50">50fps</option>
                <option value="60">60fps</option>
                <option value="72">72fps</option>
                <option value="75">75fps</option>
                <option value="80">80fps</option>
                <option value="90">90fps</option>
                <option value="96">96fps</option>
                <option value="100">100fps</option>
                <option value="108">108fps</option>
                <option value="120">120fps</option>
              </select>
              <input type="checkbox" name="aligned_fps">
              <span language="aligned"></span>
            </li>
          </ul>
        </li>` );
    };
  }
  for (let i in deviceIndex) {
    device2.splice(deviceIndex[i], 1, '');
  }
  // 没有读取到设备,但是aspro里面有的,icon变灰色
  for (let i in device2) {
    if (device2[i] != '') {
      // 获取到的设备得名称
      let deviceListName = device2[i].cam_type + ' ' + device2[i].local_id;
      // 没有读取到设备,但是aspro里面有的,icon变灰色
      let width = device2[i]['input_width'];
      let height = device2[i]['input_height'];
      let option = '';
      let aligned_fps_checked = device2[i]['aligned_fps'] == 'yes' ? 'checked' : '';
      $('a.channel').each(function (i) {
        option += "<option value=\"" + i + "\">" + $(this).html() + "</option>";
      })
      $('.video_list').append(`<li class="fixclear">
      <span class="left icon bcGray"></span>
      <ul class="left">
        <li class="fixclear">
          <div class="left">
            <span class="name" cam_type="`+ device2[i].cam_type + `" local_id="` + device2[i].local_id + `" title="` + deviceListName + `">` + deviceListName + `</span>
          </div>
          <div class="right"><span language="channel"></span>
            <select name="channel">
             `+ option + `
            </select>
          </div>
        </li>
        <li>
          <span language="input_mode"></span>
          <select name="input_mode" disabled>
          <option value="` + width + 'x' + height + videoCodec[device2[i]['input_codec']] + `" input_width="` + width + `" input_height="` + height + `" input_codec="` + device2[i]['input_codec'] + `">` + width + `x` + height + ` ` + videoCodec[device2[i]['input_codec']] + `</option>
          </select>
          <span language="recfps"></span>
          <select name="fps"  disabled>
            <option value="`+ device2[i]['fps'] + `">` + device2[i]['fps'] + `fps</option>
          </select>
          <input type="checkbox" name="aligned_fps"  disabled `+ aligned_fps_checked + `>
          <span language="aligned" class="disabled"></span>
        </li>
      </ul>
      <img src="video/img/del.png" class="removevideoDevice right">
    </li>` );
      $('.video_list>li:last-child').find('[name=channel]').val(device2[i]['channel']);
      deviceListOrder.push(Number(i));
    }
  }
  $('.video_list [language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value]);
  });
  //页面加载值更新
  $('.video_list>li').each(function () {
    if (!$(this).children('span').hasClass('bcGray')) {
      let i = deviceListOrder[$(this).index()];
      let deviceListName = deviceList[i]['cam_type'] + deviceList[i]['local_id'];
      let deviceExistName = $(this).find('span.name').attr('cam_type') + $(this).find('span.name').attr('local_id');
      if (deviceListName == deviceExistName) {
        $(this).find('[name]').each(function () {
          let name = $(this).attr('name');
          if ($(this).attr('type') == 'checkbox') {
            $(this).attr('checked', deviceList[i][name] == 'yes' ? true : false);
          } else {
            if (name == 'input_mode') {
              let value = deviceList[i]['input_width'] + 'x' + deviceList[i]['input_height'] + videoCodec[deviceList[i]['input_codec']];
              $(this).find("option").each(function () {
                if (value == $(this).attr("value")) {
                  $(this).val(value);
                };
              })

              input_mode_change(this);
            } else {
              $(this).val(deviceList[i][name]);
            }
          }
        })
        $(this).children('span').addClass(deviceList[i]['enabled'] == 'yes' ? 'bcGreen' : 'bcRed');
      }
    }
  })
  mapChannelChange();
}
$('.video_list').on('click', '.removevideoDevice', function () {
  deviceList.splice(deviceListOrder[$(this).parent().index()], 1);
  $(this).parent().remove();
  setConfig();
})
//获取设备信息
$('[language=video_infomation]').click(function () {
  $('.video_infomation').show();
})
$('.video_list').on('change', '[name=input_mode]', function () {
  input_mode_change(this);
})
function input_mode_change(obj) {
  if ($(obj).val().indexOf('H264') != -1 || $(obj).val().indexOf('H265') != -1) {
    $(obj).parent().find('[name =aligned_fps]').attr('disabled', true).next().addClass('disabled');
  } else {
    $(obj).parent().find('[name =aligned_fps]').attr('disabled', false).next().removeClass('disabled');
  }
}

/*------------------Channel Options------------------*/
// Channel name 改变，视频通道的值更新
$('.video_channel_list').on('blur', 'input.channelInput', function () {
  index = $(this).parent().parent().parent().attr('id');
  $(this).hide()
  $(this).prev().html($(this).val()).show();
  let option = '';
  $('a.channel').each(function (i) {
    option += "<option value=\"" + i + "\">" + $(this).html() + "</option>";
  })
  $('.video_list select[name=channel]').each(function () {
    let i = deviceListOrder[$(this).parent().parent().parent().parent().index()];
    $(this).empty();
    $(this).html(option).val(deviceList[i]['channel']);
  })
  channelList[index][0]['name'] = $(this).val();
  setConfig();
})
//channel options > a cha/intrinsics/extrinsics/reset/switch 打开显示，更新数据
$('.video_channel_list').on('click', 'a', function () {
  intrinsics = false;
  let lang = $(this).attr('language');
  if (lang != 'cha') $('.trans').show();
  index = $(this).parent().parent().parent().attr('id');
  let param_name = channelList[index][0]['param_type'];
  switch (lang) {
    case 'cha': {
      $(this).hide();
      $(this).next().show().val($(this).html());
      break;
    }
    case 'intrinsics': {
      $('.intrinsics').show();
      if (channelList[index][0]['param_type'] == 'fisheye') {
        $('.fisheye').next('input').removeClass('fisheye').removeAttr('style').show();
        $('.fisheye').show();
        $('.zhenkong').next('input').hide();
        $('.zhenkong').hide();
      } else {
        $('.fisheye').next('input').addClass('fisheye').hide();
        $('.fisheye').hide();
        $('.zhenkong').next('input').show()
        $('.zhenkong').show();
      }
      getContentVal(param_name);
      intrinsics = true;
      break;
    }
    case 'extrinsics': {
      let special_hint = channelList[index][1]['special_hint'];
      switch (param_name) {
        case 'normal':
          exChange(special_hint);
          $('.normal,[language="normal_camera"]').show();
          $('.fisheye').hide();
          break;
        case 'line':
        case 'bs': {
          $('.' + param_name).show();
          break;
        }
        case 'fisheye':
          exChange(special_hint ? special_hint : 0);
          $('.normal').show();
          $('.normal .fisheye').show().prev().hide();
          break;
      }
      getContentVal(param_name);
      if (param_name == "normal" || param_name == "fisheye") {
        //绘画其他图形
        for (let i in channelList) {
          if (!(channelList[i][1]["special_hint"] == 0)) {
            drawNow(i, ["#67D767", "#A6E8A6CC"]);
          }
          $('.canvas').eq(Number(i) + 1).css('z-index', 0);
        }
      }
      if (Number(special_hint)) {
        drawNow(index, ["#7189CB72", "#5D6CD866"]);
      }
      break;
    }
    //点击reset,intrinsics/extrinsics的值恢复为默认值
    case 'reset': {
      $('.trans,div.reset').show();
      break;
    }
    case 'switch': {
      $('.switch [name=param_type]').each(function () {
        if ($(this).val() == channelList[index][0]['param_type']) $(this).prop('checked', true);
      });
      $('.switch').show();
      break;
    }
    default:
      return;
  }
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value]);
  });
})
$("button.reset").click(function () {
  let param_type = channelList[index][0]["param_type"];
  if (param_type == 'fisheye') param_type = 'normal';
  $('.intrinsics [name],.' + param_type + ' [name]').each(function () {
    let type = $(this).attr('type');
    if (type == "radio") {
      $('[name="special_hint"]').eq(0).prop('checked', true)
    } else if (type == "number") {
      $(this).val(compareVal(this, $(this).attr('value')));
    } else if (type == "text") {
      $(this).val(Number($(this).attr('value')).toFixed(6));
    }
  })
  $('.video_channel_list>li').eq(index).find("input[type=checkbox]").each(function () {
    let name = $(this).attr("name");
    if (name == "vflip" || name == "invert" || (name == "undistort" && channelList[index][0]["param_type"] == "fisheye")) {
      $(this).attr({ "checked": false, "disabled": false }).next().removeClass("disabled");
    } else {
      $(this).attr({ "checked": false, "disabled": true }).next().addClass("disabled");
    }
  })
  setContentVal();
  $(this).parent().hide();
  $(".trans").hide();
  setConfig();
})
$('.reset_close ').click(function () {
  $(this).parent().hide();
  $(".trans").hide();
})
// button 导入内外参文件
$('button').click(function () {
  let name = $(this).attr('class');
  if (name.indexOf('intrinsics_import') != -1) {
    biSelectPath("intrinsics_import", BISelectPathType.OpenFile, { '.asmc': 'Module Config', '.ascip': 'Camera Intrinsic Parameter' });
  } else if (name.indexOf('intrinsics_export') != -1) {
    biSelectPath("intrinsics_export", BISelectPathType.CreateFile, { '.asmc': 'Module Config' });
  } else if (name.indexOf('line_import') != -1) {
    biSelectPath("line_import", BISelectPathType.OpenFile, { '.asmc': 'Module Config', '.asisp': 'Image Structure Parameters' })
  } else if (name.indexOf('normal_import') != -1) {
    biSelectPath("normal_import", BISelectPathType.OpenFile, { '.asmc': 'Module Config', '.asisp': 'Image Structure Parameters' })
  } else if (name.indexOf('blind_import') != -1) {
    biSelectPath("blind_import", BISelectPathType.OpenFile, { '.asmc': 'Module Config', '.asisp': 'Image Structure Parameters' })
  }
})
// 点击导入导出.asmc
function biOnSelectedPath(key, path) {
  if (key == "intrinsics_export") {
    let text = '<?xml version="1.0" encoding="utf-8"?><root type="'
    text += (channelList[index][0]['param_type'] == 'fisheye' ? 'camera-intrinsics-fisheye-v1' : 'camera-intrinsics-v2') + '"';
    $('.intrinsics [name]').each(function () {
      if ($(this).attr('style') == undefined) {
        let name = $(this).attr('name');
        if (name == "hfov_fisheye") name = "ideal-hfov";
        if (name == "aspectratio") name = "ar";
        text += " " + name + "=\"" + $(this).val() + "\"";
      };
    })
    text += "/>"
    biWriteFileText(path, text);
  } else if (key == 'intrinsics_import') {
    biQueryFileText(path);
  } else if (key == "line_import" || key == "normal_import" || key == "blind_import") {
    biQueryFileText(path);
  }
}
function biOnQueriedFileText(text, path) {
  let parser = new DOMParser();
  let xmlDoc = parser.parseFromString(text, "text/xml");
  let obj = new Object();
  let root = xmlDoc.getElementsByTagName('root');
  let keys = root[0].getAttributeNames();
  let type = root[0].getAttribute('type');
  let param_name = channelList[index][0]['param_type'];
  for (let i = 0; i < keys.length; i++) {
    //获取root自身字节的属性
    obj[keys[i].indexOf("based_") == -1 ? keys[i] : keys[i].substr(6, keys[i].length)] = root[0].getAttribute(keys[i]);
  }
  if (intrinsics && type.indexOf('intrinsics') != -1) {
    if ((param_name == 'fisheye' && type.indexOf('fish') != -1) || (param_name != 'fisheye' && type.indexOf('fish') == -1)) {
      obj = {};
      for (let i = 0; i < keys.length; i++) {
        //获取root自身字节的属性
        obj[keys[i]] = root[0].getAttribute(keys[i]);
      }
      $('.intrinsics [name]').each(function () {
        let name = $(this).attr('name');
        if (name == "hfov_fisheye") name = 'ideal-hfov';
        if (name == "aspectratio") name = 'ar';
        $(this).val(compareVal(this, obj[name]));
      })
    } else {
      biAlert(error, 'Error');
      return;
    }
  } else if (param_name == "line" && type.indexOf("lane-line") != -1) {
    let zero = obj['zero'].split(',');
    let meter = obj['meter'].split(',');
    $("." + param_name + " [name]").each(function () {
      let name = $(this).attr('name');
      if (name.indexOf('zero') != -1) {
        $("[name = zero_u]").val(Number(zero[0]).toFixed(6));
        $("[name = zero_v]").val(Number(zero[1]).toFixed(6));
      } else if (name.indexOf('meter') != -1 && name != "meter_scale") {
        $("[name = meter_u]").val(Number(meter[0]).toFixed(6));
        $("[name = meter_v]").val(Number(meter[1]).toFixed(6));
      } else if (name == "fifty") {
        $("[name = fifty]").val(Number(obj["fifty_ratio"]).toFixed(6));
      } else if (name == "special_hint1") {
        $('[name =special_hint1]').eq(Number(obj["position"])).prop('checked', true).siblings().removeAttr('checked');
      } else if (name == "meter_scale") {
        $('[name =meter_scale]').val(Number(obj["scale"]).toFixed(6))
      }
    })
    $(".video_channel_list>li").eq(index).find("ul>li:nth-child(2)>input[type=checkbox]").each(function () {
      if (obj[$(this).attr("name")] == 1) {
        $(this).attr("checked", true);
      } else {
        $(this).removeAttr('checked');
      }
    })
  } else if ((param_name == "fisheye" && (type == "fisheye-front-camera-params-v1" || type == "fisheye-generic-camera-params-v1")) || (param_name == "normal" && (type == "front-camera-params-v1" || type == "generic-camera-params-v1"))) {
    if (param_name == "fisheye") param_name = "normal";
    channelList[index][1]["hfov"] = obj["hfov"];
    $("." + param_name + " [name]").each(function () {
      $(this).attr('disabled', false);
      let name = $(this).attr('name');
      let inputType = $(this).attr('type');
      if (inputType == "radio") {
        if (type.indexOf("front") != -1) {
          $("[name =" + name + "][value=2]").prop('checked', true);
        } else if (type.indexOf("generic") != -1) {
          $("[name =" + name + "][value=1]").prop('checked', true);
        }
      } else if (inputType == "number") {
        if (name == "ox") name = "pos_x";
        if (name == "oy") name = "pos_y";
        if (name == "oz") name = "pos_z";
        if (obj[name] != undefined) {
          $(this).val(compareVal(this, obj[name]));
          channelList[index][1][$(this).attr("name")] = obj[name];
        }
        drawNow(index, ["#7189CB72", "#5D6CD866"]);
      } else if (inputType == "text") {
        if (obj[name] != undefined) {
          $(this).val(Number(obj[name]).toFixed(6));
        }
      }
    })
    $(".video_channel_list>li").eq(index).find("ul>li:nth-child(2)>input[type=checkbox]").each(function () {
      if (obj[$(this).attr("name")] == 1) {
        $(this).attr("checked", true);
      } else {
        $(this).removeAttr('checked');
      }
    })
  } else if (param_name == "bs" && type == "blind-spot-camera-params-v1") {
    $("." + param_name + " [name]").each(function () {
      $(this).attr('disabled', false);
      let name = $(this).attr('name');
      let inputType = $(this).attr('type');
      if (inputType == "radio") {
        $("[name =" + name + "][value=" + obj["position"] + "]").prop('checked', true);
      } else if (inputType == "text") {
        if (name.indexOf("_") != -1) {
          let name1 = name.split("_");
          let val = obj[name1[0]].split(",");
          if (obj[name1[0]] != undefined) {
            $(this).val(Number(name1[1] == "u" ? val[0] : val[1]).toFixed(6));
          }
        } else {
          let name1 = name + "_ratio";
          if (obj[name1] != undefined) {
            $(this).val(Number(obj[name1]).toFixed(6));
          }
        }
      }
    })
  } else {
    biAlert(error, 'Error');
    return;
  }
  if (!intrinsics) {
    $('.intrinsics [name]').each(function () {
      let name = $(this).attr('name');
      if (name == "hfov_fisheye") name = 'hfov';
      if (name == "aspectratio") name = 'as';
      $(this).val(Number(obj[name]).toFixed(6));
    })
  }
}
//close 关闭时保存数据
$('.closeInfo,.close,.ok').click(function () {
  let cls = $(this).parent().parent().attr('class');
  $(this).parent().parent().hide();
  $('.trans').hide();
  switch (cls) {
    case "normal": {
      setContentVal();
      rectifyInputChange(index);
      break;
    }
    case "switch": {
      let old_param_name = channelList[index][0]["param_type"];
      let param_name = $('.switch [name=param_type]:checked').val();
      channelList[index][0]["param_type"] = param_name;
      if (old_param_name != param_name) {
        $(".video_channel_list>li").eq(index).find("[name=rectify_roll],[name=rectify_yaw],[name=rectify_pitch],[name=undistort]").attr({ "disabled": true, "checked": false }).next().addClass('disabled');
        $(".video_channel_list>li").eq(index).find("[name=invert],[name=vflip]").removeAttr("checked").attr("disabled", false).next().removeAttr("disabled");
        if (param_name == 'fisheye') {
          $('.fisheye').show().next('input').removeClass('fisheye').removeAttr('style').show();
          $('.zhenkong').next('input').hide();
          $('.zhenkong').hide();
          $(".video_channel_list>li").eq(index).find("[name=undistort]").attr({ 'disabled': false, 'checked': false }).next().removeClass('disabled');
        } else {
          $('.fisheye').next('input').addClass('fisheye').hide();
          $('.fisheye').hide();
          $('.zhenkong').show().next('input').show();
        }
        channelList[index][1] = {};
        if (param_name) {
          $('[name=hfov]').val(120).attr({ 'min': 90, 'max': 150 });
        } else {
          $('[name=hfov]').val(45).attr({ 'min': 10, 'max': 160 });
        }
      }
      break;
    }
    case "intrinsics": {
      setContentVal();
      if (JSON.stringify(channelList[index][1]).length > 2) {
        undistortDis(channelList[index][0]['param_type'], index);
      } else {
        $(".video_channel_list>li").eq(index).find("[name=undistort]").attr({ 'disabled': true, 'checked': false }).next().addClass('disabled');
      }
    }
    default: {
      setContentVal();
    }
  }
  setConfig();
})
//rectify input启用及选中条件
function rectifyInputChange(index) {
  $(".video_channel_list>li").eq(index).find("ul>li:nth-child(3) input").prop({ "disabled": true, "checked": false }).next().addClass('disabled');
  if (channelList[index][1]["special_hint"] != 0) {
    //roll
    if (channelList[index][1]["roll"] != 0 && Math.abs(channelList[index][1]["roll"]) <= 15) {
      $('.video_channel_list>li').eq(index).find("ul>li:nth-child(3)>input[name=rectify_roll]").prop("disabled", false).next('span').removeClass('disabled');
      if (channelList[index][1]["rectify_roll"] == 1) {
        $('.video_channel_list>li').eq(index).find("ul>li:nth-child(3)>input[name=rectify_roll]").prop("checked", true).next().removeClass('disabled');
      } else {
        channelList[index][1]["rectify_pitch"] = 0;
      }
    }
    //pitch
    if (channelList[index][1]["pitch"] != 0 && (channelList[index][1]["roll"] == 0 || channelList[index][1]["rectify_roll"]) && Math.abs(channelList[index][1]["pitch"]) <= channelList[index][1]["hfov"] * 0.1) {
      $('.video_channel_list>li').eq(index).find("ul>li:nth-child(3)>input[name=rectify_pitch]").prop("disabled", false).next().removeClass('disabled');
      if (channelList[index][1]["rectify_pitch"] == 1) {
        $('.video_channel_list>li').eq(index).find("ul>li:nth-child(3)>input[name=rectify_pitch]").prop("checked", true);
      } else {
        channelList[index][1]["rectify_yaw"] = 0;
      }
    }
    //yaw
    if (channelList[index][1]["yaw"] != 0 && (channelList[index][1]["pitch"] == 0 || channelList[index][1]["rectify_pitch"] == 1) && ((channelList[index][1]["pitch"] > -180 && channelList[index][1]["yaw"] <= Number(channelList[index][1]["hfov"] * 0.15) - 180) || (channelList[index][1]["yaw"] >= -Number(channelList[index][1]["hfov"] * 0.15) && channelList[index][1]["yaw"] <= Number(channelList[index][1]["hfov"] * 0.15)))) {
      $('.video_channel_list>li').eq(index).find("ul>li:nth-child(3)>input[name=rectify_yaw]").prop("disabled", false).next().removeClass('disabled');
      if (channelList[index][1]["rectify_yaw"] == 1) {
        $('.video_channel_list>li').eq(index).find("ul>li:nth-child(3)>input[name=rectify_yaw]").prop("checked", true);
      } else {
        $('.video_channel_list>li').eq(index).find("ul>li:nth-child(3)>input[name=rectify_yaw]").removeAttr("checked");
      }
    }
  }
  $(".video_channel_list>li").eq(index).find("ul>li:nth-child(3) input").each(function () {
    channelList[index][1][$(this).attr('name')] = $(this).is(":checked") ? 1 : 0;
  })
}
function undistortDis(param_name, index) {
  if (param_name == 'fisheye' || (channelList[index][1]["aspectratio"] != 1 || channelList[index][1]["k1"] != 0 || channelList[index][1]["k2"] != 0 || channelList[index][1]["k3"] != 0 || channelList[index][1]["k4"] != 0 || channelList[index][1]["k5"] != 0 || channelList[index][1]["k6"] != 0)) {
    $(".video_channel_list>li").eq(index).find("[name=undistort]").attr({ "disabled": false, "checked": (channelList[index][1]["undistort"] == 1 ? true : false) }).next().removeClass('disabled')
  } else {
    $(".video_channel_list>li").eq(index).find("[name=undistort]").attr({ 'disabled': true, 'checked': false }).next().addClass('disabled');
  };
}
//video_channel_list 下checkbox更改，改变list
$('.video_channel').on('change', 'input[type=checkbox]', function () {
  let name = $(this).attr('name');
  index = $(this).parent().parent().parent().index();
  channelList[index][1][name] = $(this).is(':checked') ? 1 : 0;
  if (name == "rectify_pitch" || name == "rectify_roll" || name == "rectify_yaw") {
    rectifyInputChange($(this).parent().parent().parent().index())
  }
  setConfig();
})
// 保存intrinsics和extrinsics数据
function setContentVal() {
  //更新intrinsics数据
  $('.intrinsics [name]').each(function () {
    if ($(this).attr('style') == undefined || $(this).attr('style').indexOf("none") == -1) {
      let name = $(this).attr('name');
      channelList[index][1][name] = $(this).val();
    };
  })
  //更新extrinsics数据
  $('.' + (channelList[index]['0']['param_type'] == 'fisheye' ? 'normal' : channelList[index]['0']['param_type']) + ' [name]').each(function () {
    let type = $(this).attr('type');
    let name = $(this).attr('name');
    switch (type) {
      case 'radio': {
        if ($(this).is(':checked')) {
          channelList[index][1]['special_hint'] = $(this).attr('value');
        }
        break;
      }
      case 'number':
      case 'text': {
        channelList[index][1][name] = $(this).val();
        break;
      }
    }
  })
  //获取basic 和 rectify数据
  $('.video_channel_list>li').eq(index).find('input[type=checkbox]').each(function () {
    channelList[index][1][$(this).attr('name')] = $(this).is(':checked') ? 1 : 0;
  })
}
// 更新intrinsics和extrinsics数据
function getContentVal(param_name) {
  //更新intrinsics数据
  $('.intrinsics [name]').each(function () {
    if ($(this).hasClass('fisheye')) return;
    if ($(this).css("display") != "none") {
      let name = $(this).attr('name');
      let val = channelList[index][1][name];
      let type = $(this).attr('type');
      if (type == "text") {
        $(this).val(Number(val ? val : ($(this).attr("value") ? $(this).attr("value") : 0)).toFixed(6));
      } else if (type == "number") {
        $(this).val(compareVal(this, val ? val : ($(this).attr("value") ? $(this).attr("value") : 0)));
      }
    }
  })
  if (param_name != "intrinsics") {
    //更新extrinsics数据
    if (param_name == "fisheye") param_name = "normal";
    $('.' + param_name + ' [name]').each(function () {
      let type = $(this).attr('type');
      let name = $(this).attr('name');
      if (name.indexOf('special_hint') != -1) name = 'special_hint';
      let val = channelList[index][1][name];
      switch (type) {
        case 'radio': {
          if ($(this).val() == (val ? val : 0)) {
            $(this).prop('checked', true)
          } else {
            $(this).removeAttr('checked')
          }
          break;
        }
        case 'text': {
          $(this).val(Number(val ? val : ($(this).attr("value") ? $(this).attr("value") : 0)).toFixed(6));
          break;
        }
        case 'number': {
          $(this).val(compareVal(this, val ? val : ($(this).attr("value") ? $(this).attr("value") : 0)));
          break;
        }
      }
    })
  }
}
//extrinsics下normal里radio改变 样式
$('.normal input:radio').on('change', function () {
  let val = $(this).attr('value');
  exChange(val);
})
function exChange(val) {
  switch (val) {
    case '1':
    case '2':
      $('.normal input[type=number]').prop('disabled', false).val();
      drawNow(index, ["#7189CB72", "#5D6CD866"]);
      break
    default:
      $(".normal input[type=number]").each(function () {
        let name = $(this).attr("name");
        channelList[index][1][name] = $(this).attr("value");
      })
      $('.normal input[type=number]').prop('disabled', true);
      $('.normal input[type=number]').each(function () {
        $(this).val($(this).attr('value'));
      });
      $('.canvas').eq(Number(index) + 1)[0].getContext('2d').clearRect(0, 0, 218, 324);
      $('.canvas').eq(Number(index) + 1).css('z-index', 0);
  }
}

/*------------------Config------------------*/
//配置读取与存储 [type=number]值校正
$('.container').on('change', '[name]', function () {
  setConfig();
})
$('body').on('blur', '[type = number]', function () {
  $(this).val(compareVal(this, $(this).val()));
  setConfig();
})

function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
  text += "<root ";
  $('.general_settings input').each(function () {
    let key = $(this).attr('name');
    text += " " + key + "=\"" + (key == "hires_buffer_max_size" ? Number($(this).val()) * 1000000 : $(this).val()) + "\"";
  });
  text += "\>";
  // device
  for (let i in deviceList) {
    text += "<device ";
    for (let j in deviceList[i]) {
      text += j + "=\"" + deviceList[i][j] + "\" ";
    }
    text += " />";
  }
  // channel
  for (let i = 0; i < channelList.length; i++) {
    text += "<ch" + i + " ";
    for (let j in channelList[i][0]) {
      text += j + "=\"" + channelList[i][0][j] + "\" ";
    }
    text += ">";
    text += "<param "
    for (let j in channelList[i][1]) {
      text += j + "=\"1:" + channelList[i][1][j] + "\" ";
    }
    text += "/>"
    text += "</ch" + i + ">";
  }
  text += "</root>";
  biSetModuleConfig("video.system", text);
}
function compareVal(obj, val) {
  let step = $(obj).attr('step').length > 2 ? $(obj).attr('step').length - 2 : 0,
    v = Number(val),
    min = Number($(obj).attr('min')),
    max = Number($(obj).attr('max'));
  if (isNaN(v)) { v = Number($(obj).attr('value')); }
  v = v < min ? min : v;
  v = v > max ? max : v;
  return (Math.round(v * Math.pow(10, step)) / Math.pow(10, step)).toFixed(step);
}
function biOnInitEx(config, moduleConfigs) {
  let language = biGetLanguage();
  for (let k in BIVideoCodec) {
    videoCodec.push(k);
  }
  biSetViewSize(990, 613);
  biQueryVideoDevicesInfo();
  biQueryGlobalVariable('Subject.VehicleWidth', '1.9');
  biQueryGlobalVariable('Subject.VehicleHeight', '1.5');
  for (let key in moduleConfigs) {
    channelList = [], deviceList = [];
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('root');
    $('.general_settings input[type=number]').each(function () {
      if ($(this).attr("name") == "hires_buffer_max_size") {
        $(this).val(compareVal(this, countrys[0].getAttribute($(this).attr('name')) / 1000000));
      } else {
        $(this).val(countrys[0].getAttribute($(this).attr('name')));
      }
    })
    for (let k = 0; k < countrys[0].childNodes.length; k++) {
      //channel option
      if (countrys[0].childNodes[k].nodeName.indexOf('ch') != -1) {
        let obj = {};
        let arrConfig = [];
        let keys = countrys[0].childNodes[k].getAttributeNames();
        for (let n = 0; n < keys.length; n++) {
          obj[keys[n]] = countrys[0].childNodes[k].getAttribute(keys[n]);
        }
        arrConfig.push(obj, {});
        let param = countrys[0].childNodes[k].childNodes[0];
        for (let j = 0; j < param.getAttributeNames().length; j++) {
          let param_name = param.getAttributeNames()[j];
          let param_val = param.getAttribute(param_name);
          param_val = param_val.substr(2, param_val.length - 1);
          arrConfig[1][param_name] = param_val;
        }
        channelList.push(arrConfig);
      } else if (countrys[0].childNodes[k].nodeName.indexOf('device') != -1) {
        //video devices
        let obj = {};
        let keys = countrys[0].childNodes[k].getAttributeNames();
        for (let n = 0; n < keys.length; n++) {
          obj[keys[n]] = countrys[0].childNodes[k].getAttribute(keys[n]);
        }
        deviceList.push(obj);
      }
    }
    $('.video_channel_list>li').each(function () {
      let i = $(this).index();
      $(this).find('[name]').each(function () {
        let name = $(this).attr('name');
        if ($(this).is('a')) {
          $(this).html(channelList[i][0]['name']);
        } else if ($(this).attr('type') == 'checkbox') {
          if (channelList[i][1][name] == undefined) {
            $(this).attr({ 'disabled': true, 'checked': false }).next().addClass('disabled');
          } else {
            let val = channelList[i][1][name];
            if (name == 'invert' || name == 'vflip') {
              $(this).attr('checked', val == 1 ? true : false);
            } else if (name == 'undistort') {
              undistortDis(channelList[i][0]['param_type'], i);
            } else {
              rectifyInputChange(i)
            }
          }
        }
      })
    })
    let versions = biGetNativeModuleVersions(3);
    if (versions == '') {
      let wu = language == 1 ? '(NO)' : '(无)';
      $('.video_infomation_main').append('<p>' + wu + '</p>')
    } else {
      for (let i in versions) {
        $('.video_infomation_main').append('<p>' + i + ': v' + versions[i] + '</p>')
      }
    }
    if (biGetRunningMode() == 1) {
      $('h5').show();
      $('.video_list').hide();
    } else {
      $('.video_list').show();
      $('.h5').show();
    };
    $('[language]').each(function () {
      let value = $(this).attr('language');
      if (biGetLanguage() == 1) {
        $(this).html(en[value])
      } else {
        $(this).html(cn[value])
      }
    });
  }
}

/*------------------canvas画图------------------*/
/** 
 * @param {number} 当前索引
 * @param {array} [边，面] 当前:["#7189CB72", "#5D6CD866"],其他:["#67D767", "#A6E8A6b1"]
*/
// 当前图像
function drawNow(index, color) {
  let val = channelList[index][1];
  let hfov = Number(val["hfov"] == undefined ? 45 : val["hfov"]);
  let x = 25 / parseFloat(Math.tan((90 - hfov / 2) * Math.PI / 180));
  let z = hfov * 0.29 - 6;
  points = [
    { x_3d: x, y_3d: -25, z_3d: -z },//A
    { x_3d: -x, y_3d: -25, z_3d: -z },//B
    { x_3d: -x, y_3d: -25, z_3d: z },//C
    { x_3d: x, y_3d: -25, z_3d: z },//D
    { x_3d: 0, y_3d: 0, z_3d: 0 }//E
  ];
  let now = {
    "ox": val["oy"] == undefined ? 0 : val["oy"],
    "oy": val["ox"] == undefined ? 0 : val["ox"],
    "yaw": val["yaw"] == undefined ? 0 : val["yaw"],
    "pitch": val["pitch"] == undefined ? 0 : val["pitch"],
    "roll": val["roll"] == undefined ? 0 : val["roll"]
  };
  for (let j in now) {
    drawTriangle(Number(index) + 1, forRotate(now[j], j), color, { x: now["ox"], y: now["oy"] });
  }
  $('.canvas').eq(Number(index) + 1).css('z-index', 1000);
}
$('.normal input[type=number]').on({
  "change": function (e) {
    let name = $(this).attr('name');
    if (name != "oz") drawNow(index, ["#7189CB72", "#5D6CD866"]);
  },
  'input': function (e) {
    let name = $(this).attr('name');
    channelList[index][1][name] = $(this).val();
    if (e.which == undefined) {
      if (name != "oz") drawNow(index, ["#7189CB72", "#5D6CD866"]);
    }
  },
  'keypress': function (e) {
    if (e.charCode == 101 || e.charCode == 43) {
      return false;
    }
  }
})
//仅绘画基础部分，十字线、长方体、三角形
function draw() {
  if (vehicle.length < 2) return;
  let canvas = $('.canvas')[0];
  let ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  let p1 = new BIPoint(canvas.width / 2, 0);
  let p2 = new BIPoint(canvas.width / 2, canvas.height);
  let p3 = new BIPoint(0, canvas.height / 8);
  let p4 = new BIPoint(canvas.width, canvas.height / 8);
  // 十字线
  drawLine(p1, p2, 1, "#e9e9e9", ctx);
  drawLine(p3, p4, 1, "#e9e9e9", ctx);
  let size = new BISize(Number(vehicle[0]) * 40, Number(vehicle[1]) * 130);
  let p5 = new BIPoint(canvas.width / 2 - Number(vehicle[0]) * 20, canvas.height / 8);
  // 三角形
  drawRect(p5, size, "black", ctx);
  let p6 = new BIPoint(canvas.width / 2, canvas.height / 8);
  let p7 = new BIPoint(canvas.width / 2 - Number(vehicle[0]) * 20, canvas.height / 8 + Number(vehicle[1]) * 40);
  let p8 = new BIPoint(canvas.width / 2 + Number(vehicle[0]) * 20, canvas.height / 8 + Number(vehicle[1]) * 40);
  let arr = [p6, p7, p8];
  // 长方形
  drawPolygon(arr, "black", ctx);
}
/**
 * 画四棱锥
 * @param {number} index canvas的索引
 * @param {arr} points2d 所有点的二维坐标 A,B,C,D,E(顶点坐标)
 * @param {arr} color 面及边(顶点同)的颜色; 边:color[0],面:color[1]
 * @param {obj} origin 中心点位置; x:origin[x],y:origin[y]
 * @returns 返回2维坐标 x,y
 */
function drawTriangle(index, points2d, color, origin) {
  let canvas = $('.canvas').eq(index)[0];
  let ctx = canvas.getContext('2d');
  let ox = canvas.width / 2 - Number(origin["x"]) * 40;
  let oy = canvas.height / 8 - Number(origin["y"]) * 60;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.translate(ox, oy);//中心点位置
  //底面
  ctx.beginPath();
  ctx.moveTo(points2d[0].x, points2d[0].y);
  ctx.lineTo(points2d[1].x, points2d[1].y);
  ctx.lineTo(points2d[2].x, points2d[2].y);
  ctx.lineTo(points2d[3].x, points2d[3].y);
  ctx.closePath();

  for (let i = 0; i < points2d.length - 1; i++) {
    ctx.beginPath();
    ctx.moveTo(points2d[i].x, points2d[i].y);
    ctx.lineTo(points2d[4].x, points2d[4].y);
    ctx.strokeStyle = color[0];
    ctx.stroke();
    ctx.closePath();
  }
  // 绘制平面ABE
  ctx.beginPath();
  ctx.moveTo(points2d[0].x, points2d[0].y);
  ctx.lineTo(points2d[1].x, points2d[1].y);
  ctx.lineTo(points2d[4].x, points2d[4].y);
  ctx.fillStyle = color[1];
  ctx.fill();
  ctx.closePath();

  // 绘制平面ADE
  ctx.beginPath();
  ctx.moveTo(points2d[0].x, points2d[0].y);
  ctx.lineTo(points2d[3].x, points2d[3].y);
  ctx.lineTo(points2d[4].x, points2d[4].y);
  ctx.fillStyle = color[1];
  ctx.fill();
  ctx.closePath();

  // 绘制直线BCE
  ctx.beginPath();
  ctx.moveTo(points2d[1].x, points2d[1].y);
  ctx.lineTo(points2d[2].x, points2d[2].y);
  ctx.lineTo(points2d[4].x, points2d[4].y);
  ctx.fillStyle = color[1];
  ctx.fill();
  ctx.closePath();

  // 绘制平面CDE
  ctx.beginPath();
  ctx.moveTo(points2d[2].x, points2d[2].y);
  ctx.lineTo(points2d[3].x, points2d[3].y);
  ctx.lineTo(points2d[4].x, points2d[4].y);
  ctx.fillStyle = color[1];
  ctx.fill();
  ctx.closePath();


  //绘制顶点
  ctx.beginPath();
  ctx.arc(points2d[4].x, points2d[4].y, 2, 0, 2 * Math.PI);
  ctx.fillStyle = color[0];
  ctx.fill();
  ctx.stroke();

  //中心点复原
  ctx.translate(-ox, -oy);
}
/**
 * 某个3D的点转为2D的点
 * @param {number} x 点的x坐标
 * @param {number} y 点的y坐标
 * @param {number} z 点的z坐标
 * @returns 返回2维坐标 x,y
 */
function to2d(x, y, z) {
  //offsetX是容器宽的一半 x的250
  //offsety是容器高的一半 y的250
  //x,y,z是被转换（被观测）的点对应的立体几何坐标
  //view是观察点的坐标对象（根据观察点的变化，2d图形跟随变化）（自定义）
  let view = { x: 100, y: 0, z: -4000 }
  return {
    x: parseFloat(((x - view.x) * view.z) / (view.z - z) + 100),
    y: parseFloat(((y - view.y) * view.z) / (view.z - z) + 0)
  };
}
/**
 * 获取图形所有点的2D点
 * @param {*} scale x/y/yaw/pitch/roll的值
 * @param {*} which 为x/y/yaw/pitch/roll
 * @returns 返回所有的2D点
 */
function forRotate(scale, which) {
  scale = Number(scale);
  newPoint2D = [];
  sin = parseFloat(Math.sin(scale * Math.PI / 180));
  cos = parseFloat(Math.cos(scale * Math.PI / 180));
  for (let i in points) {
    let x_3d, y_3d, z_3d;
    if (which == "pitch") {//绕X轴旋转
      x_3d = points[i]["x_3d"];
      y_3d = cos * points[i]["y_3d"] - sin * points[i]["z_3d"];
      z_3d = cos * points[i]["z_3d"] + sin * points[i]["y_3d"];
    } else if (which == "roll") {//绕Y轴旋转
      x_3d = cos * points[i]["x_3d"] - sin * points[i]["z_3d"];
      y_3d = points[i]["y_3d"];
      z_3d = cos * points[i]["z_3d"] + sin * points[i]["x_3d"];
    } else if (which == "yaw") {//绕Z轴旋转
      sin = parseFloat(Math.sin(-scale * Math.PI / 180));
      cos = parseFloat(Math.cos(-scale * Math.PI / 180));
      x_3d = cos * points[i]["x_3d"] - sin * points[i]["y_3d"];
      y_3d = cos * points[i]["y_3d"] + sin * points[i]["x_3d"];
      z_3d = points[i]["z_3d"];
    } else if (which == 'ox') {
      x_3d = points[i]['x_3d'] + scale;
      y_3d = points[i]['y_3d'];
      z_3d = points[i]['z_3d'];
    } else if (which == 'oy') {
      x_3d = points[i]['x_3d'];
      y_3d = points[i]['y_3d'] + scale;
      z_3d = points[i]['z_3d'];
    }
    points[i]['x_3d'] = parseFloat(x_3d);
    points[i]['y_3d'] = parseFloat(y_3d);
    points[i]['z_3d'] = parseFloat(z_3d);
    newPoint2D.push(to2d(x_3d, y_3d, z_3d));
  }
  return newPoint2D;
}
/**
 * 画半圆
 * @param {*} origin 原点
 * @param {*} color 颜色
 * @param {*} ctx 画图上下文
 * @param {*} radius 半径
 */
function drawArc(origin, color, ctx, radius, e, s) {
  ctx.beginPath();
  ctx.lineWidth = 1;
  ctx.strokeStyle = color;
  ctx.arc(origin.x, origin.y, radius, e, s, true);
  ctx.stroke();
}
/**
 * 画多边形
 * @param {} arr 点
 * @param {*} color 颜色 
 * @param {*} ctx 上下文
 */
function drawPolygon(arr, color, ctx) {
  ctx.beginPath();
  ctx.moveTo(arr[0].x, arr[0].y);
  ctx.lineTo(arr[1].x, arr[1].y);
  ctx.lineTo(arr[2].x, arr[2].y);
  ctx.strokeStyle = color;
  ctx.closePath();
  ctx.stroke();
}
/**
 * 画线-两点一线
 * @param {*} p1 点
 * @param {*} p2 点
 * @param {*} width 线宽度
 * @param {*} color 颜色
 * @param {*} ctx 画图上下文
 */
function drawLine(p1, p2, width, color, ctx) {
  ctx.beginPath();
  ctx.lineWidth = width;
  ctx.moveTo(p1.x, p1.y);
  ctx.lineTo(p2.x, p2.y);
  // ctx.closePath();
  ctx.strokeStyle = color;
  ctx.stroke();
}
/**
 * 画矩形
 * @param {*} p 顶点
 * @param {*} s 大小
 * @param {*} color 颜色
 * @param {*} ctx 画图上下文
 */
function drawRect(p, s, color, ctx) {
  ctx.beginPath();
  ctx.rect(p.x, p.y, s.width, s.height);
  ctx.strokeStyle = color;
  ctx.stroke();
}
// 获取本车长宽
function biOnQueriedGlobalVariable(id, value) {
  vehicle.push(value);
  draw();
}