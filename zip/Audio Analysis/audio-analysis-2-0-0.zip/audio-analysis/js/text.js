var cn = {
    enabled: "启动",
    channel: "通道:",
    frequency:"频率[Hz]:",
    trigger_value:"触发值[dB]:",
    send_signal:"Can总线发送报警信号",
    clear:"清空"
  },
  en = {
    enabled: "Enabled",
    channel: "Channel:",
    frequency:"Frequency [Hz]:",
    trigger_value:"Trigger value [dB]:",
    send_signal:"Can Bus Send Alarm Signal",
    clear:"Clear"
  };