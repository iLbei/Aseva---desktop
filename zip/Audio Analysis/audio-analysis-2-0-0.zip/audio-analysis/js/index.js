$('[name]').change(function () {
  setConfig();
});
$('[name=Enabled]').click(function () {
  check($(this));
});
$('[name=SendBus]').click(function () {
  checkSendBus($(this));
});

function checkSendBus(obj) {
  if ($(obj).is(":checked")) {
    $('.bottom>div:nth-child(2) [name]').removeAttr("disabled").removeClass("disabled_background");
    $('.bottom>div:nth-child(2) span').removeClass("disabled_a");
  } else {
    $('.bottom>div:nth-child(2) [name]').attr("disabled", true).addClass("disabled_background");
    $('.bottom>div:nth-child(2) span').addClass("disabled_a");
  }
}

function check(obj) {
  if ($(obj).is(":checked")) {
    enAbled();
    checkSendBus($('[name=SendBus]'));
  } else {
    disAbled();
  }
}

/**
 * 禁用表单元素
 */
function disAbled() {
  $('.container>div:not(:first-of-type) [name],button').attr("disabled", true).addClass("disabled_background");
  $('.container>div:not(:first-of-type)').find("a,span,div").attr("disabled", true).addClass('disabled_a');
}
/**
 * 启用
 */
function enAbled() {
  $('.container>div:not(:first-of-type) [name],button').removeAttr("disabled").removeClass("disabled_background");
  $('.container>div:not(:first-of-type)').find("a,span,div").removeAttr("disabled").removeClass('disabled_a');
}

/**
 * 加载配置
 */
function loadConfig(val) {
  var enabled = val['Enabled'];
  var sendBus = val['SendBus'];
  var channel = val['Channel'];
  var id = val['ID'];
  $("[name=Enabled]").attr("checked", enabled == "yes");
  $("[name=SendBus]").attr("checked", sendBus == "yes");
  $('[name=Channel]').val(channel);
  $('[name=ID]').val(id);
  idChange();
  var arr = val["arr"];
  for (var i = 0; i < arr.length; i++) {
    var array = arr[i].split(",");
    $box = $('.box').clone(true);
    $box.children('[name=a]').val(array[0]);
    $box.children('[name=b]').val(array[1]);
    $box.children('[name=c]').val(array[2]);
    $('.border').append($box[0]);
  }
  check($('[name=Enabled]'));
}

function clearBox() {
  $('.border').children('div:not(:first-child)').remove();
  setConfig();
}

function idChange() {
  var num = Number($('[name=ID]').val());
  var v = num.toString(16);
  if (v.length == 1) v = "0" + v;
  $('[name=id2]').val(v).attr("value", v);
}
$('[name=ID]').on("change", function () {
  var val = $(this).val();
  val = compareVal(this, val);
  $(this).val(val);
  var v16 = val.toString(16);
  if (v16.length == 1) v16 = "0" + v16;
  $('[name=id2]').val(v16);
}).on('input', function (e) {
  if (e.which == undefined) {
    var step = $(this).attr("step").length - 2;
    var val = Number($(this).val());
    var v = step > 0 ? val.toFixed(step) : val;
    $(this).val(v);
    var v16 = val.toString(16);
    if (v16.length == 1) v16 = "0" + v16;
    $('[name=id2]').val(v16);
  }
  setConfig();
}).on('keypress', function (e) {
  if (!(e.charCode >= 48 && e.charCode <= 57) && !(e.charCode == 45 || e.charCode == 46)) return false;
})

$('[name=id2]').bind("input propertychange", function () {
  var v = $(this).val();
  var arr = v.split("");
  for (var i = 0; i < arr.length; i++) {
    if (arr[i] == 0) {
      arr.shift();
      i--;
    }
  }
  // var value = $(this).attr('value');
  if (!Number("0x" +v) || arr.length >= 4 || parseInt(Number("0x" + $(this).attr("value")), 10) > 2047) { //包含汉字
    $(this).addClass("red");
  } else {
    $(this).removeClass("red");
    $(this).attr('value', v);
  }
}).blur(function () {
  $(this).val($(this).attr("value")).removeClass("red").parent().prev().find("input").val(parseInt(Number("0x" + $(this).attr("value")), 10));
});

$('[name=ID]').focus(function () {
  var num = Number($(this).val());
  var v = num.toString(16);
  if (v.length == 1) v = "0" + v;
  $('[name=id2]').val(v);
  $('[name=id2]').attr('value', v);
  $('[name=id2]').removeClass('red');
});

function compareVal(obj, val) {
  var step = $(obj).attr('step').length > 2 ? $(obj).attr('step').length - 2 : 0;
  var v = Number(val);
  var newVal = "";
  if (isNaN(val) || !Boolean(val)) {
    newVal = Number($(obj).attr('value'));
  } else {
    var min = Number($(obj).attr('min')),
      max = Number($(obj).attr('max'));
    v = v < min ? min : v;
    v = v > max ? max : v;
    if (step > 0) {
      newVal = Math.round((Math.abs(v) * Math.pow(10, step)).toFixed(1)) / Math.pow(10, step);
      if (v < 0) newVal = -newVal;
    } else {
      newVal = Math.floor(v);
    }
  }
  return step > 0 ? newVal.toFixed(step) : newVal;
}
/**
 * 写配置
 */

function setConfig() {
  var text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root";
  var enabled = $("[name=Enabled]").get(0).checked ? "yes" : "no";
  var sendBus = $("[name=SendBus]").get(0).checked ? "yes" : "no";
  var channel = $("[name=Channel]").val();
  var id = $('[name=ID]').val();
  text += " " + "Enabled" + "=\"" + enabled + "\"";
  text += " " + "SendBus" + "=\"" + sendBus + "\"";
  text += " " + "Channel" + "=\"" + channel + "\"";
  text += " " + "ID" + "=\"" + id + "\"";
  text += " >";
  if ($('.border').children('div').length > 1) {
    text += "<FreVsdB";
    $('.border').children('div').each(function (i, v) {
      if (i != 0) {
        var a = $(this).find('[name=a]').val();
        var b = $(this).find('[name=b]').val();
        var c = $(this).find('[name=c]').val();
        var t = a + "," + b + "," + c;
        text += " " + "element" + (i - 1) + "=\"" + t + "\"";
      }
    });
    text += " />";
  } else {
    text += "<FreVsdB/>";
  }
  text += "</root>";
  biSetModuleConfig("audio-analysis.aspluginaudioanalysis", text);
}

function biOnInitEx(config, moduleConfigs) {
  var lang = biGetLanguage() == 1 ? en : cn;
  $('[language]').each(function () {
    var value = $(this).attr('language');
    $(this).text(lang[value])
  });
  for (var key in moduleConfigs) {
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    var countrys = xmlDoc.getElementsByTagName('root');
    var keys = countrys[0].attributes;
    var obj = new Object();
    for (var i = 0; i < keys.length; i++) {
      obj[keys[i].nodeName] = keys[i].nodeValue;
    }
    var arr = [];
    if (countrys[0].children.length != 0) {
      var childrenOne = countrys[0].children[0];
      var keyss = childrenOne.attributes;
      for (var i = 0; i < keyss.length; i++) {
        var t = keyss[i].nodeValue;
        arr.push(t);
      }
      obj.arr = arr;
    }
    loadConfig(obj);
  }
}