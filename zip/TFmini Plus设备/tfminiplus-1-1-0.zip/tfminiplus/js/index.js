let aName = '',
  viewSize = new BISize(348, 455),
  language = sessionStorage.getItem("language");
if (language == null) {
  changeLanguage(2);
}
$('input[type=number]').on({
  'change': function (e) {
    if ($(this).attr('type') == 'number') {
      compareVal(this);
      setConfig();
    }
  },
  'keypress': function (e) {
    if (e.charCode < 48 || e.charCode > 57) {
      return false;
    }
  },
  'keyup': function () {
    setConfig();
  }
});
$('.container [name]').change(function () {
  setConfig();
});
$('[type=text]').bind("input propertychange", function () {
  let val = $(this).val();
  $(this).removeClass('red');
  if (!isNaN(val)) {
    val = Number($(this).val());
    let init = Number(String(val).substr(0, 1));
    if (init <= 3) {
      if(val>2147483647){
        $(this).addClass('red');
        return;
      }
      String(val).length <= 10 ? $(this).attr('value', val) : $(this).addClass('red');
    } else if (init == 4) {
      if (String(val).substr(1, 1) <= 2) {
        String(val).length <= 10 ? $(this).attr('value', val) : $(this).addClass('red');
      } else {
        String(val).length <= 9 ? $(this).attr('value', val) : $(this).addClass('red');
      }
    } else if (init >= 5) {
      String(val).length <= 9 ? $(this).attr('value', val) : $(this).addClass('red');
    }
  } else {
    $(this).addClass('red');
  }
  setConfig();
})
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(290, 460);
  let type = biGetLanguage();
  changeLanguage(type);
  sessionStorage.setItem("language", type);
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('config');
    let keys = countrys[0].getAttributeNames();
    let obj = new Object();
    for (let i = 0; i < keys.length; i++) {
      obj[keys[i]] = countrys[0].getAttribute(keys[i]);
    };
    loadConfig(JSON.stringify(obj));
  }
}
function loadConfig(config) {
  if (config == null) return;
  let val = JSON.parse(config);
  $('[name]').each(function () {
    let name = $(this).attr('name'),
      type = $(this).attr("type");
    if (type == "checkbox") {
      val[name] == "yes" ? $(this).attr('checked', true) : $(this).attr('checked', false);
    } else if (type == "number") {
      let min = parseFloat($(this).attr('min')),
        max = parseFloat($(this).attr('max'));
      if (val[name] < min) {
        val[name] = min;
      } else if (val[name] > max) {
        val[name] = max;
      }
      let value = Number(val[name]).toFixed(0);
      $(this).val(val[name] == '' ? $(this).attr('value') : value);
    } else {
      $(this).attr('value', val[name]).val(val[name]);
    }
  });
}
function changeLanguage(type) {
  if (type == 1) { //英文
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(en[value])
    });
  } else { //中文
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(cn[value])
    });
  }
}
function compareVal(obj) {
  let val = parseFloat($(obj).val());
  if (isNaN(val)) { val = Number($(obj).attr('value')); }
  let min = parseFloat($(obj).attr('min')),
    max = parseFloat($(obj).attr('max'));
  if (val < min) {
    val = min
  } else if (val > max) {
    val = max
  }
  val = val.toFixed(0);
  $(obj).val(val);
  return val;
}
function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><config";
  $('[name]').each(function () {
    let v = '',
      type = $(this).attr("type"),
      val = $(this).attr('value');
    if (type == "checkbox") {
      v = $(this).get(0).checked ? "yes" : "no";
    } else if ($(this).is('a')) {
      v = $(this).html().indexOf('(') == -1 ? val : '';
    } else if (type == 'text') {
      v = $(this).attr('value');
    } else {
      v = $(this).val();
    }
    text += " " + $(this).attr('name') + "=\"" + v + "\"";
  });
  text += "/></root>";
  biSetModuleConfig("tfminiplus.asplugintfminiplus", text);
}
