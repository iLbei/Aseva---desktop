var cn = {
    Enable: "启用",
    not_config: "<未配置>",
    client: "客户端",
    server: "服务",
    ServiceId: "服务ID:",
    InstanceId: "实例ID:",
    MethodId: "方法ID:",
    EventId: "事件ID:",
    EventGroupId: "事件组ID:",
    ApplicationName: "应用名称:",
    ConfigFile: "JSON配置文件:"
  },
  en = {
    server: "Server",
    client: "Client",
    Enable: "Enabled",
    not_config: "<Not Configured>",
    ServiceId: "Service ID:",
    InstanceId: "Instance ID:",
    MethodId: "Method ID:",
    EventId: "Event ID:",
    EventGroupId: "Event group ID:",
    ApplicationName: "Application Name:",
    ConfigFile: "Config JSON File:"
  };