let cn = {
  enabled: "启用",
  channel:"通道"
},
  en = {
      enabled: "Enabled",
      channel:"Channel "
  };