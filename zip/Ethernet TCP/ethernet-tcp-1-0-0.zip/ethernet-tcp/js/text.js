var cn = {
  Enabled: "启用",
  ip: "IP地址:",
  port: "端口号:",
  bus_channel: "总线通道:",
},
  en = {
    Enabled: "Enabled",
    ip: "IP:",
    port: "Port:",
    bus_channel: "Bus Channel:",
  };