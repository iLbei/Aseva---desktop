let num, config, obj, n;
$(function () {
    config = sessionStorage.getItem("horizon_config");
    if (config == '') {
        config = `<?xml version=\"1.0\" encoding=\"utf-8\"?><root></root>`
    };
    num = sessionStorage.getItem("num");
    obj = parseXml(config);
    n = num == 0 ? "" : "" + num;
    let arr = obj["arr" + n];
    if (arr != undefined && arr.length != 0) {
        let txt = "";
        for (let i = 0; i < arr.length; i++) {
            let o = arr[i];
            txt += "<div class=\"fixclear\">";
            txt += "<div class=\"c-1 left\" onclick=\"onClick(this)\"></div>";
            txt += "<div class=\"left\"><input type=\"text\" value=\"" + o["cam_id" + n] + "\" name=\"cam_id\"></div>";
            txt += "<div class=\"left\"><input type=\"text\" value=\"" + o["rear" + n] + "\" name=\"rear\"></div>";
            txt += "<div class=\"left\"><input type=\"text\" value=\"" + o["front" + n] + "\" name=\"front\"></div>";
            txt += "</div>";
        }
        txt += "<div class=\"fixclear\">";
        txt += "<div class=\"c-1 left\" onclick=\"onClick(this)\"></div>";
        txt += "<div class=\"left\"><input type=\"text\" name=\"cam_id\"></div>";
        txt += "<div class=\"left\"><input type=\"text\" name=\"rear\"></div>";
        txt += "<div class=\"left\"><input type=\"text\" name=\"front\"></div>";
        txt += "</div>";
        $('.content>.table>.bottom').html(txt);
    }
});

$('.content').on('click', 'input', function (e) {
    $('input').each(function () {
        $(this).removeClass('blue2');
    })
    $('.c-1').each(function () {
        $(this).removeClass('blue');
    })
    $(this).addClass('blue2');
})
$('.content').on('input', 'input', function (e) {
    editInput(this);
    $(this).removeClass('blue2');
})
function editInput(obj) {
    let element = $(obj).parent().parent().next()[0];
    if (!element) {
        let text = "<div class=\"fixclear\">";
        text += "<div class=\"c-1 left\" onclick=\"onClick(this)\"></div>";
        text += "<div class=\"left\"><input type=\"text\" name=\"cam_id\"></div>";
        text += "<div class=\"left\"><input type=\"text\" name=\"rear\"></div>";
        text += "<div class=\"left\"><input type=\"text\" name=\"front\"></div>";
        text += "</div>";
        $(obj).parent().parent().parent().append(text);
        setConfig();
    }
}

function ok() {
    let xmlDoc = $($.parseXML(config));
    let line_bound = $(xmlDoc).find('root').children('line_bound' + n);
    if (line_bound != undefined) $(line_bound).remove();
    $('.content>.table>.bottom>div').each(function () {
        let cam_id = $(this).find('[name=cam_id]').val();
        let rear = $(this).find('[name=rear]').val();
        let front = $(this).find('[name=front]').val();
        if (cam_id != "" && rear != "" && front != "") {
            let c = Number(cam_id),
                r = Number(rear),
                f = Number(front);
            if (Number.isInteger(c) && Number.isInteger(r) && Number.isInteger(f)) {
                let line = "<line_bound" + n + " cam_id" + n + "=\"" + c + "\" rear" + n + "=\"" + r + "\" front" + n + "=\"" + f + "\" />";
                $(xmlDoc).find('root').append(line);
            }
        }
    });
    let xmlHead = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
    let xml = xmlHead + $(xmlDoc).find('root')[0].outerHTML;
    sessionStorage.setItem("horizon_config", xml);
    window.location.href = "horizon-matrix-cameras.html";
}

function onClick(obj) {
    if ($(obj).hasClass('all')) {
        $(obj).addClass('flag');
        $('.bottom>div').each(function () {
            $(this).children().each(function () {
                if ($(this).hasClass('c-1')) {
                    if (!$(this).hasClass('blue')) $(this).addClass('blue');
                } else {
                    if (!$(this).hasClass('blue2')) $(this).children().addClass('blue2');
                }
            })
        });
    } else {
        $('.bottom>div').each(function () {
            $(this).children().each(function () {
                if ($(this).hasClass('c-1')) {
                    if ($(this).hasClass('blue')) $(this).removeClass('blue');
                } else {
                    if ($(this).children().hasClass('blue2')) $(this).children().removeClass('blue2');
                }
            })
        });
        $(obj).addClass('blue').nextAll().children().addClass('blue2');
    }

}
//监听键盘del键
$('body').keydown(function (event) {
    let e = event || window.event;
    if (e.keyCode == 46) {
        if ($('.all').hasClass('flag')) {
            let i = 0;
            while (i < $('.bottom').children().length - 1) {
                $('.bottom').children()[i].remove();
                i = 0;
            }
        } else {
            let flag = $('.blue').parent().next()[0];
            if (flag) $('.blue').parent().remove();
        }
    }
})
function biOnInitEx(cig, moduleConfigs) {
    biSetViewSize(476, 210);
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(biGetLanguage() == 1 ? en[value] : cn[value])
    });
  }