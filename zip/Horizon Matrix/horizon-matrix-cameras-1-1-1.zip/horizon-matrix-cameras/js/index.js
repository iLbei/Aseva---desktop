let vehicle = [];
$('button').click(function () {
  $(this).addClass('white').siblings().removeClass('white');
  let num = $(this).index();
  $('.container>.center>div:eq(' + num + ')').show().siblings().hide();
});
$('.container [name]').change(function () {
  setConfig();
});
$('[type=number]').on({
  'change': function () {
    compareVal(this);
    setConfig();
    if ($(this).attr('name').indexOf('port') != -1) return;
    xChange(this);
  },
  'blur': function () {
    compareVal(this);
    if ($(this).attr('name').indexOf('port') != -1) return;
    xChange(this);
  },
  'input': function (e) {
    if (e.which == undefined) {
      let step = $(this).attr('step');
      $(this).val(Number($(this).val()).toFixed(step.length - 2));
      if ($(this).attr('name').indexOf('port') != -1) return;
      xInput(this);
    }
    $(this).attr('value', numberCheck(this))
    setConfig();
  },
  'keypress': function (e) {
    if (e.charCode == 43) return false;
  }
});
$('input[type=text]').on('input', function () {
  setConfig();
})
$('body').keyup(function (event) {
  let e = event || window.event;
  if (e.keyCode == 8) {
    $('input').each(function () {
      $(this).attr('value', $(this).val())
    })
    setConfig();
  }
})
function loadConfig(config) {
  if (config == null) return;
  let val = JSON.parse(config);
  $('.container>.center>div').each(function (i, v) {
    $(this).find('[name]').each(function () {
      let key = $(this).attr('name');
      let type = $(this).attr('type');
      if (i != 0) key += i;
      if (type == "checkbox") {
        if (val[key] == "yes") {
          $(this).attr('checked', true);
        }
      } else if (type == "number") {
        if (val[key] == '' || val[key] == 'null' || val[key] == undefined) return;
        let step = $(this).attr('step').length - 2;
        let v = parseFloat(val[key]);
        if (step <= -1) {
          $(this).val(v.toFixed(0));
        } else {
          $(this).val(v.toFixed(step));
        }
      } else if (type == "radio") {
        if (val[key] == $(this).val()) $(this).attr("checked", true);
      } else {
        if (val[key] == '' || val[key] == 'null' || val[key] == undefined) return;
        $(this).val(val[key]);
      }
    });
    draw($(this));
  });
}
function biOnInitEx(cig, moduleConfigs) {
  biSetViewSize(390, 541);
  biQueryGlobalVariable('Subject.VehicleWidth', '1.6');
  biQueryGlobalVariable('Subject.VehicleHeight', '1.9');
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value])
  });
  let config = sessionStorage.getItem('horizon_config');
  if (config == null) {
    for (let key in moduleConfigs) {
      config = moduleConfigs[key];
      sessionStorage.setItem('horizon_config', config);
    }
  }
  let obj = parseXml(config);
  loadConfig(JSON.stringify(obj));
}
function onForword(obj) {
  let num = $(obj).parent().parent().parent().parent().parent().parent().index();
  sessionStorage.setItem('num', num);
  window.location.href = "horizon-matrix-cameras.table.html";
}
function numberCheck(obj) {
  let min = Number($(obj).attr("min"));
  let max = Number($(obj).attr('max'));
  let value = Number($(obj).val());
  if (value < min) {
    return min;
  } else if (value > max) {
    return max;
  } else {
    return value;
  }
}
function draw(obj) {
  if (vehicle.length < 2) return;
  let canvas = $(obj).find('.myCanvas')[0];
  let ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, 143, 180);
  let p1 = new BIPoint(0, 46),
    p2 = new BIPoint(canvas.width, 46),
    p3 = new BIPoint(canvas.width / 2, 0),
    p4 = new BIPoint(canvas.width / 2, canvas.height),
    p5 = new BIPoint(canvas.width / 2 - Number(vehicle[0]) * 10, 46),
    p6 = new BIPoint(canvas.width / 2, 46),
    p7 = new BIPoint(canvas.width / 2 - Number(vehicle[0]) * 10, Number(vehicle[1]) * 15+45),
    p8 = new BIPoint(canvas.width / 2 + Number(vehicle[0]) * 10, Number(vehicle[1]) * 15+45),
    s = new BISize(Number(vehicle[0]) * 20, Number(vehicle[1]) * 50);
  drawLine(p1, p2, 1, "#e9e9e9", ctx);
  drawLine(p3, p4, 1, "#e9e9e9", ctx);
  let arr = [p6, p7, p8]
  drawPolygon(arr, "black", ctx);
  drawRect(p5, s, "black", ctx);
  let x = numberCheck($(obj).find('[name=pos_x]'));
  let y = numberCheck($(obj).find('[name=pos_y]'));
  let xScale = x * 24 / 1.5,
    yScale = 15 * y;
  let p = new BIPoint(canvas.width / 2 - yScale, 46 - xScale);
  let p10 = new BIPoint(canvas.width / 2 - yScale, 46 - 24 - xScale),
    p11 = new BIPoint(canvas.width / 2 - 15 - yScale, 46 - xScale),
    p12 = new BIPoint(canvas.width / 2 - 10 - yScale, 46 - xScale),
    p13 = new BIPoint(canvas.width / 2 + 10 - yScale, 46 - xScale),
    p14 = new BIPoint(canvas.width / 2 - yScale, 46 - 10 - xScale),
    p15 = new BIPoint(canvas.width / 2 - yScale, 46 + 10 - xScale),
    radius = 10;
  drawCircle(p, radius, '#9a79dd', 1, ctx);
  ctx.beginPath();
  ctx.moveTo(p10.x, p10.y);
  ctx.lineTo(p.x, p.y);
  ctx.lineTo(p11.x, p11.y);
  ctx.strokeStyle = "#32cd32";
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(p12.x, p12.y);
  ctx.lineTo(p13.x, p13.y);
  ctx.strokeStyle = "#9a79dd";
  ctx.stroke();
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(p14.x, p14.y);
  ctx.lineTo(p15.x, p15.y);
  ctx.strokeStyle = "#9a79dd";
  ctx.stroke();
}
function drawPolygon(arr, color, ctx) {
  ctx.beginPath();
  ctx.moveTo(arr[0].x, arr[0].y);
  ctx.lineTo(arr[1].x, arr[1].y);
  ctx.lineTo(arr[2].x, arr[2].y);
  ctx.strokeStyle = color;
  ctx.closePath();
  ctx.stroke();
}
function drawLine(p1, p2, width, color, ctx) {
  ctx.beginPath();
  ctx.lineWidth = width;
  ctx.moveTo(p1.x, p1.y);
  ctx.lineTo(p2.x, p2.y);
  ctx.closePath();
  ctx.strokeStyle = color;
  ctx.stroke();
}
function drawRect(p, s, color, ctx) {
  ctx.beginPath();
  ctx.rect(p.x, p.y, s.width, s.height);
  ctx.strokeStyle = color;
  ctx.stroke();
}
function drawCircle(p, radius, color, width, ctx) {
  ctx.beginPath();
  ctx.lineWidth = width;
  ctx.strokeStyle = color;
  ctx.arc(p.x, p.y, radius, 0, Math.PI * 2, false);
  ctx.stroke();
}
function onClick(obj) {
  if ($(obj).hasClass('all')) {
    $(obj).addClass('flag');
    $('.bottom>div').each(function () {
      $(this).children().each(function () {
        if ($(this).hasClass('c-1')) {
          if (!$(this).hasClass('blue')) $(this).addClass('blue');
        } else {
          if (!$(this).hasClass('blue2')) $(this).children().addClass('blue2');
        }
      })
    });
  } else {
    $('.bottom>div').each(function () {
      $(this).children().each(function () {
        if ($(this).hasClass('c-1')) {
          if ($(this).hasClass('blue')) $(this).removeClass('blue');
        } else {
          if ($(this).children().hasClass('blue2')) $(this).children().removeClass('blue2');
        }
      })
    });
    $(obj).addClass('blue').nextAll().children().addClass('blue2');
  }

}
function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root ";
  $('.container>.center>div').each(function (i, v) {
    let f = i == 0 ? "" : "" + i;
    $(this).find('[name]').each(function () {
      let key = $(this).attr('name');
      let type = $(this).attr('type');
      if (type == "checkbox") {
        let n = $(this).get(0).checked == true ? "yes" : "no";
        text += " " + key + f + "=\"" + n + "\"";
      } else if (type == "radio" && $(this).get(0).checked) {
        text += " " + key + f + "=\"" + $(this).val() + "\"";
      } else if (type == "number") {
        text += " " + key + f + "=\"" + $(this).attr('value') + "\"";
      } else if (type != "radio") {
        text += " " + key + f + "=\"" + $(this).val() + "\"";
      }
    });
  });
  let config = sessionStorage.getItem('horizon_config');
  let object = config == null ? undefined : parseXml(config);
  if (object != undefined) {
    let arr = object.arr,
      arr1 = object.arr1,
      arr2 = object.arr2,
      arr3 = object.arr3;
    if (arr != undefined || arr1 != undefined || arr2 != undefined || arr3 != undefined) {
      text += " >";
      if (arr != undefined) {
        for (let i = 0; i < arr.length; i++) {
          text += "<line_bound";
          text += " cam_id" + "=\"" + arr[i].cam_id + "\"";
          text += " rear" + "=\"" + arr[i].rear + "\"";
          text += " front" + "=\"" + arr[i].front + "\"";
          text += "/>";
        }
      }
      if (arr1 != undefined) {
        for (let i = 0; i < arr1.length; i++) {
          text += "<line_bound1";
          text += " cam_id1" + "=\"" + arr1[i].cam_id1 + "\"";
          text += " rear1" + "=\"" + arr1[i].rear1 + "\"";
          text += " front1" + "=\"" + arr1[i].front1 + "\"";
          text += "/>";
        }
      }
      if (arr2 != undefined) {
        for (let i = 0; i < arr2.length; i++) {
          text += "<line_bound2";
          text += " cam_id2" + "=\"" + arr2[i].cam_id2 + "\"";
          text += " rear2" + "=\"" + arr2[i].rear2 + "\"";
          text += " front2" + "=\"" + arr2[i].front2 + "\"";
          text += "/>";
        }
      }
      if (arr3 != undefined) {
        for (let i = 0; i < arr3.length; i++) {
          text += "<line_bound3";
          text += " cam_id3" + "=\"" + arr3[i].cam_id3 + "\"";
          text += " rear3" + "=\"" + arr3[i].rear3 + "\"";
          text += " front3" + "=\"" + arr3[i].front3 + "\"";
          text += "/>";
        }
      }
    }
    text += "</root>";
  } else {
    text += " />";
  }
  sessionStorage.setItem('horizon_config', text);
  biSetModuleConfig("horizon-matrix-cameras.horizonmatrix", text);
  console.log(text);
}
function compareVal(obj) {
  let step = $(obj).attr('step').length - 2;
  let v = parseFloat($(obj).val());
  if (isNaN(v)) { v = Number($(obj).attr('value')); }
  let min = parseFloat($(obj).attr('min')),
    max = parseFloat($(obj).attr('max'));
  v = v < min ? min : v;
  v = v > max ? max : v;
  let value;
  if (step <= -1) {
    value = v.toFixed(0);
  } else {
    value = v.toFixed(step);
  }
  $(obj).val(value).attr('value', value);
}
function xChange(obj) {
  let o = $(obj).parent().parent().parent().parent().parent().parent().parent();
  draw(o);
}
function xInput(obj) {
  let v = $(obj).val();
  let min = Number($(obj).attr('min'));
  let max = Number($(obj).attr('max'));
  if (v < min || v > max) return
  let o = $(obj).parent().parent().parent().parent().parent().parent().parent();
  draw(o);
}
function parseXml(text) {
  if (text == '') return;
  let parser = new DOMParser();
  let xmlDoc = parser.parseFromString(text, "text/xml");
  let countrys = xmlDoc.getElementsByTagName('root');
  let line_bound = xmlDoc.getElementsByTagName('line_bound');
  let line_bound1 = xmlDoc.getElementsByTagName('line_bound1');
  let line_bound2 = xmlDoc.getElementsByTagName('line_bound2');
  let line_bound3 = xmlDoc.getElementsByTagName('line_bound3');
  let keys = countrys[0].getAttributeNames();
  let obj = new Object();
  let lineArr = [],
    lineArr1 = [],
    lineArr2 = [],
    lineArr3 = [];
  for (let i = 0; i < keys.length; i++) {
    obj[keys[i]] = countrys[0].getAttribute(keys[i]);
  };
  for (let i = 0; i < line_bound.length; i++) {
    let keys2 = line_bound[i].getAttributeNames();
    let o = new Object();
    for (let j = 0; j < keys2.length; j++) {
      o[keys2[j]] = line_bound[i].getAttribute(keys2[j]);
    };
    lineArr.push(o);
  }
  for (let i = 0; i < line_bound1.length; i++) {
    let keys2 = line_bound1[i].getAttributeNames();
    let o = new Object();
    for (let j = 0; j < keys2.length; j++) {
      o[keys2[j]] = line_bound1[i].getAttribute(keys2[j]);
    };
    lineArr1.push(o);
  }
  for (let i = 0; i < line_bound2.length; i++) {
    let keys2 = line_bound2[i].getAttributeNames();
    let o = new Object();
    for (let j = 0; j < keys2.length; j++) {
      o[keys2[j]] = line_bound2[i].getAttribute(keys2[j]);
    };
    lineArr2.push(o);
  }
  for (let i = 0; i < line_bound3.length; i++) {
    let keys2 = line_bound3[i].getAttributeNames();
    let o = new Object();
    for (let j = 0; j < keys2.length; j++) {
      o[keys2[j]] = line_bound3[i].getAttribute(keys2[j]);
    };
    lineArr3.push(o);
  }
  obj["arr"] = lineArr;
  obj["arr1"] = lineArr1;
  obj["arr2"] = lineArr2;
  obj["arr3"] = lineArr3;
  return obj;
}
function biOnQueriedGlobalVariable(id, value) {
  vehicle.push(value);
  $('.container>.center>div').each(function () {
    draw($(this));
  });
}