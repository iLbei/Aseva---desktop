let num, config, obj, n;
$(function () {
    config = sessionStorage.getItem("horizon_config");
    if (config == '') {
        config = `<?xml version=\"1.0\" encoding=\"utf-8\"?><root></root>`
    };
    num = sessionStorage.getItem("num");
    obj = paserXml(config);
    n = num == 0 ? "" : "" + num;
    let arr = obj["arr" + n];
    if (arr != undefined && arr.length != 0) {
        let txt = "";
        for (let i = 0; i < arr.length; i++) {
            let o = arr[i];
            txt += "<div class=\"fixclear\">";
            txt += "<div class=\"c-1 left\" onclick=\"onClick(this)\"></div>";
            txt += "<div class=\"left\"><input type=\"text\" value=\"" + o["cam_id" + n] + "\" name=\"cam_id\"></div>";
            txt += "<div class=\"left\"><input type=\"text\" value=\"" + o["rear" + n] + "\" name=\"rear\"></div>";
            txt += "<div class=\"left\"><input type=\"text\" value=\"" + o["front" + n] + "\" name=\"front\"></div>";
            txt += "</div>";
        }
        txt += "<div class=\"fixclear\">";
        txt += "<div class=\"c-1 left\" onclick=\"onClick(this)\"></div>";
        txt += "<div class=\"left\"><input type=\"text\" name=\"cam_id\"></div>";
        txt += "<div class=\"left\"><input type=\"text\" name=\"rear\"></div>";
        txt += "<div class=\"left\"><input type=\"text\" name=\"front\"></div>";
        txt += "</div>";
        $('.content>.table>.bottom').html(txt);
    }
});

/**
 * 编辑
 */
$('.content').on('click', 'input', function (e) {
    editInput(this);
    inputClick(this)
})
$('.content').on('input','input',function(){
    $(this).removeClass('blue2');
})
function inputClick(obj) {
    $('input').each(function () {
        $(this).removeClass('blue2');
    })
    $('.c-1').each(function () {
        $(this).removeClass('blue');
    })
    $(obj).addClass('blue2');
}
function editInput(obj) {
    let element = $(obj).parent().parent().next()[0];
    if (!element) {
        let text = "<div class=\"fixclear\">";
        text += "<div class=\"c-1 left\" onclick=\"onClick(this)\"></div>";
        text += "<div class=\"left\"><input type=\"text\" name=\"cam_id\"></div>";
        text += "<div class=\"left\"><input type=\"text\" name=\"rear\"></div>";
        text += "<div class=\"left\"><input type=\"text\" name=\"front\"></div>";
        text += "</div>";
        $(obj).parent().parent().parent().append(text);
        setConfig();
    }
}

function ok() {
    let xmlDoc = $($.parseXML(config));
    let line_bound = $(xmlDoc).find('root').children('line_bound' + n);
    if (line_bound != undefined) $(line_bound).remove();
    $('.content>.table>.bottom>div').each(function () {
        let cam_id = $(this).find('[name=cam_id]').val();
        let rear = $(this).find('[name=rear]').val();
        let front = $(this).find('[name=front]').val();
        if (cam_id != "" && rear != "" && front != "") {
            let c = Number(cam_id),
                r = Number(rear),
                f = Number(front);
            if (Number.isInteger(c) && Number.isInteger(r) && Number.isInteger(f)) {
                let line = "<line_bound" + n + " cam_id" + n + "=\"" + c + "\" rear" + n + "=\"" + r + "\" front" + n + "=\"" + f + "\" />";
                $(xmlDoc).find('root').append(line);
            }
        }
    });
    let xmlHead = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
    let xml = xmlHead + $(xmlDoc).find('root')[0].outerHTML;
    sessionStorage.setItem("horizon_config", xml);
    window.location.href = "horizon-matrix-cameras.html";
}

function paserXml(text) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(text, "text/xml");
    let countrys = xmlDoc.getElementsByTagName('root');
    let line_bound = xmlDoc.getElementsByTagName('line_bound');
    let line_bound1 = xmlDoc.getElementsByTagName('line_bound1');
    let line_bound2 = xmlDoc.getElementsByTagName('line_bound2');
    let line_bound3 = xmlDoc.getElementsByTagName('line_bound3');
    if (countrys[0] != undefined) {
        let keys = countrys[0].getAttributeNames();
        let obj = new Object();
        let lineArr = [],
            lineArr1 = [],
            lineArr2 = [],
            lineArr3 = [];
        for (let i = 0; i < keys.length; i++) {
            obj[keys[i]] = countrys[0].getAttribute(keys[i]);
        };
        for (let i = 0; i < line_bound.length; i++) {
            let keys2 = line_bound[i].getAttributeNames();
            let o = new Object();
            for (let j = 0; j < keys2.length; j++) {
                o[keys2[j]] = line_bound[i].getAttribute(keys2[j]);
            };
            lineArr.push(o);
        }
        for (let i = 0; i < line_bound1.length; i++) {
            let keys2 = line_bound1[i].getAttributeNames();
            let o = new Object();
            for (let j = 0; j < keys2.length; j++) {
                o[keys2[j]] = line_bound1[i].getAttribute(keys2[j]);
            };
            lineArr1.push(o);
        }
        for (let i = 0; i < line_bound2.length; i++) {
            let keys2 = line_bound2[i].getAttributeNames();
            let o = new Object();
            for (let j = 0; j < keys2.length; j++) {
                o[keys2[j]] = line_bound2[i].getAttribute(keys2[j]);
            };
            lineArr2.push(o);
        }
        for (let i = 0; i < line_bound3.length; i++) {
            let keys2 = line_bound3[i].getAttributeNames();
            let o = new Object();
            for (let j = 0; j < keys2.length; j++) {
                o[keys2[j]] = line_bound3[i].getAttribute(keys2[j]);
            };
            lineArr3.push(o);
        }
        obj["arr"] = lineArr;
        obj["arr1"] = lineArr1;
        obj["arr2"] = lineArr2;
        obj["arr3"] = lineArr3;
        return obj;
    }

}

/**
 * 点击
 * @param {*} obj 当前元素
 */
function onClick(obj) {
    if ($(obj).hasClass('all')) {
        $(obj).addClass('flag');
        $('.bottom>div').each(function () {
            $(this).children().each(function () {
                if ($(this).hasClass('c-1')) {
                    if (!$(this).hasClass('blue')) $(this).addClass('blue');
                } else {
                    if (!$(this).hasClass('blue2')) $(this).children().addClass('blue2');
                }
            })
        });
    } else {
        $('.bottom>div').each(function () {
            $(this).children().each(function () {
                if ($(this).hasClass('c-1')) {
                    if ($(this).hasClass('blue')) $(this).removeClass('blue');
                } else {
                    if ($(this).children().hasClass('blue2')) $(this).children().removeClass('blue2');
                }
            })
        });
        $(obj).addClass('blue').nextAll().children().addClass('blue2');
    }

}
//监听键盘del键
$('body').keydown(function (event) {
    let e = event || window.event;
    if (e.keyCode == 46) {
        if ($('.all').hasClass('flag')) {
            let i = 0;
            while (i < $('.bottom').children().length - 1) {
                $('.bottom').children()[i].remove();
                i = 0;
            }
        } else {
            let flag = $('.blue').parent().next()[0];
            if (flag) $('.blue').parent().remove();
        }
    }
})
function biOnInitEx(cig, moduleConfigs) {
    biSetViewSize(476, 210);
    let type = sessionStorage.getItem("language");
    changeLanguage(type);
}