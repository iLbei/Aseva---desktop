let reg = /^[a-zA-Z]:/,
  input_data_path_list = '',
  output_data_path_list = '',//用来接收独立任务中output_data_path_list的内容
  data_path = '',
  generationID = '';
$('a').on('click', function () {
  switch ($(this).attr('name')) {
    case "input_data_path": {
      biSelectPath("input_data_path", BISelectPathType.Directory, null);
      break;
    }
    case "output_data_path": {
      biSelectPath("output_data_path", BISelectPathType.Directory, null);
      break;
    }
  }
});
$('[name]').on('change', function () {
  setConfig();
});
$('button').on({
  'click': function () {
    let val = '',
      local_path = $('[name=local_path]').is(":checked") ? 'yes' : 'no',
      split = reg.test($('[name=input_data_path]').html()) ? '\\' : '\/';
    val = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><config ";
    input_data_path_list = $('[name=input_data_path]').html();
    //获取output_data_path_list
    if (local_path == 'no') {
      //截取input路径片段：最后文件夹名称
      output_data_path_list = input_data_path_list.substr(0, input_data_path_list.lastIndexOf(split));
      let name = output_data_path_list.substr(output_data_path_list.lastIndexOf(split) + 1, output_data_path_list.length);
      output_data_path_list = $('[name=output_data_path]').html() + name + split + ';';
    } else {
      output_data_path_list = data_path;
    }
    $('a').each(function () {
      let name = $(this).attr('name');
      let value = $(this).html();
      if (name == "output_data_path") {
        value = output_data_path_list.substr(0, output_data_path_list.length - 1);
      } else if (name == 'input_data_path') {
        if ($('[name=main_lidar_channel]').val() == -1) {
          if (!$('[name=local_path]').is(':checked')) {
            value = input_data_path_list + split;
          }
        } else {
          $('[name=local_path]').is(':checked') ? data_path.substr(0, data_path.length - 1) : input_data_path_list + split;
        }
      }
      if (name.indexOf('data_path') != -1) name += '_list';
      val += name + "=\"" + value + "\" ";
    });
    $('select').each(function () {
      let name = $(this).attr('name');
      val += name + "=\"" + $(this).val() + "\" ";
    })
    val += " local_path=\"" + local_path + "\" ";
    val += "/></root>";
    biSetViewConfig(val);
    if ($('[name=input_data_path]').html().indexOf('(Not') == -1 && $('[name=input_data_path]').html().indexOf('(未配置)') == -1 && $('[name="format"]').val() != 0) {
      if (($('[name=local_path]').is(':checked') || ($('[name=output_data_path]').html().indexOf('(Not') == -1 && $('[name=output_data_path]').html().indexOf('(未配置)') == -1)) && !($('[name=main_lidar_channel]').val() == -1 && $('[name=local_path]').is(':checked'))) {
        biRunStandaloneTask('PCDMergeProc', 'pcd-merge-task.aspluginpcdmerge', val);
      }
    }
  }
})

function biOnSelectedPath(key, path) {
  if (path == null) {
    $('[name=' + key + ']').removeAttr('title').html(language == 1 ? '(Not configured)' : '(未配置)');
  } else {
    $('[name=' + key + ']').attr('title', path + (reg.test(path) ? '\\' : '\/')).html(path + (reg.test(path) ? '\\' : '\/'));
  };
  setConfig();
}
function loadConfig(config) {
  if (config == null) return;
  $('[name]').each(function () {
    let val = config[$(this).attr('name')];
    if ($(this).is('a')) {
      if (val == '') {
        $(this).html(biGetLanguage() == 1 ? '(Not Configured)' : '(未配置)')
      } else {
        $(this).html(val).attr('title', val)
      }
    } else if ($(this).is('input[type=checkbox]')) {
      $(this).prop('checked', val == 'yes' ? true : false);
    } else {
      $(this).val(val);
    }
  })
  data_path = biGetDataPath();
  split = reg.test(data_path) ? '\\' : '\/';
  data_path = '';
  biQuerySessionList(false);
}

function biOnQueriedSessionList(list, filtered) {
  for (let i in list) {
    biQuerySessionPath(list[i])
  }
}
function biOnQueriedSessionPath(path, session) {
  biQueryDirectoryExist(path + split + 'input' + split + 'etc')
}
function biOnQueriedDirectoryExist(exist, path) {
  if (exist) data_path += path + split + ';';
}

function setConfig() {
  text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><config ";
  $('[name]').each(function () {
    let name = $(this).attr('name');
    if ($(this).is('select')) {
      text += name + "=\"" + $(this).val() + "\" ";
    } else if ($(this).is('a')) {
      text += name + "=\"" + ($(this).html().indexOf('(Not Configured)') != -1 || $(this).html().indexOf('(未配置)') != -1 ? '' : $(this).html()) + "\" ";
    } else if ($(this).is('input[type=checkbox]')) {
      text += name + "=\"" + ($(this).is(":checked") ? 'yes' : 'no') + "\" ";
    }
  });
  text += "/></root>";
  biSetModuleConfig("pcd-merge.aspluginpcdmerge", text);
}
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(520, 190);
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value])
  });
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('root');
    let keys = countrys[0].childNodes[0].getAttributeNames();
    let obj = new Object();
    for (let i = 0; i < keys.length; i++) {
      obj[keys[i]] = countrys[0].childNodes[0].getAttribute(keys[i]);
    }
    loadConfig(obj);
  }
}