let cn = {
  input_data_path: "输入数据路径:",
  output_data_path: "输出数据路径:",
  format: "目标格式:",
  merge: "合成",
  main_lidar_channel:"主激光雷达通道:",
  local_path:"本地路径",
  pcd_merged_channel:"合并后通道:"
},
en = {
  input_data_path: "Input data path:",
  output_data_path: "Output data path:",
  format: "Target format:",
  merge: "Merge",
  main_lidar_channel:"Main lidar channel:",
  local_path:"Local Path",
  pcd_merged_channel:"Merged channel:"
};
