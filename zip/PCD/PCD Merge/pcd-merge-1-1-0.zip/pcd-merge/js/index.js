let reg = /^[a-zA-Z]:/,
  input_data_path_list = '',
  output_data_path_list = '',//用来接收独立任务中output_data_path_list的内容
  data_path = '',
  generationID = '',
  task_config = '',
  not_config = '',
  count = 0,
  dataLength = 0;
$('a').on('click', function () {
  switch ($(this).attr('name')) {
    case "input_data_path": {
      biSelectPath("input_data_path", BISelectPathType.Directory, null);
      break;
    }
    case "output_data_path": {
      biSelectPath("output_data_path", BISelectPathType.Directory, null);
      break;
    }
  }
});
$('[name]').on('change', function () {
  setConfig();
});
$('button').on({
  'click': function () {
    times = 0, existCount = 0, count = 0;
    let local_path = $('[name=local_path]').is(":checked") ? 'yes' : 'no',
      split = reg.test(data_path == '' ? $('[name=input_data_path]').html() : data_path) ? '\\' : '\/',
      path = '';
    task_config = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><config ";
    input_data_path_list = $('[name=input_data_path]').html();
    //获取output_data_path_list
    if (local_path == 'no') {
      //截取input路径片段：最后文件夹名称
      output_data_path_list = input_data_path_list.substr(0, input_data_path_list.lastIndexOf(split));
      let name = output_data_path_list.substr(output_data_path_list.lastIndexOf(split) + 1, output_data_path_list.length);
      output_data_path_list = $('[name=output_data_path]').html() + name + split + ';';
    } else {
      output_data_path_list = data_path;
    }
    $('a').each(function () {
      let name = $(this).attr('name');
      let value = $(this).html();
      if (name == "output_data_path") {
        value = output_data_path_list.substr(0, output_data_path_list.length - 1);
      } else if (name == 'input_data_path') {
        if ($('[name=main_lidar_channel]').val() == -1) {
          if (!$('[name=local_path]').is(':checked')) {
            // value = input_data_path_list + split;
            value = input_data_path_list;
          }
        } else {
          // value = $('[name=local_path]').is(':checked') ? data_path.substr(0, data_path.length - 1) : input_data_path_list + split;
          value = $('[name=local_path]').is(':checked') ? data_path.substr(0, data_path.length - 1) : input_data_path_list;
        }
      }
      if (name.indexOf('data_path') != -1) name += '_list';
      task_config += name + "=\"" + value + "\" ";
    });
    $('select').each(function () {
      let name = $(this).attr('name');
      task_config += name + "=\"" + $(this).val() + "\" ";
    })
    task_config += " local_path=\"" + local_path + "\" ";
    task_config += "/></root>";
    biSetViewConfig(task_config);
    if (!$('[name=local_path]').is(':checked')) {
      biQueryDirectoryExist(input_data_path_list + 'pcd_Merge');
    }
    path = output_data_path_list.substr(0, output_data_path_list.length - 1).split(';')
    dataLength = path.length;//获取数据文件夹下文件夹的个数
    for (let i in path) {
      biQueryDirectoryExist(path[i] + 'pcd_Merge');
    }
  }
})

function biOnSelectedPath(key, path) {
  if (path == null) {
    $('[name=' + key + ']').removeAttr('title').html(not_config);
  } else {
    $('[name=' + key + ']').attr('title', path + (reg.test(path) ? '\\' : '\/')).html(path + (reg.test(path) ? '\\' : '\/'));
  };
  setConfig();
}
function loadConfig(config) {
  if (config == null) return;
  $('[name]').each(function () {
    let val = config[$(this).attr('name')];
    if ($(this).is('a')) {
      if (val == '') {
        $(this).html(not_config)
      } else {
        $(this).html(val).attr('title', val)
      }
    } else if ($(this).is('input[type=checkbox]')) {
      $(this).prop('checked', val == 'yes' ? true : false);
    } else {
      $(this).val(val);
    }
  })
  data_path = biGetDataPath();
  split = reg.test(data_path) ? '\\' : '\/';
  data_path = '';
  biQuerySessionList(false);
}

function biOnQueriedSessionList(list, filtered) {
  for (let i in list) {
    biQuerySessionPath(list[i])
  }
}
function biOnQueriedSessionPath(path, session) {
  biQueryDirectoryExist(path + split + 'input' + split + 'etc')
}
let times = 0, existCount = 0;//times:查询文件夹次数，existCount：有pcd_merge个数
function biOnQueriedDirectoryExist(exist, path) {
  if (path.indexOf('etc') != -1 && path.length - path.indexOf('etc') == 3) {
    if (exist) data_path += path + split + ';';
  } else if (path.indexOf('pcd_Merge') != -1) {
    times++;
    if (exist) {
      biDirectoryDelete(path,true);
    };
    if ($('[name="format"]').val() != 0 && count == 0  && dataLength == times) {
      if (($('[name=local_path]').is(':checked') || ($('[name=output_data_path]').html().indexOf(not_config) == -1)) && !($('[name=main_lidar_channel]').val() == -1 && $('[name=local_path]').is(':checked'))) {
        count++;
        biRunStandaloneTask('PCDMergeProc', 'pcd-merge-task.aspluginpcdmerge', task_config);
      }
    }
  };
}

function setConfig() {
  text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><config ";
  $('[name]').each(function () {
    let name = $(this).attr('name');
    if ($(this).is('select')) {
      text += name + "=\"" + $(this).val() + "\" ";
    } else if ($(this).is('a')) {
      text += name + "=\"" + ($(this).html().indexOf(not_config) != -1 ? '' : $(this).html()) + "\" ";
    } else if ($(this).is('input[type=checkbox]')) {
      text += name + "=\"" + ($(this).is(":checked") ? 'yes' : 'no') + "\" ";
    }
  });
  text += "/></root>";
  biSetModuleConfig("pcd-merge.aspluginpcdmerge", text);
}
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(520, 190);
  $('[language]').each(function () {
    let value = $(this).attr('language');
    if (biGetLanguage() == 1) {
      not_config = '(Not Configured)';
      $(this).html(en[value])
    } else {
      not_config = '(未配置)';
      $(this).html(cn[value])
    }

  });
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('root');
    let keys = countrys[0].childNodes[0].getAttributeNames();
    let obj = new Object();
    for (let i = 0; i < keys.length; i++) {
      obj[keys[i]] = countrys[0].childNodes[0].getAttribute(keys[i]);
    }
    loadConfig(obj);
  }
}