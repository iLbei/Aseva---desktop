let empty='';
$('input').change(function () {
  setConfig();
});
$('[name="savepath"]').click(function () {
  biSelectPath("OpenFilePath:1", BISelectPathType.Directory, null);
})
function loadConfig(config) {
  if (config == null) return
  let obj = JSON.parse(config);
  //多选框和单选框
  $('input').each(function () {
    let type = $(this).attr('type');
    let name = $(this).attr('name');
    if (type == 'checkbox') {
      if (name != "channelFiltering") {
        obj[name] == 1 ? $(this).attr('checked', true) : $(this).removeAttr('checked');
      }
    } else if (type == 'radio') {
      if (obj[name] == $(this).attr('id')) {
        $(this).prop('checked', true);
        $('[name=' + name + ']').val(obj[name]);
      }
    }
    let channelFiltering = obj['channelFiltering'].split(",");
    $('[name =channelFiltering]').prop('checked', false);
    for (let j in channelFiltering) {
      if (channelFiltering[j] != "") {
        $('[name =channelFiltering]').eq(channelFiltering[j]).prop("checked", true)
      }
    }
  })
  //a标签
  $('[name=savepath]').html(obj['savepath'] == '' ? '(Empty)' : obj['savepath'].substring(0, obj['savepath'].length - 1));
  if ($('[name=savepath]').html().indexOf('(') == -1) {
    $('[name=savepath]').addClass('springgreen');
  }
}
function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root";
  $('input').each(function () {
    let name = $(this).attr('name');
    if (name == 'format') {
      if ($(this).is(':checked')) {
        text += " " + name + "=\"" + $(this).attr('id') + "\"";
      }
    } else if (name != "channelFiltering") {
      text += " " + name + "=\"" + ($(this).is(':checked') ? 1 : 0) + "\"";
    }
  })
  let channelFiltering = "";
  $("[name =channelFiltering]").each(function () {
    if ($(this).is(":checked")) channelFiltering += $(this).index() + ',';
  })
  text += " channelFiltering=\"" + channelFiltering.substr(0, channelFiltering.length - 1) + "\"";
  let savepath = $('[name="savepath"]').html();
  text += " savepath=\"" + (savepath.indexOf(empty)!=-1 ? '' : savepath + (/^[a-zA-Z]:/.test(savepath) ?  '\\': '\/')) + "\"";
  text += "/>";
  biSetModuleConfig("export-as-pcd.aspluginpcdexport", text);
}
function biOnSelectedPath(key, path) {
  if (path == null) {
    $('[name=savepath]').removeClass('springgreen');
    return;
  }
  if (key.indexOf("OpenFilePath") != -1) {
    let strs = key.split(":");
    if (strs[1] == 1) {
      $('[name=savepath]').html(path).addClass('springgreen');
    }
  }
  setConfig();
}
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(424, 169);
  $('[language]').each(function () {
    let value = $(this).attr('language');
    if (biGetLanguage() == 1) {
      empty = "(Empty)";
      $(this).html(en[value]);
    } else {
      empty = "(空)";
      $(this).html(cn[value]);
    }

  });
  for (let key in moduleConfigs) {
    let parser = new DOMParser();//创建一个空的xml文档对象
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");//把名为modeleConfigs的字符串载入到解析器中
    let countrys = xmlDoc.getElementsByTagName('root');//获取setconfig里面的root标签
    let keys = countrys[0].getAttributeNames();//获取root标签的属性名
    let obj = new Object();
    for (let i = 0; i < keys.length; i++) {
      obj[keys[i]] = countrys[0].getAttribute(keys[i]);
    }
    loadConfig(JSON.stringify(obj));
  }
}