var cn = {
  enable: "启用",
  only_xyzi: '仅XYZI',
  empty: '<空>',
  data_format: '数据格式:',
  binary: '二进制',
  ascii: 'ascii',
  channelFiltering:'通道过滤'
},
en = {
  enable: "Enable",
  only_xyzi: 'only XYZI',
  empty: '<Empty>',
  data_format: 'Data format:',
  binary: 'binary',
  ascii: 'ascii',
  channelFiltering:'Channel filtering'
};