let language = sessionStorage.getItem("language"),
  configuration = "",
  cn = {
    enable: "启用",
    only_xyzi: '仅XYZI',
    empty: '(空)',
    data_format: '数据格式:',
    binary: '二进制',
    ascii: 'ascii'
  },
  en = {
    enable: "Enable",
    only_xyzi: 'only XYZI',
    empty: '(Empty)',
    data_format: 'Data format:',
    binary: 'binary',
    ascii: 'ascii'
  };

if (language != null) {
  changeLanguage(language);
}
$('input').change(function () {
  setConfig();
});
$('[name="savepath"]').click(function () {
  biSelectPath("OpenFilePath:1", BISelectPathType.Directory, null);
})
function changeLanguage(type) {
  if (type == 1) {
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(en[value])
    });
  } else {
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(cn[value])
    });
  }
}
function loadConfig(config) {
  if (config == null) return
  let obj = JSON.parse(config);
  //多选框和单选框
  $('input').each(function () {
    let type = $(this).attr('type');
    let name = $(this).attr('name');
    if (type == 'checkbox') {
      obj[name] == 1 ? $(this).attr('checked', true) : $(this).removeAttr('checked');
    } else if (type == 'radio') {
      if (obj[name] == $(this).attr('id')) {
        $(this).prop('checked', true);
        $('[name=' + name + ']').val(obj[name]);
      }
    }
  })
  //a标签
  $('[name=savepath]').html(obj['savepath'] == '' ? '(Empty)' : obj['savepath']);
  if ($('[name=savepath]').html().indexOf('(') == -1) {
    $('[name=savepath]').addClass('springgreen');
  }
}
function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root";
  // checkbox
  $('input').each(function () {
    if ($(this).attr('name') == 'format') {
      if ($(this).is(':checked')) {
        text += " " + $(this).attr('name') + "=\"" + $(this).attr('id') + "\"";
      }
    } else {
      text += " " + $(this).attr('name') + "=\"" + ($(this).is(':checked') ? 1 : 0) + "\"";
    }
  })
  text += " savepath=\"" + ($('[name="savepath"]').html().indexOf('(') != -1 ? '' : $('[name="savepath"]').html()) + "\"";
  text += "/>";
  biSetModuleConfig("export-as-pcd.aspluginpcdexport", text);
}
function biOnSelectedPath(key, path) {
  if (path == null) {
    $('[name=savepath]').removeClass('springgreen');
    return;
  }
  if (key == "CreateFilePath") {
    createFileHandle = biFileCreate(path);
    if (createFileHandle != null) {
      document.getElementById('button-write').disabled = false;
    }
  } else if (key.indexOf("OpenFilePath") != -1) {
    let strs = key.split(":");
    if (strs[1] == 1) {
      $('[name=savepath]').html(path).addClass('springgreen');
    }
    var handle = biFileOpen(path);
    if (handle != null) biFileClose(handle);
  }
  setConfig();
}
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(260, 118);
  let type = biGetLanguage();
  changeLanguage(type);
  sessionStorage.setItem("language", type);
  configuration = moduleConfigs;
  for (let key in moduleConfigs) {
    let parser = new DOMParser();//创建一个空的xml文档对象
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");//把名为modeleConfigs的字符串载入到解析器中
    let countrys = xmlDoc.getElementsByTagName('root');//获取setconfig里面的root标签
    let keys = countrys[0].getAttributeNames();//获取root标签的属性名
    let obj = new Object();
    for (let i = 0; i < keys.length; i++) {
      obj[keys[i]] = countrys[0].getAttribute(keys[i]);
    }
    loadConfig(JSON.stringify(obj));
  }
}