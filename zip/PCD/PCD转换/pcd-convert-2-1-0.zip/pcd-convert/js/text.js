var cn = {
  input_data_path: "输入数据路径:",
  output_data_path: "输出数据路径:",
  format: "目标格式:",
  import: "导入"
},
en = {
  input_data_path: "Input data path:",
  output_data_path: "Output data path:",
  format: "Target format:",
  import: "Import"
};
