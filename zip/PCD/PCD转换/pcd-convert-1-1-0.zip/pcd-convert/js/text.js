let cn = {
  input_data_path: "输入数据路径:",
  output_data_path: "输出数据路径:",
  format: "目标格式:",
  not_config: "(未配置)",
  import: "转换"
},
en = {
  input_data_path: "Input data path:",
  output_data_path: "Output data path:",
  format: "Target format:",
  not_config: "(Not Configured)",
  import: "Convert"
};
