let aPath = '',
  parser = new DOMParser();
$('a').on('click', function () {
  switch ($(this).attr('name')) {
    case "input_data_path": {
      biSelectPath("input_data_path", BISelectPathType.Directory, null);
      break;
    }
    case "output_data_path": {
      biSelectPath("output_data_path", BISelectPathType.Directory, null);
      break;
    }
  }
});
$('[name]').on('change', function () {
  setConfig();
});
$('button').on({
  'click': function () {
    let val = '';
    val = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><config ";
    $('a').each(function () {
      val += $(this).attr('name') + "=\"" + ($(this).html().indexOf('(') != -1 ? '' : $(this).html() + '\\') + "\" ";
    });
    val += " format=\"" + $('[name=format]').val() + "\" " + "file_list" + "=\"" + (aPath.length > 1 ? aPath.substring(0, aPath.length - 1) : '') + "\"/></root>";
    localStorage.setItem('pcd-convert-task', val);
    if ($('[name=input_data_path]').html().indexOf('(') == -1 && $('[name=output_data_path]').html().indexOf('(') == -1 && $('[name=format]').val() != 0) {
      biRunStandaloneTask('PCDConvertProc', 'pcd-convert-task.aspluginpcdexport', val);
    }
  },
  "mousedown":function(){
    $(this).parent().addClass('border2').removeClass('border1')
  },
  "mouseup":function(){
    $(this).parent().removeClass('border2').addClass('border1')
  }
})
function biOnQueriedDirsInDirectory(dirs, path) {
  if (dirs[0] != '') {
    let dir = dirs[0].split('\n');
    for (let i in dir) {
      biQueryFilesInDirectory(dir[i]);
    }
  }
}
function biOnQueriedFilesInDirectory(files, path) {
  let filesArr = [];
  files = files[0].split('\n');
  for (let i in files) {
    let index = files[i].lastIndexOf('\\');
    let str = files[i].substring(0, index);
    index = str.lastIndexOf('\\') + 1;
    str = files[i].substring(index);
    filesArr.push(str);
  }
  aPath += filesArr.join(',') + ',';
}
function biOnSelectedPath(key, path) {
  if (key == "input_data_path") {
    $('[name=input_data_path]').html(path ? path : (language == 1 ? '(Not configured)' : '(未配置)'));
  } else if (key == 'output_data_path') {
    $('[name=output_data_path]').html(path ? path : (language == 1 ? '(Not configured)' : '(未配置)'));
  }
  setConfig();
  aPath = '';
  biQueryDirsInDirectory($('[name=input_data_path]').html());
}
function loadConfig(config) {
  if (config == null) return
  $('[name=format]').val(!config['format'] ? 'yes' : config['format']);
  $('a').each(function () {
    $(this).html(config[$(this).attr('name')] == '' ? (language == 1 ? '(Not configured)' : '(未配置)') : config[$(this).attr('name')]);
  });
}
function setConfig() {
  text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><config ";
  $('a').each(function () {
    text += $(this).attr('name') + "=\"" + ($(this).html().indexOf('(') != -1 ? '' : $(this).html()) + "\" ";
  });
  text += " format=\"" + $('[name=format]').val() + "\"></root>";
  biSetModuleConfig("pcd-convert-task.aspluginpcdexport", text);
  localStorage.setItem('pcd-convert', text)
}
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(520, 190);
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value])
  });
  let pcd_convert = localStorage.getItem('pcd-convert');
  if (pcd_convert) {
    let xmlDoc = parser.parseFromString(pcd_convert, "text/xml");
    let keys = xmlDoc['all'][5]['attributes'];
    let obj = new Object();
    for (let i in keys) {
      let name = keys[i].nodeName;
      let val = keys[i].nodeValue;
      obj[name] = val;
    }
    loadConfig(obj);
    if (keys['input_data_path'].nodeValue) {
      aPath = '';
      biQueryDirsInDirectory($('[name=input_data_path]').html());
    }
  }
}