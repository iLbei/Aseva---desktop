let language = sessionStorage.getItem("language"),
  cn = {
    enable: "启用",
    only_xyzi: '仅 XYZI',
    local_path: '本地路径',
    empty: '(空)',
    binary: '二进制',
    ascii: 'ascii',
    binary_compressed: '二进制压缩',
    absolute_time_file:'绝对时间文件名',
    absolute_time_points:'绝对时间点云'
  },
  en = {
    enable: "Enable",
    only_xyzi: 'only XYZI',
    local_path: 'Local path',
    empty: '(Empty)',
    binary: 'binary',
    ascii: 'ascii',
    binary_compressed: 'binary compressed',
    absolute_time_file:'Absolute time file',
    absolute_time_points:'Absolute time points'
  };

if (language != null) {
  changeLanguage(language);
}

$('input').on('change', function () {
  setConfig();
});
$('[name="savepath"]').on('click', function () {
  biSelectPath("OpenFilePath:1", BISelectPathType.Directory, null);
});
function changeLanguage(type) {
  if (type == 1) {
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(en[value])
    });
  } else {
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(cn[value])
    });
  }
}
function loadConfig(config) {
  if (config == null) return
  let obj = JSON.parse(config);
  //多选框和单选框
  $('input').each(function () {
    if ($(this).attr('type') == 'checkbox') {
      obj[$(this).attr('name')] == 1 ? $(this).attr('checked', true) : $(this).removeAttr('checked');
    } else if ($(this).attr('type') == 'radio') {
      if (obj[$(this).attr('name')] == $(this).attr('id')) {
        $(this).prop('checked', true)
      }
    }
  })
  //a标签
  $('[name=savepath]').html(obj['savepath'] == '' ? '(Empty)' : obj['savepath'].substring(0,obj['savepath'].length-1));
  if ($('[name=savepath]').html().indexOf('(') == -1) {
    $('[name=savepath]').addClass('springgreen');
  }
}
function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root";
  // checkbox
  $('input').each(function () {
    if ($(this).attr('name') == 'format') {
      if ($(this).is(':checked')) {
        text += " " + $(this).attr('name') + "=\"" + $(this).attr('id') + "\"";
      }
    } else {
      text += " " + $(this).attr('name') + "=\"" + ($(this).is(':checked') ? 1 : 0) + "\"";
    }
  })
  text += " app_mode=\"" + biGetRunningMode() + "\" ";
  text += " savepath=\"" + ($('[name="savepath"]').html().indexOf('(') != -1 ? '' : $('[name="savepath"]').html()+'\\') + "\"";
  let myDate = new Date();
  let now = myDate.getFullYear() + getNow(myDate.getMonth() + 1).toString() + getNow(myDate.getDate()) + "-" + getNow(myDate.getHours()) + '-' + getNow(myDate.getMinutes()) + "-" + getNow(s = myDate.getSeconds());
  text += " starttime=\"" + now + "\"/>";
  biSetModuleConfig("pcd-export-process.aspluginpcdexport", text);
}
function getNow(s) {
  return s < 10 ? '0' + s : s;
}
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(405, 155);
  let type = biGetLanguage();
  changeLanguage(type);
  sessionStorage.setItem("language", type);
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('root');
    let keys = countrys[0].getAttributeNames();
    let obj = new Object();
    for (let i = 0; i < keys.length; i++) {
      obj[keys[i]] = countrys[0].getAttribute(keys[i]);
    }
    loadConfig(JSON.stringify(obj));
  }
}
function biOnSelectedPath(key, path) {
  if (path == null) {
    $('[name=savepath]').removeClass('springgreen');
    return;
  }
  if (key == "CreateFilePath") {
    createFileHandle = biFileCreate(path);
    if (createFileHandle != null) {
      document.getElementById('button-write').disabled = false;
    }
  } else if (key.indexOf("OpenFilePath") != -1) {
    let strs = key.split(":");
    if (strs[1] == 1) {
      $('[name=savepath]').html(path).addClass('springgreen');
    }
    var handle = biFileOpen(path);
    if (handle != null) biFileClose(handle);
  }
  setConfig();
}