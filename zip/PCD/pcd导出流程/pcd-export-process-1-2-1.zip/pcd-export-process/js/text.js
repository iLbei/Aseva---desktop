let cn = {
  enable: "启用",
  only_xyzi: '仅 XYZI',
  local_path: '本地路径',
  empty: '(空)',
  binary: '二进制',
  ascii: 'ascii',
  binary_compressed: '二进制压缩',
  absolute_time_file:'绝对时间文件名',
  absolute_time_points:'绝对时间点云',
  channelFiltering:'通道过滤'
},
en = {
  enable: "Enable",
  only_xyzi: 'only XYZI',
  local_path: 'Local path',
  empty: '(Empty)',
  binary: 'binary',
  ascii: 'ascii',
  binary_compressed: 'binary compressed',
  absolute_time_file:'Absolute time file',
  absolute_time_points:'Absolute time points',
  channelFiltering:'Channel filtering'
};