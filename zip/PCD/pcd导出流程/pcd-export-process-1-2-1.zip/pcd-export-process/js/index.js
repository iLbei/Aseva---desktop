$('input').on('change', function () {
  setConfig();
});
$('[name="savepath"]').on('click', function () {
  biSelectPath("OpenFilePath:1", BISelectPathType.Directory, null);
});
function loadConfig(config) {
  if (config == null) return;
  //多选框和单选框
  $('input').each(function () {
    if ($(this).attr('type') == 'checkbox') {
      if (name != "channelFiltering") {
        config[$(this).attr('name')] == 1 ? $(this).attr('checked', true) : $(this).removeAttr('checked');
      }
    } else if ($(this).attr('type') == 'radio') {
      if (config[$(this).attr('name')] == $(this).attr('id')) {
        $(this).prop('checked', true)
      }
    }
    let channelFiltering = config['channelFiltering'].split(",");
    $('[name =channelFiltering]').prop('checked', false);
    for (let j in channelFiltering) {
      if (channelFiltering[j] != "") {
        $('[name =channelFiltering]').eq(channelFiltering[j]).prop("checked", true);
      }
    }
  })
  //a标签
  $('[name=savepath]').html(config['savepath'] == '' ? '(Empty)' : config['savepath'].substring(0, config['savepath'].length - 1));
  if ($('[name=savepath]').html().indexOf('(Empty)') == -1 && $('[name=savepath]').html().indexOf('(空)') == -1) {
    $('[name=savepath]').addClass('springgreen');
  }
}
function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root";
  // checkbox
  $('input').each(function () {
    let name = $(this).attr('name');
    if (name == 'format') {
      if ($(this).is(':checked')) {
        text += " " + name + "=\"" + $(this).attr('id') + "\"";
      }
    } else if (name != "channelFiltering") {
      text += " " + name + "=\"" + ($(this).is(':checked') ? 1 : 0) + "\"";
    }
  })
  let channelFiltering = "";
  $("[name =channelFiltering]").each(function () {
    if ($(this).is(":checked")) channelFiltering += $(this).index() + ',';
  })
  text += " channelFiltering=\"" + channelFiltering.substr(0, channelFiltering.length - 1) + "\"";
  text += " app_mode=\"" + biGetRunningMode() + "\" ";
  let savepath = $('[name="savepath"]').html();
  text += " savepath=\"" + (savepath.indexOf('(Empty)') != -1 || savepath.indexOf('(空)') != -1 ? '' : (savepath + (/^[a-zA-Z]:/.test(savepath) ? '\\' : '\/'))) + "\"";
  let myDate = new Date();
  let now = myDate.getFullYear() + getNow(myDate.getMonth() + 1).toString() + getNow(myDate.getDate()) + "-" + getNow(myDate.getHours()) + '-' + getNow(myDate.getMinutes()) + "-" + getNow(s = myDate.getSeconds());
  text += " starttime=\"" + now + "\"/>";
  biSetModuleConfig("pcd-export-process.aspluginpcdexport", text);
}
function getNow(s) {
  return s < 10 ? '0' + s : s;
}
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(460, 206);
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value])
  });
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('root');
    let keys = countrys[0].getAttributeNames();
    let obj = new Object();
    for (let i = 0; i < keys.length; i++) {
      obj[keys[i]] = countrys[0].getAttribute(keys[i]);
    }
    loadConfig(obj);
  }
}
function biOnSelectedPath(key, path) {
  if (path == null) {
    $('[name=savepath]').removeClass('springgreen');
    return;
  }
  if (key.indexOf("OpenFilePath") != -1) {
    let strs = key.split(":");
    if (strs[1] == 1) {
      $('[name=savepath]').html(path).addClass('springgreen');
    }
  }
  setConfig();
}