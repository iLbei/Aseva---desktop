var empty = "";
$('input').on('change', function () {
  setConfig();
});
$('[name="savepath"]').on('click', function () {
  biSelectPath("OpenFilePath:1", BISelectPathType.Directory, null);
});
function loadConfig(config) {
  if (config == null) return;
  //多选框和单选框
  $('input').each(function () {
    if ($(this).attr('type') == 'checkbox' && name != "channelFiltering") {
      config[$(this).attr('name')] == 1 ? $(this).attr('checked', true) : $(this).removeAttr('checked');
    }
  })
  $("input[type=radio][value=" + config["format"] + "]").prop('checked', true);
  var channelFiltering = config['channelFiltering'].split(",");
  $('[name =channelFiltering]').prop('checked', false);
  for (var j of channelFiltering) {
    if (j != "") {
      $('#' + j).prop("checked", true);
    }
  }
  //a标签
  var html = config['savepath'] == '' ? empty : config['savepath'].substring(0, config['savepath'].length - 1);
  $('[name=savepath]').text(html).attr("title", html);
  if ($('[name=savepath]').text().indexOf(empty) == -1) {
    $('[name=savepath]').addClass('green');
  }
}
function setConfig() {
  var text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root";
  // checkbox
  $('input').each(function () {
    var name = $(this).attr('name');
    if (name == 'format') {
      if ($(this).is(':checked')) {
        text += " " + name + "=\"" + $(this).attr('value') + "\"";
      }
    } else if (name != "channelFiltering") {
      text += " " + name + "=\"" + ($(this).is(':checked') ? 1 : 0) + "\"";
    }
  })
  var channelFiltering = "";
  $("[name =channelFiltering]").each(function () {
    if ($(this).is(":checked")) channelFiltering += $(this).attr("id") + ',';
  })
  text += " channelFiltering=\"" + channelFiltering.substr(0, channelFiltering.length - 1) + "\"";
  text += " app_mode=\"" + biGetRunningMode() + "\" ";
  var savepath = $('[name="savepath"]').html();
  text += " savepath=\"" + (savepath.indexOf(empty) != -1 ? '' : (savepath + (/^[a-zA-Z]:/.test(savepath) ? '\\' : '\/'))) + "\"";
  var myDate = new Date();
  var now = myDate.getFullYear() + getNow(myDate.getMonth() + 1).toString() + getNow(myDate.getDate()) + "-" + getNow(myDate.getHours()) + '-' + getNow(myDate.getMinutes()) + "-" + getNow(s = myDate.getSeconds());
  text += " starttime=\"" + now + "\"/>";
  biSetModuleConfig("pcd-export-process.aspluginpcdexport", text);
}
function getNow(s) {
  return s < 10 ? '0' + s : s;
}
function biOnInitEx(config, moduleConfigs) {
  $('[language]').each(function () {
    var value = $(this).attr('language');
    if (biGetLanguage() == 1) {
      $(this).html(en[value]);
      empty = "<Empty>";
    } else {
      $(this).html(cn[value]);
      empty = "<空>";
    }
  });
  for (var key in moduleConfigs) {
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    var countrys = xmlDoc.getElementsByTagName('root');
    var keys = countrys[0].attributes;
    var obj = new Object();
    for (var i = 0; i < keys.length; i++) {
      obj[keys[i].nodeName] = keys[i].nodeValue;
    }
    loadConfig(obj);
  }
}
function biOnSelectedPath(key, path) {
  if (path == null) {
    $('[name=savepath]').removeClass('green');
    return;
  }
  if (key.indexOf("OpenFilePath") != -1) {
    var strs = key.split(":");
    if (strs[1] == 1) {
      $('[name=savepath]').html(path).attr("title", path).addClass('green');
    }
  }
  setConfig();
}