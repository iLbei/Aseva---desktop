var cn = {
  not_config:"<未配置>",
  bus_channel: "总线通道:",
  flexray_data_path: "Flexray数据路径:",
  sync_data_path:"数据转换"
},
en = {
  not_config:"<Not Configured>",
  bus_channel: "Bus Channel:",
  flexray_data_path: "Flexray Data Path:",
  sync_data_path:"SYNC Flexray Data"
};