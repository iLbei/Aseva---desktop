let cn = {
  enabled: "启用",
  channel: "通道",
  listeng_mode:"监听模式"
},
  en = {
    enabled: "Enabled",
    channel: "Channel ",
    listeng_mode:"Listen-only mode"
  };