let channels = [];
$('input:text').on('keyup', function () {
  $(this).addClass('green');
  if ($(this).attr('name') == 'send_port') {
    if (!(Number($(this).val()))) {
      $(this).removeClass('green').addClass('red');
    } else {
      $(this).addClass('green').removeClass('red');
    }
  }
  if ($(this).hasClass('red')) return;
  setConfig();
})
$('[name=connect],[name=send_ip],[name=send_port]').change(function () {
  setConfig();
});
$('.channel input:checkbox').on('change', function () {
  let id = $(this).attr('id');
  if ($(this).is(':checked')) {
    channels.push(id);
  } else {
    for (let i in channels) {
      if (channels[i] == id) channels.splice(i, 1);
    }
  }
  setConfig();
})
$('[language=cancel]').on('click', function () {
  channels = [];
  $('.channel input:checkbox:checked').removeAttr('checked');
  setConfig();
})
function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root";
  text += " connect" + "=\"" + ($('[name=connect]').get(0).checked == true ? "yes" : "no") + "\"";
  text += " send_ip" + "=\"" + $('[name=send_ip]').val() + "\"";
  text += " send_port" + "=\"" + ($('[name=send_port]').val() != '' ? parseInt($('[name=send_port]').val()) : "") + "\"";
  text += " channel_num" + "=\"" + channels.length + "\"";
  for (let i in channels) {
    text += " channel_" + i + "=\"" + channels[i] + "\"";
  }
  text += " car=\"-1\"/>";
  console.log(text);
  biSetModuleConfig("upload-image.upimageapp", text);
}
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(310, 227);
  changeLanguage(biGetLanguage());
  for (let key in moduleConfigs) {
    
  console.log(moduleConfigs[key]);
  biPrint(moduleConfigs[key])
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let obj = new Object();
    let root = xmlDoc.getElementsByTagName('root');
    let keys = root[0].getAttributeNames();
    for (let i = 0; i < keys.length; i++) {
      if (root[0].getAttribute(keys[i]) == "null") {
        obj[keys[i]] = "";
      } else {
        obj[keys[i]] = root[0].getAttribute(keys[i]);
      }
    }
    loadConfig(obj);
  }
}
function loadConfig(val) {
  if (val == null) return;
  $('[name=send_ip]').val(val['send_ip']);
  $('[name=send_port]').val(val['send_port']);
  if (val['connect'] == "yes") $('[name=connect]').attr('checked', true);
  for (key in val) {
    if (key.indexOf('channel_') != -1 && key != 'channel_num') {
      $('#' + val[key]).attr('checked', true);
      channels.push(val[key]);
    }
  }
  $('input:text').addClass('green');
}
function changeLanguage(type) {
  if (type == 1) {
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(en[value])
    });
  } else {
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(cn[value])
    });
  }
}
