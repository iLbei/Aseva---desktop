let cn = {
  connect: "连接",
  send_ip: "IP地址:",
  send_port: "端口号:",
  choose: "推荐最多选择4路视频上传",
  cancel: "全部取消"
},
  en = {
    connect: "Connect",
    send_ip: "IP:",
    send_port: "Port:",
    choose: "It is recommended to select up to 4 channels",
    cancel: "Clear all"
  };