let cn = {
  enable: "启用",
  no_selected: '未选择',
  frequency: '频率:'
},
  en = {
      enable: "Enable",
      no_selected: 'No selected',
      frequency: 'Frequency:'
  };