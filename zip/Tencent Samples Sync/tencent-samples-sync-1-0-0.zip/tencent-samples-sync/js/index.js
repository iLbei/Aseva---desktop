let viewSize = new BISize(260, 120); //窗口大小
let language = sessionStorage.getItem("language"); //取中英文,用于刷新保存的值
let configuration = "";
let base = new Base64();
let cn = {
    enable: "启用",
    no_selected: '未选择',
    frequency: '频率:'
},
    en = {
        enable: "Enable",
        no_selected: 'No selected',
        frequency: 'Frequency:'
    };

if (language != null) {
    changeLanguage(language);
}
/**
 * 判断中英文
 */
function changeLanguage(type) {
    if (type == 1) {
        $('[language]').each(function () {
            let value = $(this).attr('language');
            $(this).html(en[value])
        });
    } else {
        $('[language]').each(function () {
            let value = $(this).attr('language');
            $(this).html(cn[value])
        });
    }
}
/**
 * 加载配置
 */
let arrA = [];
let aIndex = '';
function loadConfig(config) {
    biPrint('config');
    biPrint(config);
    if (config == null) return
    let obj = JSON.parse(config);
    obj.enable == "true" ? $('[name=enable]').attr('checked', true) : $('[name=enable]').removeAttr('checked');

    // 下拉框
    $('select').each(function () {
        if (typeof ($(this).attr('name')) == 'undefined') {
            $(this).val($(this).find('option').attr('value'));
        } else {
            $(this).val(obj[$(this).attr('name')]);
        }
    })
}

/**
 * 写配置
 */
function setConfig() {
    let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root";
    // enabled配置
    let m = $('[name=enable]').is(':checked') ? "true" : "false";
    text += " " + $('[name=enable]').attr('name') + "=\"" + m + "\"";
    //下拉框配置
    $('select').each(function () {
        if ($(this).attr('name') != undefined) {
            text += " " + $(this).attr('name') + "=\"" + $(this).val() + "\"";
        }
    })
    text += "/>";
    console.log(text);
    biSetModuleConfig("aspluginsamplessync.tencentsamplessync", text);
}

////////////各事件//////////////////
//鼠标经过a标签，显示提示框


//下拉框改变
function changeClassMode(obj) { }
$('select').change(function () {
    setConfig();
})
$('[type=checkbox]').click(function () {
    setConfig();
});
/**
 * 选择信号
 * @param {} obj 
 */
function biOnInitEx(config, moduleConfigs) {
    biSetViewSize(260, 100);
    let type = biGetLanguage();
    changeLanguage(type);
    sessionStorage.setItem("language", type);
    configuration = moduleConfigs;
    for (let key in moduleConfigs) {
        biPrint('100');
        biPrint(JSON.stringify(moduleConfigs));
        biPrint('101');
        biPrint(key);
        let parser = new DOMParser();//创建一个空的xml文档对象
        let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");//把名为modeleConfigs的字符串载入到解析器中
        let countrys = xmlDoc.getElementsByTagName('root');//获取setconfig里面的root标签
        biPrint('107');
        biPrint(JSON.stringify(countrys));
        let keys = countrys[0].getAttributeNames();//获取root标签的属性名
        biPrint('110');
        biPrint(keys);
        let obj = new Object();
        for (let i = 0; i < keys.length; i++) {
            obj[keys[i]] = countrys[0].getAttribute(keys[i]);
        }
        loadConfig(JSON.stringify(obj));

    }
}
function biSetViewConfig() {
    return configuration;
}

function biOnStartSession() {
}
function biSetViewSize() {
    return viewSize;
}

function biSetViewSize(width, height) {
    biUnimplemented("biSetViewSize");
}
function Base64() {
    // private property
    _keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    // public method for encoding
    this.encode = function (input) {
        var output = "";
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        var i = 0;
        input = _utf8_encode(input);
        while (i < input.length) {
            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);
            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;
            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            } else if (isNaN(chr3)) {
                enc4 = 64;
            }
            output = output +
                _keyStr.charAt(enc1) + _keyStr.charAt(enc2) +
                _keyStr.charAt(enc3) + _keyStr.charAt(enc4);
        }
        return output;
    }

    // public method for decoding
    this.decode = function (input) {
        var output = "";
        var chr1, chr2, chr3;
        var enc1, enc2, enc3, enc4;
        var i = 0;
        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
        while (i < input.length) {
            enc1 = _keyStr.indexOf(input.charAt(i++));
            enc2 = _keyStr.indexOf(input.charAt(i++));
            enc3 = _keyStr.indexOf(input.charAt(i++));
            enc4 = _keyStr.indexOf(input.charAt(i++));
            chr1 = (enc1 << 2) | (enc2 >> 4);
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            chr3 = ((enc3 & 3) << 6) | enc4;
            output = output + String.fromCharCode(chr1);
            if (enc3 != 64) {
                output = output + String.fromCharCode(chr2);
            }
            if (enc4 != 64) {
                output = output + String.fromCharCode(chr3);
            }
        }
        output = _utf8_decode(output);
        return output;
    }

    // private method for UTF-8 encoding
    _utf8_encode = function (string) {
        string = string.replace(/\r\n/g, "\n");
        var utftext = "";
        for (var n = 0; n < string.length; n++) {
            var c = string.charCodeAt(n);
            if (c < 128) {
                utftext += String.fromCharCode(c);
            } else if ((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            } else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }

        }
        return utftext;
    }

    // private method for UTF-8 decoding
    _utf8_decode = function (utftext) {
        var string = "";
        var i = 0;
        var c = c1 = c2 = 0;
        while (i < utftext.length) {
            c = utftext.charCodeAt(i);
            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            } else if ((c > 191) && (c < 224)) {
                c2 = utftext.charCodeAt(i + 1);
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                i += 2;
            } else {
                c2 = utftext.charCodeAt(i + 1);
                c3 = utftext.charCodeAt(i + 2);
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                i += 3;
            }
        }
        return string;
    }
}
