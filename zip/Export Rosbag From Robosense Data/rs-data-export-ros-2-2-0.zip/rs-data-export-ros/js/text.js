var cn = {
    Enabled: "启用",
    middleLidarIP: "中雷达IP:",
    leftLidarIP: "左雷达IP:",
    rightLidarIP: "右雷达IP:",
    gnssimuChannel: "惯导雷达:",
    frontobjectChannel: "前向目标物通道:",
    rearobjectChannel: "后向目标物通道:",
    frameSplitAngle: "分割帧角度[deg]:",
    syncTimeOffset: "Sync时间偏移:",
    RosType: "Ros类型:"
  },
  en = {
    Enabled: "Enabled",
    middleLidarIP: "Middle lidar IP:",
    leftLidarIP: "Left lidar IP:",
    rightLidarIP: "Right lidar IP:",
    gnssimuChannel: "GNSS-IMU channel:",
    frontobjectChannel: "Frontobject channel:",
    rearobjectChannel: "Rearobject channel:",
    frameSplitAngle: "Frame split angle [deg]:",
    syncTimeOffset: "Sync time offset:",
    RosType: "Ros type:"
  };