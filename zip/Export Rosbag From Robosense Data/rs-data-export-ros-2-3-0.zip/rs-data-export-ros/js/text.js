var cn = {
    Enabled: "启用",
    middleLidarIP: "中雷达IP:",
    leftLidarIP: "左雷达IP:",
    rightLidarIP: "右雷达IP:",
    gnssimuChannel: "组合惯导通道:",
    frontobjectChannel: "前向目标物通道:",
    rearobjectChannel: "后向目标物通道:",
    frameSplitAngle: "分割帧角度[度]:",
    syncTimeOffset: "Sync时间偏移[秒]:",
    RosType: "Ros类型:",
    timeSourceOffset:"时间源差值[毫秒]:"
  },
  en = {
    Enabled: "Enabled",
    middleLidarIP: "Middle lidar IP:",
    leftLidarIP: "Left lidar IP:",
    rightLidarIP: "Right lidar IP:",
    gnssimuChannel: "GNSS-IMU channel:",
    frontobjectChannel: "Frontobject channel:",
    rearobjectChannel: "Rearobject channel:",
    frameSplitAngle: "Frame split angle [Deg]:",
    syncTimeOffset: "Sync time offset [S]:",
    RosType: "Ros type:",
    timeSourceOffset:"Time Source Offset [ms]:"
  };