var cn = {
  Enabled: "启用",
  middleLidarIP: "中雷达IP:",
  leftLidarIP: "左雷达IP:",
  rightLidarIP: "右雷达IP:",
  gnssimuChannel: "惯导雷达:",
  frontobjectChannel: "前向目标物通道:",
  rearobjectChannel: "后向目标物通道:",
},
  en = {
    Enabled: "Enabled",
    middleLidarIP: "Middle Lidar IP:",
    leftLidarIP: "Left Lidar IP:",
    rightLidarIP: "Right Lidar IP:",
    gnssimuChannel: "GNSS-IMU Channel:",
    frontobjectChannel: "Frontobject Channel:",
    rearobjectChannel: "Rearobject Channel:",
  };