var boxIndex = -1; //记录box下标
var dialogConfig = [];
//ok
function editSceneOK() {
  var name = $('.edit_scene').find('[name=name]').val();
  var id = $('.edit_scene').find('#id').text();
  dialogConfig[boxIndex].name = name;
  dialogConfig[boxIndex].id = id;
  setConfig();
  biCloseChildDialog();
}

/**
 * 加载配置
 */
function loadConfig() {
  var box = dialogConfig[boxIndex];
  $('.edit_scene').find('[name=name]').val(box.name).select();
  $('.edit_scene').find('#id').text(box.name).attr("title", box.name);
}

$('[name=name]').on({
  "keyup": function (e) {
    var innerText = $(this).val();
    if (e.keyCode == 32) innerText = innerText.trim() + "-";
    $(this).val(innerText).parent().next().find("p").text(innerText).attr("title", innerText);
    if (innerText.length < 3) {
      $(this).parent().parent().next().children('button').attr('disabled', true);
    } else {
      $(this).parent().parent().next().children('button').removeAttr('disabled');
    }
  },
  "input": function () {
    $(this).parent().next().find('#id').text(innerText.toLowerCase());
  }
});
/**
 * 写配置
 */
function setConfig() {
  var text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root>";
  for (var i in dialogConfig) {
    text += "<s "
    for (var j in dialogConfig[i]) {
      if (j != "arr") {
        text += j + "=\"" + dialogConfig[i][j] + "\" ";
      }
    }
    if (dialogConfig[i]["arr"].length > 0) {
      text += ">";
      for (var j in dialogConfig[i]["arr"]) {
        text += "<property key=\"" + dialogConfig[i]["arr"][j].key + "\" value=\"" + dialogConfig[i]["arr"][j].value + "\" />";
      }
      text += "</s>";

    } else {
      text += "/>";
    }
  }
  text += "</root>";
  biSetLocalVariable("scene-by-signal", JSON.stringify(dialogConfig));
  biSetModuleConfig("scene-by-signal.system", text);
}

function biOnInitEx(config, moduleConfigs) {
  boxIndex = Number(config);
  var lang = biGetLanguage() == 1 ? en : cn;
  $('[language]').each(function () {
    var value = $(this).attr('language');
    $(this).text(lang[value])
  });
  for (var key in moduleConfigs) {
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    var countrys = xmlDoc.getElementsByTagName('root');
    for (var i = 0; i < countrys[0].childNodes.length; i++) {
      var keyss = countrys[0].childNodes[i].attributes;
      var obj = new Object();
      for (var j = 0; j < keyss.length; j++) {
        obj[keyss[j].nodeName] = keyss[j].nodeValue;
      }
      var array = [];
      for (var j = 0; j < countrys[0].childNodes[i].childNodes.length; j++) {
        var keysss = countrys[0].childNodes[i].childNodes[j].attributes;
        var object = new Object();
        for (var k = 0; k < keysss.length; k++) {
          object[keysss[k].nodeName] = keysss[k].nodeValue;
        }
        array.push(object);
      }
      obj.arr = array;
      dialogConfig.push(obj);
    }
    loadConfig();
  }
}