let viewSize = new BISize(728, 371); //窗口大小
let language = sessionStorage.getItem("language"); //取中英文,用于刷新保存的值
let configuration = "";
let boxIndex = -1; //记录box下标
let arrBox = [];
let opt = ["=", "<", ">=", ">", "<=", "!="];
$(function () {
  $('[name=cancel_timeout]').next().hide();
});

class Box {
  constructor(name, id, enabled, trigger_condition, end_condition, cancel_condition, begin_offset, end_offset, cancel_timeout, arr) {
    this.name = name;
    this.id = id;
    this.enabled = enabled;
    this.trigger_condition = trigger_condition;
    this.end_condition = end_condition;
    this.cancel_condition = cancel_condition;
    this.begin_offset = begin_offset;
    this.end_offset = end_offset;
    this.cancel_timeout = cancel_timeout;
    this.arr = arr;
  }
}
class Property {
  constructor(key, value) {
    this.key = key;
    this.value = value;
  }
}
$('[type=number]').bind('input propertychange', function () {
  let n = Number($(this).val());
  if (isNaN(n) && $(this).val() !== "-") {
    n = $(this).attr('value');
    $(this).val(n);
  }
  let index = $(this).parent().parent().parent().parent().parent().parent().index();
  let name = $(this).attr('name');
  let box = arrBox[index - 1];
  box[name] = n;
}).blur(function () {
  numChange($(this));
  setConfig();
});
$(".container").on("change","[name]",function(){
  setConfig();
})
$('[name=enabled]').click(function () {
  let index = $(this).parent().parent().parent().parent().index();
  let box = arrBox[index - 1];
  box.enabled = $(this).get(0).checked ? "yes" : "no";
});



function numChange(obj) {
  let value = $(obj).val();
  let step = $(obj).attr('step').length - 2;
  let min = Number($(obj).attr('min'));
  let max = Number($(obj).attr('max'));
  let v = Number(value);
  if (!isNaN(v)) {
    v = v < min ? min : v;
    v = v > max ? max : v;
    let value;
    if (step <= -1) {
      value = v.toFixed(0);
    } else {
      value = v.toFixed(step);
    }
    $(obj).attr('value', value).val(value);
  } else {
    $(obj).val($(obj).attr('value'));
  }
}
//添加
function add() {
  $box = $('.container>.content>div:nth-of-type(1)').clone(true);
  $('.container>.content').append($box[0]);
  let name = $box.children('p').html();
  let id = $box.find('.id').html();
  let n = -1;
  let flag = false;
  $('.container>.content>div').each(function (i, v) {
    if (i != 0) {
      let tt = $(this).find('p').html();
      if (name == tt) {
        n++;
      }
    }
  });
  for (let i = 0; i < arrBox.length; i++) {
    let box = arrBox[i];
    if (id == box.id) {
      flag = true;
      break;
    }
  }

  if (n > 0 && flag) {
    id = id + "-" + n;
  }
  $box.find('.id').html(id);
  let enabled = $box.find('[name=enabled]').is(':checked');
  let trigger_condition = $box.find('.trigger_condition').html();
  trigger_condition = trigger_condition.indexOf("(") == -1 ? trigger_condition : null;
  let end_condition = $box.find('.end_condition').html();
  end_condition = end_condition.indexOf("(") == -1 ? end_condition : null;
  let cancel_condition = $box.find('.cancel_condition').html();
  cancel_condition = cancel_condition.indexOf("(") == -1 ? cancel_condition : null;
  let begin_offset = $box.find('[name=begin_offset]').val();
  let end_offset = $box.find('[name=end_offset]').val();
  let cancel_timeout = $box.find('[name=cancel]').is(':checked') ? $box.find('[name=cancel_timeout]').val() : null;
  let box = new Box(name, id, enabled, trigger_condition, end_condition, cancel_condition, begin_offset, end_offset, cancel_timeout, []);
  arrBox.push(box);
}

//删除
function remove(obj) {
  let index = $(obj).parent().parent().parent().index() - 1;
  $(obj).parent().parent().parent().remove();
  arrBox.splice(index, 1);
  setConfig();
}
//openEditScene
function openEditScene(obj) {
  boxIndex = $(obj).parent().parent().parent().parent().index();
  let box = arrBox[boxIndex - 1];
  $('.edit_scene').find('[name=name]').val(box.name);
  $('.edit_scene').find('#id').html(box.id);
  $('.shadow').show();
  $('.edit_scene').show();
}
//ok
function editSceneOK() {
  let box = arrBox[boxIndex - 1];
  let name = $('.edit_scene').find('[name=name]').val();
  let id = $('.edit_scene').find('#id').html();
  let n = -1;
  let flag = false;
  $('.container>.content>div').each(function (i, v) {
    if (i != 0) {
      let tt = $(this).find('p').html();
      if (name == tt) {
        n++;
      }
    }
  });
  for (let i = 0; i < arrBox.length; i++) {
    let box = arrBox[i];
    if (id == box.id) {
      flag = true;
      break;
    }
  }
  if (n != -1 && flag) {
    id = id + (n == 0 ? "" : "-" + n);
  }
  box.name = name;
  box.id = id;
  $('.container>.content>div:eq(' + boxIndex + ')').find('.id').html(id);
  $('.container>.content>div:eq(' + boxIndex + ')>p').html(name);
  closeEditScene();
}
$('.edit_scene [name=name]').on('input', function () {
  let val = $(this).val();
  $(this).parent().next().find('#id').html(val.toLowerCase());
});
//关闭
function closeEditScene() {
  $('.edit_scene').find('[name=name]').val('Unknown scene');
  $('.edit_scene').find('#id').html('unknown scene');
  $('.shadow').hide();
  $('.edit_scene').hide();
  setConfig();
}
let conditionIndex = -1;
//openSelectSignal
function openSelectSignal(obj) {
  let className = $(obj).attr('class');
  if (className.indexOf("pik") != -1) return;
  conditionIndex = $(obj).parent().parent().index();
  boxIndex = $(obj).parent().parent().parent().parent().parent().index();
  let box = arrBox[boxIndex - 1];
  let value;
  if (conditionIndex == 0) {
    value = box.trigger_condition
  } else if (conditionIndex == 1) {
    value = box.end_condition;
  } else {
    value = box.cancel_condition;
  }
  if (value != "null" && value != null) {
    let arr = value.split("|");
    $('.signal_condition').find('[name=input]').val(arr[2]);
    $('.signal_condition').find('[name=operation]').val(arr[0]);
    if (className.indexOf('springgreen') == -1) {
      $('.signal_condition').find('#signal').addClass('red').html(arr[1]).next().html("");
      $('.signal_condition').find('button').attr('disabled', true);
    } else {
      let a = arr[1].split(":");
      $('.signal_condition').find('#signal').html(a[2]).addClass('springgreen').next().html(a[1] + ":" + a[2]);
    }
    $('.signal_condition').find('#signal').attr('val', arr[1]);
    biQuerySignalInfo("signal", arr[1]);
  }
  $('.shadow').show();
  $('.signal_condition').show();
}
//检查文本框的值
function checkTextValue(obj) {
  let str = $(obj).val();
  if (str.indexOf(',') != -1) {
    let flag = false;
    let arr = str.split(","),
      newArr = [];;
    for (let i = 0; i < arr.length; i++) {
      if (arr[i] == "") {
        flag = true;
        break;
      }
      let v = Number(arr[i]);
      if (arr[i] != "") {
        if (isNaN(v)) {
          flag = true;
          break;
        }
      }
      newArr.push(v);
    }
    if (flag) {
      $(obj).addClass('red').removeClass('green');
    } else {
      $(obj).addClass('green').attr('value', newArr.join());
    }
  } else {
    let v = Number(str);
    if (!isNaN(v) && str != "") { //green
      $(obj).addClass('green').attr('value', v);
    } else if (str != "") { //red
      $(obj).addClass('red').removeClass('green');
    } else if (str == "" && $(obj).hasClass('bar')) {
      $(obj).attr('value', "");
    }
  }

}

function checkBur(obj) {
  if ($(obj).hasClass('green')) {
    let str = $(obj).val();
    if (str.indexOf(",") != -1) {
      let arr = str.split(','),
        newArr = [];
      for (let i = 0; i < arr.length; i++) {
        let v = Number(arr[i]);
        newArr.push(v);
      }
      $(obj).val(newArr.join()).attr('value', newArr.join());
    } else {
      if (str != "") {
        let v = Number(str);
        $(obj).val(v).attr('value', v);
      } else {
        let v = $(obj).attr('value');
        $(obj).val(v).attr('value', v);
      }
    }
  } else if ($(obj).hasClass('red')) {
    let v = $(obj).attr('value');
    $(obj).val(v).removeClass('red').addClass('green');
  }
}
//校验文本框
$('[name=input]').bind("input propertychange", function () {
  let t = $(this).val();
  if (t.length == 0) {
    $(this).parent().next().children('button').attr('disabled', true);
  } else {
    $(this).parent().next().children('button').removeAttr('disabled');
  }
  checkTextValue($(this));
}).blur(function () {
  checkBur($(this));
  setConfig();
});
//ok
function signalConditionON() {
  let box = arrBox[boxIndex - 1];
  let value = null;
  let t = biGetLanguage() == 1 ? "(Not configured)" : "(未配置)";
  let valType = $('#signal').attr('valtype');
  let val = $('#signal').attr('val');
  let obj = $('.content>div:eq(' + boxIndex + ')>div>div:nth-of-type(2)>div:eq(' + conditionIndex + ')').find('a');
  if (val != undefined && val != "undefined") {
    let operation = $('.signal_condition').find('[name=operation]').val();
    let input = $('.signal_condition').find('[name=input]').val();
    value = operation + "|" + val + "|" + input;
    let tt = valType + " " + opt[Number(operation)] + " " + input;
    $(obj).html(tt).addClass('springgreen');
  } else {
    $(obj).html(t).removeClass('springgreen');
  }
  if (conditionIndex == 0) {
    box.trigger_condition = value;
    checkTrigger($(obj));
  } else if (conditionIndex == 1) {
    box.end_condition = value;
    checkEnd($(obj));
  } else {
    box.cancel_condition = value;
  }
  closeSignalCondition();
  setConfig();
}
//关闭siganlCondition
function closeSignalCondition() {
  let t = biGetLanguage() == 1 ? "(Not configured)" : "(未配置)";
  $('.signal_condition').find('[name=input]').val("0");
  $('.signal_condition').find('[name=operation]').val("0");
  $('.signal_condition').find('#signal').removeAttr('val').html(t).removeClass('springgreen').removeClass('red');
  $('.signal_condition').find('#signal').next().html("");
  $('.shadow').hide();
  $('.signal_condition').hide();
  setConfig();
}
//openConfig
function openConfig(obj) {
  boxIndex = $(obj).parent().parent().parent().parent().index();
  let box = arrBox[boxIndex - 1];
  let arr = box.arr;
  for (let i = 0; i < arr.length; i++) {
    let property = arr[i];
    $tableBox = $('.config>.content>.table>.body>div:first-of-type').clone(true);
    $tableBox.find('[name=key]').val(property.key);
    $tableBox.find('[name=value]').val(property.value);
    $('.config>.content>.table>.body>div:last-of-type').before($tableBox[0]);
  }
  $('.shadow').show();
  $('.config').show();
}
//ok
function configOK() {
  let box = arrBox[boxIndex - 1];
  let arr = [];
  let len = $('.config>.content>.table>.body>div').length;
  let flag = false;
  $('.config>.content>.table>.body>div').each(function (i, v) {
    if (i != 0 && i < len) {
      let key = $(this).find('[name=key]').val();
      let value = $(this).find('[name=value]').val();
      if ($(this).find('[name=key]').hasClass('red')) {
        flag = true;
        return
      }
      if (key != "" && value != "" && !$(this).find('[name=key]').hasClass('red')) {
        let property = new Property(key, value);
        arr.push(property);
      }
    }
  });
  if (flag) {
    let language = sessionStorage.getItem('language');
    let txt = language == 1 ? "The Key should not be repeat." : "Key不应该重复.";
    let t = language == 1 ? "Error" : "错误";
    biAlert(txt, t);
    return
  }

  box.arr = arr;
  let t = "";
  let type = biGetLanguage();
  if (arr.length == 1) {
    t = type == 1 ? "1 property preset" : "1个属性预设";
  } else if (arr.length > 1) {
    t = type == 1 ? arr.length + " property presets" : arr.length + "个属性预设";
  } else {
    t = type == 1 ? "No property preset" : "无属性预设";
  }
  $('.container>.content>div:eq(' + boxIndex + ')>div>div:nth-of-type(1)>div:nth-of-type(3)').children('a').html(t)
  closeConfig();
  setConfig();
}

//关闭config
function closeConfig() {
  let len = $('.config>.content>.table>.body>div').length;
  $('.config>.content>.table>.body>div').each(function (i, v) {
    if (i != 0 && i < len - 1) {
      $(this).remove();
    }
  });
  $('.shadow').hide();
  $('.config').hide();
  setConfig();
}
//关闭error
function closeError() {
  $('.shadow2').hide();
  $('.error').hide();
}



if (language != null) {
  changeLanguage(language);
}
/**
 * 判断中英文
 */
function changeLanguage(type) {
  if (type == 1) {
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(en[value])
    });
  } else {
    $('[language]').each(function () {
      let value = $(this).attr('language');
      $(this).html(cn[value])
    });
  }
}
let busChannelKeyArr = [],
  busChannelArr = [];
/**
 * 加载配置
 */
function loadConfig(config) {
  if (config == null) return
  let arr = JSON.parse(config);
  for (let i = 0; i < arr.length; i++) {
    let obj = arr[i];
    $box = $('.container>.content>.box').clone(true);
    $('.container>.content').append($box[0]);
    let name = obj.name;
    let id = obj.id
    $box.children('p').html(name);
    $box.find('.id').html(id);
    let enabled = obj.enabled;

    if (enabled == "yes") {
      $box.find('[name=enabled]').removeAttr('disabled');
      $box.find('[name=enabled]').attr('checked', true);
    } else {
      $box.find('[name=enabled]').removeAttr('checked');
    }
    let trigger_condition = obj.trigger_condition;
    if (trigger_condition != "null") {
      let array = trigger_condition.split("|");
      let a = array[1].split(":");
      biQuerySignalInfo(i + "|trigger_condition|" + array[0] + "|" + array[2], array[1]);
      $box.find('.trigger_condition').attr("val", array[1]);
    }
    checkTrigger($box.find('.trigger_condition'));
    let end_condition = obj.end_condition;
    if (end_condition != "null") {
      let array = end_condition.split("|");
      biQuerySignalInfo(i + "|end_condition|" + array[0] + "|" + array[2], array[1]);
      $box.find('.end_condition').attr("val", array[1]);
    }
    checkEnd($box.find('.end_condition'));
    let cancel_condition = obj.cancel_condition;
    if (cancel_condition != "null") {
      let array = cancel_condition.split("|");
      biQuerySignalInfo(i + "|cancel_condition|" + array[0] + "|" + array[2], array[1]);
    }
    let begin_offset = obj.begin_offset;
    $box.find('[name=begin_offset]').val(begin_offset);
    let end_offset = obj.end_offset;
    $box.find('[name=end_offset]').val(end_offset);
    let cancel_timeout = obj.cancel_timeout;
    if (cancel_timeout != "null") {
      $box.find('[name=cancel]').attr('checked', true);
      $box.find('[name=cancel_timeout]').val(cancel_timeout);
      $box.find('[name=cancel_timeout]').removeAttr('disabled');
      $box.find('[name=cancel_timeout]').next().show();
    }
    let a = obj.arr;
    let t = "";
    let type = biGetLanguage();
    if (a.length == 1) {
      t = type == 1 ? "1 property preset" : "1个属性预设";
    } else if (a.length > 1) {
      t = type == 1 ? a.length + " property presets" : a.length + "个属性预设";
    } else {
      t = type == 1 ? "No property preset" : "无属性预设";
    }
    $box.find('[language=no_property]').html(t);
    let box = new Box(name, id, enabled, trigger_condition, end_condition, cancel_condition, begin_offset, end_offset, cancel_timeout, a);
    arrBox.push(box);
  }
}
let num = 0;
//获取总线协议文件绑定的通道
function biOnQueriedBusProtocolFileChannel(busFileProtocolID, busChannel) {
  if (busChannel == 0) {
    let s = busChannelKeyArr[num];
    let arr = s.split("|");
    $('.container>.content>div:eq(' + (Number(arr[0]) + 1) + ')').find('.' + arr[1]).html(arr[2]).addClass('red').removeClass('springgreen').next().html(arr[2]);
    $('.container>.content>div:eq(' + (Number(arr[0]) + 1) + ')').find('.' + arr[1]).parent().attr("title", "");
  } else {
    let s = busChannelKeyArr[num];
    let arr = s.split("|");
    $('.container>.content>div:eq(' + (Number(arr[0]) + 1) + ')').find('.' + arr[1]).removeClass('pik');
  }
  num++;
}
//获取信号信息
function biOnQueriedSignalInfo(key, signalID) {
  console.log(key, signalID);
  if (signalID != null) {
    if (key == "signal") {
      $('.signal_condition').find('#signal').attr('valtype', signalID.typeName + ":" + signalID.signalName);
    } else {
      let arr = key.split("|");
      let tt = signalID.typeName + ":" + signalID.signalName + " " + opt[Number(arr[2])] + " " + arr[3];
      $('.container>.content>div:eq(' + (Number(arr[0]) + 1) + ')').find('.' + arr[1]).attr("val", signalID.id);
      $('.container>.content>div:eq(' + (Number(arr[0]) + 1) + ')').find('.' + arr[1]).html(tt);
      $('.container>.content>div:eq(' + (Number(arr[0]) + 1) + ')').find('.' + arr[1]).addClass('springgreen').parent().attr("title", tt);
      checkTrigger($('.container>.content>div:eq(' + (Number(arr[0]) + 1) + ')').find('.' + arr[1]));
      checkEnd($('.container>.content>div:eq(' + (Number(arr[0]) + 1) + ')').find('.' + arr[1]));
    }
  }
  setConfig();
}

$('[name=name]').bind("input propertychange", function () {
  let text = $(this).val();
  if (text.length < 3) {
    $(this).parent().parent().next().children('button').attr('disabled', true);
  } else {
    $(this).parent().parent().next().children('button').removeAttr('disabled');
  }
});
/**
 * 写配置
 */
function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root>";
  for (let i = 0; i < arrBox.length; i++) {
    numChange($('.container>.content>div:eq(' + (i + 1) + ')').find('[name=begin_offset]'));
    numChange($('.container>.content>div:eq(' + (i + 1) + ')').find('[name=end_offset]'));
    numChange($('.container>.content>div:eq(' + (i + 1) + ')').find('[name=cancel_timeout]'));
    let box = arrBox[i];
    let begin_offset = $('.container>.content>div:eq(' + (i + 1) + ')').find('[name=begin_offset]').val();
    let end_offset = $('.container>.content>div:eq(' + (i + 1) + ')').find('[name=end_offset]').val();
    let cancel = $('.container>.content>div:eq(' + (i + 1) + ')').find('[name=cancel]').get(0).checked;
    let cancel_timeout = cancel ? Number($('.container>.content>div:eq(' + (i + 1) + ')').find('[name=cancel_timeout]').val()) : "null";
    text += "<s name=\"" + box.name + "\" id=\"" + box.id + "\" enabled=\"" + box.enabled + "\" trigger_condition=\"" +
      box.trigger_condition + "\" end_condition=\"" + box.end_condition + "\" cancel_condition=\"" + box.cancel_condition +
      "\" begin_offset=\"" + begin_offset + "\" end_offset=\"" + end_offset + "\" cancel_timeout=\"" + cancel_timeout + "\">"
    for (let j = 0; j < box.arr.length; j++) {
      let property = box.arr[j];
      text += "<property key=\"" + property.key + "\" value=\"" + property.value + "\" />";
    }
    text += "</s>";
  }
  text += "</root>";
  biSetModuleConfig("scene-by-signal.system", text);
}
//gridview    
function selectOneRow(obj) {
  $('.config>.content>.table>.body>div').each(function () {
    $(this).children('div:first-of-type').removeClass('blue2');
    $(this).find('input').removeClass('blue1');
  });
  $('.config>.content>.table>.top>div:first-of-type').removeClass('all');
  $(obj).addClass('blue2');
  $(obj).next().children().addClass('blue1');
  $(obj).next().next().children().addClass('blue1');
}
//监听键盘del键
$('body').keydown(function (event) {
  let e = event || window.event;
  if (e.keyCode == 46) {
    if ($('.config>.content>.table>.top>div:first-of-type').hasClass('all')) {
      let i = 1;
      while (i < $('.config>.content>.table>.body>div').length - 1) {
        $('.config>.content>.table>.body>div')[i].remove();
        i = 1;
      }
    } else {
      if ($('.blue2').parent().next().html() != undefined) {
        $('.blue2').parent().remove();
      }
    }
  }
});

function wipeBlue(obj) {
  $(obj).parent().parent().children('div:first-of-type').removeClass('blue2');
  $(obj).parent().parent().children('div:nth-of-type(2)').children().removeClass('blue1');
  $(obj).parent().parent().children('div:nth-of-type(3)').children().removeClass('blue1');
}

function selectAll() {
  $('.config>.content>.table>.body>div').each(function (i, v) {
    if (i != 0) {
      $(this).children('div:first-of-type').addClass('blue2');
      $(this).find('input').addClass('blue1');
    }
  });
  $('.config>.content>.table>.top>div:first-of-type').addClass('all');
}

function keyPress(obj) {
  let parent = $(obj).parent().parent();
  if ($(parent).next().html() == undefined) {
    $tableBox = $('.config>.content>.table>.body>div:first-of-type').clone(true);
    $('.config>.content>.table>.body').append($tableBox[0]);
  }
  let len = $('.config>.content>.table>.body>div').length;
  for (let i = 1; i < len - 1; i++) {
    let div = $('.config>.content>.table>.body>div:eq(' + i + ')');
    let m = $(div).find('[name=key]').val();
    let flag = false;
    for (let j = 1; j < len - 1 && j != i; j++) {
      let div2 = $('.config>.content>.table>.body>div:eq(' + j + ')');
      let n = $(div2).find('[name=key]').val();
      if (m == n && m != "") {
        $(div).find('[name=key]').addClass('red');
        $(div2).find('[name=key]').addClass('red');
        flag = true;
        break;
      }
    }
    if (!flag) $(div).find('[name=key]').removeClass('red');
  }
}

//检查trigger
function checkTrigger(obj) {
  let text = $(obj).html();
  if (text.indexOf("Not configured") == -1 || text.indexOf("未配置") == -1) {
    $(obj).parent().parent().parent().prev().find('[name=enabled]').removeAttr('disabled', true);
    $(obj).parent().parent().parent().prev().find('[language=enabled]').removeClass('pik');
  } else {
    $(obj).parent().parent().parent().prev().find('[name=enabled]').removeAttr('checked').attr('disabled', true);
    $(obj).parent().parent().parent().prev().find('[language=enabled]').addClass('pik');
  }
}
//检查cancel
function cancelChange(obj) {
  let flag = $(obj).get(0).checked;
  if (!flag) {
    $(obj).parent().next().attr('disabled', true);
  } else {
    $(obj).parent().next().removeAttr('disabled');
  }
}
//检查end
function checkEnd(obj) {
  let text = $(obj).html();
  if (text.indexOf("Not configured") == -1 || text.indexOf("未配置") == -1) {
    $(obj).parent().parent().parent().next().find('[name=cancel]').removeAttr('disabled');
    $(obj).parent().parent().parent().next().find('[language=cancel_timeout]').removeClass('pik');
    $(obj).parent().parent().next().find('.cancel_condition').removeClass('pik');
  } else {
    $(obj).parent().parent().parent().next().find('[name=cancel]').attr('disabled', true).attr('checked', false);
    $(obj).parent().parent().parent().next().find('[language=cancel_timeout]').addClass('pik');
    $(obj).parent().parent().next().find('.cancel_condition').addClass('pik');

  }
  cancelChange($(obj).parent().parent().parent().next().find('[name=cancel]'));
}
/**
 * 选择信号
 * @param {} obj 
 */
let idName = null; //选择的元素的id名
function selectSignal(obj) {
  let originID = null;
  if ($(obj).html().lastIndexOf('(') == -1) originID = $(obj).attr('val');
  idName = obj;
  let key = "TargetSignal";
  biSelectSignal(key, originID, false, null, false, 1, "[m]");
}

function biOnSelectedSignal(key, valueInfo, signBitInfo, scale) {
  let text = null;
  if (valueInfo == null) {
    text = biGetLanguage() == 1 ? "(Not configured)" : "(未配置)";
    $(idName).removeClass('springgreen');
    $(idName).removeClass('red');
    $(idName).html(text);
    $(idName).removeAttr("val");
    $(idName).removeAttr("valtype");
    $(idName).parent().attr("title", "");
  } else if (valueInfo.typeName == undefined) {
    $(idName).html(valueInfo.id).addClass('red').removeClass('springgreen');
    $(idName).parent().attr("title", "");
  } else {
    $(idName).html(valueInfo.signalName);
    $(idName).attr("val", valueInfo.id);
    $(idName).attr("valtype", valueInfo.typeName + ":" + valueInfo.signalName);
    $(idName).parent().attr("title", valueInfo.typeName + ":" + valueInfo.signalName);
    $(idName).addClass('springgreen');
    $(idName).parent().parent().parent().find('button').removeAttr('disabled');
  }
  setConfig();
}
$('.space_a').mouseover(function (e) {
  if ($(this).children('p').html() == "" || $(this).children('a').hasClass('not_a')) return
  $(this).children('p').show();
  let left = e.offsetX + 30;
  $(this).children('p').css({ "left": left + "px", "top": 25 + "px" });
}).mouseout(function (e) {
  $(this).children('p').hide();
});


function biOnSelectedPath(key, path) {
  if (path == null) {
    return;
  }
}

/**
 * 根据ui改变背景色
 * @param {} ui 
 */
function changeUiBgc(ui) {
  if (ui == 3) { //"Winform"
    $('.container').css("background-color", "rgb(240,240,240)");
  } else if (ui == 4) { //"WPF"
    $('.container').css("background-color", "rgb(255,255,255)");
  } else if (ui == 5 || ui == 6) { //"gtk"
    $('.container').css("background-color", "rgb(250,250,250)");
  }
}

function biOnInitEx(config, moduleConfigs) {
  let type = biGetLanguage();
  let ui = biGetUIBackend();
  changeUiBgc(ui);
  changeLanguage(type);
  biSetViewSize(728, 371);
  sessionStorage.setItem("language", type);
  configuration = config;
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('root');
    let arr = [];
    for (let i = 0; i < countrys[0].childNodes.length; i++) {
      let keyss = countrys[0].childNodes[i].getAttributeNames();
      let obj = new Object();
      for (let j = 0; j < keyss.length; j++) {
        obj[keyss[j]] = countrys[0].childNodes[i].getAttribute(keyss[j]);
      }
      let array = [];
      for (let j = 0; j < countrys[0].childNodes[i].childNodes.length; j++) {
        let keysss = countrys[0].childNodes[i].childNodes[j].getAttributeNames();
        let object = new Object();
        for (let k = 0; k < keysss.length; k++) {
          object[keysss[k]] = countrys[0].childNodes[i].childNodes[j].getAttribute(keysss[k]);
        }
        array.push(object);
      }
      obj.arr = array;
      arr.push(obj);
    }
    loadConfig(JSON.stringify(arr));
  }
}