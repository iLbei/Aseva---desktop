let cn = {
  enable_read_bag: "启用bag文件读取  读取线程数为  ",
  enable_record_bag: "启用bag文件写入",
  enable_read_db3: "启用db3文件读取",
  enable_record_db3: "启用db3文件写入"
},
  en = {
    enable_read_bag: "Enable bag reader with threads",
    enable_record_bag: "Enable bag writer",
    enable_read_db3: "Enable db3 reader",
    enable_record_db3: "Enable db3 writer"
  };