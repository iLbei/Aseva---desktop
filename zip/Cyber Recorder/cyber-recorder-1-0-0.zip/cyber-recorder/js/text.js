var zh = {
  enabled: "启用",
  dockerID: "Docker ID:",
  splitTime: "分隔时间:",
},
  en = {
    enabled: "Enabled",
    dockerID: "Docker ID:",
    splitTime: "Split time:",
  };