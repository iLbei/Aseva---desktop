let viewSize = new BISize(348, 455),
    language = sessionStorage.getItem("language"),
    cn = {
        in_point_map: "输入点地图:",
        no1: "第一",
        output_obj: "输出目标物:",
        output_free: "输出可行驶区域:",
        no2: "第二",
        param: "参数",
        min_point_dist: "最小值点的距离",
        max_relat_speed: "最大相对速度",
        max_lat_clear: "最大侧隙",
        disabled: "(禁用)",
        chan_a: "通道 A",
        chan_b: "通道 B",
        chan_c: "通道 C",
        chan_d: "通道 D",
        chan_e: "通道 E",
        chan_f: "通道 F",
        chan_g: "通道 G",
        chan_h: "通道 H",
        chan_i: "通道 I",
        chan_j: "通道 J",
        chan_k: "通道 K",
        chan_l: "通道 L",
    },
    en = {
        disabled: "(Disabled)",
        chan_a: "Channel A",
        chan_b: "Channel B",
        chan_c: "Channel C",
        chan_d: "Channel D",
        chan_e: "Channel E",
        chan_f: "Channel F",
        chan_g: "Channel G",
        chan_h: "Channel H",
        chan_i: "Channel I",
        chan_j: "Channel J",
        chan_k: "Channel K",
        chan_l: "Channel L",
        in_point_map: "Input point map:",
        no1: "1st",
        output_obj: "Output objects:",
        output_free: "Output Freespace:",
        no2: "2nd",
        param: "Parameters",
        min_point_dist: "Minimum point distance",
        max_relat_speed: "Maximum relative speed",
        max_lat_clear: "Maximum lateral clearance",
    };
$('input').on({
    'change': function () {
        if ($(this).attr('type') == 'number') {
            compareVal(this)
        }
    },
    'keypress': function (e) {
        if (e.charCode == 43 || e.charCode == 45) {
            return false;
        }
    }
});
$('.container [name]').change(function () {
    setConfig();
});
$('[name=in_channel_2],[name=in_channel_1]').change(function () {
    changeChannel($(this));
});
if (language == null) {
    changeLanguage(2);
}
function biOnInitEx(config, moduleConfigs) {
    biSetViewSize(348, 455)
    let type = biGetLanguage();
    changeLanguage(type);
    configuration = config;
    sessionStorage.setItem("language", type);
    for (let key in moduleConfigs) {
        let parser = new DOMParser();
        let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
        let countrys = xmlDoc.getElementsByTagName('root');
        let keys = countrys[0].getAttributeNames();
        let obj = new Object();
        for (let i = 0; i < keys.length; i++) {
            obj[keys[i]] = countrys[0].getAttribute(keys[i]);
        };
        loadConfig(JSON.stringify(obj));
    }
}
function loadConfig(config) {
    if (config == null) return
    let val = JSON.parse(config);
    $('[name]').each(function () {
        let value = $(this).attr('name'),
            type = $(this).attr("type");
        if (type == "checkbox") {
            val[value] == "yes" ? $(this).attr('checked', true) : $(this).attr('checked', false);
        } else if (type == "number") {
            let step = $(this).attr('step').length - 2;
            let v = parseFloat(val[value]);
            if (step <= -1) {
                $(this).val(v.toFixed(0));
            } else {
                $(this).val(v.toFixed(step));
            }
        } else {
            let v = val[value] == "null" ? "" : val[value]
            $(this).val(v);
        }
    });
    biQueryChannelNames(1, 'point-map-v2', 6)
    changeChannel($('[name=in_channel_1]'));
    changeChannel($('[name=in_channel_2]'));
}
function changeChannel(obj) {
    if ($(obj).find('option[value=' + $(obj).val() + ']').html().indexOf('(') != -1) {
        $(obj).parent().prev().children().addClass("red");
    } else {
        $(obj).parent().prev().children().removeClass("red");
    }
}
function changeLanguage(type) {
    if (type == 1) { //英文
        $('[language]').each(function () {
            let value = $(this).attr('language');
            $(this).html(en[value])
        });
    } else { //中文
        $('[language]').each(function () {
            let value = $(this).attr('language');
            $(this).html(cn[value])
        });
    }
}
function compareVal(obj) {
    let step = $(obj).attr('step').length - 2;
    let v = parseFloat($(obj).val());
    if (isNaN(v)) { v = Number($(obj).attr('value')); }
    let min = parseFloat($(obj).attr('min')),
        max = parseFloat($(obj).attr('max'));
    v = v < min ? min : v;
    v = v > max ? max : v;
    let value;
    if (step <= -1) {
        value = v.toFixed(0);
    } else {
        value = v.toFixed(step);
    }
    $(obj).val(value);
}
function setConfig() {
    let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root";
    $('[name]').each(function () {
        let key = $(this).attr('name'),
            type = $(this).attr("type");
        if (type == "checkbox") {
            let n = $(this).get(0).checked ? "yes" : "no";
            text += " " + key + "=\"" + n + "\"";
        } else {
            let v = $(this).val() == "" ? null : $(this).val();
            text += " " + key + "=\"" + v + "\"";
        }
    });
    text += " />";
    console.log(text);
    biSetModuleConfig("rear-object-extraction.pluginlidar", text);
}
function biOnQueriedChannelNames(key, channelNames) {
    if (key == 1) {
        for (let k in channelNames) {
            if (channelNames[k] != '') {
                let option = 'option[value=' + k.substr(13) + ']';
                $('select').each(function () {
                    if ($(this).attr('name') == 'in_channel_1' || $(this).attr('name') == 'in_channel_2') {
                        $(this).find(option).html($(this).find(option).html().substr(0, 2) + channelNames[k]);
                        changeChannel(this);
                    }
                })
            }
        }
    }
}