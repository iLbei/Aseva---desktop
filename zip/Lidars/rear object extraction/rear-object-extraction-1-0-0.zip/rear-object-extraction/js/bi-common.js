﻿// 2020/6/16: 首个版本
// 2020/8/21: 插件2.0支持。调用未实现的功能函数弹异常。标准化注释
// 2020/8/27: 插件2.1支持
// 2020/10/20: 插件2.3支持
// 2020/12/21: 插件2.4支持
// 2021/1/5: 插件2.5支持
// 2021/1/29: biSelectPath输入filter支持完整文件名过滤
// 2021/2/1: 插件2.6支持
// 2021/7/2: 插件4.0支持

// 构造函数 //////////////////////////////////////////////////////////////////

/**
 * 二维尺寸构造函数
 * @constructor
 * @param {Number} width 宽度
 * @param {Number} height 高度
 */
 function BISize(width, height) {
    this.width = width;
    this.height = height;
}

/**
 * 二维点构造函数
 * @constructor
 * @param {Number} x x轴坐标
 * @param {Number} y y轴坐标
 */
function BIPoint(x, y) {
    this.x = x;
    this.y = y;
}

/**
 * 通用样本构造函数
 * @constructor
 * @param {String} protocol 样本协议
 * @param {Number} channel 样本通道，可为null
 * @param {Date} session 所属session
 * @param {Number} time 在session中的相对时间戳，单位秒
 * @param {Array} values 样本值
 */
function BIGeneralSample(protocol, channel, session, time, values) {
    this.protocol = protocol;
    this.channel = channel;
    this.session = session;
    this.time = time;
    this.values = values;
}

/**
 * 通用样本对构造函数
 * @constructor
 * @param {BIGeneralSample} sample1 较早的最近样本
 * @param {Number} weight1 sample1的权重
 * @param {BIGeneralSample} sample2 较晚的最近样本
 * @param {Number} weight2 sample2的权重
 */
function BIGeneralSamplePair(sample1, weight1, sample2, weight2) {
    this.sample1 = sample1;
    this.weight1 = weight1;
    this.sample2 = sample2;
    this.weight2 = weight2;
}

/**
 * 总线报文信息构造函数
 * @constructor
 * @param {String} id 总线报文ID
 * @param {String} protocol 报文所属协议
 * @param {Number} idInProtocol 在协议中的ID
 * @param {String} name 报文名称
 */
function BIBusMessageInfo(id, protocol, idInProtocol, name) {
    this.id = id;
    this.protocol = protocol;
    this.idInProtocol = idInProtocol;
    this.name = name;
}

/**
 * 信号信息构造函数
 * @constructor
 * @param {String} id 信号ID
 * @param {String} category 信号所属大类
 * @param {String} typeID 信号所属小类ID
 * @param {String} typeName 信号小类名称
 * @param {String} signalName 信号名称
 */
function BISignalInfo(id, category, typeID, typeName, signalName) {
    this.id = id;
    this.category = category;
    this.typeID = typeID;
    this.typeName = typeName;
    this.signalName = signalName;
}

/**
  * 缓存范围构造函数
  * @constructor
  * @param {Date} lowerSession 缓存范围下限所属session
  * @param {Number} lowerTime 缓存范围下限在所属session中的时间
  * @param {Date} upperSession 缓存范围上限所属session
  * @param {Number} upperTime 缓存范围上限在所属session中的时间
  */
function BIBufferRangeX(lowerSession, lowerTime, upperSession, upperTime) {
    this.lowerSession = lowerSession;
    this.lowerTime = lowerTime;
    this.upperSession = upperSession;
    this.upperTime = upperTime;
}

// 枚举类型 //////////////////////////////////////////////////////////////////

/**
 * 语言
 * @enum
 */
var BILanguage = {
    English: 1, // 英文
    Chinese: 2, // 中文
}

/**
 * 运行平台
 * @enum
 */
var BIPlatform = {
    ClientWindows: 1, // Windows客户端
    ClientLinux: 2, // Linux客户端
    Web: 3, // Web端
}

/**
 * 运行模式 
 * @enum
 */
var BIRunningMode = {
    Offline: 1, // 离线模式（含回放模式）
    Online: 2, // 在线模式
}

/**
 * 选择路径类型 
 * @enum
 */
var BISelectPathType = {
    OpenFile: 1, // 用于打开文件
    CreateFile: 2, // 用于创建文件
    Directory: 3, // 用于获取文件夹路径
    MultipleFiles: 4, // 用于获取多个文件路径
};

/**
 * 独立任务运行结果 
 * @enum
 */
var BITaskResult = {
    RunOK: 1, // 运行成功
    RunFailed: 2, // 运行失败
    TaskTypeNotFound: 3, // 无法找到任务类型
    TaskInitFailed: 4, // 任务初始化失败
    NotIdle: 5, // 非空闲状态无法运行
}

/**
 * 清单信息等级 
 * @enum
 */
var BILogLevel = {
    Info: 1, // 消息
    Warning: 2, // 警告
    Error: 3, // 错误
}

// 功能函数 //////////////////////////////////////////////////////////////////

function biUnimplemented(funcName) {
}

function biDeprecated(funcName) {
}

/**
 * 添加窗口至工作空间
 * @param {String} windowTypeID 窗口类型ID
 * @param {String} config 窗口配置
 * @param {Boolean} newWorkspaceIfNeeded 若空间不足是否在新工作空间中添加
 */
function biAddWindow(windowTypeID, config, newWorkspaceIfNeeded) {
    biUnimplemented("biAddWindow");
}

/**
 * 弹出对话框显示消息
 * @param {Any} msg 需要显示的消息
 * @param {String} title 对话框标题
 */
function biAlert(msg, title) {
    biUnimplemented("biAlert");
}

/**
 * 删除文件夹
 * @param {String} path 删除文件夹路径
 * @param {Boolean} toRecycleBin 是否删除至回收站
 */
function biDirectoryDelete(path, toRecycleBin) {
    biUnimplemented("biDirectoryDelete");
}

/**
 * 创建文件夹
 * @param {String} path 创建文件夹路径
 */
function biDirectoryMake(path) {
    biUnimplemented("biDirectoryMake");
}

function biFileClose(handle) {
    biDeprecated("biFileClose");
}

function biFileCreate(path) {
    biDeprecated("biFileCreate");
    return null;
}

/**
 * 删除文件
 * @param {String} path 删除文件路径
 * @param {Boolean} toRecycleBin 是否删除至回收站
 */
function biFileDelete(path, toRecycleBin) {
    biUnimplemented("biFileDelete");
}

function biFileOpen(path) {
    biDeprecated("biFileOpen");
    return null;
}

function biFileReadLine(handle) {
    biDeprecated("biFileReadLine");
    return null;
}

function biFileWriteLine(handle, text) {
    biDeprecated("biFileWriteLine");
}

function biGetBufferRange() {
    biDeprecated("biGetBufferRange");
    return null;
}

/**
 * 获取当前缓存范围
 * @return {BIBufferRangeX} 缓存范围，若缓存为空返回null
 */
function biGetBufferRangeX() {
    biUnimplemented("biGetBufferRangeX");
    return null;
}

/**
 * 获取数据文件夹根路径
 * @return {String} 数据文件夹根路径，若未设置则返回null
 */
function biGetDataPath() {
    biUnimplemented("biGetDataPath");
    return null;
}

function biGetDirsInDirectory(path) {
    biDeprecated("biGetDirsInDirectory");
    return null;
}

function biGetFilesInDirectory(path) {
    biDeprecated("biGetFilesInDirectory");
    return null;
}

/**
 * 获取指定协议、通道、时间对应的通用样本对
 * @param {String} protocol 样本协议
 * @param {Number} channel 样本通道，可为null
 * @param {Date} session 所属session
 * @param {Number} time 在session中的相对时间戳，单位秒
 * @param {Number} maxGap 与前后帧间的最大时间差，单位秒
 * @return {BIGeneralSamplePair} 目标的通用样本对，若找不到有效数据则返回null
 */
function biGetGeneralSamplePair(protocol, channel, session, time, maxGap) {
    biUnimplemented("biGetGeneralSamplePair");
    return null;
}

function biGetGenerationPath(session, generationID) {
    biDeprecated("biGetGenerationPath");
    return null;
}

/**
 * 获取当前软件指定使用的语言
 * @return {BILanguage} 语言
 */
function biGetLanguage() {
    biUnimplemented("biGetLanguage");
    return null;
}

/**
 * 获取所有手动触发器通道的名称
 * @return {Array} 手动触发器通道名称列表，数组元素都为String类型，长度未触发器通道个数
 */
function biGetManualTriggerNames() {
    biUnimplemented("biGetManualTriggerNames");
    return null;
}

/**
 * 获取运行当前脚本的平台
 * @return {BIPlatform} 运行平台
 */
function biGetPlatform() {
    biUnimplemented("biGetPlatform");
    return null;
}

/**
 * 获取当前的运行模式
 * @return {BIRunningMode} 运行模式
 */
function biGetRunningMode() {
    biUnimplemented("biGetRunningMode");
    return null;
}

function biGetSessionPath(session) {
    biDeprecated("biGetSessionPath");
    return null;
}

function biIsFileExist(path) {
    biDeprecated("biIsFileExist");
    return null;
}

function biIsDirectoryExist(path) {
    biDeprecated("biIsDirectoryExist");
    return null;
}

/**
 * 监听通用样本，随后可通过biGetGeneralSamplePair获取样本
 * @param {Array} protocols 通用样本的协议（一般为多个，对应不同版本）
 * @param {Number} channel 样本通道，null表示无通道
 */
function biListenGeneralSample(protocols, channel) {
    biUnimplemented("biListenGeneralSample");
}

/**
 * 记录信息至清单
 * @param {String} msg 需要记录的信息
 * @param {BILogLevel} level 清单信息等级
 */
function biLog(msg, level) {
    biUnimplemented("biLog");
}

/**
 * 打开对话框
 * @param {String} dialogTypeID 对话框类型ID
 * @param {String} config 对话框配置
 */
function biOpenDialog(dialogTypeID, config) {
    biUnimplemented("biOpenDialog");
}

/**
 * 打开HTML对话框
 * @param {String} entryName HTML对话框入口名称（无需加.html）
 * @param {String} config HTML对话框配置
 */
function biOpenHTMLDialog(entryName, config) {
    biUnimplemented("biOpenHTMLDialog");
}

/**
 * 打印消息至Debugger
 * @param {Any} msg 打印的消息
 */
function biPrint(msg) {
    biUnimplemented("biPrint");
}

/**
 * 获取总线报文信息，获取完毕后会回调biOnQueriedBusMessageInfo
 * @param {String} key 用于确定获取报文的标识符，与biOnQueriedBusMessageInfo的输入key一致
 * @param {String} busMessageID 总线报文ID
 */
function biQueryBusMessageInfo(key, busMessageID) {
    biUnimplemented("biQueryBusMessageInfo");
}

/**
 * 获取总线协议文件绑定的通道，获取完毕后会回调biOnQueriedBusProtocolFileChannel
 * @param {String} busProtocolFileID 总线协议文件ID
 */
function biQueryBusProtocolFileChannel(busProtocolFileID) {
    biUnimplemented("biQueryBusProtocolFileChannel");
}

/**
 * 获取指定协议下指定数目的所有通道名称，获取完毕后会回调biOnQueriedChannelNames
 * @param {String} key 用于确定获取通道协议的标识符，与biOnQueriedChannelNames的输入key一致
 * @param {String} protocol 协议名，如"vehicle-sample-v4"，视频通道协议名为video
 * @param {Number} channelCount 需要获取的通道数目(有效范围1~64)，如4表示获取0~3(A~D)通道名称，输入null表示获取唯一通道名称
 */
function biQueryChannelNames(key, protocol, channelCount) {
    biUnimplemented("biQueryChannelNames");
}

/**
 * 获取指定文件夹是否存在，获取完毕后会回调biOnQueriedDirectoryExist
 * @param {String} path 文件夹路径
 */
function biQueryDirectoryExist(path) {
    biUm("biQueryDirectoryExist");
}

/**
 * 获取指定文件夹内的所有文件夹路径，获取完毕后会回调biOnQueriedDirsInDirectory
 * @param {String} path 文件夹路径
 */
function biQueryDirsInDirectory(path) {
    biUnimplemented("biQueryDirsInDirectory");
}

/**
 * 获取指定文件是否存在，获取完毕后会回调biOnQueriedFileExist
 * @param {String} path 文件路径
 */
function biQueryFileExist(path) {
    biUnimplemented("biQueryFileExist");
}

/**
 * 获取指定文件夹内的所有文件路径，获取完毕后会回调biOnQueriedFilesInDirectory
 * @param {String} path 文件夹路径
 */
function biQueryFilesInDirectory(path) {
    biUnimplemented("biQueryFilesInDirectory");
}

/**
 * 获取指定文件的所有文本内容，获取完毕后会回调biOnQueriedFileText
 * @param {String} path 文件路径
 */
function biQueryFileText(path) {
    biUnimplemented("biQueryFileText");
}

/**
 * 获取generation列表，获取完毕后会回调biOnQueriedGenerationList
 */
function biQueryGenerationList() {
    biUnimplemented("biQueryGenerationList");
}

/**
 * 获取指定session下指定generation的路径，获取完毕后会回调biOnQueriedGenerationPath
 * @param {Date} session 指定session
 * @param {String} generationID 指定generation的ID
 */
function biQueryGenerationPath(session, generationID) {
    biUnimplemented("biQueryGenerationPath");
}

/**
 * 获取session列表，获取完毕后会回调biOnQueriedSessionList
 * @param {Boolean} filtered 是否为筛选后的列表
 */
function biQuerySessionList(filtered) {
    biUnimplemented("biQuerySessionList");
}

/**
 * 获取指定session的路径，获取完毕后会回调biOnQueriedSessionPath
 * @param {Date} session 指定session
 */
function biQuerySessionPath(session) {
    biUnimplemented("biQuerySessionPath");
}

/**
 * 获取信号信息，获取完毕后会回调biOnQueriedSignalInfo
 * @param {String} key 用于确定获取信号的标识符，与biOnQueriedSignalInfo的输入key一致
 * @param {String} signalID 信号ID
 */
function biQuerySignalInfo(key, signalID) {
    biUnimplemented("biQuerySignalInfo");
}

/**
 * 获取指定总线报文的信号列表，获取完毕后会回调biOnQueriedSignalsInBusMessage
 * @param {String} key 用于确定获取信号列表的标识符，与biOnQueriedSignalsInBusMessage的输入key一致
 * @param {String} busMessageID 总线报文ID

 */
function biQuerySignalsInBusMessage(key, busMessageID) {
    biUnimplemented("biQuerySignalsInBusMessage");
}

/**
 * 运行独立任务，运行后会回调biOnResultOfStandaloneTask
 * @param {String} key 用于确定运行任务的标识符，与biOnResultOfStandaloneTask的输入key一致
 * @param {String} taskTypeID 任务类型ID
 * @param {String} config 任务配置
 */
function biRunStandaloneTask(key, taskTypeID, config) {
    biUnimplemented("biRunStandaloneTask");
}

/**
 * 打开选择总线报文对话框，选择完毕后会回调biOnSelectedBusMessage
 * @param {String} key 用于确定选择报文的标识符，与biOnSelectedBusMessage的输入key一致
 * @param {String} originID 初始选择的总线报文ID
 */
function biSelectBusMessage(key, originID) {
    biUnimplemented("biSelectBusMessage");
}

/**
 * 打开对话框选择路径，选择完毕后会回调biOnSelectedPath(es)
 * @param {String} key 用于确定选择路径的标识符，与biOnSelectedPath(es)的输入key一致
 * @param {BISelectPathType} type 选择路径的类型，当类型为OpenFile/CreateFile/MultipleFiles时下述filter有效
 * @param {Dictionary} filter 文件筛选，null表示不筛选；键为以'.'开头的全小写后缀或完整文件名，值为文字说明
 */
function biSelectPath(key, type, filter) {
    biUnimplemented("biSelectPath");
}

/**
 * 打开选择信号对话框，选择完毕后会回调biOnSelectedSignal
 * @param {String} key 用于确定选择信号的标识符，与biOnSelectedSignal的输入key一致
 * @param {String} originValueID 初始选择的值信号ID
 * @param {Boolean} withSignBit 是否需要选择符号位信号
 * @param {String} originSignBitID 初始选择的符号位信号ID，仅当withSignBit为true时有效
 * @param {Boolean} withScale 是否需要配置值系数
 * @param {Number} originScale 初始的值系数，仅当withScale为true时有效
 * @param {String} unit 值单位，仅当withScale为true时有效
 */
function biSelectSignal(key, originValueID, withSignBit, originSignBitID, withScale, originScale, unit) {
    biUnimplemented("biSelectSignal");
}

/**
 * 更新指定ID模块的配置
 * @param {String} moduleClassID 需要更新的模块类别ID
 * @param {String} config 模块配置信息（在插件版本2.4以上，需要加密的文字段可用此格式包裹：[[SRC]]xxx[[SRC]]）
 */
function biSetModuleConfig(moduleClassID, config) {
    biUnimplemented("biSetModuleConfig");
}

/**
 * 更新当前页面的配置
 * @param {String} config 页面配置信息
 */
function biSetViewConfig(config) {
    biUnimplemented("biSetViewConfig");
}

/**
 * 更新当前对话框的页面尺寸
 * @param {Number} width 页面宽度
 * @param {Number} height 页面高度
 */
function biSetViewSize(width, height) {
    biUnimplemented("biSetViewSize");
}

/**
 * 开启进程运行
 * @param {String} target 需要运行的目标，如文件、文件夹、网页等
 */
function biStartProcess(target) {
    biUnimplemented("biStartProcess");
}

/**
 * 写入文本内容至指定路径的文件，若文件已存在则删除并重新写入
 * @param {String} path 文件路径
 * @param {String} text 文本内容
 */
function biWriteFileText(path, text) {
    biUnimplemented("biWriteFileText");
}

// 回调函数 //////////////////////////////////////////////////////////////////

/**
 * 在初始化时被调用，与biOnInitEx二选一实现即可
 * @param {String} config 页面配置信息
 */
function biOnInit(config) {
}

/**
 * 在初始化时被调用，与biOnInit二选一实现即可
 * @param {String} config 页面配置信息
 * @param {Dictionary} moduleConfigs 关联模块的配置信息，键为模块类别ID，值为模块配置信息
 */
function biOnInitEx(config, moduleConfigs) {
}

/**
 * 在调用biQueryBusMessageInfo返回结果后被调用
 * @param {String} key 用于确定获取报文的标识符
 * @param {BIBusMessageInfo} busMessageInfo 获取的总线报文信息，若获取失败则为null
 */
function biOnQueriedBusMessageInfo(key, busMessageInfo) {
}

/**
 * 在调用biQueryBusProtocolFileChannel返回结果后被调用
 * @param {String} busFileProtocolID 总线文件协议ID
 * @param {Number} busChannel 绑定的总线通道，范围为1~16，0表示不存在
 */
function biOnQueriedBusProtocolFileChannel(busFileProtocolID, busChannel) {
}

/**
 * 在调用biQueryChannelNames返回结果后被调用
 * @param {String} key 用于确定获取通道协议的标识符
 * @param {Dictionary} channelNames 获取的通道名称信息，键为通道协议，值为通道名称（null表示该通道无效）
 */
function biOnQueriedChannelNames(key, channelNames) {
}

/**
 * 在调用biQueryDirectoryExist返回结果后被调用
 * @param {Boolean} exist 文件夹是否存在
 * @param {String} path 文件夹路径
 */
function biOnQueriedDirectoryExist(exist, path) {
}

/**
 * 在调用biQueryDirsInDirectory返回结果后被调用
 * @param {Array} dirs 文件夹内的所有文件夹路径，若文件夹不存在则为null
 * @param {String} path 文件夹路径
 */
function biOnQueriedDirsInDirectory(dirs, path) {
}

/**
 * 在调用biQueryFileExist返回结果后被调用
 * @param {Boolean} exist 文件是否存在
 * @param {String} path 文件路径
 */
 function biOnQueriedFileExist(exist, path) {
}

/**
 * 在调用biQueryFilesInDirectory返回结果后被调用
 * @param {Array} files 文件夹内的所有文件路径，若文件夹不存在则为null
 * @param {String} path 文件夹路径
 */
function biOnQueriedFilesInDirectory(files, path) {
}

/**
 * 在调用biQueryFileText返回结果后被调用
 * @param {String} text 文件中的所有文本内容，若文件不存在则为null
 * @param {String} path 文件路径
 */
function biOnQueriedFileText(text, path) {  
}

/**
 * 在调用biQueryGenerationList返回结果后被调用
 * @param {Array} list generation ID列表，数组元素都为String类型
 */
function biOnQueriedGenerationList(list) {
}

/**
 * 在调用biQueryGenerationPath返回结果后被调用
 * @param {String} path generation的根目录，若不存在则为null
 * @param {Date} session 指定session
 * @param {String} generationID 指定generation的ID
 */
function biOnQueriedGenerationPath(path, session, generationID) {
}

/**
 * 在调用biQuerySessionList返回结果后被调用
 * @param {Array} list session列表，数组元素都为Date类型
 * @param {Boolean} filtered 是否为筛选后的列表
 */
function biOnQueriedSessionList(list, filtered) {
}

/**
 * 在调用biQuerySessionPath返回结果后被调用
 * @param {String} path session的根目录，若不存在则为null
 * @param {Date} session 指定session
 */
function biOnQueriedSessionPath(path, session) {
}

/**
 * 在调用biQuerySignalInfo返回结果后被调用
 * @param {String} key 用于确定获取信号的标识符
 * @param {BISignalInfo} signalInfo 获取的信号信息，若获取失败则为null
 */
function biOnQueriedSignalInfo(key, signalInfo) {
}

/**
 * 在调用biQuerySignalsInBusMessage返回结果后被调用
 * @param {String} key 用于确定获取信号列表的标识符
 * @param {Array} signalIDList 信号ID列表，数组元素都为String，若获取失败则为null
 */
function biOnQueriedSignalsInBusMessage(key, signalIDList) {
}

/**
 * 在调用biRunStandaloneTask返回结果后被调用
 * @param {String} key 用于确定运行任务的标识符
 * @param {BITaskResult} result 任务运行结果
 * @param {String} returnValue 任务运行返回值
 */
function biOnResultOfStandaloneTask(key, result, returnValue) {
}

/**
 * 在调用biSelectBusMessage返回结果后被调用
 * @param {String} key 用于确定选择报文的标识符
 * @param {BIBusMessageInfo} busMessageInfo 选择的总线报文信息，当在对话框中点击删除后则为null
 */
function biOnSelectedBusMessage(key, busMessageInfo) {
}

/**
 * 在调用biSelectPath返回结果后被调用 (type为OpenFile/CreateFile/Directory时)
 * @param {String} key 用于确定选择路径的标识符
 * @param {String} path 选择的路径，若取消则为null
 */
function biOnSelectedPath(key, path) {
}

/**
 * 在调用biSelectPath返回结果后被调用 (type为MultipleFiles时)
 * @param {String} key 用于确定选择路径的标识符
 * @param {Array} pathes 选择的路径列表，数组元素都为String，若取消则为null
 */
function biOnSelectedPathes(key, pathes) {
}

/**
 * 在调用biSelectSignal返回结果后被调用
 * @param {String} key 用于确定选择信号的标识符
 * @param {BISignalInfo} valueSignalInfo 选择的值信号信息，当在对话框中点击删除后则为null
 * @param {BISignalInfo} signBitSignalInfo 选择的符号位信号信息，当在对话框中点击删除后或withSignBit为false时为null
 * @param {Number} scale 配置的值系数，当在对话框中点击删除后或withScale为false时为null
 */
function biOnSelectedSignal(key, valueSignalInfo, signBitSignalInfo, scale) {
}

/**
 * 在设置兴趣点时间时被调用
 * @param {Date} session 兴趣点所在session
 * @param {Number} time 兴趣点在该session中的相对时间戳，单位秒
 */
function biOnSetInterest(session, time) {
}

/**
 * 在开始session时被调用
 */
 function biOnStartSession() {
}

/**
 * 在结束session时被调用
 */
 function biOnStopSession() {
}