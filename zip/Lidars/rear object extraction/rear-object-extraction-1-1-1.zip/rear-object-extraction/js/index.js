$('input').on({
  'change': function () {
    if ($(this).attr('type') == 'number') {
      compareVal(this)
    }
  },
  'keypress': function (e) {
    if (e.charCode == 43) {
      return false;
    }
  }
});
$('.container [name]').change(function () {
  setConfig();
});
$('[name=in_channel_2],[name=in_channel_1]').change(function () {
  changeChannel($(this));
});
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(348, 455);
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value])
  });
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('root');
    let keys = countrys[0].getAttributeNames();
    let obj = new Object();
    for (let i = 0; i < keys.length; i++) {
      obj[keys[i]] = countrys[0].getAttribute(keys[i]);
    };
    loadConfig(JSON.stringify(obj));
  }
}
function loadConfig(config) {
  if (config == null) return
  let val = JSON.parse(config);
  $('[name]').each(function () {
    let value = $(this).attr('name'),
      type = $(this).attr("type");
    if (type == "checkbox") {
      val[value] == "yes" ? $(this).attr('checked', true) : $(this).attr('checked', false);
    } else if (type == "number") {
      let step = $(this).attr('step').length - 2;
      let v = parseFloat(val[value]);
      if (step <= -1) {
        $(this).val(v.toFixed(0));
      } else {
        $(this).val(v.toFixed(step));
      }
    } else {
      let v = val[value] == "null" ? "" : val[value]
      $(this).val(v);
    }
  });
  biQueryChannelNames(1, 'point-map-v2', 6)
  changeChannel($('[name=in_channel_1]'));
  changeChannel($('[name=in_channel_2]'));
}
function changeChannel(obj) {
  if ($(obj).find('option[value=' + $(obj).val() + ']').html().indexOf('(Not') != -1) {
    $(obj).parent().prev().children().addClass("red");
  } else {
    $(obj).parent().prev().children().removeClass("red");
  }
}
function compareVal(obj) {
  let step = $(obj).attr('step').length - 2;
  let v = parseFloat($(obj).val());
  if (isNaN(v)) { v = Number($(obj).attr('value')); }
  let min = parseFloat($(obj).attr('min')),
    max = parseFloat($(obj).attr('max'));
  v = v < min ? min : v;
  v = v > max ? max : v;
  let value;
  if (step <= -1) {
    value = v.toFixed(0);
  } else {
    value = v.toFixed(step);
  }
  $(obj).val(value);
}
function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root";
  $('[name]').each(function () {
    let key = $(this).attr('name'),
      type = $(this).attr("type");
    if (type == "checkbox") {
      let n = $(this).get(0).checked ? "yes" : "no";
      text += " " + key + "=\"" + n + "\"";
    } else {
      let v = $(this).val() == "" ? null : $(this).val();
      text += " " + key + "=\"" + v + "\"";
    }
  });
  text += " />";
  console.log(text);
  biSetModuleConfig("rear-object-extraction.pluginlidar", text);
}
function biOnQueriedChannelNames(key, channelNames) {
  if (key == 1) {
    for (let k in channelNames) {
      if (channelNames[k] != '') {
        let option = 'option[value=' + k.substr(13) + ']';
        $('select').each(function () {
          if ($(this).attr('name') == 'in_channel_1' || $(this).attr('name') == 'in_channel_2') {
            $(this).find(option).html($(this).find(option).html().substr(0, 2) + channelNames[k]);
            changeChannel(this);
          }
        })
      }
    }
  }
}