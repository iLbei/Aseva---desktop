let vehicle = [],
  index = -1,
  createFileHandle = null,
  signalScale = 1,
  pitch_angles = [[], [], [], [], [], []],
  yaw_offsets = [[], [], [], [], [], []],
  pitch_angles2 = [[], [], [], [], [], []],
  yaw_offsets2 = [[], [], [], [], [], []],
  dist_offsets = [[], [], [], [], [], []],
  dist_offsets_temperature = [[], [], [], [], [], []];
$('.lidar input[type=radio]').on('change', function () {
  radioChange(this);
})
$('input[type=number]').on({
  'change': function () {
    $(this).val(compareVal(this, $(this).val()));
    changeDraw(this);
  },
  'blur': function () {
    if ($(this).attr('name') != 'bus_channel' && $(this).attr('name') != 'frame_timestamp_ratio') {
      changeDraw(this);
    }
  },
  'input': function (e) {
    if (e.which == undefined) {
      if ($(this).attr('name') != 'bus_channel' && $(this).attr('name') != 'frame_timestamp_ratio') {
        changeDraw(this);
      }
    }
    setConfig();
  },
  'keypress': function (e) {
    if (e.charCode == 101 || e.charCode == 43) {
      return false;
    }
  }
})
$('.bottom').find('input[type=checkbox]').on('click', function () {
  if ($(this).is(':checked')) {
    $(this).parents('.bottom').find('input[type=checkbox]').prop('checked', false);
    $(this).prop('checked', true)
  } else {
    $(this).parents('.bottom').find('input[type=checkbox]').prop('checked', true);
    $(this).prop('checked', false);
  }
})
$('[type=text]').bind("input propertychange", function () {
  let val = Number($(this).val());
  $(this).removeClass('red');
  if (!isNaN(val)) {
    let init = String(val).substr(0, 1);
    if (init <= 3) {
      String(val).length <= 10 ? $(this).attr('value', val) : $(this).addClass('red');
    } else if (init == 4) {
      if (String(val).substr(1, 1) <= 2) {
        String(val).length <= 10 ? $(this).attr('value', val) : $(this).addClass('red');
      } else {
        String(val).length <= 9 ? $(this).attr('value', val) : $(this).addClass('red');
      }
    } else if (init >= 5) {
      String(val).length <= 9 ? $(this).attr('value', val) : $(this).addClass('red');
    }
  } else {
    $(this).addClass('red');
  }
  setConfig();
}).blur(function () {
  let v = $(this).attr('value');
  if ($(this).hasClass('red')) {
    $(this).val(v).removeClass('red');
  } else if ($(this).val() == "") {
    $(this).val(v);
  }
})
$('[name]').change(function () {
  console.log("namechange");
  setConfig()
})
function Temperature(t, v) {
  this.t = t;
  this.v = v;
}
function scaleCanvas(obj) {
  let type = $(obj).attr("scale");
  let lang = biGetLanguage();
  let text = "";
  let scale = 0;
  if (type == "large") {
    text = lang == 1 ? "Scale: Large" : "比例: 放大";
    $(obj).attr("scale", "small");
    scale = 0.3;
  } else {
    text = lang == 1 ? "Scale: Small" : "比例: 缩小";
    $(obj).attr("scale", "large");
    scale = 1;
  }
  $(obj).html(text);
  let parent = $(obj).parent().parent();
  draw(parent, scale);
}
function draw(obj, scale) {
  if (vehicle.length < 2) return;
  let canvas = $(obj).find('canvas')[0];
  let ctx = canvas.getContext('2d');
  let x = $(obj).find('[name=offset_x]').val();
  let y = $(obj).find('[name=offset_y]').val();
  let yaw = $(obj).find('[name=yaw]').val();
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  let p1 = new BIPoint(canvas.width / 2, 0);
  let p2 = new BIPoint(canvas.width / 2, canvas.height);
  let p3 = new BIPoint(0, 48);
  let p4 = new BIPoint(canvas.width, 48);
  drawLine(p1, p2, 1, "#e9e9e9", ctx);
  drawLine(p3, p4, 1, "#e9e9e9", ctx);
  let size = new BISize(Number(vehicle[0]) * 20 * scale, Number(vehicle[1]) * 50 * scale);
  let p5 = new BIPoint(canvas.width / 2 - Number(vehicle[0]) * 10 * scale, 48);
  drawRect(p5, size, "black", ctx);
  let p6 = new BIPoint(canvas.width / 2, 48);
  let p7 = new BIPoint(canvas.width / 2 - Number(vehicle[0]) * 10 * scale, 48 + Number(vehicle[1]) * 15 * scale);
  let p8 = new BIPoint(canvas.width / 2 + Number(vehicle[0]) * 10 * scale, 48 + Number(vehicle[1]) * 15 * scale);
  let arr = [p6, p7, p8];
  drawPolygon(arr, "black", ctx);
  p8 = new BIPoint(canvas.width / 2 - y * 15 * scale, 48 - (24 + x * 24 / 1.5) * scale);
  let p9 = new BIPoint(canvas.width / 2 - y * 15 * scale, 48 - x * 24 / 1.5 * scale);
  let p10 = new BIPoint(canvas.width / 2 - (15 + y * 15) * scale, 48 - x * 24 / 1.5 * scale);
  ctx.save();
  ctx.translate(p9.x, p9.y);
  ctx.rotate(Math.PI / 180 * (0 - yaw));
  p1 = new BIPoint(p8.x - p9.x, p8.y - p9.y);
  p2 = new BIPoint(p9.x - p9.x, p9.y - p9.y);
  p3 = new BIPoint(p10.x - p9.x, p10.y - p9.y);
  ctx.beginPath();
  ctx.moveTo(p1.x, p1.y);
  ctx.lineTo(p2.x, p2.y);
  ctx.lineTo(p3.x, p3.y);
  ctx.strokeStyle = "#32cd32";
  ctx.stroke();
  ctx.restore();
}
function changeDraw(obj) {
  let parent = $(obj).parent().parent().parent().parent().parent();
  let type = $(parent).find('.scale_change').attr("scale");
  let scale = type == "large" ? 1 : 0.3;
  draw(parent, scale);
}
function drawPolygon(arr, color, ctx) {
  ctx.beginPath();
  ctx.moveTo(arr[0].x, arr[0].y);
  ctx.lineTo(arr[1].x, arr[1].y);
  ctx.lineTo(arr[2].x, arr[2].y);
  ctx.strokeStyle = color;
  ctx.closePath();
  ctx.stroke();
}
function radioChange(obj) {
  if ($(obj).val() == 13 || $(obj).val() == 14 || $(obj).val() == 17 || $(obj).val() == 21) {
    $(obj).parents('.lidar').find('[name="utc_time_sync"]').attr('disabled', false)
  } else {
    $(obj).parents('.lidar').find('[name="utc_time_sync"]').attr({ 'disabled': true, 'checked': false })
  }
}
function loadConfig(config) {
  if (config == null) return;
  $('.container>.lidar').each(function (i, v) {
    let obj = config[i];
    $(this).find('[name]').each(function () {
      let key = $(this).attr('name');
      let type = $(this).attr('type');
      if (type == "number") {
        $(this).val(compareVal(this, obj[key]));
      } else if (type == "radio") {
        if (obj[key] == $(this).val()) {
          $(this).attr('checked', true);
        } else {
          $(this).removeAttr('checked');
        }
        if (obj[key] == 13 || obj[key] == 14 || obj[key] == 17 || obj[key] == 21) {
          $(this).parents('.lidar').find('[name="utc_time_sync"]').attr('disabled', false);
          if (obj['utc_time_sync'] == 'yes') {
            $(this).parents('.lidar').find('[name="utc_time_sync"]').attr('checked', true);
          } else {
            $(this).parents('.lidar').find('[name="utc_time_sync"]').attr('checked', false);
          }
        } else {
          $(this).parents('.lidar').find('[name="utc_time_sync"]').attr({ 'disabled': true, 'checked': false })
        }
      } else if (type == 'checkbox') {
        if (key == 'yaw_lock') {
          if (obj[key] == 'yes') {
            $(this).prop('checked', true);
            $(this).parents('.lidar').find('[name=roll_lock]').removeAttr('checked')
          } else {
            $(this).prop('checked', false);
            $(this).parents('.lidar').find('[name=roll_lock]').prop('checked', true);
          }
        } else {
          $(this).prop('checked', obj[key] == 'yes' ? true : false);
        }
      } else {
        $(this).val(obj[key]).attr("value", obj[key]);
      }
    });
    if (obj.dist_offsets != "null") {
      dist_offsets[i] = (obj.dist_offsets.split(",")).slice();
      pitch_angles[i] = (obj.pitch_angles.split(",")).slice();
      yaw_offsets[i] = (obj.yaw_offsets.split(",")).slice();
    } else if (obj.yaw_offsets != "null") {
      pitch_angles2[i] = obj.pitch_angles.split(",").slice();
      yaw_offsets2[i] = obj.yaw_offsets.split(",").slice();
    }
  });
}
function compareVal(obj, val) {
  var step = $(obj).attr('step').length > 2 ? $(obj).attr('step').length - 2 : 0,
    v = Number(val),
    min = Number($(obj).attr('min')),
    max = Number($(obj).attr('max'));
  if (isNaN(v)) { v = Number($(obj).attr('value')); }
  v = v < min ? min : v;
  v = v > max ? max : v;
  return (Math.round(v * Math.pow(10, step)) / Math.pow(10, step)).toFixed(step);
}
function setConfig() {
  let text = `<?xml version="1.0" encoding="utf-8"?><root>`;
  $('.container>.lidar').each(function (i, v) {
    text += `<lidar` + (i + 1);
    $(this).find('[name]').each(function () {
      let key = $(this).attr('name');
      let type = $(this).attr('type');
      let value = $(this).val();
      if (type == "number"||$(this).is("select")) {
        text += " " + key + "=\"" + value + "\"";
      } else if (type == "text") {
        if ($(this).hasClass('red') || value == "") {
          value = $(this).attr('value');
        }
        text += " " + key + "=\"" + value + "\"";
      } else if (type == 'checkbox') {
        if (key != "roll_lock") {
          text += " " + key + `="` + ($(this).is(':checked') ? "yes" : "no") + `\"`;
        }
      }
    });
    text += " model" + "=\"" + $(this).find('input[name=model]:checked').val() + "\"";
    if (pitch_angles[i].length != 0 || pitch_angles2[i].length != 0) {
      text += " pitch_angles" + "=\"" + (pitch_angles[i].length == 0 ? pitch_angles2[i].toString() : pitch_angles[i].toString()) + "\"";
    }
    if (yaw_offsets[i].length != 0 || yaw_offsets2[i].length != 0) {
      text += " yaw_offsets" + "=\"" + (yaw_offsets[i].length == 0 ? yaw_offsets2[i].toString() : yaw_offsets[i].toString()) + "\"";
    }
    if (dist_offsets[i].length != 0) text += " dist_offsets" + "=\"" + dist_offsets[i].toString() + "\"";
    if (dist_offsets_temperature[i].length != 0) {
      let channelNum = dist_offsets_temperature[i];
      text += ">";
      for (let n = 0; n < channelNum.length; n++) {
        text += "<dist_offsets_temperature";
        text += " t=\"" + channelNum[n].t + "\"";
        text += " v=\"" + channelNum[n].v + "\"/>";
      }
      text += "</lidar" + (i + 1) + ">";
    } else {
      text += " />";
    }
  });
  text += `</root>`;
  console.log(text);
  biSetModuleConfig("lidars-simple-mode.pluginlidar", text);
}
function calibShow(obj) {
  $('.calib').show();
  biSetViewSize(379, 391);
  $('.container').hide();
  index = $(obj).parent().parent().parent().parent().parent().parent().parent().index() - 4;
  yaw_offsets2[index - 1] = [];
  pitch_angles2[index - 1] = [];
  dist_offsets_temperature[index - 1] = [];
  let pitch = pitch_angles[index - 1],
    yaw = yaw_offsets[index - 1],
    dist = dist_offsets[index - 1];
  if (pitch.length != 0) loadXml(pitch, yaw, dist);
}
function rsHeliosShow(obj) {
  $('.rshelios32').show();
  biSetViewSize(300, 390);
  $('.container').hide();
  index = $(obj).parent().parent().parent().parent().parent().parent().parent().index() - 4;
  yaw_offsets2[index - 1] = [];
  pitch_angles2[index - 1] = [];
  let pitch = pitch_angles[index - 1],
    yaw = yaw_offsets[index - 1];
  if (pitch.length != 0) {
    $('.rshelios32>div:nth-of-type(2) table tr').each(function (i, v) {
      $(this).children('td:nth-of-type(2)').html(Number(pitch[i]).toFixed(2));
      $(this).children('td:nth-of-type(3)').html(Number(yaw[i]).toFixed(2));
      $(this).children('td:nth-of-type(4)').html(Number(dist[i] * 100).toFixed(1));
    });
    for (let i = 64; i < pitch.length; i++) {
      let d = Number(dist[i] * 100);
      let text = "<tr><td>" + i + "</td><td>" + Number(pitch[i]).toFixed(2) + "</td><td>" + Number(yaw[i]).toFixed(2) + "</td><td>" + d.toFixed(1) + "</td></tr>";
      $('.rshelios32>div:nth-of-type(2) table>tbody').append(text);
    }
  };
}
function rsLis32LeShow(obj) {
  $('.rsLidar32Le').show();
  biSetViewSize(1080, 388);
  $('.container').hide();
  index = $(obj).parent().parent().parent().parent().parent().parent().parent().index() - 4;
  dist_offsets[index - 1] = [];
  yaw_offsets[index - 1] = [];
  pitch_angles[index - 1] = [];
  let pitch = pitch_angles2[index - 1],
    yaw = yaw_offsets2[index - 1];
  if (pitch.length != 0) loadAngle(pitch, yaw);
  let temperature = dist_offsets_temperature[index - 1];
  if (temperature.length != 0) {
    let arr = [],
      t = [];
    for (let i = 0; i < temperature.length; i++) {
      let tem = temperature[i];
      let array = tem.v.split(",");
      arr.push(array);
      t.push(tem.t);
    }
    let arrP = [];
    for (let i = 0; i < arr[0].length; i++) {
      let aa = [];
      for (let j = 0; j < arr.length; j++) {
        aa.push(Number(arr[j][i] * 100).toFixed(0));
      }
      arrP.push(aa.toString());
    }
    arrP.push(t.toString());
    loadChannelNum(arrP);
  }
}
function rsLidLaShow(obj) {
  $('.rsLidar32La').show();
  biSetViewSize(300, 390);
  $('.container').hide();
  index = $(obj).parent().parent().parent().parent().parent().parent().parent().index() - 4;
  yaw_offsets2[index - 1] = [];
  pitch_angles2[index - 1] = [];
  let pitch = pitch_angles[index - 1],
    yaw = yaw_offsets[index - 1];
  if (pitch.length != 0) {
    $('.rsLidar32La>div:nth-of-type(2) table tr').each(function (i, v) {
      $(this).children('td:nth-of-type(2)').html(Number(pitch[i]).toFixed(2));
      $(this).children('td:nth-of-type(3)').html(Number(yaw[i]).toFixed(2));
      $(this).children('td:nth-of-type(4)').html(Number(dist[i] * 100).toFixed(1));
    });
    for (let i = 64; i < pitch.length; i++) {
      let d = Number(dist[i] * 100);
      let text = "<tr><td>" + i + "</td><td>" + Number(pitch[i]).toFixed(2) + "</td><td>" + Number(yaw[i]).toFixed(2) + "</td><td>" + d.toFixed(1) + "</td></tr>";
      $('.rsLidar32La>div:nth-of-type(2) table>tbody').append(text);
    }
  };
}
function closeCalib() {
  let pitch = [],
    dist = [],
    yaw = [];
  $('.calib>div:nth-of-type(2) table tr').each(function (i, v) {
    if (i >= 32) $(this).remove();
  });
  for (let i = 0; i < 32; i++) {
    pitch.push(0.00);
    yaw.push(0.00);
    dist.push(0.00);
  }
  loadXml(pitch, yaw, dist);
  $('.calib').hide();
  $('.container').show();
  biSetViewSize(443, 769);
}
function closeRsHelios() {
  let pitch = [],
    yaw = [];
  for (let i = 0; i < 32; i++) {
    pitch.push(0.00);
    yaw.push(0.00);
  }
  loadAngle(pitch, yaw);
  loadChannelNum([]);
  $('.rshelios32').hide();
  $('.container').show();
  biSetViewSize(443, 769);
}
function closeRsLidar32La() {
  let pitch = [],
    yaw = [];
  for (let i = 0; i < 32; i++) {
    pitch.push(0.00);
    yaw.push(0.00);
  }
  loadAngle(pitch, yaw);
  loadChannelNum([]);
  $('.rsLidar32La').hide();
  $('.container').show();
  biSetViewSize(443, 769);
}
function closeRsLidar32Le() {
  let pitch = [],
    yaw = [];
  for (let i = 0; i < 32; i++) {
    pitch.push(0.00);
    yaw.push(0.00);
  }
  loadAngle(pitch, yaw);
  loadChannelNum([]);
  $('.rsLidar32Le').hide();
  $('.container').show();
  biSetViewSize(443, 769);
}
function importCalib() {
  var filter = { ".xml": "Velodyne 64L calibration file (*.xml)" };
  biSelectPath("OpenFilePath1", BISelectPathType.OpenFile, filter);
}
function importAngle() {
  var filter = { "angle.csv": "RSLidar32 calibration file (angle.csv)" };
  biSelectPath("OpenFilePath2", BISelectPathType.OpenFile, filter);
}
function importChannel() {
  var filter = { "ChannelNum.csv": "RSLidar32 calibration file (ChannelNum.csv)" };
  biSelectPath("OpenFilePath3", BISelectPathType.OpenFile, filter);
}
function biOnSelectedPath(key, path) {
  if (path == null) {
    return;
  }
  if (key == "CreateFilePath") {
    createFileHandle = biWriteFileText(path);
    if (createFileHandle != null) {
      document.getElementById('button-write').disabled = false;
    }
  } else if (key == "OpenFilePath1") {
    let handle = biQueryFileText(path);
    if (handle != null) {
      let text = "";
      while (true) {
        let rowText = biQueryFileText(handle);
        if (rowText == null) break;
        else {
          text += rowText.trim();
        }
      }
      biWriteFileText(handle);
      let parser = new DOMParser();
      let xmlDoc = parser.parseFromString(text, "text/xml");
      let countrys = xmlDoc.getElementsByTagName('points_');
      let arr = [];
      for (let i = 0; i < countrys[0].childNodes.length; i++) {
        let nodeName = countrys[0].childNodes[i].nodeName;
        if (nodeName == "item") {
          let a = [];
          for (let n = 0; n < countrys[0].childNodes[i].childNodes.length; n++) {
            let name = countrys[0].childNodes[i].childNodes[n].nodeName;
            if (name == "px") {
              let pitch = Number(countrys[0].childNodes[i].childNodes[n].childNodes[2].textContent);
              let yaw = Number(countrys[0].childNodes[i].childNodes[n].childNodes[1].textContent);
              let dist = Number(countrys[0].childNodes[i].childNodes[n].childNodes[3].textContent) / 100;
              if (isNaN(pitch) || isNaN(yaw) || isNaN(dist)) {
                biAlert("The file is NOT a calibration file for RSLdar32.", "Error");
                return;
              }
              a.push(pitch.toFixed(2));
              a.push(yaw.toFixed(2));
              a.push(dist);
              arr.push(a);
            }
          }
        }
      }
      arr.sort(function (x, y) {
        return x[0] - y[0];
      });
      let pitch = pitch_angles[index - 1] = [],
        yaw = yaw_offsets[index - 1] = [],
        dist = dist_offsets[index - 1] = [];
      for (let i = 0; i < arr.length; i++) {
        pitch.push(arr[i][0]);
        yaw.push(arr[i][1]);
        dist.push(arr[i][2]);
      }
      loadXml(pitch, yaw, dist);
    }
  } else if (key == "OpenFilePath2") {
    let handle = biQueryFileText(path);
    if (handle != null) {
      let arr = [],
        flag = false;
      while (true) {
        let rowText = biQueryFileText(handle);
        if (rowText == null) break;
        else {
          let a = rowText.split(",");
          if (isNaN(Number(a[0])) || isNaN(Number(a[1]))) {
            flag = true;
            biAlert("The file is NOT a calibration file for RSLdar32.", "Error");
            break;
          }
          let b = [Number(a[0]).toFixed(2), (0 - Number(a[1])).toFixed(2)];
          arr.push(b);
        }
      }
      biWriteFileText(handle);
      if (!flag) {
        arr.sort(function (x, y) {
          return x[0] - y[0];
        });
        let pitch = pitch_angles2[index - 1] = [],
          yaw = yaw_offsets2[index - 1] = [];
        for (let i = 0; i < arr.length; i++) {
          pitch.push(arr[i][0]);
          yaw.push(arr[i][1]);
        }
        loadAngle(pitch, yaw);
      }
    }
  } else if (key == "OpenFilePath3") {
    let handle = biQueryFileText(path);
    if (handle != null) {
      let arr = [];
      while (true) {
        let rowText = biQueryFileText(handle);
        if (rowText == null) break;
        else {
          arr.push(rowText);
        }
      }
      biWriteFileText(handle);
      let aa = dist_offsets_temperature[index - 1] = [];
      let arrayP = [];
      for (let i = 0; i < arr.length; i++) {
        let array = arr[i].split(",");
        arrayP.push(array);
      }
      for (let i = 0; i < arrayP[arrayP.length - 1].length; i++) {
        let tem = new Temperature(arrayP[arrayP.length - 1][i], "");
        let bb = [];
        for (let j = 0; j < arrayP.length - 1; j++) {
          bb.push(0 - arrayP[j][i] / 100);
        }
        tem.v = bb.toString();
        aa.push(tem);
      }
      loadChannelNum(arr);
    }
  }
}
function loadXml(pitch, yaw, dist) {
  $('.calib>div:nth-of-type(2) table tr').each(function (i, v) {
    $(this).children('td:nth-of-type(2)').html(Number(pitch[i]).toFixed(2));
    $(this).children('td:nth-of-type(3)').html(Number(yaw[i]).toFixed(2));
    $(this).children('td:nth-of-type(4)').html(Number(dist[i] * 100).toFixed(1));
  });
  for (let i = 64; i < pitch.length; i++) {
    let d = Number(dist[i] * 100);
    let text = "<tr><td>" + i + "</td><td>" + Number(pitch[i]).toFixed(2) + "</td><td>" + Number(yaw[i]).toFixed(2) + "</td><td>" + d.toFixed(1) + "</td></tr>";
    $('.calib>div:nth-of-type(2) table>tbody').append(text);
  }
}
function loadAngle(pitch, yaw) {
  $('.rslidar>div:nth-of-type(2)>.left table tr').each(function (i, v) {
    $(this).children('td:nth-of-type(2)').html(Number(pitch[i]).toFixed(2));
    $(this).children('td:nth-of-type(3)').html(Number(yaw[i]).toFixed(2));
  });
}
function loadChannelNum(arr) {
  let text = "<span>Index</span>";
  if (arr.length == 0) {
    $('.rslidar>div:nth-of-type(2)>.right>div>div:first-of-type').html(text);
    for (let i = 0; i < 32; i++) {
      $('.rslidar>div:nth-of-type(2)>.right>div table tr:eq(' + i + ')').html(i + 1);
    }
  } else {
    let title = arr[arr.length - 1].split(",");
    for (let n = 0; n < title.length; n++) {
      text += "<span>" + title[n] + "℃</span>";
    }
    $('.rslidar>div:nth-of-type(2)>.right>div>div:first-of-type').html(text);
    for (let i = 0; i < arr.length - 1; i++) {
      let tem = arr[i];
      let vArr = tem.split(",");
      let mm = "<td>" + (i + 1) + "</td>";
      for (let j = 0; j < vArr.length; j++) {
        mm += "<td>" + (0 - vArr[j]) + "</td>";
      }
      $('.rslidar>div:nth-of-type(2)>.right>div table tr:eq(' + i + ')').html(mm);
    }
  }
}
function drawLine(p1, p2, width, color, ctx) {
  ctx.beginPath();
  ctx.lineWidth = width;
  ctx.moveTo(p1.x, p1.y);
  ctx.lineTo(p2.x, p2.y);
  ctx.closePath();
  ctx.strokeStyle = color;
  ctx.stroke();
}
function drawRect(p, s, color, ctx) {
  ctx.beginPath();
  ctx.rect(p.x, p.y, s.width, s.height);
  ctx.strokeStyle = color;
  ctx.stroke();
}
function drawCircle(p, radius, color, width, ctx) {
  ctx.beginPath();
  ctx.lineWidth = width;
  ctx.strokeStyle = color;
  ctx.arc(p.x, p.y, radius, 0, Math.PI * 2, false);
  ctx.stroke();
}
function handleButtonSignal(evt) {
  let originID = document.getElementById('signal').innerHTML;
  biSelectSignal("TargetSignal", originID.length == 0 ? null : originID, false, null, true, signalScale, "[m]");
}
function biOnSelectedSignal(key, valueInfo, signBitInfo, scale) {
  if (key == "TargetSignal") {
    document.getElementById('signal').innerHTML = valueInfo == null ? "" : valueInfo.id;
    signalScale = scale;
  }
}
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(443, 769);
  biQueryGlobalVariable('Subject.VehicleWidth', '1.6');
  biQueryGlobalVariable('Subject.VehicleHeight', '1.9');
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value]);
  });
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('root');
    let arr = [];
    for (let i = 0; i < countrys[0].childNodes.length; i++) {
      let keys = countrys[0].childNodes[i].getAttributeNames();
      let obj = new Object();
      for (let n = 0; n < keys.length; n++) {
        obj[keys[n]] = countrys[0].childNodes[i].getAttribute(keys[n]);
      }
      for (let j = 0; j < countrys[0].childNodes[i].childNodes.length; j++) {
        let keyss = countrys[0].childNodes[i].childNodes[j].getAttributeNames();
        let t = countrys[0].childNodes[i].childNodes[j].getAttribute(keyss[0]);
        let v = countrys[0].childNodes[i].childNodes[j].getAttribute(keyss[1]);
        let tem = new Temperature(t, v);
        dist_offsets_temperature[i].push(tem);
      }
      arr.push(obj);
    }
    loadConfig(arr);
  }
}
function biOnQueriedGlobalVariable(id, value) {
  vehicle.push(value);
  $('.lidar').each(function () {
    scaleCanvas($(this).find('.scale_change'));
  })
}