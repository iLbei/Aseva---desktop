let language = sessionStorage.getItem("language");
let cn = {
    lidar1: "激光雷达1",
    lidar2: "激光雷达2",
    device: "设备",
    connect: "连接",
    ip_filter: "IP筛选器(可选):",
    adaptor: "适配器:",
    point_cloud_output_channel: "点云输出通道:",
    point_map_output_channel: "点映射输出通道:",
    processing: "处理",
    device_type: "设备类型:",
    frame_split_angle: "帧分角[deg]:",
    origin: "原点 [m]:",
    yaw_offset: "偏航角偏移量[deg]:",
    for_only: "仅用于离线/回放模式",
    disabled: "(禁用)",
    channel_a: "通道 A",
    channel_b: "通道 B",
    channel_c: "通道 C"
},
    en = {
        disabled: "(Disabled)",
        channel_a: "Channel A",
        channel_b: "Channel B",
        channel_c: "Channel C",
        for_only: "For offline/replay mode only",
        lidar1: "Lidar1",
        lidar2: "Lidar2",
        device: "Device",
        connect: "Connect",
        ip_filter: "IP filter (optional):",
        adaptor: "Adaptor:",
        device_type: "Device type:",
        frame_split_angle: "Frame split angle [deg]:",
        processing: "Processing",
        point_cloud_output_channel: "Point cloud output channel:",
        point_map_output_channel: "Point map output channel:",
        origin: "Origin [m]:",
        yaw_offset: "Yaw offset [deg]:"
    };

$('input[type=number]').on({
    'change': function () {
        let step = $(this).attr('step').length - 2;
        let v = parseFloat($(this).val());
        let min = parseFloat($(this).attr('min')),
            max = parseFloat($(this).attr('max'));
        v = v < min ? min : v;
        v = v > max ? max : v;
        let value;
        if (step <= -1) {
            value = v.toFixed(0);
        } else {
            value = v.toFixed(step);
        }
        $(this).val(value);
        drawPaint(this);
        setConfig();
    },
    'input': function (e) {
        if (e.which == undefined) {
            drawPaint(this);
        }
    },
    'blur': function () {
        if($(this).val()=='') $(this).val($(this).attr('value'))
        drawPaint(this);
    }
})
$('select').change(function () {
    setConfig()
})
if (language != null) {
    changeLanguage(language);
}
/**
 * 判断中英文
 */
function changeLanguage(type) {
    if (type == 1) {
        $('[language]').each(function () {
            let value = $(this).attr('language');
            $(this).html(en[value])
        });
    } else {
        $('[language]').each(function () {
            let value = $(this).attr('language');
            $(this).html(cn[value])
        });
    }
}

$(function () {
    $('.content>div').each(function () {
        draw($(this), 1);
    });
});
function biOnInitEx(config, moduleConfigs) {
    biSetViewSize(436, 397)
    let type = biGetLanguage();
    changeLanguage(type);
    sessionStorage.setItem("language", type);
    for (let key in moduleConfigs) {
        let parser = new DOMParser();
        let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
        let countrys = xmlDoc.getElementsByTagName('root');
        let o = new Object();
        let arr = [];
        for (let i = 0; i < countrys[0].childNodes.length; i++) {
            let nodeName = countrys[0].childNodes[i].nodeName;
            let conu = xmlDoc.getElementsByTagName(nodeName);
            let keyss = conu[0].getAttributeNames();
            let obj = new Object();
            for (let j = 0; j < keyss.length; j++) {
                obj[keyss[j]] = conu[0].getAttribute(keyss[j]);
            }
            arr.push(obj);
        }
        o["arr"] = arr;
        loadConfig(JSON.stringify(o));
    }
}
/**
 *  页面加载时,读取本地配置
 */
 function loadConfig(config) {
    if (config == null) return;
    let val = JSON.parse(config).arr;
    $('.content>div').each(function (i, v) {
        let obj = val[i];
        $(this).find('[name]').each(function () {
            let name = $(this).attr("name");
            let type = $(this).attr("type");
            if ($(this).is('select')) {
                $(this).val(obj[name]);
            } if (type == "number") {
                let step = $(this).attr('step').length - 2;
                let v = parseFloat(obj[name]);
                if (step <= -1) {
                    $(this).val(v.toFixed(0));
                } else {
                    $(this).val(v.toFixed(step));
                }
            }
        });
        draw($(this), 1);
    });
}

function setConfig() {
    let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root>";
    $('.content>div').each(function () {
        let className = $(this).attr('class');
        text += "<" + className + "";
        $(this).find('[name]').each(function () {
            let name = $(this).attr("name");
            let type = $(this).attr("type");
            if ($(this).is('select')) {
                text += " " + name + "=\"" + $(this).val() + "\"";
            } else if (type == "number") {
                let step = $(this).attr('step').length - 2;
                let v = parseFloat($(this).val());
                let min = parseFloat($(this).attr('min')),
                    max = parseFloat($(this).attr('max'));
                v = v < min ? min : v;
                v = v > max ? max : v;
                let value;
                if (step <= -1) {
                    value = v.toFixed(0);
                } else {
                    value = v.toFixed(step);
                }
                text += " " + name + "=\"" + value + "\"";
            }
        });
        text += "/>"
    });
    text += "</root>";
    console.log(text);
    biSetModuleConfig("lidars.pluginlidar", text);
}
//画图
function draw(obj, scale) {
    let canvas = $(obj).find('.canvas')[0];
    let ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    let p1 = new BIPoint(canvas.width / 2, 0);
    let p2 = new BIPoint(canvas.width / 2, canvas.height);
    let p3 = new BIPoint(0, 56);
    let p4 = new BIPoint(canvas.width, 56);
    drawLine(p1, p2, 1, "#e9e9e9", ctx);
    drawLine(p3, p4, 1, "#e9e9e9", ctx);
    let size = new BISize(30 * scale, 70 * scale);
    let p5 = new BIPoint(canvas.width / 2 - 15 * scale, 56);
    drawRect(p5, size, "black", ctx);
    let p6 = new BIPoint(canvas.width / 2, 56);
    let p7 = new BIPoint(canvas.width / 2 - 15 * scale, 56 + 25 * scale);
    let p8 = new BIPoint(canvas.width / 2 + 15 * scale, 56 + 25 * scale);
    let arr = [p6, p7, p8];
    drawPolygon(arr, "black", ctx);
    let x = Number($(obj).find('[name=offset_x]')[0].value);
    let y = Number($(obj).find('[name=offset_y]')[0].value);
    let yaw = Number($(obj).find('[name=yaw]')[0].value);
    p8 = new BIPoint(canvas.width / 2 - y * 15 * scale, 56 - (24 + x * 24 / 1.5) * scale);
    let p9 = new BIPoint(canvas.width / 2 - y * 15 * scale, 56 - x * 24 / 1.5 * scale);
    let p10 = new BIPoint(canvas.width / 2 - (15 + y * 15) * scale, 56 - x * 24 / 1.5 * scale);
    ctx.save();
    ctx.translate(p9.x, p9.y);
    ctx.rotate(Math.PI / 180 * (0 - yaw));
    p1 = new BIPoint(p8.x - p9.x, p8.y - p9.y);
    p2 = new BIPoint(p9.x - p9.x, p9.y - p9.y);
    p3 = new BIPoint(p10.x - p9.x, p10.y - p9.y);
    ctx.beginPath();
    ctx.moveTo(p1.x, p1.y);
    ctx.lineTo(p2.x, p2.y);
    ctx.lineTo(p3.x, p3.y);
    ctx.strokeStyle = "#32cd32";
    ctx.stroke();
    ctx.restore();
}
//改变事件
function drawPaint(obj) {
    let o = $(obj).parent().parent().parent().parent().parent();
    let scale = $(o).find('.scale_change').attr("scale") == "large" ? 1 : 0.3;
    draw(o, scale);
}
//放大或缩小
function transformation(obj) {
    let type = $(obj).attr("scale");
    let lang = biGetLanguage();
    let text = "";
    let scale = 0;
    if (type == "large") {
        text = lang == 1 ? "Scale: Large" : "比例: 放大";
        $(obj).attr("scale", "small");
        scale = 0.3;
    } else {
        text = lang == 1 ? "Scale: Small" : "比例: 缩小";
        $(obj).attr("scale", "large");
        scale = 1;
    }
    $(obj).html(text);
    draw($(obj).parent().parent(), scale);
}
/**
 * 画多边形
 * @param {} arr 点
 * @param {*} color 颜色 
 * @param {*} ctx 上下文
 */
function drawPolygon(arr, color, ctx) {
    ctx.beginPath();
    ctx.moveTo(arr[0].x, arr[0].y);
    ctx.lineTo(arr[1].x, arr[1].y);
    ctx.lineTo(arr[2].x, arr[2].y);
    ctx.strokeStyle = color;
    ctx.closePath();
    ctx.stroke();
}

/**
 * 画线-两点一线
 * @param {*} p1 点
 * @param {*} p2 点
 * @param {*} width 线宽度
 * @param {*} color 颜色
 * @param {*} ctx 画图上下文
 */
function drawLine(p1, p2, width, color, ctx) {
    ctx.beginPath();
    ctx.lineWidth = width;
    ctx.moveTo(p1.x, p1.y);
    ctx.lineTo(p2.x, p2.y);
    ctx.closePath();
    ctx.strokeStyle = color;
    ctx.stroke();
}
/**
 * 画矩形
 * @param {*} p 顶点
 * @param {*} s 大小
 * @param {*} color 颜色
 * @param {*} ctx 画图上下文
 */
function drawRect(p, s, color, ctx) {
    ctx.beginPath();
    ctx.rect(p.x, p.y, s.width, s.height);
    ctx.strokeStyle = color;
    ctx.stroke();
}
/**
 * 画圆
 * @param {*} p 圆心
 * @param {*} radius 半径 
 * @param {*} color 颜色
 * @param {*} width 线宽
 * @param {*} ctx 画图上下文
 */
function drawCircle(p, radius, color, width, ctx) {
    ctx.beginPath();
    ctx.lineWidth = width;
    ctx.strokeStyle = color;
    ctx.arc(p.x, p.y, radius, 0, Math.PI * 2, false);
    ctx.stroke();
}