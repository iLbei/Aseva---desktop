let cn = {
  lmc_enable:"启用",
  lmc_input_channel_pts:"点云输入通道:",
  lmc_output_channel_pts:"点云输出通道:",
  lmc_angle:"角度:",
  lmc_fov:"视角范围:",
  lmc_delay:"延迟时间:",
  lmc_video_channel:"视频通道:",
  compensate_mode:"补偿模式:"
},
en = {
  lmc_enable:"Enable",
  lmc_input_channel_pts:"Input Points channel:",
  lmc_output_channel_pts:"Output Points channel:",
  lmc_angle:"Angle:",
  lmc_fov:"FOV:",
  lmc_delay:"Delay:",
  compensate_mode:"Mode:",
  lmc_video_channel:"Video channel:"
};