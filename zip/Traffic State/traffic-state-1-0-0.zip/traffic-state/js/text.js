let cn = {
  tsEnable: "启用",
  lanesChannel:"车道线通道:",
  objectsChannel:"目标物通道:",
  obj_sensor:"目标物传感器 ",
  lanes_channel:"通道 "
},
  en = {
    tsEnable: "Enable",
    lanesChannel:"Lanes channel:",
    objectsChannel:"Objects channel:",
    obj_sensor:"Object sensor ",
    lanes_channel:"Channel "
  };