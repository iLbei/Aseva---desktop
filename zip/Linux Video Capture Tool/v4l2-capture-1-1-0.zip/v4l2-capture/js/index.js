$('[name]').change(function () {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
  text += "<root ";
  $('.container [name]').each(function () {
    let name = $(this).attr('name');
    let val = $(this).val();
    if ($(this).attr('type') == 'checkbox') {
      val = $(this).is(':checked') ? "yes" : "no"
    }
    text += name + "=\"" + val + "\" ";
  });
  text += " />";
  biSetModuleConfig("v4l2-capture.v4l2capture", text);
});

function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(265, 116)
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value])
  });
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('root');
    let keys = countrys[0].getAttributeNames();
    let obj = new Object();
    for (let i = 0; i < keys.length; i++) {
      obj[keys[i]] = countrys[0].getAttribute(keys[i]);
    };
    $('.container [name]').each(function(){
      let val = obj[$(this).attr('name')];
      if($(this).is('select')){
        $(this).val(val);
      }else if($(this).attr('type')=='checkbox'){
        $(this).prop('checked',val=='yes'?true:false);
      }
    })
  }
}
