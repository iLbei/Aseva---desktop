let cn = {
  enabled: "启用",
  m2_code_rate: "2M码率:",
  m8_code_rate: "8M码率:",
  calGPSTime:"GPS时间计算",
  leapSecond:"闰秒:"
},
  en = {
    enabled: "Enabled",
    m2_code_rate: "2M Code Rate:",
    m8_code_rate: "8M Code Rate:",
    calGPSTime:"CalGPSTime",
    leapSecond:"LeapSecond:"
  };