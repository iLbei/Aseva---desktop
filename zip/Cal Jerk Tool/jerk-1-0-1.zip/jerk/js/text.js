var cn = {
    Enabled: "启用",
    CalpointNum: "计算点数:",
    RelThresholdx: "X相对阈值:",
    RelThresholdy: "Y相对阈值:",
    GNSS_IMUChannel: "GNSS通道:",
  },
  en = {
    Enabled: "Enabled",
    CalpointNum: "CalpointNum:",
    RelThresholdx: "RelThreshold X:",
    RelThresholdy: "RelThreshold Y:",
    GNSS_IMUChannel: "GNSSChannel:",
  };