var not_select = "", dialogConfig = [{}, {}, {}, {}, {}];

$(".top button").click(function () {
  getVal($(this).index());
  $(this).addClass("active").siblings().removeClass("active");
})
/*---------------input [type=number]--------------*/
$('input[type=number]').on({
  "change": function () {
    $(this).val(compareVal(this, $(this).val()));
  },
  'input': function (e) {
    if (e.which == undefined) {
      var step = $(this).attr("step").length - 2;
      var val = Number($(this).val());
      $(this).val(step > 0 ? val.toFixed(step) : val);
    }
    setVal(this);
  },
  'keypress': function (e) {
    if (!(e.charCode >= 48 && e.charCode <= 57) && !(e.charCode == 45 || e.charCode == 46)) {
      return false;
    }
  }
})
$("input[type=text]").on("input",function(){
  setVal(this);
})
$("a").click(function () {
  var name = $(this).attr("name");
  biSelectPath(name, BISelectPathType.Directory, "");
})
function compareVal(obj, val) {
  var step = $(obj).attr('step').length > 2 ? $(obj).attr('step').length - 2 : 0,
    v = Number(val),
    newVal = 0;
  if (isNaN(v)) {
    newVal = Number($(obj).attr('value'));
  } else {
    var min = Number($(obj).attr('min')),
      max = Number($(obj).attr('max'));
    v = v < min ? min : v;
    v = v > max ? max : v;
    if (step > 0) {
      newVal = Math.round(Math.abs(v) * Math.pow(10, step)) / Math.pow(10, step);
      if (v < 0) newVal = -newVal;
    } else {
      newVal = Math.floor(v);
    }
  }
  return step > 0 ? newVal.toFixed(step) : newVal;
}

/*----------配置读取与存储-----------*/
$('.container').on("change", "[name]", function () {
  setVal(this);
});
//保存配置
function setConfig() {
  var text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root ";
  for (var i in dialogConfig) {
    for (var j in dialogConfig[i]) {
      text += j + "_" + i + "=\"" + dialogConfig[i][j] + "\" ";
    }
  }
  text += "/>";
  biSetModuleConfig("ASPackerSHUsbCam4", text);
}

function biOnInitEx(config, moduleConfigs) {
  if (biGetLanguage() == 1) {
    $('[language]').each(function () {
      var value = $(this).attr('language');
      $(this).text(en[value]);
    });
    not_select = "<Not Selected>";
  } else {
    $('[language]').each(function () {
      var value = $(this).attr('language');
      $(this).text(cn[value]);
      not_select = "<未选择>";
    });
  }
  for (var key in moduleConfigs) {
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    var root = xmlDoc.getElementsByTagName('root');
    var keys = root[0].attributes;
    for (var i = 0; i < keys.length; i++) {
      //获取root自身字节的属性
      var nodeName = keys[i].nodeName;
      var name = nodeName.substr(0, nodeName.lastIndexOf("_"));
      var val = keys[i].nodeValue;
      if (nodeName.indexOf("_0") != -1) {
        dialogConfig[0][name] = val;
      } else if (nodeName.indexOf("_1") != -1) {
        dialogConfig[1][name] = val;
      } else if (nodeName.indexOf("_2") != -1) {
        dialogConfig[2][name] = val;
      } else if (nodeName.indexOf("_3") != -1) {
        dialogConfig[3][name] = val;
      } else if (nodeName.indexOf("_4") != -1) {
        dialogConfig[4][name] = val;
      }
    }
    getVal($(".active").index());
  }
}
function getVal(i) {
  $('.content [name]').each(function () {
    var val = dialogConfig[i][$(this).attr('name')];
    var type = $(this).attr('type');
    if (type == 'checkbox') {
      $(this).prop('checked', val == '1');
    } else if (type == "number") {
      $(this).val(compareVal(this, val));
    } else if ($(this).is('a')) {
      $(this).attr("title", val == "" || val == "null" ? not_select : val).text(val == "" || val == "null" ? not_select : val);
    } else {
      $(this).val(val);
    }
  })
}
function setVal(obj) {
  var i = $(".active").index();
  var val = 0;
  var type = $(obj).attr('type');
  if (type == 'checkbox') {
    val = $(obj).is(":checked") ? "1" :" 0";
  } else if (type == "number") {
    val = compareVal(obj, $(obj).val());
  } else if ($(obj).is('a')) {
    val = $(obj).text().indexOf(not_select) == -1 ? $(obj).text() : "";
  } else {
    val = $(obj).val();
  }
  dialogConfig[i][$(obj).attr('name')] = val;
  setConfig();
}
function biOnSelectedPath(key, path) {
  if (path == null) {
    $('[name=' + key + ']').removeAttr('title').text(not_select);
  } else {
    $('[name=' + key + ']').attr('title', path).text(path);
  };
  setVal($('[name=' + key + ']'));
}