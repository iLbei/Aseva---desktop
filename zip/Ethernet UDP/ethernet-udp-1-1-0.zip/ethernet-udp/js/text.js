let cn = {
  Enabled: "启用",
},
  en = {
    Enabled: "Enabled",
  };