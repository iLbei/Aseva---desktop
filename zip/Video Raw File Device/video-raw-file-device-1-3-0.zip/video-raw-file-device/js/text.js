var cn = {
    data_path: "数据路径:",
    not_config: "<未配置>",
    enable: "启用",
    load_speed: "读取倍率:",
    time_ratio: "时间比例:",
    time_offset:"时间偏移:",
  },
  en = {
    data_path: "Data Path:",
    not_config: "<Not Configured>",
    enable: "Enabled",
    load_speed: "Load Speed:",
    time_ratio: "Time ratio:",
    time_offset:"Time offset:",
  };