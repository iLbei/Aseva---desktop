var cn = {
    data_path: "数据路径:",
    not_config: "<未配置>",
    enable: "启用",
    load_speed: "读取倍率:",
    time_ratio: "时间比例:",
    time_offset:"时间偏移:",
    prepare_frames_delay:"预准备帧延迟:",
    prepare_frames_count:"预准备帧数:",
    ms:"[毫秒]"
  },
  en = {
    data_path: "Data Path:",
    not_config: "<Not configured>",
    enable: "Enabled",
    load_speed: "Load Speed:",
    time_ratio: "Time ratio:",
    time_offset:"Time offset:",
    prepare_frames_delay:"Prepare frames delay:",
    prepare_frames_count:"Prepare frames count:",
    ms:"[ms]"
  };