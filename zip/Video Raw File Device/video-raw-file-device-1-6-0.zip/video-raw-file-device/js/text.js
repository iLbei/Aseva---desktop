var cn = {
    data_path: "数据路径:",
    not_config: "<未配置>",
    enable: "启用",
    load_speed: "读取倍率:",
    timeRatio: "时间比例:",
    time_offset:"时间偏移:",
    prepare_frames_delay:"预准备帧延迟:",
    prepare_frames_count:"预准备帧数:",
    ms:"[毫秒]",
    timeSyncType:"时间同步类型:",
    startPosix:"起始Posix:",
    posixTimeUnit:"Posix单位:"
  },
  en = {
    data_path: "Data Path:",
    not_config: "<Not configured>",
    enable: "Enabled",
    load_speed: "Load Speed:",
    timeRatio: "Time ratio:",
    time_offset:"Time offset:",
    prepare_frames_delay:"Prepare frames delay:",
    prepare_frames_count:"Prepare frames count:",
    ms:"[ms]",
    timeSyncType:"Time sync type:",
    startPosix:"Start posix:",
    posixTimeUnit:"Posix unit:"
  };