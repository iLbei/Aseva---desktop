var cn = {
    data_path: "数据路径:",
    not_config:"<未配置>"
  },
  en = {
    data_path: "Data Path:",
    not_config:"<Not Configured>"
  };