var not_config = "";
var reg = /^[a-zA-Z]:/;
$("a").click(function () {
  var name = $(this).attr("name");
  biSelectPath(name, 3, null)
})

//仅步长=精确位数-1时适用
$(".container").on("input", "input[type=number]", function (e) {
  var v = $(this).val();
  if (isNaN(e.which)) {
    $(this).attr("value", compareVal(this, v)).val(compareVal(this, v))
  } else {
    $(this).attr("value", v);
    setConfig();
  }
});
$(".container").on("blur", "input[type=number]", function () {
  $(this).attr("value", compareVal(this, $(this).val())).val(compareVal(this, $(this).val()));
});

function compareVal(obj, val) {
  var newVal = 0;
  var step = $(obj).attr("step").length - 1;
  var name = $(obj).attr("name");
  if (isNaN(val) || !Boolean(val)) {
    newVal = Number($(obj).attr('value'));
  } else {
    var min = 0,
      max = 0;
    switch (name) {
      case "time_ratio": {
        max = 10;
        min = 0.000001;
        break;
      }
      case "load_speed": {
        step = step - 1;
        max = 10;
        min = 0.01;
        break;
      }
      case "time_offset": {
        step = step - 1;
        max = 100000000;
        min = -100000000;
        break;
      }
      case "prepare_frames_delay": {
        min = 0;
        max = 10000;
        step = step - 2;
        break;
      }
      case "prepare_frames_count": {
        min = 0;
        max = 1000;
        step = step - 1;
        break;
      }
      default:
        break;
    }
    if (val > max) {
      val = max;
    } else if (val < min) {
      val = min;
    }
    //解决为负数时末尾输入5不能进行四舍五入
    if (name == "time_ratio") {
      newVal = Math.round(Math.abs(val) * Math.pow(10, 6)) / Math.pow(10, 6);
    } else {
      newVal = Math.round(Math.abs(val) * Math.pow(10, step)) / Math.pow(10, step);
    }
    if (val < 0) newVal = -newVal;
  }
  if (name == "time_ratio") {
    return step > 0 ? newVal.toFixed(6) : newVal;
  } else {
    return step > 0 ? newVal.toFixed(step) : newVal;
  }
}

//保存配置
function setConfig() {
  var text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root><config ";
  $('.container [name]').each(function () {
    var name = $(this).attr('name');
    var val = $(this).val();
    var type = $(this).attr('type');
    if (type == 'checkbox') {
      text += name + "=\"" + ($(this).is(':checked') ? "yes" : "no") + "\" ";
    } else if (type == "number") {
      text += name + "=\"" + compareVal(this, val) + "\" ";
    } else if ($(this).is("a")) {
      text += name + "=\"" + ($(this).text().indexOf(not_config) != -1 ? "" : $(this).text()) + "\" ";
    } else {
      text += name + "=\"" + val + "\" ";
    }
  });
  text += " /></root>";
  biSetModuleConfig("video-raw-file-device.aspluginvideorawfiledevice", text);
}

function biOnInitEx(config, moduleConfigs) {
  var lang = biGetLanguage() == 1 ? en : cn;
  $('[language]').each(function () {
    var value = $(this).attr('language');
    $(this).text(lang[value])
  });
  not_config = lang["not_config"];
  for (var key in moduleConfigs) {
    var parser = new DOMParser();
    var xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    var obj = new Object();
    var root = xmlDoc.getElementsByTagName('root');
    var keys = root[0].childNodes[0].attributes;
    for (var i = 0; i < keys.length; i++) {
      //获取root自身字节的属性
      obj[keys[i].nodeName] = keys[i].nodeValue;
    }
    loadConfig(obj);
  }
}

function loadConfig(obj) {
  $('.container [name]').each(function () {
    var val = obj[$(this).attr('name')];
    if (!Boolean(val)) return;
    var type = $(this).attr('type');
    if (type == 'checkbox') {
      $(this).prop('checked', val == 'yes');
    } else if (type == "number") {
      $(this).val(compareVal(this, val)).attr("value", compareVal(this, val));
    } else if ($(this).is('a')) {
      $(this).attr("title", val == "" || val == "null" ? not_config : val).text(val == "" || val == "null" ? not_config : val);
    } else {
      $(this).val(val);
    }
  })
}

function biOnSelectedPath(key, path) {
  if (path != null) {
    $('[name=' + key + ']').attr('title', path + (reg.test(path) ? '\\' : '\/')).text(path + (reg.test(path) ? '\\' : '\/'));
    // } else {
    //   $('[name=' + key + ']').removeAttr('title').text(not_config);
  };
  setConfig();
}
$("[name]").change(function () {
  setConfig();
})