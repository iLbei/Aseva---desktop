var cn = {
  calib_channel: "点阵输出通道:",
  add: "添加标定板",
  remove: "删除标定板",
  set_parameter: "设置参数",
  model: "平面模式:",
  split: "间隔:",
  position: "左上角位置(m):",
  count: "点个数:",
  confirm: "确定",
  width:"横向",
  height:"纵向"
},
  en = {
    calib_channel: "Point Matrix Channel:",
    add: "Add",
    remove: "Remove",
    set_parameter: "Set Parameters",
    model: "Flat Model:",
    split: "Gap:",
    position: "Left top position(m):",
    count: "Point Count:",
    confirm: "OK",
    width:"Widthwise",
    height:"Heightwise"
  };