var zh = {
  enableISASceneExtract: "启用ISA场景提取",
  sceneOffset: "起始偏移(s):",
  sceneLength: "场景长度(s):"
},
  en = {
    enableISASceneExtract: "Enable ISA scene",
    sceneOffset: "Scene start offset:",
    sceneLength: "Scene length:"
  };