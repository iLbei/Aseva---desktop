var cn = {
  connect: "连接",
  ip: "IP地址:",
  port: "端口号:"
},
  en = {
    connect: "Connect",
    ip: "IP:",
    port: "Port:"
  };