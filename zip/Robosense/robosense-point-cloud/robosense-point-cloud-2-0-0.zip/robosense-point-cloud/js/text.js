var cn = {
  m1_lidar:"M1雷达",
  input: "输入",
  msgID: "报文ID:",
  bus_channel: "总线通道:",
  processing: "处理",
  disabled: "(未启用)",
  point_cloud_channel: "点云输出通道:",
  origin: "起始点 [m]:",
  pos_offset: "偏移位置[°]:",
  pitch: "倾斜度",
  roll: "旋转",
  yaw: "偏航"
},
en = {
  m1_lidar:"M1 Lidar",
  enabled: " Enabled",
  input: "Input",
  msgID: "Message ID:",
  bus_channel: "Bus Channel:",
  processing: "Processing",
  disabled: "(Disabled)",
  point_cloud_channel: "Point Cloud Output Channel:",
  origin: "Origin [m]:",
  pos_offset: "Pos Offset[°]:",
  pitch: "Pitch",
  roll: "Roll",
  yaw: "Yaw"
};