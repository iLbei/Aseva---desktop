let data_path = [],
  session_length = [],
  session_start_utc = [],
  gt_data_path = [],
  dir = [],
  vehicle = [],
  metas = [],
  input_file = [],
  output_file = [];
$('input[type=number]').on({
  'change': function () {
    draw();
    $(this).val(compareVal(this, $(this).val()));
  },
  'blur': function () {
    draw();
  },
  'input': function (e) {
    if (e.which == undefined) {
      draw();
    }
    setConfig();
  },
  'keypress': function (e) {
    if (e.charCode == 101 || e.charCode == 43) {
      return false;
    }
  }
})
$('[name]').change(function () {
  setConfig()
})
$('a').click(function () {
  biSelectPath('gt_data_path', BISelectPathType.Directory, 'null');
})
function biOnSelectedPath(key, path) {
  if (path == null) return;
  if (key == "gt_data_path") $('[name=gt_data_path]').html(path).attr('title',path);
  biQueryDirsInDirectory(path);
  if (input_file == '') {
    biAlert('There is no session for the current path,Please choose right Data path!', '');
  }
  setConfig();
}
$('button').click(function () {
  if (input_file == '') {
    biAlert('There is no session for the current path,Please choose right Data path!', '');
  }
  let config = '';
  config = `<?xml version="1.0" encoding="utf-8"?><root>`;
  config += `<type time_type=\"` + $('[name=time_type]').val() + "\"/>";
  for (let i in input_file) {
    config += "<Session data_path=\"" + input_file[i] + "\"";
    config += " session_length=\"" + (session_length[i] ? session_length[i] : '') + "\"";
    config += " session_start_utc=\"" + (session_start_utc[i] ? session_start_utc[i] : '') + "\"";
    config += "/>";
  }
  for (let i in output_file) {
    config += "<reference_session gt_data_path=\"" + output_file[i] + "\"/>";
  }
  config += "</root>";
  biPrint(config);
  console.log(config);
  biSetViewConfig(config);
  biRunStandaloneTask('RobosenseReference', 'robosense-reference-task.pluginrobosense', config);
})
function biOnQueriedDirsInDirectory(dirs, path) {
  dir = [], output_file = [];
  dir = dirs[0].split('\n');
  for (let i in dir) {
    biPrint(dir[i]);
    biPrint(dir[i].substr(2, 1));
    biQueryDirectoryExist(dir[i] + (dir[i].indexOf(':') != -1 ? dir[i].substr(2, 1) : '/') + 'result');
    if (input_file == '') {
      biQueryFilesInDirectory(dir[i]);
    }
  }
}
function biOnQueriedDirectoryExist(exist, path) {
  let new_path = path.substr(0, path.length - 7);
  if (exist) {
    output_file.push(path);
  } else {
    if (session_length == '' && session_start_utc == '') {
      biPrint(new_path);
      biPrint(new_path.substr(2, 1));
      biQueryFileText(new_path + (new_path.indexOf(':') != -1 ? new_path.substr(2, 1) : '/') + 'meta.xml');
    }
  }
}
function biOnResultOfStandaloneTask(key, result, returnValue) {
  if (result == 1) {
    biAlert('Import reference data success!', '')
  } else {
    biAlert('Failed', '')
  }
}
function biOnQueriedFileText(text, path) {
  if (!path) return;
  let parser = new DOMParser();
  let xmlDoc = parser.parseFromString(text, "text/xml");
  let countrys = xmlDoc.getElementsByTagName('root')
  let keys = countrys[0].getAttributeNames();
  let obj = new Object();
  for (let n = 0; n < keys.length; n++) {
    obj[keys[n]] = countrys[0].getAttribute(keys[n]);
  }
  session_length.push(obj.length);
  session_start_utc.push(obj.start_posix_utc);
}
function biOnQueriedFilesInDirectory(files, path) {
  let file = files[0].split('\n');
  for (let i in file) {
    if (file[i].indexOf('meta.xml') != -1) {
      input_file.push(file[i].substr(0, file[i].length - 9));
    }
  }
}
function setConfig() {
  let text = `<?xml version="1.0" encoding="utf-8"?><root `;
  $('.container [name]').each(function () {
    let key = $(this).attr('name');
    let type = $(this).attr('type');
    let value = $(this).val();
    if (type == 'checkbox') {
      text += " " + key + `="` + ($(this).is(':checked') ? "yes" : "no") + `\"`;
    } else if ($(this).is('a')) {
      text += " " + key + `="` + ($(this).html().indexOf('(') == -1 ? $(this).text() : '') + `\"`;
    } else {
      text += " " + key + "=\"" + value + "\"";
    }
  });
  text += " data_path" + "=\"" + biGetDataPath() + "\"";
  text += " session_length" + "=\"" + session_length[session_length.length - 1] + "\"";
  text += " session_start_utc" + "=\"" + session_start_utc[session_start_utc.length - 1] + "\"";
  text += `/>`;
  biSetModuleConfig("robosense-reference.pluginrobosense", text);
}
function biOnQueriedGlobalVariable(id, value) {
  vehicle.push(value);
  draw();
}
function biOnInitEx(config, moduleConfigs) {
  biQueryDirsInDirectory(biGetDataPath());
  biSetViewSize(400, 514);
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value]);
  });
  biQueryGlobalVariable('Subject.VehicleWidth', '1.6');
  biQueryGlobalVariable('Subject.VehicleHeight', '1.9');
  for (let key in moduleConfigs) {
    let parser = new DOMParser();
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");
    let countrys = xmlDoc.getElementsByTagName('root')
    let keys = countrys[0].getAttributeNames();
    let obj = new Object();
    for (let n = 0; n < keys.length; n++) {
      obj[keys[n]] = countrys[0].getAttribute(keys[n]);
    }
    loadConfig(obj);
  }
}
function loadConfig(config) {
  $(".container [name]").each(function () {
    let name = $(this).attr('name');
    let type = $(this).attr('type');
    let val = config[name];
    if (val == "null" || val == "") return;
    if ($(this).is('select') || type == "number" || type == "text") {
      if (val) {
        if (type == "number") {
          $(this).val(compareVal(this, val));
        } else {
          $(this).val(val);
        }
      }
    } else if (type == "checkbox" && val == "yes") {
      $(this).attr('checked', true)
    } else if ($(this).is('a')) {
      $(this).text(val).attr('title',val)
    }
  })
  biQueryDirsInDirectory(config['gt_data_path']);
}
function drawLine(p1, p2, width, color, ctx) {
  ctx.beginPath();
  ctx.lineWidth = width;
  ctx.moveTo(p1.x, p1.y);
  ctx.lineTo(p2.x, p2.y);
  ctx.closePath();
  ctx.strokeStyle = color;
  ctx.stroke();
}
function drawRect(p, s, color, ctx) {
  ctx.beginPath();
  ctx.rect(p.x, p.y, s.width, s.height);
  ctx.strokeStyle = color;
  ctx.stroke();
}
function draw() {
  let canvas = $(".myCanvas")[0];
  let ctx = canvas.getContext('2d');
  let x = $('[name=offset_x]').val();
  let y = $('[name=offset_y]').val();
  let yaw = $('[name=yaw]').val();
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  let p1 = new BIPoint(canvas.width / 2, 0);
  let p2 = new BIPoint(canvas.width / 2, canvas.height);
  let p3 = new BIPoint(0, 50);
  let p4 = new BIPoint(canvas.width, 50);
  drawLine(p1, p2, 1, "#e9e9e9", ctx);
  drawLine(p3, p4, 1, "#e9e9e9", ctx);
  let p5 = new BIPoint(canvas.width / 2 - Number(vehicle[0]) * 10, 50);
  let size = new BISize(Number(vehicle[0]) * 20, Number(vehicle[1]) * 50);
  drawRect(p5, size, "black", ctx);
  let p6 = new BIPoint(canvas.width / 2, 50);
  let p7 = new BIPoint(canvas.width / 2 - Number(vehicle[0]) * 10, 50 + Number(vehicle[1]) * 15);
  let p8 = new BIPoint(canvas.width / 2 + Number(vehicle[0]) * 10, 50 + Number(vehicle[1]) * 15);
  let arr = [p6, p7, p8];
  drawPolygon(arr, "black", ctx);
  p8 = new BIPoint(canvas.width / 2 - y * 15, 50 - (24 + x * 24 / 1.5));
  let p9 = new BIPoint(canvas.width / 2 - y * 15, 50 - x * 24 / 1.5);
  let p10 = new BIPoint(canvas.width / 2 - (15 + y * 15), 50 - x * 24 / 1.5);
  ctx.save();
  ctx.translate(p9.x, p9.y);
  ctx.rotate(Math.PI / 180 * (0 - yaw));
  p1 = new BIPoint(p8.x - p9.x, p8.y - p9.y);
  p2 = new BIPoint(p9.x - p9.x, p9.y - p9.y);
  p3 = new BIPoint(p10.x - p9.x, p10.y - p9.y);
  ctx.beginPath();
  ctx.moveTo(p1.x, p1.y);
  ctx.lineTo(p2.x, p2.y);
  ctx.lineTo(p3.x, p3.y);
  ctx.strokeStyle = "#32cd32";
  ctx.stroke();
  ctx.restore();
}
function drawPolygon(arr, color, ctx) {
  ctx.beginPath();
  ctx.moveTo(arr[0].x, arr[0].y);
  ctx.lineTo(arr[1].x, arr[1].y);
  ctx.lineTo(arr[2].x, arr[2].y);
  ctx.strokeStyle = color;
  ctx.closePath();
  ctx.stroke();
}

function compareVal(obj, val) {
  let step = $(obj).attr('step'),
    min = parseFloat($(obj).attr('min')),
    max = parseFloat($(obj).attr('max')),
    v = parseFloat(val);
  if (isNaN(v)) { v = Number($(obj).attr('value')); }
  v = v < min ? min : v;
  v = v > max ? max : v;
  return v.toFixed(step.length > 2 ? step.length - 2 : 0)
}