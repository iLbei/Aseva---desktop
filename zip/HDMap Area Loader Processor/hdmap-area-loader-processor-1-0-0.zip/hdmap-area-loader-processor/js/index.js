// let viewSize = new BISize(260, 120); //窗口大小
let language = sessionStorage.getItem("language"); //取中英文,用于刷新保存的值
let configuration = "";
let base = new Base64();
let cn = {
    kb_data: 'KB数据',
    data_sourse: '数据源',
    hdmap_files: '高清地图文件',
    map_sourse: '地图文件',
    external_hdMap: '外部高清地图',
    ibeo_evs: 'IBEO EVS的后处理(map-evs.xodr)',
    lane_sensor_sample: '车道传感器样本的后处理(map-lss.xodr)',
    gnss_imu_sample: 'GNSS-IMU样本的后处理(map-gis.xodr)',
    external_geo_json: '外部 Geo Json',
    external_shape_file: '外部文件',
    not_config: '(未配置)',
    processing: '数据处理',
    gnss_imu_input: 'GNSS-IMU输入通道：',
    disabled: '(未启用)',
    gnss_imu: 'GNSS-IMU设备',
    visible_area_region: '可视区域:',
    fine_interval: '间隔[m]:'
},
    en = {
        kb_data: 'KB Data',
        data_sourse: 'Data Sourse',
        hdmap_files: 'HDMap Files',
        map_sourse: 'Map Source',
        external_hdMap: 'External HDMap',
        ibeo_evs: 'Post processed by IBEO EVS(map-evs.xodr)',
        lane_sensor_sample: 'Post processed by lane sensor sample(map-lss.xodr)',
        gnss_imu_sample: 'Post processed by gnss imu sample(map-gis.xodr)',
        external_geo_json: 'External Geo Json',
        external_shape_file: 'External Shape File',
        not_config: '(Not configured)',
        processing: 'Processing',
        gnss_imu_input: 'GNSS-IMU input channel:',
        disabled: '(Disabled)',
        gnss_imu: 'GNSS IMU ',
        visible_area_region: 'Visible Area Region:',
        fine_interval: 'Fine interval[m]:'
    };

if (language != null) {
    changeLanguage(language);
}
/**  
 * 判断中英文
 */
function changeLanguage(type) {
    if (type == 1) {
        $('[language]').each(function () {
            let value = $(this).attr('language');
            $(this).html(en[value])
        });
    } else {
        $('[language]').each(function () {
            let value = $(this).attr('language');
            $(this).html(cn[value])
        });
    }
}
/**
 * 加载配置
 */
function loadConfig(config) {
    if (config == null) return;
    let obj = JSON.parse(config);
    //select
    $('[name="areaGnssChannel"]').val(obj["areaGnssChannel"]);
    //多选框和单选框
    $('input').each(function () {
        let name = $(this).attr('name');
        if ($(this).attr('type') == 'radio') {
            if (obj[name] == $(this).val()) {
                $(this).attr('checked', true);
                if (name == 'areaMapSource' && $(this).siblings('a').attr('name') != undefined && $(this).is(':checked')) {
                    $(this).siblings('a').html(obj['areaMapPath'] == '' ? '(Not configured)' : obj['areaMapPath'])
                }
            }
        } else {
            $(this).val(obj[name]);
            compareVal(this)
        }
    })
}
function compareVal(obj) {
    let step = $(obj).attr('step').length - 2;
    let v = parseFloat($(obj).val());
    if (isNaN(v)) { v = Number($(obj).attr('value')); }
    let min = parseFloat($(obj).attr('min')),
        max = parseFloat($(obj).attr('max'));
    v = v < min ? min : v;
    v = v > max ? max : v;
    let value;
    if (step <= -1) {
        value = v.toFixed(0);
    } else {
        value = v.toFixed(step);
    }
    $(obj).val(value);
}
/**
 * 写配置
 */
function setConfig() {
    let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root";
    // checkbox
    $('input').each(function () {
        if ($(this).attr('type') == 'radio') {
            let name = $(this).attr('name');
            if ($(this).is(':checked')) {
                text += " " + name + "=\"" + $('[name=' + name + ']:checked').val() + "\"";
                if (name == 'areaMapSource' && $(this).siblings('a').attr('name') != undefined) {
                    text += ' ' + $(this).siblings('a').attr('name') + '=\"' + ($(this).html().indexOf('(') != -1 ? 'null' : $(this).siblings('a').html()) + '\" '
                }
            }
        } else {
            text += ' ' + $(this).attr('name') + '=\"' + $(this).val() + '\"'
        }

    })
    text += ' ' + 'areaGnssChannel' + '=\"' + $('[name=areaGnssChannel]').val() + '\"';
    text += "/>";
    biSetModuleConfig("hdmap-area-loader-processor.aspluginhdmaploadandconvert", text);
}

$('input').change(() => {
    setConfig();
});
$('select').change(() => setConfig())
//点击选择文件夹
$('a').each(function () {
    $(this).click(function () {
        let name = $(this).attr('id');
        switch (name) {
            case 'external_hdMap':
                biSelectPath("OpenFilePath1", BISelectPathType.OpenFile, null);
                break;
            case 'external_geo_json':
                biSelectPath("Directory1", BISelectPathType.Directory, null);
                break;
            case 'external_shape_file':
                biSelectPath("Directory2", BISelectPathType.Directory, null);
                break;
        }

    })
})
$('input[type=number]').blur(function () {
    compareVal(this);
    setConfig();
})
function biOnSelectedPath(key, path) {
    if (path == null) {
        return;
    } else {
        biQueryFileText(path);
        if (key == "Directory1") {
            $('#external_geo_json').html(path);
        } else if (key == "Directory2") {
            $('#external_shape_file').html(path);
        } else if (key == "OpenFilePath1") {
            $('#external_hdMap').html(path);
        }
    }
    setConfig();
}
function biOnInitEx(config, moduleConfigs) {
    biSetViewSize(365, 398);
    let type = biGetLanguage();
    changeLanguage(type);
    sessionStorage.setItem("language", type);
    configuration = moduleConfigs;
    for (let key in moduleConfigs) {
        let parser = new DOMParser();//创建一个空的xml文档对象
        let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");//把名为modeleConfigs的字符串载入到解析器中
        let countrys = xmlDoc.getElementsByTagName('root');//获取setconfig里面的root标签
        let keys = countrys[0].getAttributeNames();//获取root标签的属性名
        let obj = new Object();
        for (let i = 0; i < keys.length; i++) {
            obj[keys[i]] = countrys[0].getAttribute(keys[i]);
        }
        loadConfig(JSON.stringify(obj));
    }
}

function Base64() {
    // private property
    _keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    // public method for encoding
    this.encode = function (input) {
        var output = "";
        var chr1, chr2, chr3, enc1, enc2, enc3, enc4;
        var i = 0;
        input = _utf8_encode(input);
        while (i < input.length) {
            chr1 = input.charCodeAt(i++);
            chr2 = input.charCodeAt(i++);
            chr3 = input.charCodeAt(i++);
            enc1 = chr1 >> 2;
            enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
            enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);
            enc4 = chr3 & 63;
            if (isNaN(chr2)) {
                enc3 = enc4 = 64;
            } else if (isNaN(chr3)) {
                enc4 = 64;
            }
            output = output +
                _keyStr.charAt(enc1) + _keyStr.charAt(enc2) +
                _keyStr.charAt(enc3) + _keyStr.charAt(enc4);
        }
        return output;
    }

    // public method for decoding
    this.decode = function (input) {
        var output = "";
        var chr1, chr2, chr3;
        var enc1, enc2, enc3, enc4;
        var i = 0;
        input = input.replace(/[^A-Za-z0-9\+\/\=]/g, "");
        while (i < input.length) {
            enc1 = _keyStr.indexOf(input.charAt(i++));
            enc2 = _keyStr.indexOf(input.charAt(i++));
            enc3 = _keyStr.indexOf(input.charAt(i++));
            enc4 = _keyStr.indexOf(input.charAt(i++));
            chr1 = (enc1 << 2) | (enc2 >> 4);
            chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
            chr3 = ((enc3 & 3) << 6) | enc4;
            output = output + String.fromCharCode(chr1);
            if (enc3 != 64) {
                output = output + String.fromCharCode(chr2);
            }
            if (enc4 != 64) {
                output = output + String.fromCharCode(chr3);
            }
        }
        output = _utf8_decode(output);
        return output;
    }

    // private method for UTF-8 encoding
    _utf8_encode = function (string) {
        string = string.replace(/\r\n/g, "\n");
        var utftext = "";
        for (var n = 0; n < string.length; n++) {
            var c = string.charCodeAt(n);
            if (c < 128) {
                utftext += String.fromCharCode(c);
            } else if ((c > 127) && (c < 2048)) {
                utftext += String.fromCharCode((c >> 6) | 192);
                utftext += String.fromCharCode((c & 63) | 128);
            } else {
                utftext += String.fromCharCode((c >> 12) | 224);
                utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                utftext += String.fromCharCode((c & 63) | 128);
            }

        }
        return utftext;
    }

    // private method for UTF-8 decoding
    _utf8_decode = function (utftext) {
        var string = "";
        var i = 0;
        var c = c1 = c2 = 0;
        while (i < utftext.length) {
            c = utftext.charCodeAt(i);
            if (c < 128) {
                string += String.fromCharCode(c);
                i++;
            } else if ((c > 191) && (c < 224)) {
                c2 = utftext.charCodeAt(i + 1);
                string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                i += 2;
            } else {
                c2 = utftext.charCodeAt(i + 1);
                c3 = utftext.charCodeAt(i + 2);
                string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                i += 3;
            }
        }
        return string;
    }
}
