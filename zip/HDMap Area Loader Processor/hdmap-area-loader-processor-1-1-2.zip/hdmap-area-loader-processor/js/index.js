function loadConfig(config) {
  if (config == null) return;
  let obj = JSON.parse(config);
  //select
  $('[name="areaGnssChannel"]').val(obj["areaGnssChannel"]);
  //多选框和单选框
  $('input').each(function () {
    let name = $(this).attr('name');
    if ($(this).attr('type') == 'radio') {
      if (obj[name] == $(this).val()) {
        $(this).attr('checked', true);
        if (name == 'areaMapSource' && $(this).siblings('a').attr('name') != undefined && $(this).is(':checked')) {
          $(this).siblings('a').html(obj['areaMapPath'] == '' ? '(Not configured)' : obj['areaMapPath'])
        }
      }
    } else {
      $(this).val(obj[name]);
      compareVal(this)
    }
  })
}
function compareVal(obj) {
  let step = $(obj).attr('step').length - 2;
  let v = parseFloat($(obj).val());
  if (isNaN(v)) { v = Number($(obj).attr('value')); }
  let min = parseFloat($(obj).attr('min')),
    max = parseFloat($(obj).attr('max'));
  v = v < min ? min : v;
  v = v > max ? max : v;
  let value;
  if (step <= -1) {
    value = v.toFixed(0);
  } else {
    value = v.toFixed(step);
  }
  $(obj).val(value);
}
/**
 * 写配置
 */
function setConfig() {
  let text = "<?xml version=\"1.0\" encoding=\"utf-8\"?><root";
  // checkbox
  $('input').each(function () {
    if ($(this).attr('type') == 'radio') {
      let name = $(this).attr('name');
      if ($(this).is(':checked')) {
        text += " " + name + "=\"" + $('[name=' + name + ']:checked').val() + "\"";
        if (name == 'areaMapSource' && $(this).siblings('a').attr('name') != undefined) {
          text += ' ' + $(this).siblings('a').attr('name') + '=\"' + ($(this).html().indexOf('(') != -1 ? 'null' : $(this).siblings('a').html()) + '\" '
        }
      }
    } else {
      text += ' ' + $(this).attr('name') + '=\"' + $(this).val() + '\"'
    }

  })
  text += ' ' + 'areaGnssChannel' + '=\"' + $('[name=areaGnssChannel]').val() + '\"';
  text += "/>";
  biSetModuleConfig("hdmap-area-loader-processor.aspluginhdmaploadandconvert", text);
}

$('input').change(() => {
  setConfig();
});
$('select').change(() => setConfig())
//点击选择文件夹
$('a').each(function () {
  $(this).click(function () {
    let name = $(this).attr('id');
    switch (name) {
      case 'external_hdMap':
        biSelectPath("OpenFilePath1", BISelectPathType.OpenFile, null);
        break;
      case 'external_geo_json':
        biSelectPath("Directory1", BISelectPathType.Directory, null);
        break;
      case 'external_shape_file':
        biSelectPath("Directory2", BISelectPathType.Directory, null);
        break;
    }

  })
})
$('input[type=number]').blur(function () {
  compareVal(this);
  setConfig();
})
function biOnSelectedPath(key, path) {
  if (path == null) {
    return;
  } else {
    biQueryFileText(path);
    if (key == "Directory1") {
      $('#external_geo_json').html(path);
    } else if (key == "Directory2") {
      $('#external_shape_file').html(path);
    } else if (key == "OpenFilePath1") {
      $('#external_hdMap').html(path);
    }
  }
  setConfig();
}
function biOnInitEx(config, moduleConfigs) {
  biSetViewSize(380, 398);
  $('[language]').each(function () {
    let value = $(this).attr('language');
    $(this).html(biGetLanguage() == 1 ? en[value] : cn[value]);
  });
  for (let key in moduleConfigs) {
    let parser = new DOMParser();//创建一个空的xml文档对象
    let xmlDoc = parser.parseFromString(moduleConfigs[key], "text/xml");//把名为modeleConfigs的字符串载入到解析器中
    let countrys = xmlDoc.getElementsByTagName('root');//获取setconfig里面的root标签
    let keys = countrys[0].getAttributeNames();//获取root标签的属性名
    let obj = new Object();
    for (let i = 0; i < keys.length; i++) {
      obj[keys[i]] = countrys[0].getAttribute(keys[i]);
    }
    loadConfig(JSON.stringify(obj));
  }
}
